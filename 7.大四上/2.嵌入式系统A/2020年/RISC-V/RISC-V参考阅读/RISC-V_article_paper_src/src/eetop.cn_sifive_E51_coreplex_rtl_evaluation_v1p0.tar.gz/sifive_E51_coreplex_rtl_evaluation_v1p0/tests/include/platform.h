// See LICENSE for license details.

#ifndef _SIFIVE_PLATFORM_H
#define _SIFIVE_PLATFORM_H

// Some things missing from the official encoding.h
#define MCAUSE_INT         0x80000000
#define MCAUSE_CAUSE       0x7FFFFFFF

#include "sifive/const.h"
#include "sifive/riscv_test_defaults.h"
#include "sifive/devices/clint.h"
#include "sifive/devices/plic.h"

/****************************************************************************
 * Platform definitions
 *****************************************************************************/

// Memory map
#define CLINT_CTRL_ADDR _AC(0x02000000,UL)
#define ITIM_MEM_ADDR _AC(0x08000000,UL)
#define ITIM_MEM_SIZE _AC(0x2000,UL)
#define MASKROM_MEM_ADDR _AC(0x00001000,UL)
#define MASKROM_MEM_SIZE _AC(0x2000,UL)
#define PERIPHPORT_MEM_ADDR _AC(0x20000000,UL)
#define PERIPHPORT_MEM_SIZE _AC(0x10000000,UL)
#define PLIC_CTRL_ADDR _AC(0x0C000000,UL)
#define RAM_MEM_ADDR _AC(0x80000000,UL)
#define RAM_MEM_SIZE _AC(0x10000,UL)
#define SYSPORT_MEM_ADDR _AC(0x40000000,UL)
#define SYSPORT_MEM_SIZE _AC(0x10000000,UL)
#define TRAPVEC_TABLE_CTRL_ADDR _AC(0x00001010,UL)

// IOF masks


// Interrupt numbers


// Helper functions
#define _REG64(p, i) (*(volatile uint64_t *)((p) + (i)))
#define _REG32(p, i) (*(volatile uint32_t *)((p) + (i)))
#define _REG16(p, i) (*(volatile uint16_t *)((p) + (i)))
// Bulk set bits in `reg` to either 0 or 1.
// E.g. SET_BITS(MY_REG, 0x00000007, 0) would generate MY_REG &= ~0x7
// E.g. SET_BITS(MY_REG, 0x00000007, 1) would generate MY_REG |= 0x7
#define SET_BITS(reg, mask, value) if ((value) == 0) { (reg) &= ~(mask); } else { (reg) |= (mask); }
#define CLINT_REG(offset) _REG32(CLINT_CTRL_ADDR, offset)
#define PLIC_REG(offset) _REG32(PLIC_CTRL_ADDR, offset)
#define TRAPVEC_TABLE_REG(offset) _REG32(TRAPVEC_TABLE_CTRL_ADDR, offset)
#define CLINT_REG64(offset) _REG64(CLINT_CTRL_ADDR, offset)
#define PLIC_REG64(offset) _REG64(PLIC_CTRL_ADDR, offset)
#define TRAPVEC_TABLE_REG64(offset) _REG64(TRAPVEC_TABLE_CTRL_ADDR, offset)

// Misc


#endif /* _SIFIVE_PLATFORM_H */
