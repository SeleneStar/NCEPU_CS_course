//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// See LICENSE.SiFive for license details.

/** This black-boxes verilog machinery for ending simulations
  * based on test results.
  *  
  *  @param codebits Width of error code
  *  @param idx Width of test index
  *  
  */

module TestFinisher #(
  parameter CODEBITS=16,
  parameter IDXBITS=1
) (
                      input [CODEBITS-1:0] code,
                      input [IDXBITS-1:0] idx,
                      input done,
                      input success,
                      input failure,
                      input clock,
                      input reset);
`ifndef SYNTHESIS
  integer stderr = 32'h80000002;
  always @(posedge clock)
  begin
    if (!reset)
    begin
      if (failure)
      begin
        $fdisplay(stderr, "*** FAILED *** test %0d had error code %0d after %0d simulation cycles (in TestFinisher)", idx, code, TestDriver.trace_count);
        $fatal;
      end
      if(done && success)
      begin
        $fdisplay(stderr, "*** PASSED *** all tests passed after %0d simulation cycles (in TestFinisher)", TestDriver.trace_count);
`ifdef TESTBENCH_IN_UVM
        TestDriver.finish_request=1;
`else
        $finish;
`endif
      end
    end
  end
`else
  initial begin end
`endif
endmodule // TestFinisher
