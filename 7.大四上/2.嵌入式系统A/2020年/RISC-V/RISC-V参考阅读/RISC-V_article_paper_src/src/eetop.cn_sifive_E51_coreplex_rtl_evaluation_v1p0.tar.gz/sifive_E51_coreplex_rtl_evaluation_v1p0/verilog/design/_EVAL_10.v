//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_10(
  input  [31:0] _EVAL_0,
  input         _EVAL_1,
  output [3:0]  _EVAL_2,
  input  [2:0]  _EVAL_3,
  output [1:0]  _EVAL_4,
  output        _EVAL_5,
  output [1:0]  _EVAL_6,
  input         _EVAL_7,
  input  [1:0]  _EVAL_8,
  output [3:0]  _EVAL_9,
  output        _EVAL_10,
  output [31:0] _EVAL_11,
  output [1:0]  _EVAL_12,
  input         _EVAL_13,
  input         _EVAL_14,
  input         _EVAL_15,
  output        _EVAL_16,
  output [2:0]  _EVAL_17,
  output        _EVAL_18,
  input  [3:0]  _EVAL_19,
  input         _EVAL_20,
  input  [1:0]  _EVAL_21,
  input  [3:0]  _EVAL_22
);
  wire [1:0] _EVAL_23;
  reg  _EVAL_24 [0:1];
  reg [31:0] _GEN_0;
  wire  _EVAL_24__EVAL_25_data;
  wire  _EVAL_24__EVAL_25_addr;
  wire  _EVAL_24__EVAL_26_data;
  wire  _EVAL_24__EVAL_26_addr;
  wire  _EVAL_24__EVAL_26_mask;
  wire  _EVAL_24__EVAL_26_en;
  wire [1:0] _EVAL_27;
  wire  _EVAL_28;
  reg [31:0] _EVAL_29 [0:1];
  reg [31:0] _GEN_1;
  wire [31:0] _EVAL_29__EVAL_30_data;
  wire  _EVAL_29__EVAL_30_addr;
  wire [31:0] _EVAL_29__EVAL_31_data;
  wire  _EVAL_29__EVAL_31_addr;
  wire  _EVAL_29__EVAL_31_mask;
  wire  _EVAL_29__EVAL_31_en;
  reg [2:0] _EVAL_32 [0:1];
  reg [31:0] _GEN_2;
  wire [2:0] _EVAL_32__EVAL_33_data;
  wire  _EVAL_32__EVAL_33_addr;
  wire [2:0] _EVAL_32__EVAL_34_data;
  wire  _EVAL_32__EVAL_34_addr;
  wire  _EVAL_32__EVAL_34_mask;
  wire  _EVAL_32__EVAL_34_en;
  wire  _EVAL_35;
  wire [1:0] _EVAL_36;
  wire  _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire  _EVAL_40;
  reg  _EVAL_41 [0:1];
  reg [31:0] _GEN_3;
  wire  _EVAL_41__EVAL_42_data;
  wire  _EVAL_41__EVAL_42_addr;
  wire  _EVAL_41__EVAL_43_data;
  wire  _EVAL_41__EVAL_43_addr;
  wire  _EVAL_41__EVAL_43_mask;
  wire  _EVAL_41__EVAL_43_en;
  wire  _EVAL_44;
  wire  _EVAL_45;
  wire  _EVAL_46;
  reg  _EVAL_47;
  reg [31:0] _GEN_4;
  reg  _EVAL_48;
  reg [31:0] _GEN_5;
  wire  _EVAL_49;
  wire [1:0] _EVAL_50;
  reg [3:0] _EVAL_51 [0:1];
  reg [31:0] _GEN_6;
  wire [3:0] _EVAL_51__EVAL_52_data;
  wire  _EVAL_51__EVAL_52_addr;
  wire [3:0] _EVAL_51__EVAL_53_data;
  wire  _EVAL_51__EVAL_53_addr;
  wire  _EVAL_51__EVAL_53_mask;
  wire  _EVAL_51__EVAL_53_en;
  wire  _EVAL_54;
  wire  _EVAL_55;
  reg [1:0] _EVAL_56 [0:1];
  reg [31:0] _GEN_7;
  wire [1:0] _EVAL_56__EVAL_57_data;
  wire  _EVAL_56__EVAL_57_addr;
  wire [1:0] _EVAL_56__EVAL_58_data;
  wire  _EVAL_56__EVAL_58_addr;
  wire  _EVAL_56__EVAL_58_mask;
  wire  _EVAL_56__EVAL_58_en;
  wire  _EVAL_59;
  wire  _EVAL_60;
  wire  _EVAL_61;
  reg [1:0] _EVAL_62 [0:1];
  reg [31:0] _GEN_8;
  wire [1:0] _EVAL_62__EVAL_63_data;
  wire  _EVAL_62__EVAL_63_addr;
  wire [1:0] _EVAL_62__EVAL_64_data;
  wire  _EVAL_62__EVAL_64_addr;
  wire  _EVAL_62__EVAL_64_mask;
  wire  _EVAL_62__EVAL_64_en;
  wire  _EVAL_65;
  reg [3:0] _EVAL_66 [0:1];
  reg [31:0] _GEN_9;
  wire [3:0] _EVAL_66__EVAL_67_data;
  wire  _EVAL_66__EVAL_67_addr;
  wire [3:0] _EVAL_66__EVAL_68_data;
  wire  _EVAL_66__EVAL_68_addr;
  wire  _EVAL_66__EVAL_68_mask;
  wire  _EVAL_66__EVAL_68_en;
  wire [1:0] _EVAL_69;
  reg  _EVAL_70;
  reg [31:0] _GEN_10;
  wire  _EVAL_71;
  wire  _EVAL_72;
  assign _EVAL_2 = _EVAL_51__EVAL_52_data;
  assign _EVAL_4 = _EVAL_62__EVAL_63_data;
  assign _EVAL_5 = _EVAL_41__EVAL_42_data;
  assign _EVAL_6 = _EVAL_36;
  assign _EVAL_9 = _EVAL_66__EVAL_67_data;
  assign _EVAL_10 = _EVAL_54;
  assign _EVAL_11 = _EVAL_29__EVAL_30_data;
  assign _EVAL_12 = _EVAL_56__EVAL_57_data;
  assign _EVAL_16 = _EVAL_39;
  assign _EVAL_17 = _EVAL_32__EVAL_33_data;
  assign _EVAL_18 = _EVAL_24__EVAL_25_data;
  assign _EVAL_23 = $unsigned(_EVAL_50);
  assign _EVAL_24__EVAL_25_addr = _EVAL_47;
  assign _EVAL_24__EVAL_25_data = _EVAL_24[_EVAL_24__EVAL_25_addr];
  assign _EVAL_24__EVAL_26_data = _EVAL_20;
  assign _EVAL_24__EVAL_26_addr = _EVAL_48;
  assign _EVAL_24__EVAL_26_mask = _EVAL_46;
  assign _EVAL_24__EVAL_26_en = _EVAL_46;
  assign _EVAL_27 = _EVAL_48 + 1'h1;
  assign _EVAL_28 = _EVAL_70 == 1'h0;
  assign _EVAL_29__EVAL_30_addr = _EVAL_47;
  assign _EVAL_29__EVAL_30_data = _EVAL_29[_EVAL_29__EVAL_30_addr];
  assign _EVAL_29__EVAL_31_data = _EVAL_0;
  assign _EVAL_29__EVAL_31_addr = _EVAL_48;
  assign _EVAL_29__EVAL_31_mask = _EVAL_46;
  assign _EVAL_29__EVAL_31_en = _EVAL_46;
  assign _EVAL_32__EVAL_33_addr = _EVAL_47;
  assign _EVAL_32__EVAL_33_data = _EVAL_32[_EVAL_32__EVAL_33_addr];
  assign _EVAL_32__EVAL_34_data = _EVAL_3;
  assign _EVAL_32__EVAL_34_addr = _EVAL_48;
  assign _EVAL_32__EVAL_34_mask = _EVAL_46;
  assign _EVAL_32__EVAL_34_en = _EVAL_46;
  assign _EVAL_35 = _EVAL_15 & _EVAL_10;
  assign _EVAL_36 = {_EVAL_60,_EVAL_44};
  assign _EVAL_37 = _EVAL_46 ? _EVAL_49 : _EVAL_48;
  assign _EVAL_38 = _EVAL_35;
  assign _EVAL_39 = _EVAL_71 == 1'h0;
  assign _EVAL_40 = _EVAL_72 & _EVAL_28;
  assign _EVAL_41__EVAL_42_addr = _EVAL_47;
  assign _EVAL_41__EVAL_42_data = _EVAL_41[_EVAL_41__EVAL_42_addr];
  assign _EVAL_41__EVAL_43_data = _EVAL_13;
  assign _EVAL_41__EVAL_43_addr = _EVAL_48;
  assign _EVAL_41__EVAL_43_mask = _EVAL_46;
  assign _EVAL_41__EVAL_43_en = _EVAL_46;
  assign _EVAL_44 = _EVAL_23[0:0];
  assign _EVAL_45 = _EVAL_46 != _EVAL_38;
  assign _EVAL_46 = _EVAL_55;
  assign _EVAL_49 = _EVAL_27[0:0];
  assign _EVAL_50 = _EVAL_48 - _EVAL_47;
  assign _EVAL_51__EVAL_52_addr = _EVAL_47;
  assign _EVAL_51__EVAL_52_data = _EVAL_51[_EVAL_51__EVAL_52_addr];
  assign _EVAL_51__EVAL_53_data = _EVAL_22;
  assign _EVAL_51__EVAL_53_addr = _EVAL_48;
  assign _EVAL_51__EVAL_53_mask = _EVAL_46;
  assign _EVAL_51__EVAL_53_en = _EVAL_46;
  assign _EVAL_54 = _EVAL_40 == 1'h0;
  assign _EVAL_55 = _EVAL_16 & _EVAL_7;
  assign _EVAL_56__EVAL_57_addr = _EVAL_47;
  assign _EVAL_56__EVAL_57_data = _EVAL_56[_EVAL_56__EVAL_57_addr];
  assign _EVAL_56__EVAL_58_data = _EVAL_21;
  assign _EVAL_56__EVAL_58_addr = _EVAL_48;
  assign _EVAL_56__EVAL_58_mask = _EVAL_46;
  assign _EVAL_56__EVAL_58_en = _EVAL_46;
  assign _EVAL_59 = _EVAL_69[0:0];
  assign _EVAL_60 = _EVAL_70 & _EVAL_72;
  assign _EVAL_61 = _EVAL_38 ? _EVAL_59 : _EVAL_47;
  assign _EVAL_62__EVAL_63_addr = _EVAL_47;
  assign _EVAL_62__EVAL_63_data = _EVAL_62[_EVAL_62__EVAL_63_addr];
  assign _EVAL_62__EVAL_64_data = _EVAL_8;
  assign _EVAL_62__EVAL_64_addr = _EVAL_48;
  assign _EVAL_62__EVAL_64_mask = _EVAL_46;
  assign _EVAL_62__EVAL_64_en = _EVAL_46;
  assign _EVAL_65 = _EVAL_45 ? _EVAL_46 : _EVAL_70;
  assign _EVAL_66__EVAL_67_addr = _EVAL_47;
  assign _EVAL_66__EVAL_67_data = _EVAL_66[_EVAL_66__EVAL_67_addr];
  assign _EVAL_66__EVAL_68_data = _EVAL_19;
  assign _EVAL_66__EVAL_68_addr = _EVAL_48;
  assign _EVAL_66__EVAL_68_mask = _EVAL_46;
  assign _EVAL_66__EVAL_68_en = _EVAL_46;
  assign _EVAL_69 = _EVAL_47 + 1'h1;
  assign _EVAL_71 = _EVAL_72 & _EVAL_70;
  assign _EVAL_72 = _EVAL_48 == _EVAL_47;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_24[initvar] = _GEN_0[0:0];
  `endif
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_29[initvar] = _GEN_1[31:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_32[initvar] = _GEN_2[2:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_41[initvar] = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_4[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_5[0:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_51[initvar] = _GEN_6[3:0];
  `endif
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_56[initvar] = _GEN_7[1:0];
  `endif
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_62[initvar] = _GEN_8[1:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_66[initvar] = _GEN_9[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_70 = _GEN_10[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_14) begin
    if(_EVAL_24__EVAL_26_en & _EVAL_24__EVAL_26_mask) begin
      _EVAL_24[_EVAL_24__EVAL_26_addr] <= _EVAL_24__EVAL_26_data;
    end
    if(_EVAL_29__EVAL_31_en & _EVAL_29__EVAL_31_mask) begin
      _EVAL_29[_EVAL_29__EVAL_31_addr] <= _EVAL_29__EVAL_31_data;
    end
    if(_EVAL_32__EVAL_34_en & _EVAL_32__EVAL_34_mask) begin
      _EVAL_32[_EVAL_32__EVAL_34_addr] <= _EVAL_32__EVAL_34_data;
    end
    if(_EVAL_41__EVAL_43_en & _EVAL_41__EVAL_43_mask) begin
      _EVAL_41[_EVAL_41__EVAL_43_addr] <= _EVAL_41__EVAL_43_data;
    end
    if (_EVAL_1) begin
      _EVAL_47 <= 1'h0;
    end else begin
      if (_EVAL_38) begin
        _EVAL_47 <= _EVAL_59;
      end
    end
    if (_EVAL_1) begin
      _EVAL_48 <= 1'h0;
    end else begin
      if (_EVAL_46) begin
        _EVAL_48 <= _EVAL_49;
      end
    end
    if(_EVAL_51__EVAL_53_en & _EVAL_51__EVAL_53_mask) begin
      _EVAL_51[_EVAL_51__EVAL_53_addr] <= _EVAL_51__EVAL_53_data;
    end
    if(_EVAL_56__EVAL_58_en & _EVAL_56__EVAL_58_mask) begin
      _EVAL_56[_EVAL_56__EVAL_58_addr] <= _EVAL_56__EVAL_58_data;
    end
    if(_EVAL_62__EVAL_64_en & _EVAL_62__EVAL_64_mask) begin
      _EVAL_62[_EVAL_62__EVAL_64_addr] <= _EVAL_62__EVAL_64_data;
    end
    if(_EVAL_66__EVAL_68_en & _EVAL_66__EVAL_68_mask) begin
      _EVAL_66[_EVAL_66__EVAL_68_addr] <= _EVAL_66__EVAL_68_data;
    end
    if (_EVAL_1) begin
      _EVAL_70 <= 1'h0;
    end else begin
      if (_EVAL_45) begin
        _EVAL_70 <= _EVAL_46;
      end
    end
  end
endmodule
