//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_103(
  output        _EVAL_0,
  output        _EVAL_1,
  output        _EVAL_2,
  input  [26:0] _EVAL_3,
  input  [26:0] _EVAL_4,
  input         _EVAL_5,
  input         _EVAL_6,
  input         _EVAL_7,
  input         _EVAL_8,
  output [26:0] _EVAL_9,
  input         _EVAL_10,
  output        _EVAL_11
);
  wire  _EVAL_12;
  wire  _EVAL_13;
  wire  _EVAL_15;
  wire [26:0] _EVAL_16;
  wire  _EVAL_18;
  wire  _EVAL_20;
  wire  _EVAL_21;
  wire  _EVAL_22;
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire  _EVAL_27;
  wire [26:0] _EVAL_28;
  reg  _EVAL_29;
  reg [31:0] _GEN_0;
  wire  _EVAL_30;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  assign _EVAL_0 = _EVAL_31;
  assign _EVAL_1 = _EVAL_33;
  assign _EVAL_2 = _EVAL_13;
  assign _EVAL_9 = _EVAL_16;
  assign _EVAL_11 = _EVAL_23;
  assign _EVAL_12 = _EVAL_1 ? _EVAL_8 : _EVAL_6;
  assign _EVAL_13 = _EVAL_12;
  assign _EVAL_15 = _EVAL_24 == 1'h0;
  assign _EVAL_16 = _EVAL_28;
  assign _EVAL_18 = _EVAL_6 ? 1'h0 : 1'h1;
  assign _EVAL_20 = _EVAL_21 ? 1'h1 : _EVAL_18;
  assign _EVAL_21 = _EVAL_8 & _EVAL_22;
  assign _EVAL_22 = 1'h1 > _EVAL_29;
  assign _EVAL_23 = _EVAL_30 & _EVAL_7;
  assign _EVAL_24 = _EVAL_21 | _EVAL_6;
  assign _EVAL_27 = _EVAL_7 & _EVAL_2;
  assign _EVAL_28 = _EVAL_1 ? _EVAL_4 : _EVAL_3;
  assign _EVAL_30 = _EVAL_21 == 1'h0;
  assign _EVAL_31 = _EVAL_32 & _EVAL_7;
  assign _EVAL_32 = _EVAL_22 | _EVAL_15;
  assign _EVAL_33 = _EVAL_20;
  assign _EVAL_34 = _EVAL_27 ? _EVAL_1 : _EVAL_29;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_29 = _GEN_0[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_5) begin
    if (_EVAL_27) begin
      _EVAL_29 <= _EVAL_1;
    end
  end
endmodule
