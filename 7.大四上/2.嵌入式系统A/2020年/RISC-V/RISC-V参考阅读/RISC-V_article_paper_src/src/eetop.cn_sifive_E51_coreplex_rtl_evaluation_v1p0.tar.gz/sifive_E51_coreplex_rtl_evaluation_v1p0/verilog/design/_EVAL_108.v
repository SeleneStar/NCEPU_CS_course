//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_108(
  output        _EVAL_0,
  output        _EVAL_1,
  input  [38:0] _EVAL_2,
  input         _EVAL_3,
  input         _EVAL_4,
  input  [1:0]  _EVAL_5,
  input  [31:0] _EVAL_6,
  input         _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  input         _EVAL_10,
  input         _EVAL_11,
  output        _EVAL_12,
  input         _EVAL_13,
  input  [1:0]  _EVAL_14,
  input         _EVAL_15,
  input  [38:0] _EVAL_16,
  input         _EVAL_17,
  input         _EVAL_18,
  input  [5:0]  _EVAL_19,
  input         _EVAL_20,
  input         _EVAL_21,
  input         _EVAL_22,
  input  [30:0] _EVAL_23,
  input         _EVAL_24,
  output        _EVAL_25,
  input  [7:0]  _EVAL_26,
  input  [1:0]  _EVAL_27,
  input  [1:0]  _EVAL_28,
  input  [1:0]  _EVAL_29,
  input         _EVAL_30,
  input  [1:0]  _EVAL_31,
  input         _EVAL_32,
  input         _EVAL_33,
  input         _EVAL_34,
  input  [3:0]  _EVAL_35,
  input         _EVAL_36,
  input         _EVAL_37,
  input         _EVAL_38,
  input  [39:0] _EVAL_39,
  input         _EVAL_40,
  input         _EVAL_41,
  input  [38:0] _EVAL_42,
  input  [3:0]  _EVAL_43,
  output        _EVAL_44,
  input         _EVAL_45,
  output        _EVAL_46,
  input         _EVAL_47,
  input         _EVAL_48,
  input  [1:0]  _EVAL_49,
  input         _EVAL_50,
  input         _EVAL_51,
  input         _EVAL_52,
  input         _EVAL_53,
  input  [1:0]  _EVAL_54,
  input         _EVAL_55,
  input         _EVAL_56,
  input  [1:0]  _EVAL_57,
  input  [38:0] _EVAL_58,
  input         _EVAL_59,
  input         _EVAL_60,
  input  [1:0]  _EVAL_61,
  input         _EVAL_62,
  input         _EVAL_63,
  input  [5:0]  _EVAL_64,
  input         _EVAL_65,
  input  [39:0] _EVAL_66,
  input         _EVAL_67,
  input         _EVAL_68
);
  wire  _EVAL_69;
  wire  _EVAL_70;
  wire  _EVAL_71;
  wire  _EVAL_72;
  wire  _EVAL_73;
  wire  _EVAL_74;
  wire  _EVAL_75;
  wire  _EVAL_76;
  wire  _EVAL_77;
  wire  _EVAL_78;
  wire  _EVAL_79;
  wire  _EVAL_80;
  wire [1:0] _EVAL_81;
  wire  _EVAL_82;
  wire  _EVAL_83;
  wire  _EVAL_84;
  wire  _EVAL_85;
  wire  _EVAL_86;
  wire [3:0] _EVAL_87;
  wire  _EVAL_88;
  wire [38:0] _EVAL_89;
  wire  _EVAL_90;
  wire [1:0] _EVAL_91;
  wire  _EVAL_92;
  wire  _EVAL_93;
  wire  _EVAL_94;
  wire [3:0] _EVAL_95;
  wire  _EVAL_96;
  wire  _EVAL_97;
  wire [38:0] _EVAL_98;
  wire  _EVAL_99;
  wire  _EVAL_100;
  wire [38:0] _EVAL_101;
  wire  _EVAL_102;
  wire  _EVAL_103;
  wire [38:0] _EVAL_104;
  wire  _EVAL_105;
  wire [38:0] _EVAL_106;
  wire  _EVAL_107;
  wire  _EVAL_108;
  wire  _EVAL_109;
  wire [3:0] _EVAL_110;
  wire  _EVAL_111;
  wire  _EVAL_112;
  wire  _EVAL_113;
  wire [3:0] _EVAL_114;
  wire [1:0] _EVAL_115;
  wire  _EVAL_116;
  wire  _EVAL_117;
  wire  _EVAL_118;
  wire  _EVAL_119;
  wire  _EVAL_120;
  wire [38:0] _EVAL_121;
  wire  _EVAL_122;
  wire  _EVAL_123;
  wire  _EVAL_124;
  wire  _EVAL_125;
  wire  _EVAL_126;
  wire [1:0] _EVAL_127;
  wire [1:0] _EVAL_128;
  wire  _EVAL_129;
  wire [1:0] _EVAL_130;
  wire  _EVAL_131;
  wire  _EVAL_132;
  wire  _EVAL_133;
  wire  _EVAL_134;
  wire  _EVAL_135;
  wire [3:0] _EVAL_136;
  wire  _EVAL_137;
  wire  _EVAL_138;
  wire  _EVAL_139;
  wire [38:0] _EVAL_140;
  wire  _EVAL_141;
  wire  _EVAL_142;
  wire  _EVAL_143;
  wire  _EVAL_144;
  wire  _EVAL_145;
  wire  _EVAL_146;
  wire [1:0] _EVAL_147;
  wire  _EVAL_148;
  wire  _EVAL_149;
  wire  _EVAL_150;
  wire  _EVAL_151;
  wire [3:0] _EVAL_152;
  wire  _EVAL_153;
  wire  _EVAL_154;
  wire  _EVAL_155;
  wire  _EVAL_156;
  wire [38:0] _EVAL_157;
  wire  _EVAL_158;
  wire [1:0] _EVAL_159;
  wire [38:0] _EVAL_160;
  wire  _EVAL_161;
  wire  _EVAL_162;
  wire  _EVAL_163;
  wire [38:0] _EVAL_164;
  wire  _EVAL_165;
  wire  _EVAL_166;
  wire [38:0] _EVAL_167;
  wire  _EVAL_168;
  wire  _EVAL_169;
  wire [38:0] _EVAL_170;
  wire  _EVAL_171;
  assign _EVAL_0 = _EVAL_79;
  assign _EVAL_1 = _EVAL_149;
  assign _EVAL_12 = _EVAL_118;
  assign _EVAL_25 = _EVAL_84;
  assign _EVAL_44 = _EVAL_153;
  assign _EVAL_46 = _EVAL_141;
  assign _EVAL_69 = _EVAL_80 ? _EVAL_30 : 1'h0;
  assign _EVAL_70 = _EVAL_138 ? _EVAL_103 : _EVAL_90;
  assign _EVAL_71 = _EVAL_109 & _EVAL_32;
  assign _EVAL_72 = _EVAL_82 & _EVAL_70;
  assign _EVAL_73 = _EVAL_93 ^ _EVAL_85;
  assign _EVAL_74 = _EVAL_125 | _EVAL_156;
  assign _EVAL_75 = _EVAL_95[0];
  assign _EVAL_76 = _EVAL_168 ? _EVAL_171 : 1'h0;
  assign _EVAL_77 = _EVAL_58[2];
  assign _EVAL_78 = _EVAL_168 ? _EVAL_30 : 1'h0;
  assign _EVAL_79 = _EVAL_158 ? _EVAL_113 : _EVAL_102;
  assign _EVAL_80 = _EVAL_125 & _EVAL_117;
  assign _EVAL_81 = {_EVAL_21,_EVAL_15};
  assign _EVAL_82 = _EVAL_112 & _EVAL_50;
  assign _EVAL_83 = _EVAL_139 & _EVAL_105;
  assign _EVAL_84 = _EVAL_96 ? _EVAL_17 : _EVAL_69;
  assign _EVAL_85 = _EVAL_28[0];
  assign _EVAL_86 = _EVAL_125 & _EVAL_156;
  assign _EVAL_87 = {_EVAL_130,_EVAL_128};
  assign _EVAL_88 = _EVAL_124 & _EVAL_132;
  assign _EVAL_89 = _EVAL_157 | _EVAL_164;
  assign _EVAL_90 = _EVAL_167 == _EVAL_170;
  assign _EVAL_91 = {_EVAL_133,_EVAL_129};
  assign _EVAL_92 = _EVAL_138 ? _EVAL_134 : _EVAL_146;
  assign _EVAL_93 = _EVAL_16 >= _EVAL_58;
  assign _EVAL_94 = _EVAL_108 & _EVAL_131;
  assign _EVAL_95 = _EVAL_87 >> _EVAL_14;
  assign _EVAL_96 = _EVAL_139 & _EVAL_137;
  assign _EVAL_97 = _EVAL_107 ^ _EVAL_85;
  assign _EVAL_98 = _EVAL_121 | _EVAL_164;
  assign _EVAL_99 = _EVAL_140 == _EVAL_89;
  assign _EVAL_100 = _EVAL_80 ? _EVAL_171 : 1'h0;
  assign _EVAL_101 = ~ _EVAL_2;
  assign _EVAL_102 = _EVAL_86 ? _EVAL_171 : 1'h0;
  assign _EVAL_103 = _EVAL_116 ^ _EVAL_124;
  assign _EVAL_104 = _EVAL_106 | _EVAL_160;
  assign _EVAL_105 = _EVAL_119 & _EVAL_92;
  assign _EVAL_106 = ~ _EVAL_16;
  assign _EVAL_107 = _EVAL_42 >= _EVAL_58;
  assign _EVAL_108 = _EVAL_88 & _EVAL_143;
  assign _EVAL_109 = _EVAL_123 & _EVAL_169;
  assign _EVAL_110 = {_EVAL_127,_EVAL_81};
  assign _EVAL_111 = _EVAL_123 & _EVAL_144;
  assign _EVAL_112 = _EVAL_123 & _EVAL_74;
  assign _EVAL_113 = _EVAL_17 == 1'h0;
  assign _EVAL_114 = {_EVAL_91,_EVAL_147};
  assign _EVAL_115 = {_EVAL_88,_EVAL_124};
  assign _EVAL_116 = _EVAL_42 >= _EVAL_2;
  assign _EVAL_117 = _EVAL_151 & _EVAL_145;
  assign _EVAL_118 = _EVAL_83 ? _EVAL_113 : _EVAL_76;
  assign _EVAL_119 = _EVAL_111 & _EVAL_55;
  assign _EVAL_120 = _EVAL_142 & _EVAL_53;
  assign _EVAL_121 = ~ _EVAL_42;
  assign _EVAL_122 = _EVAL_85 & _EVAL_135;
  assign _EVAL_123 = _EVAL_126 & _EVAL_75;
  assign _EVAL_124 = _EVAL_31[0];
  assign _EVAL_125 = _EVAL_38 == 1'h0;
  assign _EVAL_126 = _EVAL_36 == 1'h0;
  assign _EVAL_127 = {_EVAL_22,_EVAL_37};
  assign _EVAL_128 = {_EVAL_8,_EVAL_68};
  assign _EVAL_129 = _EVAL_122 & _EVAL_162;
  assign _EVAL_130 = {_EVAL_51,_EVAL_60};
  assign _EVAL_131 = _EVAL_2[2];
  assign _EVAL_132 = _EVAL_2[0];
  assign _EVAL_133 = _EVAL_129 & _EVAL_77;
  assign _EVAL_134 = _EVAL_166 ^ _EVAL_124;
  assign _EVAL_135 = _EVAL_58[0];
  assign _EVAL_136 = _EVAL_110 >> _EVAL_14;
  assign _EVAL_137 = _EVAL_71 & _EVAL_70;
  assign _EVAL_138 = _EVAL_31[1];
  assign _EVAL_139 = _EVAL_7 == 1'h0;
  assign _EVAL_140 = _EVAL_106 | _EVAL_164;
  assign _EVAL_141 = _EVAL_96 ? _EVAL_113 : _EVAL_100;
  assign _EVAL_142 = _EVAL_126 & _EVAL_148;
  assign _EVAL_143 = _EVAL_2[1];
  assign _EVAL_144 = _EVAL_125 | _EVAL_154;
  assign _EVAL_145 = _EVAL_161 ? _EVAL_97 : _EVAL_150;
  assign _EVAL_146 = _EVAL_104 == _EVAL_170;
  assign _EVAL_147 = {_EVAL_122,_EVAL_85};
  assign _EVAL_148 = _EVAL_136[0];
  assign _EVAL_149 = _EVAL_83 ? _EVAL_17 : _EVAL_78;
  assign _EVAL_150 = _EVAL_98 == _EVAL_89;
  assign _EVAL_151 = _EVAL_142 & _EVAL_20;
  assign _EVAL_152 = {_EVAL_159,_EVAL_115};
  assign _EVAL_153 = _EVAL_158 ? _EVAL_17 : _EVAL_155;
  assign _EVAL_154 = _EVAL_165 & _EVAL_163;
  assign _EVAL_155 = _EVAL_86 ? _EVAL_30 : 1'h0;
  assign _EVAL_156 = _EVAL_120 & _EVAL_145;
  assign _EVAL_157 = ~ _EVAL_58;
  assign _EVAL_158 = _EVAL_139 & _EVAL_72;
  assign _EVAL_159 = {_EVAL_94,_EVAL_108};
  assign _EVAL_160 = {{35'd0}, _EVAL_152};
  assign _EVAL_161 = _EVAL_28[1];
  assign _EVAL_162 = _EVAL_58[1];
  assign _EVAL_163 = _EVAL_161 ? _EVAL_73 : _EVAL_99;
  assign _EVAL_164 = {{35'd0}, _EVAL_114};
  assign _EVAL_165 = _EVAL_142 & _EVAL_47;
  assign _EVAL_166 = _EVAL_16 >= _EVAL_2;
  assign _EVAL_167 = _EVAL_121 | _EVAL_160;
  assign _EVAL_168 = _EVAL_125 & _EVAL_154;
  assign _EVAL_169 = _EVAL_125 | _EVAL_117;
  assign _EVAL_170 = _EVAL_101 | _EVAL_160;
  assign _EVAL_171 = _EVAL_30 == 1'h0;
endmodule
