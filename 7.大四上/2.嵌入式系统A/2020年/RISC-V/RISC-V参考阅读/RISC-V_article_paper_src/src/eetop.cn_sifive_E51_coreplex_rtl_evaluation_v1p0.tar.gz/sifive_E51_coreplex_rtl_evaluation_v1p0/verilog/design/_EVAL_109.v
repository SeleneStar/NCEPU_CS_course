//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_109(
  input  [63:0] _EVAL_0,
  output [63:0] _EVAL_1,
  output        _EVAL_2,
  input         _EVAL_3,
  input  [63:0] _EVAL_4,
  input  [3:0]  _EVAL_5,
  input         _EVAL_6,
  output [63:0] _EVAL_7,
  input         _EVAL_8
);
  wire  _EVAL_9;
  wire [63:0] _EVAL_10;
  wire [63:0] _EVAL_11;
  wire  _EVAL_12;
  wire [63:0] _EVAL_13;
  wire [64:0] _EVAL_14;
  wire [63:0] _EVAL_15;
  wire [55:0] _EVAL_16;
  wire [63:0] _EVAL_17;
  wire  _EVAL_18;
  wire [63:0] _EVAL_19;
  wire [63:0] _EVAL_20;
  wire [63:0] _EVAL_21;
  wire [62:0] _EVAL_22;
  wire [5:0] _EVAL_23;
  wire [63:0] _EVAL_24;
  wire [62:0] _EVAL_25;
  wire  _EVAL_26;
  wire [31:0] _EVAL_27;
  wire [63:0] _EVAL_28;
  wire  _EVAL_29;
  wire [63:0] _EVAL_30;
  wire  _EVAL_31;
  wire [31:0] _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  wire [63:0] _EVAL_35;
  wire [63:0] _EVAL_36;
  wire [63:0] _EVAL_37;
  wire [63:0] _EVAL_38;
  wire [63:0] _EVAL_39;
  wire [55:0] _EVAL_40;
  wire [63:0] _EVAL_41;
  wire [63:0] _EVAL_42;
  wire [63:0] _EVAL_43;
  wire [63:0] _EVAL_44;
  wire [63:0] _EVAL_45;
  wire [63:0] _EVAL_46;
  wire [63:0] _EVAL_47;
  wire [55:0] _EVAL_48;
  wire [31:0] _EVAL_49;
  wire [63:0] _EVAL_50;
  wire [63:0] _EVAL_51;
  wire [63:0] _EVAL_52;
  wire  _EVAL_53;
  wire [64:0] _EVAL_54;
  wire [63:0] _EVAL_55;
  wire [63:0] _EVAL_56;
  wire [63:0] _EVAL_57;
  wire  _EVAL_58;
  wire [63:0] _EVAL_59;
  wire [63:0] _EVAL_60;
  wire [31:0] _EVAL_61;
  wire [63:0] _EVAL_62;
  wire  _EVAL_63;
  wire [63:0] _EVAL_64;
  wire [63:0] _EVAL_65;
  wire [63:0] _EVAL_66;
  wire [63:0] _EVAL_67;
  wire [61:0] _EVAL_68;
  wire [63:0] _EVAL_69;
  wire [63:0] _EVAL_70;
  wire [59:0] _EVAL_71;
  wire [63:0] _EVAL_72;
  wire [63:0] _EVAL_73;
  wire [64:0] _EVAL_74;
  wire [63:0] _EVAL_75;
  wire [63:0] _EVAL_76;
  wire  _EVAL_77;
  wire [63:0] _EVAL_78;
  wire  _EVAL_79;
  wire [63:0] _EVAL_80;
  wire [63:0] _EVAL_81;
  wire  _EVAL_82;
  wire [63:0] _EVAL_83;
  wire [63:0] _EVAL_84;
  wire [63:0] _EVAL_85;
  wire [63:0] _EVAL_86;
  wire [63:0] _EVAL_87;
  wire [63:0] _EVAL_88;
  wire [31:0] _EVAL_89;
  wire  _EVAL_90;
  wire  _EVAL_91;
  wire [63:0] _EVAL_92;
  wire [63:0] _EVAL_93;
  wire [31:0] _EVAL_94;
  wire [64:0] _EVAL_95;
  wire [63:0] _EVAL_96;
  wire [31:0] _EVAL_97;
  wire [63:0] _EVAL_98;
  wire [63:0] _EVAL_99;
  wire  _EVAL_100;
  wire [59:0] _EVAL_101;
  wire  _EVAL_102;
  wire  _EVAL_103;
  wire [47:0] _EVAL_104;
  wire  _EVAL_105;
  wire [63:0] _EVAL_106;
  wire  _EVAL_107;
  wire [62:0] _EVAL_108;
  wire  _EVAL_109;
  wire [63:0] _EVAL_110;
  wire [63:0] _EVAL_111;
  wire [61:0] _EVAL_112;
  wire  _EVAL_113;
  wire [63:0] _EVAL_114;
  wire  _EVAL_115;
  wire [63:0] _EVAL_116;
  wire [63:0] _EVAL_117;
  wire [63:0] _EVAL_118;
  wire [61:0] _EVAL_119;
  wire  _EVAL_120;
  wire [63:0] _EVAL_121;
  wire [63:0] _EVAL_122;
  wire [63:0] _EVAL_123;
  wire [63:0] _EVAL_124;
  wire [47:0] _EVAL_125;
  wire [63:0] _EVAL_126;
  wire [63:0] _EVAL_127;
  wire  _EVAL_128;
  wire  _EVAL_129;
  wire  _EVAL_130;
  wire [63:0] _EVAL_131;
  wire [63:0] _EVAL_132;
  wire [63:0] _EVAL_133;
  wire [63:0] _EVAL_134;
  wire  _EVAL_135;
  wire  _EVAL_136;
  wire [55:0] _EVAL_137;
  wire [63:0] _EVAL_138;
  wire [63:0] _EVAL_139;
  wire [31:0] _EVAL_140;
  wire  _EVAL_141;
  wire [31:0] _EVAL_142;
  wire [63:0] _EVAL_143;
  wire [59:0] _EVAL_144;
  wire  _EVAL_145;
  wire [63:0] _EVAL_146;
  wire  _EVAL_147;
  wire [63:0] _EVAL_148;
  wire [63:0] _EVAL_149;
  wire [63:0] _EVAL_150;
  wire  _EVAL_151;
  wire [63:0] _EVAL_152;
  wire [63:0] _EVAL_153;
  wire [64:0] _EVAL_154;
  wire  _EVAL_155;
  wire [63:0] _EVAL_156;
  wire [61:0] _EVAL_157;
  wire [4:0] _EVAL_158;
  wire [59:0] _EVAL_159;
  wire [63:0] _EVAL_160;
  wire [63:0] _EVAL_161;
  wire [31:0] _EVAL_162;
  wire  _EVAL_163;
  wire [63:0] _EVAL_164;
  wire  _EVAL_165;
  wire [63:0] _EVAL_166;
  wire [62:0] _EVAL_167;
  wire  _EVAL_168;
  wire  _EVAL_169;
  wire [63:0] _EVAL_170;
  wire [63:0] _EVAL_171;
  wire [47:0] _EVAL_172;
  wire [63:0] _EVAL_173;
  wire [63:0] _EVAL_174;
  wire [47:0] _EVAL_175;
  wire [63:0] _EVAL_176;
  assign _EVAL_1 = _EVAL_92;
  assign _EVAL_2 = _EVAL_151;
  assign _EVAL_7 = _EVAL_152;
  assign _EVAL_9 = _EVAL_103 == _EVAL_128;
  assign _EVAL_10 = _EVAL_130 ? _EVAL_99 : _EVAL_0;
  assign _EVAL_11 = _EVAL_65 | _EVAL_30;
  assign _EVAL_12 = _EVAL_4[31];
  assign _EVAL_13 = _EVAL_174 & 64'hf0f0f0f0f0f0f0f;
  assign _EVAL_14 = _EVAL_28 + _EVAL_76;
  assign _EVAL_15 = _EVAL_115 ? _EVAL_17 : 64'h0;
  assign _EVAL_16 = _EVAL_164[63:8];
  assign _EVAL_17 = _EVAL_154[63:0];
  assign _EVAL_18 = _EVAL_5 == 4'h1;
  assign _EVAL_19 = _EVAL_123 & 64'hffff0000ffff0000;
  assign _EVAL_20 = {{32'd0}, _EVAL_49};
  assign _EVAL_21 = {{16'd0}, _EVAL_175};
  assign _EVAL_22 = _EVAL_11[63:1];
  assign _EVAL_23 = {_EVAL_91,_EVAL_158};
  assign _EVAL_24 = _EVAL_86 << 4;
  assign _EVAL_25 = _EVAL_52[62:0];
  assign _EVAL_26 = _EVAL_130 & _EVAL_12;
  assign _EVAL_27 = _EVAL_17[63:32];
  assign _EVAL_28 = _EVAL_54[63:0];
  assign _EVAL_29 = _EVAL_90 & _EVAL_2;
  assign _EVAL_30 = _EVAL_73 & 64'hcccccccccccccccc;
  assign _EVAL_31 = _EVAL_9 ? _EVAL_105 : _EVAL_165;
  assign _EVAL_32 = _EVAL_122[31:0];
  assign _EVAL_33 = _EVAL_5 == 4'h3;
  assign _EVAL_34 = _EVAL_5 == 4'h4;
  assign _EVAL_35 = _EVAL_171 << 8;
  assign _EVAL_36 = _EVAL_24 & 64'hf0f0f0f0f0f0f0f0;
  assign _EVAL_37 = {{2'd0}, _EVAL_157};
  assign _EVAL_38 = _EVAL_106 & 64'hffffffff00000000;
  assign _EVAL_39 = _EVAL_20 | _EVAL_38;
  assign _EVAL_40 = _EVAL_164[55:0];
  assign _EVAL_41 = _EVAL_57 & 64'hff00ff00ff00ff00;
  assign _EVAL_42 = {_EVAL_162,_EVAL_97};
  assign _EVAL_43 = _EVAL_166 & 64'haaaaaaaaaaaaaaaa;
  assign _EVAL_44 = {{2'd0}, _EVAL_119};
  assign _EVAL_45 = _EVAL_169 ? _EVAL_1 : _EVAL_114;
  assign _EVAL_46 = {{32'd0}, _EVAL_27};
  assign _EVAL_47 = {{63'd0}, _EVAL_29};
  assign _EVAL_48 = _EVAL_121[55:0];
  assign _EVAL_49 = _EVAL_122[63:32];
  assign _EVAL_50 = _EVAL_127 | _EVAL_85;
  assign _EVAL_51 = _EVAL_69 & 64'hff00ff00ff00ff;
  assign _EVAL_52 = _EVAL_173 | _EVAL_78;
  assign _EVAL_53 = _EVAL_130 == 1'h0;
  assign _EVAL_54 = _EVAL_4 + _EVAL_10;
  assign _EVAL_55 = _EVAL_4 ^ _EVAL_10;
  assign _EVAL_56 = _EVAL_46 | _EVAL_70;
  assign _EVAL_57 = _EVAL_149 << 8;
  assign _EVAL_58 = _EVAL_5 == 4'ha;
  assign _EVAL_59 = {{2'd0}, _EVAL_68};
  assign _EVAL_60 = _EVAL_51 | _EVAL_93;
  assign _EVAL_61 = _EVAL_4[63:32];
  assign _EVAL_62 = _EVAL_146 | _EVAL_153;
  assign _EVAL_63 = _EVAL_5 == 4'h7;
  assign _EVAL_64 = {{4'd0}, _EVAL_101};
  assign _EVAL_65 = _EVAL_161 & 64'h3333333333333333;
  assign _EVAL_66 = {{1'd0}, _EVAL_25};
  assign _EVAL_67 = _EVAL_115 ? _EVAL_122 : _EVAL_50;
  assign _EVAL_68 = _EVAL_176[61:0];
  assign _EVAL_69 = {{8'd0}, _EVAL_16};
  assign _EVAL_70 = _EVAL_134 & 64'hffffffff00000000;
  assign _EVAL_71 = _EVAL_75[63:4];
  assign _EVAL_72 = {{1'd0}, _EVAL_167};
  assign _EVAL_73 = _EVAL_44 << 2;
  assign _EVAL_74 = $signed(_EVAL_95);
  assign _EVAL_75 = _EVAL_131 | _EVAL_41;
  assign _EVAL_76 = {{63'd0}, _EVAL_130};
  assign _EVAL_77 = _EVAL_109 | _EVAL_63;
  assign _EVAL_78 = _EVAL_80 & 64'hcccccccccccccccc;
  assign _EVAL_79 = _EVAL_53 ? _EVAL_147 : _EVAL_31;
  assign _EVAL_80 = _EVAL_59 << 2;
  assign _EVAL_81 = _EVAL_88 & 64'hf0f0f0f0f0f0f0f;
  assign _EVAL_82 = _EVAL_5 == 4'h2;
  assign _EVAL_83 = _EVAL_138 & 64'hffff0000ffff;
  assign _EVAL_84 = _EVAL_13 | _EVAL_36;
  assign _EVAL_85 = _EVAL_118 & 64'haaaaaaaaaaaaaaaa;
  assign _EVAL_86 = {{4'd0}, _EVAL_144};
  assign _EVAL_87 = _EVAL_126 & 64'hffff0000ffff;
  assign _EVAL_88 = {{4'd0}, _EVAL_159};
  assign _EVAL_89 = _EVAL_17[31:0];
  assign _EVAL_90 = _EVAL_100 | _EVAL_163;
  assign _EVAL_91 = _EVAL_102 & _EVAL_6;
  assign _EVAL_92 = _EVAL_14[63:0];
  assign _EVAL_93 = _EVAL_35 & 64'hff00ff00ff00ff00;
  assign _EVAL_94 = _EVAL_26 ? 32'hffffffff : 32'h0;
  assign _EVAL_95 = {_EVAL_107,_EVAL_67};
  assign _EVAL_96 = {{32'd0}, _EVAL_32};
  assign _EVAL_97 = _EVAL_45[31:0];
  assign _EVAL_98 = {{8'd0}, _EVAL_137};
  assign _EVAL_99 = ~ _EVAL_0;
  assign _EVAL_100 = _EVAL_82 | _EVAL_33;
  assign _EVAL_101 = _EVAL_60[59:0];
  assign _EVAL_102 = _EVAL_0[5];
  assign _EVAL_103 = _EVAL_4[63];
  assign _EVAL_104 = _EVAL_56[47:0];
  assign _EVAL_105 = _EVAL_1[63];
  assign _EVAL_106 = _EVAL_96 << 32;
  assign _EVAL_107 = _EVAL_130 & _EVAL_120;
  assign _EVAL_108 = _EVAL_11[62:0];
  assign _EVAL_109 = _EVAL_5 == 4'h6;
  assign _EVAL_110 = {{1'd0}, _EVAL_22};
  assign _EVAL_111 = _EVAL_64 << 4;
  assign _EVAL_112 = _EVAL_84[63:2];
  assign _EVAL_113 = _EVAL_6 == 1'h0;
  assign _EVAL_114 = _EVAL_160 | _EVAL_150;
  assign _EVAL_115 = _EVAL_141 | _EVAL_168;
  assign _EVAL_116 = _EVAL_4 & _EVAL_0;
  assign _EVAL_117 = _EVAL_18 ? _EVAL_156 : 64'h0;
  assign _EVAL_118 = _EVAL_66 << 1;
  assign _EVAL_119 = _EVAL_84[61:0];
  assign _EVAL_120 = _EVAL_67[63];
  assign _EVAL_121 = _EVAL_87 | _EVAL_19;
  assign _EVAL_122 = {_EVAL_142,_EVAL_140};
  assign _EVAL_123 = _EVAL_139 << 16;
  assign _EVAL_124 = _EVAL_143 & 64'hffff0000ffff0000;
  assign _EVAL_125 = _EVAL_56[63:16];
  assign _EVAL_126 = {{16'd0}, _EVAL_125};
  assign _EVAL_127 = _EVAL_72 & 64'h5555555555555555;
  assign _EVAL_128 = _EVAL_0[63];
  assign _EVAL_129 = _EVAL_5[0];
  assign _EVAL_130 = _EVAL_5[3];
  assign _EVAL_131 = _EVAL_98 & 64'hff00ff00ff00ff;
  assign _EVAL_132 = {{32'd0}, _EVAL_89};
  assign _EVAL_133 = _EVAL_111 & 64'hf0f0f0f0f0f0f0f0;
  assign _EVAL_134 = _EVAL_132 << 32;
  assign _EVAL_135 = _EVAL_5 == 4'h0;
  assign _EVAL_136 = _EVAL_45[31];
  assign _EVAL_137 = _EVAL_121[63:8];
  assign _EVAL_138 = {{16'd0}, _EVAL_172};
  assign _EVAL_139 = {{16'd0}, _EVAL_104};
  assign _EVAL_140 = _EVAL_4[31:0];
  assign _EVAL_141 = _EVAL_5 == 4'h5;
  assign _EVAL_142 = _EVAL_6 ? _EVAL_61 : _EVAL_94;
  assign _EVAL_143 = _EVAL_21 << 16;
  assign _EVAL_144 = _EVAL_75[59:0];
  assign _EVAL_145 = _EVAL_34 | _EVAL_109;
  assign _EVAL_146 = _EVAL_145 ? _EVAL_55 : 64'h0;
  assign _EVAL_147 = _EVAL_55 == 64'h0;
  assign _EVAL_148 = _EVAL_110 & 64'h5555555555555555;
  assign _EVAL_149 = {{8'd0}, _EVAL_48};
  assign _EVAL_150 = _EVAL_15 | _EVAL_117;
  assign _EVAL_151 = _EVAL_129 ^ _EVAL_79;
  assign _EVAL_152 = _EVAL_113 ? _EVAL_42 : _EVAL_45;
  assign _EVAL_153 = _EVAL_77 ? _EVAL_116 : 64'h0;
  assign _EVAL_154 = $signed(_EVAL_74) >>> _EVAL_23;
  assign _EVAL_155 = _EVAL_5[1];
  assign _EVAL_156 = _EVAL_148 | _EVAL_43;
  assign _EVAL_157 = _EVAL_176[63:2];
  assign _EVAL_158 = _EVAL_0[4:0];
  assign _EVAL_159 = _EVAL_60[63:4];
  assign _EVAL_160 = _EVAL_47 | _EVAL_62;
  assign _EVAL_161 = {{2'd0}, _EVAL_112};
  assign _EVAL_162 = _EVAL_136 ? 32'hffffffff : 32'h0;
  assign _EVAL_163 = _EVAL_5 >= 4'hc;
  assign _EVAL_164 = _EVAL_83 | _EVAL_124;
  assign _EVAL_165 = _EVAL_155 ? _EVAL_128 : _EVAL_103;
  assign _EVAL_166 = _EVAL_170 << 1;
  assign _EVAL_167 = _EVAL_52[63:1];
  assign _EVAL_168 = _EVAL_5 == 4'hb;
  assign _EVAL_169 = _EVAL_135 | _EVAL_58;
  assign _EVAL_170 = {{1'd0}, _EVAL_108};
  assign _EVAL_171 = {{8'd0}, _EVAL_40};
  assign _EVAL_172 = _EVAL_39[63:16];
  assign _EVAL_173 = _EVAL_37 & 64'h3333333333333333;
  assign _EVAL_174 = {{4'd0}, _EVAL_71};
  assign _EVAL_175 = _EVAL_39[47:0];
  assign _EVAL_176 = _EVAL_81 | _EVAL_133;
endmodule
