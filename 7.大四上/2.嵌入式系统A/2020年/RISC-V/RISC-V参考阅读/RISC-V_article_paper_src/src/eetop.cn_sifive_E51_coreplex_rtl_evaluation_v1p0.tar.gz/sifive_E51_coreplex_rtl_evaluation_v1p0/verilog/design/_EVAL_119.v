//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_119(
  input         _EVAL_0,
  input  [2:0]  _EVAL_1,
  input  [63:0] _EVAL_2,
  input  [1:0]  _EVAL_3,
  output [2:0]  _EVAL_4,
  input  [2:0]  _EVAL_5,
  input         _EVAL_6,
  input  [7:0]  _EVAL_7,
  output [2:0]  _EVAL_8,
  input  [2:0]  _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  output [31:0] _EVAL_12,
  output [63:0] _EVAL_13,
  output [3:0]  _EVAL_14,
  input         _EVAL_15,
  output [7:0]  _EVAL_16,
  output [2:0]  _EVAL_17,
  output        _EVAL_18,
  output [1:0]  _EVAL_19,
  input  [3:0]  _EVAL_20,
  input  [31:0] _EVAL_21
);
  wire [7:0] _EVAL_24;
  wire  _EVAL_25;
  wire [2:0] _EVAL_27;
  wire [2:0] _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  wire [1:0] _EVAL_31;
  wire [3:0] _EVAL_32;
  wire [1:0] _EVAL_33;
  wire  _EVAL_34;
  wire [31:0] _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  wire [63:0] _EVAL_38;
  wire  _EVAL_39;
  wire [2:0] _EVAL_40;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_44;
  reg [1:0] _EVAL_45;
  reg [31:0] _GEN_0;
  assign _EVAL_4 = _EVAL_40;
  assign _EVAL_8 = _EVAL_28;
  assign _EVAL_10 = _EVAL_41;
  assign _EVAL_12 = _EVAL_35;
  assign _EVAL_13 = _EVAL_38;
  assign _EVAL_14 = _EVAL_32;
  assign _EVAL_16 = _EVAL_24;
  assign _EVAL_17 = _EVAL_27;
  assign _EVAL_18 = _EVAL_25;
  assign _EVAL_19 = _EVAL_45;
  assign _EVAL_24 = _EVAL_7;
  assign _EVAL_25 = _EVAL_11;
  assign _EVAL_27 = _EVAL_9;
  assign _EVAL_28 = _EVAL_1;
  assign _EVAL_29 = _EVAL_45 == _EVAL_3;
  assign _EVAL_30 = _EVAL_42 != _EVAL_34;
  assign _EVAL_31 = {_EVAL_37,_EVAL_44};
  assign _EVAL_32 = _EVAL_20;
  assign _EVAL_33 = _EVAL_39 ? _EVAL_31 : _EVAL_45;
  assign _EVAL_34 = _EVAL_3[0];
  assign _EVAL_35 = _EVAL_21;
  assign _EVAL_36 = _EVAL_29 ? _EVAL_6 : _EVAL_30;
  assign _EVAL_37 = _EVAL_45[0];
  assign _EVAL_38 = _EVAL_2;
  assign _EVAL_39 = _EVAL_25 & _EVAL_41;
  assign _EVAL_40 = _EVAL_5;
  assign _EVAL_41 = _EVAL_36;
  assign _EVAL_42 = _EVAL_45[1];
  assign _EVAL_44 = _EVAL_42 == 1'h0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_45 = _GEN_0[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_15) begin
    if (_EVAL_0) begin
      _EVAL_45 <= 2'h0;
    end else begin
      if (_EVAL_39) begin
        _EVAL_45 <= _EVAL_31;
      end
    end
  end
endmodule
