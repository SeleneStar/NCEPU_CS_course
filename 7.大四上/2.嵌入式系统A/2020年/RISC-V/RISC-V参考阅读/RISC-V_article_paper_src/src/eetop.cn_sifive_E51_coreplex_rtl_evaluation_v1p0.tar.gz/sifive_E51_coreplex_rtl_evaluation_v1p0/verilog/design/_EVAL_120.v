//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_120(
  output [2:0]  _EVAL_0,
  input         _EVAL_1,
  input  [2:0]  _EVAL_2,
  output        _EVAL_3,
  output [1:0]  _EVAL_4,
  input  [2:0]  _EVAL_5,
  output [2:0]  _EVAL_6,
  input  [3:0]  _EVAL_7,
  output [63:0] _EVAL_8,
  input         _EVAL_9,
  input         _EVAL_10,
  output        _EVAL_11,
  input  [1:0]  _EVAL_12,
  input         _EVAL_13,
  input  [1:0]  _EVAL_14,
  output        _EVAL_15,
  output [1:0]  _EVAL_16,
  input  [2:0]  _EVAL_17,
  input         _EVAL_18,
  input  [63:0] _EVAL_19,
  output [2:0]  _EVAL_20,
  output [3:0]  _EVAL_21,
  input         _EVAL_22,
  output        _EVAL_23
);
  reg [3:0] _EVAL_24;
  reg [31:0] _GEN_0;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire [1:0] _EVAL_28;
  wire [1:0] _EVAL_29;
  reg  _EVAL_30;
  reg [31:0] _GEN_1;
  reg [2:0] _EVAL_31;
  reg [31:0] _GEN_2;
  wire [3:0] _EVAL_32;
  wire  _EVAL_34;
  wire  _EVAL_36;
  wire  _EVAL_37;
  wire  _EVAL_38;
  wire [1:0] _EVAL_39;
  wire  _EVAL_40;
  reg [2:0] _EVAL_41;
  reg [31:0] _GEN_3;
  reg [1:0] _EVAL_42;
  reg [31:0] _GEN_4;
  wire [2:0] _EVAL_43;
  wire [63:0] _EVAL_44;
  reg [63:0] _EVAL_45;
  reg [63:0] _GEN_5;
  reg [2:0] _EVAL_47;
  reg [31:0] _GEN_6;
  reg  _EVAL_48;
  reg [31:0] _GEN_7;
  wire [2:0] _EVAL_50;
  wire [2:0] _EVAL_51;
  reg [1:0] _EVAL_52;
  reg [31:0] _GEN_8;
  wire  _EVAL_53;
  wire  _EVAL_54;
  assign _EVAL_0 = _EVAL_43;
  assign _EVAL_3 = _EVAL_9;
  assign _EVAL_4 = _EVAL_42;
  assign _EVAL_6 = _EVAL_50;
  assign _EVAL_8 = _EVAL_44;
  assign _EVAL_11 = _EVAL_37;
  assign _EVAL_15 = _EVAL_38;
  assign _EVAL_16 = _EVAL_28;
  assign _EVAL_20 = _EVAL_51;
  assign _EVAL_21 = _EVAL_32;
  assign _EVAL_23 = _EVAL_27;
  assign _EVAL_25 = _EVAL_34 == 1'h0;
  assign _EVAL_26 = _EVAL_34 != _EVAL_53;
  assign _EVAL_27 = _EVAL_40 ? _EVAL_1 : _EVAL_48;
  assign _EVAL_28 = _EVAL_40 ? _EVAL_12 : _EVAL_52;
  assign _EVAL_29 = {_EVAL_54,_EVAL_25};
  assign _EVAL_32 = _EVAL_40 ? _EVAL_7 : _EVAL_24;
  assign _EVAL_34 = _EVAL_42[1];
  assign _EVAL_36 = _EVAL_15 & _EVAL_9;
  assign _EVAL_37 = _EVAL_40 ? _EVAL_10 : _EVAL_30;
  assign _EVAL_38 = _EVAL_40 ? _EVAL_22 : _EVAL_26;
  assign _EVAL_39 = _EVAL_36 ? _EVAL_29 : _EVAL_42;
  assign _EVAL_40 = _EVAL_42 == _EVAL_14;
  assign _EVAL_43 = _EVAL_40 ? _EVAL_5 : _EVAL_31;
  assign _EVAL_44 = _EVAL_40 ? _EVAL_19 : _EVAL_45;
  assign _EVAL_50 = _EVAL_40 ? _EVAL_17 : _EVAL_41;
  assign _EVAL_51 = _EVAL_40 ? _EVAL_2 : _EVAL_47;
  assign _EVAL_53 = _EVAL_14[0];
  assign _EVAL_54 = _EVAL_42[0];
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_24 = _GEN_0[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_30 = _GEN_1[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_31 = _GEN_2[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_41 = _GEN_3[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_42 = _GEN_4[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_45 = _GEN_5[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_6[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_52 = _GEN_8[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_13) begin
    if (_EVAL_40) begin
      _EVAL_24 <= _EVAL_7;
    end
    if (_EVAL_40) begin
      _EVAL_30 <= _EVAL_10;
    end
    if (_EVAL_40) begin
      _EVAL_31 <= _EVAL_5;
    end
    if (_EVAL_40) begin
      _EVAL_41 <= _EVAL_17;
    end
    if (_EVAL_18) begin
      _EVAL_42 <= 2'h0;
    end else begin
      if (_EVAL_36) begin
        _EVAL_42 <= _EVAL_29;
      end
    end
    if (_EVAL_40) begin
      _EVAL_45 <= _EVAL_19;
    end
    if (_EVAL_40) begin
      _EVAL_47 <= _EVAL_2;
    end
    if (_EVAL_40) begin
      _EVAL_48 <= _EVAL_1;
    end
    if (_EVAL_40) begin
      _EVAL_52 <= _EVAL_12;
    end
  end
endmodule
