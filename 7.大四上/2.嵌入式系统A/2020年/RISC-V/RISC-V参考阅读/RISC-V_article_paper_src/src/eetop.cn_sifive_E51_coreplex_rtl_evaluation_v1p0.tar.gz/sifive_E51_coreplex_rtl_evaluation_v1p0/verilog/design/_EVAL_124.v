//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_124(
  input   _EVAL_0,
  input   _EVAL_1,
  input   _EVAL_2,
  output  _EVAL_3,
  output  _EVAL_4,
  input   _EVAL_5,
  input   _EVAL_6,
  output  _EVAL_7
);
  reg  _EVAL_8;
  reg [31:0] _GEN_0;
  reg  _EVAL_9;
  reg [31:0] _GEN_1;
  reg  _EVAL_10;
  reg [31:0] _GEN_2;
  reg  _EVAL_11;
  reg [31:0] _GEN_3;
  reg  _EVAL_12;
  reg [31:0] _GEN_4;
  reg  _EVAL_13;
  reg [31:0] _GEN_5;
  assign _EVAL_3 = _EVAL_9;
  assign _EVAL_4 = _EVAL_8;
  assign _EVAL_7 = _EVAL_11;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_8 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_9 = _GEN_1[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_10 = _GEN_2[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_11 = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_12 = _GEN_4[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_13 = _GEN_5[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_5) begin
    _EVAL_8 <= _EVAL_10;
    _EVAL_9 <= _EVAL_12;
    _EVAL_10 <= _EVAL_6;
    _EVAL_11 <= _EVAL_13;
    _EVAL_12 <= _EVAL_1;
    _EVAL_13 <= _EVAL_2;
  end
endmodule
