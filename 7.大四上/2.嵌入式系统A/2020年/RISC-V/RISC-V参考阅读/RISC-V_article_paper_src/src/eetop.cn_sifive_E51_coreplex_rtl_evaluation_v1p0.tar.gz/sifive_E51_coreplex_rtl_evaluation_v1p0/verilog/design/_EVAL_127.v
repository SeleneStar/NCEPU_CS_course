//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_127(
  input         _EVAL_0,
  output        _EVAL_1,
  output [63:0] _EVAL_2,
  output [7:0]  _EVAL_3,
  input  [2:0]  _EVAL_4,
  input  [31:0] _EVAL_5,
  input  [3:0]  _EVAL_6,
  input         _EVAL_7,
  input  [7:0]  _EVAL_8,
  output [31:0] _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  output [2:0]  _EVAL_12,
  output [1:0]  _EVAL_13,
  input  [2:0]  _EVAL_14,
  input  [63:0] _EVAL_15,
  input  [2:0]  _EVAL_16,
  output [3:0]  _EVAL_17,
  output [2:0]  _EVAL_18,
  output [2:0]  _EVAL_19,
  input         _EVAL_20
);
  wire  _EVAL_21;
  wire [1:0] _EVAL_22;
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire  _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  reg [7:0] _EVAL_31 [0:1];
  reg [31:0] _GEN_0;
  wire [7:0] _EVAL_31__EVAL_32_data;
  wire  _EVAL_31__EVAL_32_addr;
  wire [7:0] _EVAL_31__EVAL_33_data;
  wire  _EVAL_31__EVAL_33_addr;
  wire  _EVAL_31__EVAL_33_mask;
  wire  _EVAL_31__EVAL_33_en;
  wire  _EVAL_34;
  wire  _EVAL_35;
  reg  _EVAL_36;
  reg [31:0] _GEN_1;
  reg [3:0] _EVAL_37 [0:1];
  reg [31:0] _GEN_2;
  wire [3:0] _EVAL_37__EVAL_38_data;
  wire  _EVAL_37__EVAL_38_addr;
  wire [3:0] _EVAL_37__EVAL_39_data;
  wire  _EVAL_37__EVAL_39_addr;
  wire  _EVAL_37__EVAL_39_mask;
  wire  _EVAL_37__EVAL_39_en;
  wire  _EVAL_40;
  reg [2:0] _EVAL_41 [0:1];
  reg [31:0] _GEN_3;
  wire [2:0] _EVAL_41__EVAL_42_data;
  wire  _EVAL_41__EVAL_42_addr;
  wire [2:0] _EVAL_41__EVAL_43_data;
  wire  _EVAL_41__EVAL_43_addr;
  wire  _EVAL_41__EVAL_43_mask;
  wire  _EVAL_41__EVAL_43_en;
  wire [1:0] _EVAL_44;
  reg [31:0] _EVAL_45 [0:1];
  reg [31:0] _GEN_4;
  wire [31:0] _EVAL_45__EVAL_46_data;
  wire  _EVAL_45__EVAL_46_addr;
  wire [31:0] _EVAL_45__EVAL_47_data;
  wire  _EVAL_45__EVAL_47_addr;
  wire  _EVAL_45__EVAL_47_mask;
  wire  _EVAL_45__EVAL_47_en;
  wire [1:0] _EVAL_48;
  reg [63:0] _EVAL_49 [0:1];
  reg [63:0] _GEN_5;
  wire [63:0] _EVAL_49__EVAL_50_data;
  wire  _EVAL_49__EVAL_50_addr;
  wire [63:0] _EVAL_49__EVAL_51_data;
  wire  _EVAL_49__EVAL_51_addr;
  wire  _EVAL_49__EVAL_51_mask;
  wire  _EVAL_49__EVAL_51_en;
  reg [2:0] _EVAL_52 [0:1];
  reg [31:0] _GEN_6;
  wire [2:0] _EVAL_52__EVAL_53_data;
  wire  _EVAL_52__EVAL_53_addr;
  wire [2:0] _EVAL_52__EVAL_54_data;
  wire  _EVAL_52__EVAL_54_addr;
  wire  _EVAL_52__EVAL_54_mask;
  wire  _EVAL_52__EVAL_54_en;
  reg  _EVAL_55;
  reg [31:0] _GEN_7;
  reg  _EVAL_56;
  reg [31:0] _GEN_8;
  wire [1:0] _EVAL_57;
  wire  _EVAL_58;
  reg [2:0] _EVAL_59 [0:1];
  reg [31:0] _GEN_9;
  wire [2:0] _EVAL_59__EVAL_60_data;
  wire  _EVAL_59__EVAL_60_addr;
  wire [2:0] _EVAL_59__EVAL_61_data;
  wire  _EVAL_59__EVAL_61_addr;
  wire  _EVAL_59__EVAL_61_mask;
  wire  _EVAL_59__EVAL_61_en;
  wire  _EVAL_62;
  wire [1:0] _EVAL_63;
  wire  _EVAL_64;
  wire  _EVAL_65;
  wire  _EVAL_66;
  wire  _EVAL_67;
  assign _EVAL_1 = _EVAL_62;
  assign _EVAL_2 = _EVAL_49__EVAL_50_data;
  assign _EVAL_3 = _EVAL_31__EVAL_32_data;
  assign _EVAL_9 = _EVAL_45__EVAL_46_data;
  assign _EVAL_10 = _EVAL_27;
  assign _EVAL_12 = _EVAL_59__EVAL_60_data;
  assign _EVAL_13 = _EVAL_57;
  assign _EVAL_17 = _EVAL_37__EVAL_38_data;
  assign _EVAL_18 = _EVAL_52__EVAL_53_data;
  assign _EVAL_19 = _EVAL_41__EVAL_42_data;
  assign _EVAL_21 = _EVAL_56 == _EVAL_55;
  assign _EVAL_22 = _EVAL_55 + 1'h1;
  assign _EVAL_23 = _EVAL_22[0:0];
  assign _EVAL_24 = _EVAL_44[0:0];
  assign _EVAL_25 = _EVAL_66 ? _EVAL_65 : _EVAL_36;
  assign _EVAL_26 = _EVAL_21 & _EVAL_29;
  assign _EVAL_27 = _EVAL_35 == 1'h0;
  assign _EVAL_28 = _EVAL_0 & _EVAL_1;
  assign _EVAL_29 = _EVAL_36 == 1'h0;
  assign _EVAL_30 = _EVAL_36 & _EVAL_21;
  assign _EVAL_31__EVAL_32_addr = _EVAL_55;
  assign _EVAL_31__EVAL_32_data = _EVAL_31[_EVAL_31__EVAL_32_addr];
  assign _EVAL_31__EVAL_33_data = _EVAL_8;
  assign _EVAL_31__EVAL_33_addr = _EVAL_56;
  assign _EVAL_31__EVAL_33_mask = _EVAL_65;
  assign _EVAL_31__EVAL_33_en = _EVAL_65;
  assign _EVAL_34 = _EVAL_65 ? _EVAL_24 : _EVAL_56;
  assign _EVAL_35 = _EVAL_21 & _EVAL_36;
  assign _EVAL_37__EVAL_38_addr = _EVAL_55;
  assign _EVAL_37__EVAL_38_data = _EVAL_37[_EVAL_37__EVAL_38_addr];
  assign _EVAL_37__EVAL_39_data = _EVAL_6;
  assign _EVAL_37__EVAL_39_addr = _EVAL_56;
  assign _EVAL_37__EVAL_39_mask = _EVAL_65;
  assign _EVAL_37__EVAL_39_en = _EVAL_65;
  assign _EVAL_40 = _EVAL_10 & _EVAL_20;
  assign _EVAL_41__EVAL_42_addr = _EVAL_55;
  assign _EVAL_41__EVAL_42_data = _EVAL_41[_EVAL_41__EVAL_42_addr];
  assign _EVAL_41__EVAL_43_data = _EVAL_16;
  assign _EVAL_41__EVAL_43_addr = _EVAL_56;
  assign _EVAL_41__EVAL_43_mask = _EVAL_65;
  assign _EVAL_41__EVAL_43_en = _EVAL_65;
  assign _EVAL_44 = _EVAL_56 + 1'h1;
  assign _EVAL_45__EVAL_46_addr = _EVAL_55;
  assign _EVAL_45__EVAL_46_data = _EVAL_45[_EVAL_45__EVAL_46_addr];
  assign _EVAL_45__EVAL_47_data = _EVAL_5;
  assign _EVAL_45__EVAL_47_addr = _EVAL_56;
  assign _EVAL_45__EVAL_47_mask = _EVAL_65;
  assign _EVAL_45__EVAL_47_en = _EVAL_65;
  assign _EVAL_48 = _EVAL_56 - _EVAL_55;
  assign _EVAL_49__EVAL_50_addr = _EVAL_55;
  assign _EVAL_49__EVAL_50_data = _EVAL_49[_EVAL_49__EVAL_50_addr];
  assign _EVAL_49__EVAL_51_data = _EVAL_15;
  assign _EVAL_49__EVAL_51_addr = _EVAL_56;
  assign _EVAL_49__EVAL_51_mask = _EVAL_65;
  assign _EVAL_49__EVAL_51_en = _EVAL_65;
  assign _EVAL_52__EVAL_53_addr = _EVAL_55;
  assign _EVAL_52__EVAL_53_data = _EVAL_52[_EVAL_52__EVAL_53_addr];
  assign _EVAL_52__EVAL_54_data = _EVAL_14;
  assign _EVAL_52__EVAL_54_addr = _EVAL_56;
  assign _EVAL_52__EVAL_54_mask = _EVAL_65;
  assign _EVAL_52__EVAL_54_en = _EVAL_65;
  assign _EVAL_57 = {_EVAL_30,_EVAL_64};
  assign _EVAL_58 = _EVAL_28;
  assign _EVAL_59__EVAL_60_addr = _EVAL_55;
  assign _EVAL_59__EVAL_60_data = _EVAL_59[_EVAL_59__EVAL_60_addr];
  assign _EVAL_59__EVAL_61_data = _EVAL_4;
  assign _EVAL_59__EVAL_61_addr = _EVAL_56;
  assign _EVAL_59__EVAL_61_mask = _EVAL_65;
  assign _EVAL_59__EVAL_61_en = _EVAL_65;
  assign _EVAL_62 = _EVAL_26 == 1'h0;
  assign _EVAL_63 = $unsigned(_EVAL_48);
  assign _EVAL_64 = _EVAL_63[0:0];
  assign _EVAL_65 = _EVAL_40;
  assign _EVAL_66 = _EVAL_65 != _EVAL_58;
  assign _EVAL_67 = _EVAL_58 ? _EVAL_23 : _EVAL_55;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_31[initvar] = _GEN_0[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_36 = _GEN_1[0:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_37[initvar] = _GEN_2[3:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_41[initvar] = _GEN_3[2:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_45[initvar] = _GEN_4[31:0];
  `endif
  _GEN_5 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_49[initvar] = _GEN_5[63:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_52[initvar] = _GEN_6[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_55 = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_56 = _GEN_8[0:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_59[initvar] = _GEN_9[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_7) begin
    if(_EVAL_31__EVAL_33_en & _EVAL_31__EVAL_33_mask) begin
      _EVAL_31[_EVAL_31__EVAL_33_addr] <= _EVAL_31__EVAL_33_data;
    end
    if (_EVAL_11) begin
      _EVAL_36 <= 1'h0;
    end else begin
      if (_EVAL_66) begin
        _EVAL_36 <= _EVAL_65;
      end
    end
    if(_EVAL_37__EVAL_39_en & _EVAL_37__EVAL_39_mask) begin
      _EVAL_37[_EVAL_37__EVAL_39_addr] <= _EVAL_37__EVAL_39_data;
    end
    if(_EVAL_41__EVAL_43_en & _EVAL_41__EVAL_43_mask) begin
      _EVAL_41[_EVAL_41__EVAL_43_addr] <= _EVAL_41__EVAL_43_data;
    end
    if(_EVAL_45__EVAL_47_en & _EVAL_45__EVAL_47_mask) begin
      _EVAL_45[_EVAL_45__EVAL_47_addr] <= _EVAL_45__EVAL_47_data;
    end
    if(_EVAL_49__EVAL_51_en & _EVAL_49__EVAL_51_mask) begin
      _EVAL_49[_EVAL_49__EVAL_51_addr] <= _EVAL_49__EVAL_51_data;
    end
    if(_EVAL_52__EVAL_54_en & _EVAL_52__EVAL_54_mask) begin
      _EVAL_52[_EVAL_52__EVAL_54_addr] <= _EVAL_52__EVAL_54_data;
    end
    if (_EVAL_11) begin
      _EVAL_55 <= 1'h0;
    end else begin
      if (_EVAL_58) begin
        _EVAL_55 <= _EVAL_23;
      end
    end
    if (_EVAL_11) begin
      _EVAL_56 <= 1'h0;
    end else begin
      if (_EVAL_65) begin
        _EVAL_56 <= _EVAL_24;
      end
    end
    if(_EVAL_59__EVAL_61_en & _EVAL_59__EVAL_61_mask) begin
      _EVAL_59[_EVAL_59__EVAL_61_addr] <= _EVAL_59__EVAL_61_data;
    end
  end
endmodule
