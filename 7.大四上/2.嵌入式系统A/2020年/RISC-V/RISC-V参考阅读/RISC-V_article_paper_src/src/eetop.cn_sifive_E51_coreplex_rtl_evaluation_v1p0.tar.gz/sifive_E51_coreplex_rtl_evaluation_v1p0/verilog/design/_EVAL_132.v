//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_132(
  input         _EVAL_0,
  output [63:0] _EVAL_1,
  output        _EVAL_2,
  input  [7:0]  _EVAL_3,
  output [1:0]  _EVAL_4,
  input         _EVAL_5,
  input  [31:0] _EVAL_6,
  output [3:0]  _EVAL_7,
  input  [2:0]  _EVAL_8,
  input         _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  input         _EVAL_12,
  output [7:0]  _EVAL_13,
  output [31:0] _EVAL_14,
  input  [63:0] _EVAL_15,
  output [2:0]  _EVAL_16,
  input  [1:0]  _EVAL_17,
  output        _EVAL_18,
  input  [3:0]  _EVAL_19,
  input  [2:0]  _EVAL_20,
  output [2:0]  _EVAL_21
);
  wire  _EVAL_23;
  wire [7:0] _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire [63:0] _EVAL_27;
  wire [31:0] _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  wire  _EVAL_31;
  wire [2:0] _EVAL_33;
  reg [1:0] _EVAL_34;
  reg [31:0] _GEN_0;
  wire  _EVAL_36;
  wire [3:0] _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire [2:0] _EVAL_40;
  wire [1:0] _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_43;
  wire [31:0] Queue__EVAL_0;
  wire [2:0] Queue__EVAL_1;
  wire  Queue__EVAL_2;
  wire  Queue__EVAL_3;
  wire [31:0] Queue__EVAL_4;
  wire [7:0] Queue__EVAL_5;
  wire [7:0] Queue__EVAL_6;
  wire  Queue__EVAL_7;
  wire [1:0] Queue__EVAL_8;
  wire [63:0] Queue__EVAL_9;
  wire  Queue__EVAL_10;
  wire  Queue__EVAL_11;
  wire  Queue__EVAL_12;
  wire  Queue__EVAL_13;
  wire  Queue__EVAL_14;
  wire [2:0] Queue__EVAL_15;
  wire [63:0] Queue__EVAL_16;
  wire [2:0] Queue__EVAL_17;
  wire [2:0] Queue__EVAL_18;
  wire [3:0] Queue__EVAL_19;
  wire [3:0] Queue__EVAL_20;
  wire [1:0] _EVAL_44;
  _EVAL_131 Queue (
    ._EVAL_0(Queue__EVAL_0),
    ._EVAL_1(Queue__EVAL_1),
    ._EVAL_2(Queue__EVAL_2),
    ._EVAL_3(Queue__EVAL_3),
    ._EVAL_4(Queue__EVAL_4),
    ._EVAL_5(Queue__EVAL_5),
    ._EVAL_6(Queue__EVAL_6),
    ._EVAL_7(Queue__EVAL_7),
    ._EVAL_8(Queue__EVAL_8),
    ._EVAL_9(Queue__EVAL_9),
    ._EVAL_10(Queue__EVAL_10),
    ._EVAL_11(Queue__EVAL_11),
    ._EVAL_12(Queue__EVAL_12),
    ._EVAL_13(Queue__EVAL_13),
    ._EVAL_14(Queue__EVAL_14),
    ._EVAL_15(Queue__EVAL_15),
    ._EVAL_16(Queue__EVAL_16),
    ._EVAL_17(Queue__EVAL_17),
    ._EVAL_18(Queue__EVAL_18),
    ._EVAL_19(Queue__EVAL_19),
    ._EVAL_20(Queue__EVAL_20)
  );
  assign _EVAL_1 = Queue__EVAL_16;
  assign _EVAL_2 = _EVAL_39;
  assign _EVAL_4 = _EVAL_34;
  assign _EVAL_7 = Queue__EVAL_20;
  assign _EVAL_10 = Queue__EVAL_7;
  assign _EVAL_13 = Queue__EVAL_6;
  assign _EVAL_14 = Queue__EVAL_4;
  assign _EVAL_16 = Queue__EVAL_18;
  assign _EVAL_18 = Queue__EVAL_14;
  assign _EVAL_21 = Queue__EVAL_1;
  assign _EVAL_23 = _EVAL_26;
  assign _EVAL_24 = _EVAL_3;
  assign _EVAL_25 = _EVAL_34[1];
  assign _EVAL_26 = _EVAL_43 ? _EVAL_12 : _EVAL_29;
  assign _EVAL_27 = _EVAL_15;
  assign _EVAL_28 = _EVAL_6;
  assign _EVAL_29 = _EVAL_25 != _EVAL_36;
  assign _EVAL_30 = _EVAL_25 == 1'h0;
  assign _EVAL_31 = _EVAL_5;
  assign _EVAL_33 = _EVAL_8;
  assign _EVAL_36 = _EVAL_17[0];
  assign _EVAL_37 = _EVAL_19;
  assign _EVAL_38 = _EVAL_34[0];
  assign _EVAL_39 = Queue__EVAL_11;
  assign _EVAL_40 = _EVAL_20;
  assign _EVAL_41 = _EVAL_42 ? _EVAL_44 : _EVAL_34;
  assign _EVAL_42 = _EVAL_39 & _EVAL_23;
  assign _EVAL_43 = _EVAL_34 == _EVAL_17;
  assign Queue__EVAL_0 = _EVAL_28;
  assign Queue__EVAL_2 = _EVAL_31;
  assign Queue__EVAL_3 = _EVAL_9;
  assign Queue__EVAL_5 = _EVAL_24;
  assign Queue__EVAL_9 = _EVAL_27;
  assign Queue__EVAL_10 = _EVAL_23;
  assign Queue__EVAL_12 = _EVAL_0;
  assign Queue__EVAL_13 = _EVAL_11;
  assign Queue__EVAL_15 = _EVAL_33;
  assign Queue__EVAL_17 = _EVAL_40;
  assign Queue__EVAL_19 = _EVAL_37;
  assign _EVAL_44 = {_EVAL_38,_EVAL_30};
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_34 = _GEN_0[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_0) begin
    if (_EVAL_9) begin
      _EVAL_34 <= 2'h0;
    end else begin
      if (_EVAL_42) begin
        _EVAL_34 <= _EVAL_44;
      end
    end
  end
endmodule
