//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_134(
  input  [2:0]  _EVAL_0,
  input         _EVAL_1,
  output        _EVAL_2,
  input         _EVAL_3,
  output [63:0] _EVAL_4,
  input         _EVAL_5,
  output [1:0]  _EVAL_6,
  input  [2:0]  _EVAL_7,
  input         _EVAL_8,
  input  [1:0]  _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  input         _EVAL_12,
  output [2:0]  _EVAL_13,
  input  [3:0]  _EVAL_14,
  output        _EVAL_15,
  output        _EVAL_16,
  output [2:0]  _EVAL_17,
  output [3:0]  _EVAL_18,
  output        _EVAL_19,
  output [1:0]  _EVAL_20,
  input  [1:0]  _EVAL_21,
  input         _EVAL_22,
  input  [63:0] _EVAL_23
);
  wire [1:0] _EVAL_25;
  reg [2:0] _EVAL_26;
  reg [31:0] _GEN_0;
  wire  _EVAL_27;
  wire [2:0] _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  reg [2:0] _EVAL_31;
  reg [31:0] _GEN_1;
  wire  _EVAL_32;
  wire  _EVAL_33;
  reg  _EVAL_34;
  reg [31:0] _GEN_2;
  reg  _EVAL_35;
  reg [31:0] _GEN_3;
  wire  _EVAL_36;
  reg [63:0] _EVAL_37;
  reg [63:0] _GEN_4;
  wire  _EVAL_38;
  wire  _EVAL_39;
  reg [3:0] _EVAL_40;
  reg [31:0] _GEN_5;
  wire [2:0] _EVAL_41;
  reg  _EVAL_43;
  reg [31:0] _GEN_6;
  reg [1:0] _EVAL_44;
  reg [31:0] _GEN_7;
  wire  _EVAL_45;
  wire  _EVAL_46;
  wire [3:0] _EVAL_47;
  wire [63:0] _EVAL_48;
  wire [1:0] _EVAL_49;
  wire [1:0] _EVAL_51;
  wire  _EVAL_52;
  wire [1:0] enq__EVAL_0;
  wire [2:0] enq__EVAL_1;
  wire  enq__EVAL_2;
  wire  enq__EVAL_3;
  wire [3:0] enq__EVAL_4;
  wire  enq__EVAL_5;
  wire  enq__EVAL_6;
  wire  enq__EVAL_7;
  wire  enq__EVAL_8;
  wire  enq__EVAL_9;
  wire  enq__EVAL_10;
  wire [1:0] enq__EVAL_11;
  wire  enq__EVAL_12;
  wire [2:0] enq__EVAL_13;
  wire [63:0] enq__EVAL_14;
  wire [63:0] enq__EVAL_15;
  wire  enq__EVAL_16;
  wire [1:0] enq__EVAL_17;
  wire  enq__EVAL_18;
  wire  enq__EVAL_19;
  wire [2:0] enq__EVAL_20;
  wire [2:0] enq__EVAL_21;
  wire [3:0] enq__EVAL_22;
  reg [1:0] _EVAL_53;
  reg [31:0] _GEN_8;
  _EVAL_133 enq (
    ._EVAL_0(enq__EVAL_0),
    ._EVAL_1(enq__EVAL_1),
    ._EVAL_2(enq__EVAL_2),
    ._EVAL_3(enq__EVAL_3),
    ._EVAL_4(enq__EVAL_4),
    ._EVAL_5(enq__EVAL_5),
    ._EVAL_6(enq__EVAL_6),
    ._EVAL_7(enq__EVAL_7),
    ._EVAL_8(enq__EVAL_8),
    ._EVAL_9(enq__EVAL_9),
    ._EVAL_10(enq__EVAL_10),
    ._EVAL_11(enq__EVAL_11),
    ._EVAL_12(enq__EVAL_12),
    ._EVAL_13(enq__EVAL_13),
    ._EVAL_14(enq__EVAL_14),
    ._EVAL_15(enq__EVAL_15),
    ._EVAL_16(enq__EVAL_16),
    ._EVAL_17(enq__EVAL_17),
    ._EVAL_18(enq__EVAL_18),
    ._EVAL_19(enq__EVAL_19),
    ._EVAL_20(enq__EVAL_20),
    ._EVAL_21(enq__EVAL_21),
    ._EVAL_22(enq__EVAL_22)
  );
  assign _EVAL_2 = _EVAL_46;
  assign _EVAL_4 = _EVAL_48;
  assign _EVAL_6 = _EVAL_49;
  assign _EVAL_10 = enq__EVAL_9;
  assign _EVAL_13 = _EVAL_41;
  assign _EVAL_15 = enq__EVAL_7;
  assign _EVAL_16 = _EVAL_45;
  assign _EVAL_17 = _EVAL_28;
  assign _EVAL_18 = _EVAL_47;
  assign _EVAL_19 = _EVAL_38;
  assign _EVAL_20 = _EVAL_53;
  assign _EVAL_25 = _EVAL_52 ? _EVAL_51 : _EVAL_53;
  assign _EVAL_27 = _EVAL_39 ? _EVAL_5 : _EVAL_30;
  assign _EVAL_28 = _EVAL_39 ? enq__EVAL_20 : _EVAL_26;
  assign _EVAL_29 = _EVAL_53[1];
  assign _EVAL_30 = _EVAL_29 != _EVAL_33;
  assign _EVAL_32 = _EVAL_29 == 1'h0;
  assign _EVAL_33 = _EVAL_21[0];
  assign _EVAL_36 = _EVAL_53[0];
  assign _EVAL_38 = _EVAL_39 ? enq__EVAL_5 : _EVAL_35;
  assign _EVAL_39 = _EVAL_53 == _EVAL_21;
  assign _EVAL_41 = _EVAL_39 ? enq__EVAL_1 : _EVAL_31;
  assign _EVAL_45 = _EVAL_39 ? enq__EVAL_10 : _EVAL_43;
  assign _EVAL_46 = _EVAL_39 ? enq__EVAL_12 : _EVAL_34;
  assign _EVAL_47 = _EVAL_39 ? enq__EVAL_4 : _EVAL_40;
  assign _EVAL_48 = _EVAL_39 ? enq__EVAL_15 : _EVAL_37;
  assign _EVAL_49 = _EVAL_39 ? enq__EVAL_17 : _EVAL_44;
  assign _EVAL_51 = {_EVAL_36,_EVAL_32};
  assign _EVAL_52 = enq__EVAL_2 & enq__EVAL_7;
  assign enq__EVAL_0 = _EVAL_9;
  assign enq__EVAL_2 = _EVAL_27;
  assign enq__EVAL_3 = _EVAL_1;
  assign enq__EVAL_6 = _EVAL_3;
  assign enq__EVAL_8 = _EVAL_8;
  assign enq__EVAL_13 = _EVAL_7;
  assign enq__EVAL_14 = _EVAL_23;
  assign enq__EVAL_16 = _EVAL_22;
  assign enq__EVAL_18 = _EVAL_12;
  assign enq__EVAL_19 = _EVAL_11;
  assign enq__EVAL_21 = _EVAL_0;
  assign enq__EVAL_22 = _EVAL_14;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_26 = _GEN_0[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_31 = _GEN_1[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_34 = _GEN_2[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_35 = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_4[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_40 = _GEN_5[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_43 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_44 = _GEN_7[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_53 = _GEN_8[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_22) begin
    if (_EVAL_39) begin
      _EVAL_26 <= enq__EVAL_20;
    end
    if (_EVAL_39) begin
      _EVAL_31 <= enq__EVAL_1;
    end
    if (_EVAL_39) begin
      _EVAL_34 <= enq__EVAL_12;
    end
    if (_EVAL_39) begin
      _EVAL_35 <= enq__EVAL_5;
    end
    if (_EVAL_39) begin
      _EVAL_37 <= enq__EVAL_15;
    end
    if (_EVAL_39) begin
      _EVAL_40 <= enq__EVAL_4;
    end
    if (_EVAL_39) begin
      _EVAL_43 <= enq__EVAL_10;
    end
    if (_EVAL_39) begin
      _EVAL_44 <= enq__EVAL_17;
    end
    if (_EVAL_3) begin
      _EVAL_53 <= 2'h0;
    end else begin
      if (_EVAL_52) begin
        _EVAL_53 <= _EVAL_51;
      end
    end
  end
endmodule
