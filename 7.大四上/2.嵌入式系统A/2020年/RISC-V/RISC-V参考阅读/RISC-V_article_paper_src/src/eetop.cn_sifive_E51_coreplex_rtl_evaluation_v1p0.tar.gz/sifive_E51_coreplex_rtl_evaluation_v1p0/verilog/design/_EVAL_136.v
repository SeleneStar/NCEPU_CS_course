//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_136(
  input         _EVAL_0,
  input         _EVAL_1,
  output [2:0]  _EVAL_2,
  output [3:0]  _EVAL_3,
  input  [2:0]  _EVAL_4,
  input  [2:0]  _EVAL_5,
  input  [7:0]  _EVAL_6,
  output [2:0]  _EVAL_7,
  output        _EVAL_8,
  input  [3:0]  _EVAL_9,
  input         _EVAL_10,
  input  [2:0]  _EVAL_11,
  output [2:0]  _EVAL_12,
  output [63:0] _EVAL_13,
  input         _EVAL_14,
  output        _EVAL_15,
  output [7:0]  _EVAL_16,
  output [31:0] _EVAL_17,
  input  [31:0] _EVAL_18,
  output [1:0]  _EVAL_19,
  input  [1:0]  _EVAL_20,
  input  [63:0] _EVAL_21
);
  wire  _EVAL_22;
  wire [1:0] _EVAL_23;
  wire [31:0] _EVAL_24;
  reg [1:0] _EVAL_25;
  reg [31:0] _GEN_0;
  reg [7:0] _EVAL_26;
  reg [31:0] _GEN_1;
  wire  _EVAL_27;
  wire [7:0] _EVAL_28;
  wire  _EVAL_29;
  wire [1:0] _EVAL_30;
  wire  _EVAL_32;
  reg [2:0] _EVAL_33;
  reg [31:0] _GEN_2;
  reg [2:0] _EVAL_34;
  reg [31:0] _GEN_3;
  wire [2:0] _EVAL_35;
  reg [63:0] _EVAL_36;
  reg [63:0] _GEN_4;
  wire [3:0] _EVAL_38;
  wire [2:0] _EVAL_39;
  wire  _EVAL_40;
  wire [2:0] _EVAL_41;
  reg [31:0] _EVAL_42;
  reg [31:0] _GEN_5;
  reg [3:0] _EVAL_43;
  reg [31:0] _GEN_6;
  wire  _EVAL_44;
  wire [31:0] enq__EVAL_0;
  wire [3:0] enq__EVAL_1;
  wire  enq__EVAL_2;
  wire [3:0] enq__EVAL_3;
  wire  enq__EVAL_4;
  wire [63:0] enq__EVAL_5;
  wire [2:0] enq__EVAL_6;
  wire  enq__EVAL_7;
  wire [2:0] enq__EVAL_8;
  wire [2:0] enq__EVAL_9;
  wire [2:0] enq__EVAL_10;
  wire  enq__EVAL_11;
  wire [1:0] enq__EVAL_12;
  wire [2:0] enq__EVAL_13;
  wire [63:0] enq__EVAL_14;
  wire  enq__EVAL_15;
  wire [7:0] enq__EVAL_16;
  wire  enq__EVAL_17;
  wire [2:0] enq__EVAL_18;
  wire [7:0] enq__EVAL_19;
  wire [31:0] enq__EVAL_20;
  wire  _EVAL_46;
  wire  _EVAL_47;
  reg [2:0] _EVAL_48;
  reg [31:0] _GEN_7;
  wire [63:0] _EVAL_49;
  _EVAL_21 enq (
    ._EVAL_0(enq__EVAL_0),
    ._EVAL_1(enq__EVAL_1),
    ._EVAL_2(enq__EVAL_2),
    ._EVAL_3(enq__EVAL_3),
    ._EVAL_4(enq__EVAL_4),
    ._EVAL_5(enq__EVAL_5),
    ._EVAL_6(enq__EVAL_6),
    ._EVAL_7(enq__EVAL_7),
    ._EVAL_8(enq__EVAL_8),
    ._EVAL_9(enq__EVAL_9),
    ._EVAL_10(enq__EVAL_10),
    ._EVAL_11(enq__EVAL_11),
    ._EVAL_12(enq__EVAL_12),
    ._EVAL_13(enq__EVAL_13),
    ._EVAL_14(enq__EVAL_14),
    ._EVAL_15(enq__EVAL_15),
    ._EVAL_16(enq__EVAL_16),
    ._EVAL_17(enq__EVAL_17),
    ._EVAL_18(enq__EVAL_18),
    ._EVAL_19(enq__EVAL_19),
    ._EVAL_20(enq__EVAL_20)
  );
  assign _EVAL_2 = _EVAL_39;
  assign _EVAL_3 = _EVAL_38;
  assign _EVAL_7 = _EVAL_41;
  assign _EVAL_8 = enq__EVAL_15;
  assign _EVAL_12 = _EVAL_35;
  assign _EVAL_13 = _EVAL_49;
  assign _EVAL_15 = enq__EVAL_4;
  assign _EVAL_16 = _EVAL_28;
  assign _EVAL_17 = _EVAL_24;
  assign _EVAL_19 = _EVAL_25;
  assign _EVAL_22 = _EVAL_47 == 1'h0;
  assign _EVAL_23 = {_EVAL_40,_EVAL_22};
  assign _EVAL_24 = _EVAL_29 ? enq__EVAL_0 : _EVAL_42;
  assign _EVAL_27 = _EVAL_20[0];
  assign _EVAL_28 = _EVAL_29 ? enq__EVAL_16 : _EVAL_26;
  assign _EVAL_29 = _EVAL_25 == _EVAL_20;
  assign _EVAL_30 = _EVAL_46 ? _EVAL_23 : _EVAL_25;
  assign _EVAL_32 = _EVAL_29 ? _EVAL_1 : _EVAL_44;
  assign _EVAL_35 = _EVAL_29 ? enq__EVAL_18 : _EVAL_34;
  assign _EVAL_38 = _EVAL_29 ? enq__EVAL_1 : _EVAL_43;
  assign _EVAL_39 = _EVAL_29 ? enq__EVAL_8 : _EVAL_48;
  assign _EVAL_40 = _EVAL_25[0];
  assign _EVAL_41 = _EVAL_29 ? enq__EVAL_10 : _EVAL_33;
  assign _EVAL_44 = _EVAL_47 != _EVAL_27;
  assign enq__EVAL_2 = _EVAL_14;
  assign enq__EVAL_3 = _EVAL_9;
  assign enq__EVAL_5 = _EVAL_21;
  assign enq__EVAL_6 = _EVAL_11;
  assign enq__EVAL_7 = _EVAL_32;
  assign enq__EVAL_9 = _EVAL_4;
  assign enq__EVAL_11 = _EVAL_0;
  assign enq__EVAL_13 = _EVAL_5;
  assign enq__EVAL_17 = _EVAL_10;
  assign enq__EVAL_19 = _EVAL_6;
  assign enq__EVAL_20 = _EVAL_18;
  assign _EVAL_46 = enq__EVAL_7 & enq__EVAL_4;
  assign _EVAL_47 = _EVAL_25[1];
  assign _EVAL_49 = _EVAL_29 ? enq__EVAL_14 : _EVAL_36;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_25 = _GEN_0[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_26 = _GEN_1[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_33 = _GEN_2[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_34 = _GEN_3[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_36 = _GEN_4[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_42 = _GEN_5[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_43 = _GEN_6[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_7[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_0) begin
    if (_EVAL_10) begin
      _EVAL_25 <= 2'h0;
    end else begin
      if (_EVAL_46) begin
        _EVAL_25 <= _EVAL_23;
      end
    end
    if (_EVAL_29) begin
      _EVAL_26 <= enq__EVAL_16;
    end
    if (_EVAL_29) begin
      _EVAL_33 <= enq__EVAL_10;
    end
    if (_EVAL_29) begin
      _EVAL_34 <= enq__EVAL_18;
    end
    if (_EVAL_29) begin
      _EVAL_36 <= enq__EVAL_14;
    end
    if (_EVAL_29) begin
      _EVAL_42 <= enq__EVAL_0;
    end
    if (_EVAL_29) begin
      _EVAL_43 <= enq__EVAL_1;
    end
    if (_EVAL_29) begin
      _EVAL_48 <= enq__EVAL_8;
    end
  end
endmodule
