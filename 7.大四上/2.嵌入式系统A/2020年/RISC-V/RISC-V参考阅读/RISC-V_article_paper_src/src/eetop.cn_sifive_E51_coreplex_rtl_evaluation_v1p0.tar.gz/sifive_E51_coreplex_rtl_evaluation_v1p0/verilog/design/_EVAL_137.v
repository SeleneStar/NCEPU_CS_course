//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_137(
  input         _EVAL_0,
  output [3:0]  _EVAL_1,
  output        _EVAL_2,
  output        _EVAL_3,
  input         _EVAL_4,
  input  [63:0] _EVAL_5,
  input  [3:0]  _EVAL_6,
  input  [1:0]  _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  output [1:0]  _EVAL_10,
  output        _EVAL_11,
  input  [1:0]  _EVAL_12,
  input  [2:0]  _EVAL_13,
  output [2:0]  _EVAL_14,
  input  [2:0]  _EVAL_15,
  input         _EVAL_16,
  output [1:0]  _EVAL_17,
  output        _EVAL_18,
  output [2:0]  _EVAL_19,
  output [2:0]  _EVAL_20,
  output [63:0] _EVAL_21,
  input         _EVAL_22,
  input  [2:0]  _EVAL_23
);
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire [1:0] _EVAL_26;
  wire  _EVAL_28;
  wire [2:0] _EVAL_29;
  wire  _EVAL_30;
  wire [1:0] _EVAL_31;
  wire [2:0] _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  wire [1:0] _EVAL_35;
  wire  _EVAL_36;
  reg [1:0] _EVAL_37;
  reg [31:0] _GEN_0;
  wire [63:0] Queue__EVAL_0;
  wire [2:0] Queue__EVAL_1;
  wire [2:0] Queue__EVAL_2;
  wire  Queue__EVAL_3;
  wire  Queue__EVAL_4;
  wire  Queue__EVAL_5;
  wire  Queue__EVAL_6;
  wire  Queue__EVAL_7;
  wire [1:0] Queue__EVAL_8;
  wire [1:0] Queue__EVAL_9;
  wire [2:0] Queue__EVAL_10;
  wire  Queue__EVAL_11;
  wire [2:0] Queue__EVAL_12;
  wire  Queue__EVAL_13;
  wire [63:0] Queue__EVAL_14;
  wire [3:0] Queue__EVAL_15;
  wire [2:0] Queue__EVAL_16;
  wire  Queue__EVAL_17;
  wire  Queue__EVAL_18;
  wire  Queue__EVAL_19;
  wire [2:0] Queue__EVAL_20;
  wire [3:0] Queue__EVAL_21;
  wire [1:0] Queue__EVAL_22;
  wire  _EVAL_39;
  wire [2:0] _EVAL_40;
  wire [63:0] _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_43;
  wire [3:0] _EVAL_44;
  wire  _EVAL_45;
  wire  _EVAL_47;
  _EVAL_22 Queue (
    ._EVAL_0(Queue__EVAL_0),
    ._EVAL_1(Queue__EVAL_1),
    ._EVAL_2(Queue__EVAL_2),
    ._EVAL_3(Queue__EVAL_3),
    ._EVAL_4(Queue__EVAL_4),
    ._EVAL_5(Queue__EVAL_5),
    ._EVAL_6(Queue__EVAL_6),
    ._EVAL_7(Queue__EVAL_7),
    ._EVAL_8(Queue__EVAL_8),
    ._EVAL_9(Queue__EVAL_9),
    ._EVAL_10(Queue__EVAL_10),
    ._EVAL_11(Queue__EVAL_11),
    ._EVAL_12(Queue__EVAL_12),
    ._EVAL_13(Queue__EVAL_13),
    ._EVAL_14(Queue__EVAL_14),
    ._EVAL_15(Queue__EVAL_15),
    ._EVAL_16(Queue__EVAL_16),
    ._EVAL_17(Queue__EVAL_17),
    ._EVAL_18(Queue__EVAL_18),
    ._EVAL_19(Queue__EVAL_19),
    ._EVAL_20(Queue__EVAL_20),
    ._EVAL_21(Queue__EVAL_21),
    ._EVAL_22(Queue__EVAL_22)
  );
  assign _EVAL_1 = Queue__EVAL_21;
  assign _EVAL_2 = _EVAL_45;
  assign _EVAL_3 = Queue__EVAL_18;
  assign _EVAL_10 = _EVAL_37;
  assign _EVAL_11 = Queue__EVAL_11;
  assign _EVAL_14 = Queue__EVAL_16;
  assign _EVAL_17 = Queue__EVAL_9;
  assign _EVAL_18 = Queue__EVAL_3;
  assign _EVAL_19 = Queue__EVAL_20;
  assign _EVAL_20 = Queue__EVAL_12;
  assign _EVAL_21 = Queue__EVAL_14;
  assign _EVAL_24 = _EVAL_45 & _EVAL_43;
  assign _EVAL_25 = _EVAL_33 ? _EVAL_8 : _EVAL_34;
  assign _EVAL_26 = _EVAL_7;
  assign _EVAL_28 = _EVAL_12[0];
  assign _EVAL_29 = _EVAL_15;
  assign _EVAL_30 = _EVAL_37[0];
  assign _EVAL_31 = _EVAL_24 ? _EVAL_35 : _EVAL_37;
  assign _EVAL_32 = _EVAL_13;
  assign _EVAL_33 = _EVAL_37 == _EVAL_12;
  assign _EVAL_34 = _EVAL_39 != _EVAL_28;
  assign _EVAL_35 = {_EVAL_30,_EVAL_42};
  assign _EVAL_36 = _EVAL_4;
  assign Queue__EVAL_0 = _EVAL_41;
  assign Queue__EVAL_1 = _EVAL_40;
  assign Queue__EVAL_2 = _EVAL_29;
  assign Queue__EVAL_4 = _EVAL_36;
  assign Queue__EVAL_5 = _EVAL_43;
  assign Queue__EVAL_6 = _EVAL_22;
  assign Queue__EVAL_7 = _EVAL_0;
  assign Queue__EVAL_10 = _EVAL_32;
  assign Queue__EVAL_13 = _EVAL_47;
  assign Queue__EVAL_15 = _EVAL_44;
  assign Queue__EVAL_19 = _EVAL_16;
  assign Queue__EVAL_22 = _EVAL_26;
  assign _EVAL_39 = _EVAL_37[1];
  assign _EVAL_40 = _EVAL_23;
  assign _EVAL_41 = _EVAL_5;
  assign _EVAL_42 = _EVAL_39 == 1'h0;
  assign _EVAL_43 = _EVAL_25;
  assign _EVAL_44 = _EVAL_6;
  assign _EVAL_45 = Queue__EVAL_17;
  assign _EVAL_47 = _EVAL_9;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_0[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_0) begin
    if (_EVAL_22) begin
      _EVAL_37 <= 2'h0;
    end else begin
      if (_EVAL_24) begin
        _EVAL_37 <= _EVAL_35;
      end
    end
  end
endmodule
