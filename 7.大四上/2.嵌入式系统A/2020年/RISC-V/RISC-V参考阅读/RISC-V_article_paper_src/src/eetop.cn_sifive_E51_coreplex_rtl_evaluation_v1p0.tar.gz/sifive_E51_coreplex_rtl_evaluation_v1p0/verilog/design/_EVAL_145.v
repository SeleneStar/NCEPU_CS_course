//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_145(
  input         _EVAL_0,
  input         _EVAL_1,
  output [9:0]  _EVAL_2,
  input  [3:0]  _EVAL_3,
  input  [31:0] _EVAL_4,
  output [31:0] _EVAL_5,
  input  [10:0] _EVAL_6,
  output        _EVAL_7,
  output [3:0]  _EVAL_8,
  output        _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  output [10:0] _EVAL_12,
  input         _EVAL_13,
  output        _EVAL_14,
  input  [9:0]  _EVAL_15,
  input         _EVAL_16
);
  reg [10:0] _EVAL_17 [0:0];
  reg [31:0] _GEN_0;
  wire [10:0] _EVAL_17__EVAL_18_data;
  wire  _EVAL_17__EVAL_18_addr;
  wire [10:0] _EVAL_17__EVAL_19_data;
  wire  _EVAL_17__EVAL_19_addr;
  wire  _EVAL_17__EVAL_19_mask;
  wire  _EVAL_17__EVAL_19_en;
  wire  _EVAL_20;
  wire  _EVAL_21;
  reg  _EVAL_22;
  reg [31:0] _GEN_1;
  wire [1:0] _EVAL_23;
  reg [9:0] _EVAL_24 [0:0];
  reg [31:0] _GEN_2;
  wire [9:0] _EVAL_24__EVAL_25_data;
  wire  _EVAL_24__EVAL_25_addr;
  wire [9:0] _EVAL_24__EVAL_26_data;
  wire  _EVAL_24__EVAL_26_addr;
  wire  _EVAL_24__EVAL_26_mask;
  wire  _EVAL_24__EVAL_26_en;
  wire  _EVAL_27;
  reg [3:0] _EVAL_28 [0:0];
  reg [31:0] _GEN_3;
  wire [3:0] _EVAL_28__EVAL_29_data;
  wire  _EVAL_28__EVAL_29_addr;
  wire [3:0] _EVAL_28__EVAL_30_data;
  wire  _EVAL_28__EVAL_30_addr;
  wire  _EVAL_28__EVAL_30_mask;
  wire  _EVAL_28__EVAL_30_en;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  reg [31:0] _EVAL_35 [0:0];
  reg [31:0] _GEN_4;
  wire [31:0] _EVAL_35__EVAL_36_data;
  wire  _EVAL_35__EVAL_36_addr;
  wire [31:0] _EVAL_35__EVAL_37_data;
  wire  _EVAL_35__EVAL_37_addr;
  wire  _EVAL_35__EVAL_37_mask;
  wire  _EVAL_35__EVAL_37_en;
  wire  _EVAL_38;
  wire [1:0] _EVAL_39;
  wire  _EVAL_40;
  reg  _EVAL_41 [0:0];
  reg [31:0] _GEN_5;
  wire  _EVAL_41__EVAL_42_data;
  wire  _EVAL_41__EVAL_42_addr;
  wire  _EVAL_41__EVAL_43_data;
  wire  _EVAL_41__EVAL_43_addr;
  wire  _EVAL_41__EVAL_43_mask;
  wire  _EVAL_41__EVAL_43_en;
  wire [1:0] _EVAL_44;
  assign _EVAL_2 = _EVAL_24__EVAL_25_data;
  assign _EVAL_5 = _EVAL_35__EVAL_36_data;
  assign _EVAL_7 = _EVAL_23[0];
  assign _EVAL_8 = _EVAL_28__EVAL_29_data;
  assign _EVAL_9 = _EVAL_21;
  assign _EVAL_10 = _EVAL_41__EVAL_42_data;
  assign _EVAL_12 = _EVAL_17__EVAL_18_data;
  assign _EVAL_14 = _EVAL_38;
  assign _EVAL_17__EVAL_18_addr = 1'h0;
  assign _EVAL_17__EVAL_18_data = _EVAL_17[_EVAL_17__EVAL_18_addr];
  assign _EVAL_17__EVAL_19_data = _EVAL_6;
  assign _EVAL_17__EVAL_19_addr = 1'h0;
  assign _EVAL_17__EVAL_19_mask = _EVAL_34;
  assign _EVAL_17__EVAL_19_en = _EVAL_34;
  assign _EVAL_20 = _EVAL_34 != _EVAL_27;
  assign _EVAL_21 = _EVAL_38 == 1'h0;
  assign _EVAL_23 = {_EVAL_22,_EVAL_33};
  assign _EVAL_24__EVAL_25_addr = 1'h0;
  assign _EVAL_24__EVAL_25_data = _EVAL_24[_EVAL_24__EVAL_25_addr];
  assign _EVAL_24__EVAL_26_data = _EVAL_15;
  assign _EVAL_24__EVAL_26_addr = 1'h0;
  assign _EVAL_24__EVAL_26_mask = _EVAL_34;
  assign _EVAL_24__EVAL_26_en = _EVAL_34;
  assign _EVAL_27 = _EVAL_32;
  assign _EVAL_28__EVAL_29_addr = 1'h0;
  assign _EVAL_28__EVAL_29_data = _EVAL_28[_EVAL_28__EVAL_29_addr];
  assign _EVAL_28__EVAL_30_data = _EVAL_3;
  assign _EVAL_28__EVAL_30_addr = 1'h0;
  assign _EVAL_28__EVAL_30_mask = _EVAL_34;
  assign _EVAL_28__EVAL_30_en = _EVAL_34;
  assign _EVAL_31 = _EVAL_14 & _EVAL_1;
  assign _EVAL_32 = _EVAL_11 & _EVAL_9;
  assign _EVAL_33 = _EVAL_44[0:0];
  assign _EVAL_34 = _EVAL_31;
  assign _EVAL_35__EVAL_36_addr = 1'h0;
  assign _EVAL_35__EVAL_36_data = _EVAL_35[_EVAL_35__EVAL_36_addr];
  assign _EVAL_35__EVAL_37_data = _EVAL_4;
  assign _EVAL_35__EVAL_37_addr = 1'h0;
  assign _EVAL_35__EVAL_37_mask = _EVAL_34;
  assign _EVAL_35__EVAL_37_en = _EVAL_34;
  assign _EVAL_38 = _EVAL_22 == 1'h0;
  assign _EVAL_39 = 1'h0 - 1'h0;
  assign _EVAL_40 = _EVAL_20 ? _EVAL_34 : _EVAL_22;
  assign _EVAL_41__EVAL_42_addr = 1'h0;
  assign _EVAL_41__EVAL_42_data = _EVAL_41[_EVAL_41__EVAL_42_addr];
  assign _EVAL_41__EVAL_43_data = _EVAL_16;
  assign _EVAL_41__EVAL_43_addr = 1'h0;
  assign _EVAL_41__EVAL_43_mask = _EVAL_34;
  assign _EVAL_41__EVAL_43_en = _EVAL_34;
  assign _EVAL_44 = $unsigned(_EVAL_39);
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_17[initvar] = _GEN_0[10:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_22 = _GEN_1[0:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_24[initvar] = _GEN_2[9:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_28[initvar] = _GEN_3[3:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_35[initvar] = _GEN_4[31:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_41[initvar] = _GEN_5[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_13) begin
    if(_EVAL_17__EVAL_19_en & _EVAL_17__EVAL_19_mask) begin
      _EVAL_17[_EVAL_17__EVAL_19_addr] <= _EVAL_17__EVAL_19_data;
    end
    if (_EVAL_0) begin
      _EVAL_22 <= 1'h0;
    end else begin
      if (_EVAL_20) begin
        _EVAL_22 <= _EVAL_34;
      end
    end
    if(_EVAL_24__EVAL_26_en & _EVAL_24__EVAL_26_mask) begin
      _EVAL_24[_EVAL_24__EVAL_26_addr] <= _EVAL_24__EVAL_26_data;
    end
    if(_EVAL_28__EVAL_30_en & _EVAL_28__EVAL_30_mask) begin
      _EVAL_28[_EVAL_28__EVAL_30_addr] <= _EVAL_28__EVAL_30_data;
    end
    if(_EVAL_35__EVAL_37_en & _EVAL_35__EVAL_37_mask) begin
      _EVAL_35[_EVAL_35__EVAL_37_addr] <= _EVAL_35__EVAL_37_data;
    end
    if(_EVAL_41__EVAL_43_en & _EVAL_41__EVAL_43_mask) begin
      _EVAL_41[_EVAL_41__EVAL_43_addr] <= _EVAL_41__EVAL_43_data;
    end
  end
endmodule
