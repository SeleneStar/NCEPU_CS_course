//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_154(
  input  [13:0] _EVAL_0,
  input         _EVAL_1,
  output [2:0]  _EVAL_2,
  output        _EVAL_3,
  input  [2:0]  _EVAL_4,
  input  [2:0]  _EVAL_5,
  input  [13:0] _EVAL_6,
  output [1:0]  _EVAL_7,
  output [13:0] _EVAL_8,
  output        _EVAL_9,
  input  [31:0] _EVAL_10,
  output [3:0]  _EVAL_11,
  input  [1:0]  _EVAL_12,
  output [31:0] _EVAL_13,
  output [13:0] _EVAL_14,
  output [1:0]  _EVAL_15,
  output        _EVAL_16,
  input  [13:0] _EVAL_17,
  input         _EVAL_18,
  input  [2:0]  _EVAL_19,
  input  [13:0] _EVAL_20,
  output [1:0]  _EVAL_21,
  output [13:0] _EVAL_22,
  input  [2:0]  _EVAL_23,
  input  [31:0] _EVAL_24,
  output        _EVAL_25,
  input         _EVAL_26,
  input         _EVAL_27,
  output        _EVAL_28,
  input         _EVAL_29,
  input         _EVAL_30,
  input  [1:0]  _EVAL_31,
  input         _EVAL_32,
  output        _EVAL_33,
  input  [3:0]  _EVAL_34,
  output [1:0]  _EVAL_35,
  input         _EVAL_36,
  input         _EVAL_37,
  output [2:0]  _EVAL_38,
  output        _EVAL_39,
  output [31:0] _EVAL_40,
  output [1:0]  _EVAL_41
);
  wire  _EVAL_42;
  wire [1:0] _EVAL_43;
  wire [1:0] _EVAL_44;
  wire [1:0] _EVAL_45;
  wire [1:0] _EVAL_46;
  wire [1:0] a__EVAL_0;
  wire  a__EVAL_1;
  wire  a__EVAL_2;
  wire  a__EVAL_3;
  wire [31:0] a__EVAL_4;
  wire [13:0] a__EVAL_5;
  wire [3:0] a__EVAL_6;
  wire [2:0] a__EVAL_7;
  wire  a__EVAL_8;
  wire [31:0] a__EVAL_9;
  wire [2:0] a__EVAL_10;
  wire [2:0] a__EVAL_11;
  wire  a__EVAL_12;
  wire  a__EVAL_13;
  wire [2:0] a__EVAL_14;
  wire [3:0] a__EVAL_15;
  wire [13:0] a__EVAL_16;
  wire [13:0] a__EVAL_17;
  wire [1:0] a__EVAL_18;
  wire  a__EVAL_19;
  wire [13:0] a__EVAL_20;
  wire [1:0] _EVAL_47;
  wire [1:0] _EVAL_48;
  wire [1:0] _EVAL_49;
  wire [1:0] _EVAL_50;
  wire [1:0] _EVAL_51;
  wire [1:0] _EVAL_52;
  wire [1:0] _EVAL_53;
  wire [1:0] _EVAL_54;
  reg [1:0] _GEN_0;
  reg [31:0] _GEN_7;
  reg [1:0] _GEN_1;
  reg [31:0] _GEN_8;
  reg [13:0] _GEN_2;
  reg [31:0] _GEN_9;
  reg [3:0] _GEN_3;
  reg [31:0] _GEN_10;
  reg [31:0] _GEN_4;
  reg [31:0] _GEN_11;
  reg [13:0] _GEN_5;
  reg [31:0] _GEN_12;
  reg [2:0] _GEN_6;
  reg [31:0] _GEN_13;
  _EVAL_153 a (
    ._EVAL_0(a__EVAL_0),
    ._EVAL_1(a__EVAL_1),
    ._EVAL_2(a__EVAL_2),
    ._EVAL_3(a__EVAL_3),
    ._EVAL_4(a__EVAL_4),
    ._EVAL_5(a__EVAL_5),
    ._EVAL_6(a__EVAL_6),
    ._EVAL_7(a__EVAL_7),
    ._EVAL_8(a__EVAL_8),
    ._EVAL_9(a__EVAL_9),
    ._EVAL_10(a__EVAL_10),
    ._EVAL_11(a__EVAL_11),
    ._EVAL_12(a__EVAL_12),
    ._EVAL_13(a__EVAL_13),
    ._EVAL_14(a__EVAL_14),
    ._EVAL_15(a__EVAL_15),
    ._EVAL_16(a__EVAL_16),
    ._EVAL_17(a__EVAL_17),
    ._EVAL_18(a__EVAL_18),
    ._EVAL_19(a__EVAL_19),
    ._EVAL_20(a__EVAL_20)
  );
  assign _EVAL_2 = {{1'd0}, _EVAL_46};
  assign _EVAL_3 = 1'h1;
  assign _EVAL_7 = a__EVAL_17[1:0];
  assign _EVAL_8 = _GEN_2;
  assign _EVAL_9 = 1'h0;
  assign _EVAL_11 = _GEN_3;
  assign _EVAL_13 = 32'h0;
  assign _EVAL_14 = _GEN_5;
  assign _EVAL_15 = 2'h0;
  assign _EVAL_16 = _EVAL_42;
  assign _EVAL_21 = a__EVAL_0;
  assign _EVAL_22 = a__EVAL_20;
  assign _EVAL_25 = a__EVAL_2;
  assign _EVAL_28 = a__EVAL_12;
  assign _EVAL_33 = 1'h1;
  assign _EVAL_35 = _GEN_1;
  assign _EVAL_38 = _GEN_6;
  assign _EVAL_39 = 1'h0;
  assign _EVAL_40 = _GEN_4;
  assign _EVAL_41 = _GEN_0;
  assign _EVAL_42 = a__EVAL_11 != 3'h5;
  assign _EVAL_43 = 2'h1;
  assign _EVAL_44 = 3'h4 == a__EVAL_11 ? _EVAL_48 : _EVAL_53;
  assign _EVAL_45 = 2'h1;
  assign _EVAL_46 = _EVAL_50;
  assign a__EVAL_1 = _EVAL_27;
  assign a__EVAL_3 = _EVAL_18;
  assign a__EVAL_4 = _EVAL_24;
  assign a__EVAL_5 = _EVAL_20;
  assign a__EVAL_7 = _EVAL_23;
  assign a__EVAL_8 = _EVAL_29;
  assign a__EVAL_10 = _EVAL_5;
  assign a__EVAL_15 = _EVAL_34;
  assign a__EVAL_16 = _EVAL_17;
  assign a__EVAL_18 = _EVAL_31;
  assign a__EVAL_19 = _EVAL_36;
  assign _EVAL_47 = 2'h0;
  assign _EVAL_48 = 2'h1;
  assign _EVAL_49 = 3'h2 == a__EVAL_11 ? _EVAL_45 : _EVAL_52;
  assign _EVAL_50 = 3'h5 == a__EVAL_11 ? _EVAL_51 : _EVAL_44;
  assign _EVAL_51 = 2'h2;
  assign _EVAL_52 = 3'h1 == a__EVAL_11 ? _EVAL_47 : _EVAL_54;
  assign _EVAL_53 = 3'h3 == a__EVAL_11 ? _EVAL_43 : _EVAL_49;
  assign _EVAL_54 = 2'h0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_0 = _GEN_7[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_8[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_9[13:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_10[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_11 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_11[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_12 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_12[13:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_13 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_13[2:0];
  `endif
  end
`endif
endmodule
