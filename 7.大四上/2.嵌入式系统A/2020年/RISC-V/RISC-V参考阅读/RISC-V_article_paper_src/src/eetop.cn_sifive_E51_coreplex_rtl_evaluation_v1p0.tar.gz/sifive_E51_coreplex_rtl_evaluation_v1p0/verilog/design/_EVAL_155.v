//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_155(
  input  [2:0]  _EVAL_0,
  input         _EVAL_1,
  output [2:0]  _EVAL_2,
  output        _EVAL_3,
  input  [3:0]  _EVAL_4,
  output [2:0]  _EVAL_5,
  output [3:0]  _EVAL_6,
  output        _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  input  [3:0]  _EVAL_10,
  input  [31:0] _EVAL_11,
  output [31:0] _EVAL_12,
  output        _EVAL_13,
  input         _EVAL_14,
  input  [3:0]  _EVAL_15,
  input  [13:0] _EVAL_16,
  input         _EVAL_17,
  input  [2:0]  _EVAL_18,
  output [3:0]  _EVAL_19,
  output [3:0]  _EVAL_20,
  output [13:0] _EVAL_21
);
  reg [2:0] _EVAL_22;
  reg [31:0] _GEN_0;
  reg  _EVAL_23;
  reg [31:0] _GEN_1;
  wire [3:0] _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  reg [31:0] _EVAL_28;
  reg [31:0] _GEN_2;
  wire  _EVAL_29;
  wire [3:0] _EVAL_30;
  wire [3:0] _EVAL_31;
  wire [31:0] _EVAL_32;
  wire [2:0] _EVAL_33;
  reg [2:0] _EVAL_34;
  reg [31:0] _GEN_3;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire [13:0] _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire [3:0] _EVAL_40;
  wire [2:0] _EVAL_41;
  wire [31:0] _EVAL_42;
  reg [3:0] _EVAL_43;
  reg [31:0] _GEN_4;
  reg [13:0] _EVAL_44;
  reg [31:0] _GEN_5;
  reg [3:0] _EVAL_45;
  reg [31:0] _GEN_6;
  wire [2:0] _EVAL_46;
  wire  _EVAL_47;
  wire [2:0] _EVAL_48;
  wire [3:0] _EVAL_49;
  reg [3:0] _EVAL_50;
  reg [31:0] _GEN_7;
  wire [13:0] _EVAL_51;
  wire  _EVAL_52;
  wire [3:0] _EVAL_53;
  assign _EVAL_2 = _EVAL_33;
  assign _EVAL_3 = _EVAL_23;
  assign _EVAL_5 = _EVAL_41;
  assign _EVAL_6 = _EVAL_31;
  assign _EVAL_7 = _EVAL_39;
  assign _EVAL_12 = _EVAL_42;
  assign _EVAL_13 = _EVAL_47;
  assign _EVAL_19 = _EVAL_40;
  assign _EVAL_20 = _EVAL_53;
  assign _EVAL_21 = _EVAL_37;
  assign _EVAL_24 = _EVAL_25 ? _EVAL_4 : _EVAL_43;
  assign _EVAL_25 = _EVAL_36 & _EVAL_1;
  assign _EVAL_26 = _EVAL_14 & _EVAL_7;
  assign _EVAL_27 = _EVAL_35 ? 1'h0 : _EVAL_38;
  assign _EVAL_29 = _EVAL_23 == 1'h0;
  assign _EVAL_30 = _EVAL_25 ? _EVAL_10 : _EVAL_45;
  assign _EVAL_31 = _EVAL_23 ? _EVAL_45 : _EVAL_10;
  assign _EVAL_32 = _EVAL_25 ? _EVAL_11 : _EVAL_28;
  assign _EVAL_33 = _EVAL_23 ? _EVAL_34 : _EVAL_0;
  assign _EVAL_35 = _EVAL_26 & _EVAL_52;
  assign _EVAL_36 = _EVAL_13 & _EVAL_9;
  assign _EVAL_37 = _EVAL_23 ? _EVAL_44 : _EVAL_16;
  assign _EVAL_38 = _EVAL_25 ? 1'h1 : _EVAL_23;
  assign _EVAL_39 = _EVAL_9 | _EVAL_23;
  assign _EVAL_40 = _EVAL_23 ? _EVAL_50 : _EVAL_15;
  assign _EVAL_41 = _EVAL_23 ? _EVAL_22 : _EVAL_18;
  assign _EVAL_42 = _EVAL_23 ? _EVAL_28 : _EVAL_11;
  assign _EVAL_46 = _EVAL_25 ? _EVAL_18 : _EVAL_22;
  assign _EVAL_47 = _EVAL_14 & _EVAL_29;
  assign _EVAL_48 = _EVAL_25 ? _EVAL_0 : _EVAL_34;
  assign _EVAL_49 = _EVAL_25 ? _EVAL_15 : _EVAL_50;
  assign _EVAL_51 = _EVAL_25 ? _EVAL_16 : _EVAL_44;
  assign _EVAL_52 = _EVAL_1 == 1'h0;
  assign _EVAL_53 = _EVAL_23 ? _EVAL_43 : _EVAL_4;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_22 = _GEN_0[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_23 = _GEN_1[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_28 = _GEN_2[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_34 = _GEN_3[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_43 = _GEN_4[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_44 = _GEN_5[13:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_45 = _GEN_6[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_50 = _GEN_7[3:0];
  `endif
  end
`endif
  always @(posedge _EVAL_8) begin
    if (_EVAL_25) begin
      _EVAL_22 <= _EVAL_18;
    end
    if (_EVAL_17) begin
      _EVAL_23 <= 1'h0;
    end else begin
      if (_EVAL_35) begin
        _EVAL_23 <= 1'h0;
      end else begin
        if (_EVAL_25) begin
          _EVAL_23 <= 1'h1;
        end
      end
    end
    if (_EVAL_25) begin
      _EVAL_28 <= _EVAL_11;
    end
    if (_EVAL_25) begin
      _EVAL_34 <= _EVAL_0;
    end
    if (_EVAL_25) begin
      _EVAL_43 <= _EVAL_4;
    end
    if (_EVAL_25) begin
      _EVAL_44 <= _EVAL_16;
    end
    if (_EVAL_25) begin
      _EVAL_45 <= _EVAL_10;
    end
    if (_EVAL_25) begin
      _EVAL_50 <= _EVAL_15;
    end
  end
endmodule
