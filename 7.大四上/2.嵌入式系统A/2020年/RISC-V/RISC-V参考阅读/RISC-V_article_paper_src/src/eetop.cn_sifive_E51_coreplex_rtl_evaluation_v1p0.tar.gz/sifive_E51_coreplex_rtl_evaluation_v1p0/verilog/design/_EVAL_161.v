//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_161(
  input  [2:0]  _EVAL_0,
  input         _EVAL_1,
  output        _EVAL_2,
  output [31:0] _EVAL_3,
  input  [3:0]  _EVAL_4,
  output [3:0]  _EVAL_5,
  output        _EVAL_6,
  output [3:0]  _EVAL_7,
  output        _EVAL_8,
  input  [3:0]  _EVAL_9,
  input         _EVAL_10,
  input         _EVAL_11,
  input         _EVAL_12,
  input  [3:0]  _EVAL_13,
  input         _EVAL_14,
  input  [31:0] _EVAL_15,
  input         _EVAL_16,
  output [29:0] _EVAL_17,
  output [2:0]  _EVAL_18,
  output        _EVAL_19,
  input         _EVAL_20,
  output        _EVAL_21,
  input         _EVAL_22,
  output [3:0]  _EVAL_23,
  input  [3:0]  _EVAL_24,
  output [2:0]  _EVAL_25,
  input         _EVAL_26,
  output        _EVAL_27,
  input  [1:0]  _EVAL_28,
  input  [1:0]  _EVAL_29,
  input  [2:0]  _EVAL_30,
  input         _EVAL_31,
  input  [2:0]  _EVAL_32,
  output [2:0]  _EVAL_33,
  input  [2:0]  _EVAL_34,
  output [2:0]  _EVAL_35,
  input  [2:0]  _EVAL_36,
  input  [31:0] _EVAL_37,
  input  [3:0]  _EVAL_38,
  output [1:0]  _EVAL_39,
  input         _EVAL_40,
  output [2:0]  _EVAL_41,
  input  [2:0]  _EVAL_42,
  output [29:0] _EVAL_43,
  input         _EVAL_44,
  output [31:0] _EVAL_45,
  output [3:0]  _EVAL_46,
  output [31:0] _EVAL_47,
  output        _EVAL_48,
  input  [2:0]  _EVAL_49,
  output        _EVAL_50,
  input         _EVAL_51,
  input  [1:0]  _EVAL_52,
  input  [29:0] _EVAL_53,
  input  [2:0]  _EVAL_54,
  input  [2:0]  _EVAL_55,
  input         _EVAL_56,
  input  [31:0] _EVAL_57,
  output [3:0]  _EVAL_58,
  input         _EVAL_59,
  output [1:0]  _EVAL_60,
  output        _EVAL_61,
  output        _EVAL_62,
  output [29:0] _EVAL_63,
  output [3:0]  _EVAL_64,
  output [2:0]  _EVAL_65,
  output [2:0]  _EVAL_66,
  output [2:0]  _EVAL_67,
  output [31:0] _EVAL_68,
  input  [29:0] _EVAL_69,
  input  [31:0] _EVAL_70,
  output [1:0]  _EVAL_71,
  output [2:0]  _EVAL_72,
  output        _EVAL_73,
  input  [3:0]  _EVAL_74,
  output        _EVAL_75,
  input  [29:0] _EVAL_76,
  output        _EVAL_77,
  output [2:0]  _EVAL_78,
  output        _EVAL_79,
  input         _EVAL_80,
  input  [2:0]  _EVAL_81
);
  wire  _EVAL_82;
  wire [3:0] _EVAL_83;
  wire [3:0] _EVAL_84;
  wire [4:0] _EVAL_85;
  wire  _EVAL_86;
  wire  _EVAL_87;
  wire  _EVAL_88;
  wire [4:0] _EVAL_89;
  wire  _EVAL_90;
  wire [3:0] _EVAL_91;
  wire [3:0] _EVAL_93;
  wire [3:0] _EVAL_94;
  wire [3:0] _EVAL_95;
  wire [4:0] _EVAL_96;
  wire  _EVAL_97;
  wire [3:0] _EVAL_98;
  wire [4:0] _EVAL_99;
  wire  _EVAL_100;
  reg [3:0] _EVAL_102;
  reg [31:0] _GEN_15;
  reg [3:0] _EVAL_103;
  reg [31:0] _GEN_16;
  wire  _EVAL_104;
  wire  _EVAL_105;
  wire [3:0] _EVAL_106;
  wire [12:0] _EVAL_107;
  wire [12:0] _EVAL_108;
  wire [3:0] _EVAL_109;
  wire  _EVAL_110;
  wire [3:0] _EVAL_111;
  wire [3:0] _EVAL_112;
  wire [3:0] _EVAL_113;
  wire [5:0] _EVAL_114;
  wire [4:0] _EVAL_115;
  wire  _EVAL_116;
  wire  _EVAL_117;
  wire [3:0] _EVAL_118;
  wire  _EVAL_119;
  reg [3:0] _EVAL_120;
  reg [31:0] _GEN_17;
  wire  _EVAL_121;
  wire [3:0] _EVAL_122;
  wire  _EVAL_123;
  wire [3:0] _EVAL_124;
  wire  _EVAL_125;
  wire [3:0] _EVAL_126;
  wire [4:0] _EVAL_127;
  wire [3:0] _EVAL_129;
  wire  _EVAL_130;
  wire [3:0] _EVAL_131;
  wire  _EVAL_133;
  wire [5:0] _EVAL_134;
  wire [4:0] _EVAL_135;
  wire [5:0] _EVAL_136;
  wire [3:0] _EVAL_137;
  wire  _EVAL_138;
  wire  _EVAL_139;
  wire [5:0] _EVAL_140;
  wire  _EVAL_141;
  wire  _EVAL_142;
  wire [3:0] _EVAL_143;
  reg [31:0] _GEN_0;
  reg [31:0] _GEN_18;
  reg [29:0] _GEN_1;
  reg [31:0] _GEN_19;
  reg [2:0] _GEN_2;
  reg [31:0] _GEN_20;
  reg [1:0] _GEN_3;
  reg [31:0] _GEN_21;
  reg  _GEN_4;
  reg [31:0] _GEN_22;
  reg [2:0] _GEN_5;
  reg [31:0] _GEN_23;
  reg [3:0] _GEN_6;
  reg [31:0] _GEN_24;
  reg [2:0] _GEN_7;
  reg [31:0] _GEN_25;
  reg [3:0] _GEN_8;
  reg [31:0] _GEN_26;
  reg [31:0] _GEN_9;
  reg [31:0] _GEN_27;
  reg [2:0] _GEN_10;
  reg [31:0] _GEN_28;
  reg [29:0] _GEN_11;
  reg [31:0] _GEN_29;
  reg [2:0] _GEN_12;
  reg [31:0] _GEN_30;
  reg [3:0] _GEN_13;
  reg [31:0] _GEN_31;
  reg  _GEN_14;
  reg [31:0] _GEN_32;
  assign _EVAL_2 = _EVAL_100;
  assign _EVAL_3 = _GEN_0;
  assign _EVAL_5 = _EVAL_74;
  assign _EVAL_6 = _EVAL_123;
  assign _EVAL_7 = _EVAL_9;
  assign _EVAL_8 = _EVAL_31;
  assign _EVAL_17 = _GEN_11;
  assign _EVAL_18 = _GEN_7;
  assign _EVAL_19 = 1'h0;
  assign _EVAL_21 = _EVAL_1;
  assign _EVAL_23 = _GEN_13;
  assign _EVAL_25 = _EVAL_49;
  assign _EVAL_27 = 1'h0;
  assign _EVAL_33 = _GEN_12;
  assign _EVAL_35 = _EVAL_30;
  assign _EVAL_39 = _EVAL_52;
  assign _EVAL_41 = _EVAL_0;
  assign _EVAL_43 = _GEN_1;
  assign _EVAL_45 = _EVAL_70;
  assign _EVAL_46 = _EVAL_38;
  assign _EVAL_47 = _GEN_9;
  assign _EVAL_48 = _GEN_14;
  assign _EVAL_50 = 1'h1;
  assign _EVAL_58 = _GEN_8;
  assign _EVAL_60 = _GEN_3;
  assign _EVAL_61 = _EVAL_26;
  assign _EVAL_62 = 1'h1;
  assign _EVAL_63 = _EVAL_69;
  assign _EVAL_64 = _GEN_6;
  assign _EVAL_65 = _GEN_2;
  assign _EVAL_66 = _EVAL_34;
  assign _EVAL_67 = _GEN_5;
  assign _EVAL_68 = _EVAL_57;
  assign _EVAL_71 = _EVAL_28;
  assign _EVAL_72 = _GEN_10;
  assign _EVAL_73 = _GEN_4;
  assign _EVAL_75 = _EVAL_20;
  assign _EVAL_77 = 1'h1;
  assign _EVAL_78 = _EVAL_36;
  assign _EVAL_79 = 1'h0;
  assign _EVAL_82 = _EVAL_142 & _EVAL_116;
  assign _EVAL_83 = _EVAL_139 ? _EVAL_94 : _EVAL_120;
  assign _EVAL_84 = _EVAL_130 ? _EVAL_93 : 4'h0;
  assign _EVAL_85 = $unsigned(_EVAL_115);
  assign _EVAL_86 = _EVAL_120 == 4'h0;
  assign _EVAL_87 = _EVAL_30 != 3'h6;
  assign _EVAL_88 = _EVAL_31 & _EVAL_75;
  assign _EVAL_89 = _EVAL_102 - 4'h1;
  assign _EVAL_90 = _EVAL_86 & _EVAL_87;
  assign _EVAL_91 = _EVAL_127[3:0];
  assign _EVAL_93 = _EVAL_134[5:2];
  assign _EVAL_94 = _EVAL_86 ? _EVAL_84 : _EVAL_106;
  assign _EVAL_95 = _EVAL_141 ? _EVAL_111 : 4'h0;
  assign _EVAL_96 = _EVAL_124 - _EVAL_137;
  assign _EVAL_97 = _EVAL_2 & _EVAL_11;
  assign _EVAL_98 = _EVAL_122 | 4'h7;
  assign _EVAL_99 = $unsigned(_EVAL_96);
  assign _EVAL_100 = _EVAL_59 & _EVAL_117;
  assign _EVAL_104 = _EVAL_138 & _EVAL_105;
  assign _EVAL_105 = _EVAL_113 == 4'h0;
  assign _EVAL_106 = _EVAL_85[3:0];
  assign _EVAL_107 = 13'h3f << _EVAL_0;
  assign _EVAL_108 = 13'h3f << _EVAL_49;
  assign _EVAL_109 = _EVAL_99[3:0];
  assign _EVAL_110 = _EVAL_102 == 4'h0;
  assign _EVAL_111 = _EVAL_114[5:2];
  assign _EVAL_112 = ~ _EVAL_38;
  assign _EVAL_113 = ~ _EVAL_126;
  assign _EVAL_114 = ~ _EVAL_140;
  assign _EVAL_115 = _EVAL_120 - 4'h1;
  assign _EVAL_116 = _EVAL_103 != 4'h0;
  assign _EVAL_117 = _EVAL_82 == 1'h0;
  assign _EVAL_118 = _EVAL_97 ? _EVAL_131 : _EVAL_102;
  assign _EVAL_119 = _EVAL_36[2];
  assign _EVAL_121 = _EVAL_88 & _EVAL_90;
  assign _EVAL_122 = ~ _EVAL_5;
  assign _EVAL_123 = _EVAL_11 & _EVAL_117;
  assign _EVAL_124 = _EVAL_135[3:0];
  assign _EVAL_125 = _EVAL_143 == 4'h0;
  assign _EVAL_126 = _EVAL_112 | 4'h7;
  assign _EVAL_127 = $unsigned(_EVAL_89);
  assign _EVAL_129 = {{3'd0}, _EVAL_104};
  assign _EVAL_130 = _EVAL_30[0];
  assign _EVAL_131 = _EVAL_110 ? _EVAL_95 : _EVAL_91;
  assign _EVAL_133 = _EVAL_121 & _EVAL_125;
  assign _EVAL_134 = ~ _EVAL_136;
  assign _EVAL_135 = _EVAL_103 + _EVAL_129;
  assign _EVAL_136 = _EVAL_107[5:0];
  assign _EVAL_137 = {{3'd0}, _EVAL_133};
  assign _EVAL_138 = _EVAL_97 & _EVAL_110;
  assign _EVAL_139 = _EVAL_8 & _EVAL_20;
  assign _EVAL_140 = _EVAL_108[5:0];
  assign _EVAL_141 = _EVAL_119 == 1'h0;
  assign _EVAL_142 = _EVAL_105 & _EVAL_110;
  assign _EVAL_143 = ~ _EVAL_98;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_102 = _GEN_15[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_103 = _GEN_16[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_17 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_120 = _GEN_17[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_18 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_0 = _GEN_18[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_19 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_19[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_20 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_20[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_21[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_22 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_22[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_23[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_24 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_24[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_25[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_26[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_27[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_28[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_11 = _GEN_29[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_30 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_12 = _GEN_30[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_31 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_13 = _GEN_31[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_32 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_14 = _GEN_32[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_80) begin
    if (_EVAL_22) begin
      _EVAL_102 <= 4'h0;
    end else begin
      if (_EVAL_97) begin
        if (_EVAL_110) begin
          if (_EVAL_141) begin
            _EVAL_102 <= _EVAL_111;
          end else begin
            _EVAL_102 <= 4'h0;
          end
        end else begin
          _EVAL_102 <= _EVAL_91;
        end
      end
    end
    if (_EVAL_22) begin
      _EVAL_103 <= 4'h0;
    end else begin
      _EVAL_103 <= _EVAL_109;
    end
    if (_EVAL_22) begin
      _EVAL_120 <= 4'h0;
    end else begin
      if (_EVAL_139) begin
        if (_EVAL_86) begin
          if (_EVAL_130) begin
            _EVAL_120 <= _EVAL_93;
          end else begin
            _EVAL_120 <= 4'h0;
          end
        end else begin
          _EVAL_120 <= _EVAL_106;
        end
      end
    end
  end
endmodule
