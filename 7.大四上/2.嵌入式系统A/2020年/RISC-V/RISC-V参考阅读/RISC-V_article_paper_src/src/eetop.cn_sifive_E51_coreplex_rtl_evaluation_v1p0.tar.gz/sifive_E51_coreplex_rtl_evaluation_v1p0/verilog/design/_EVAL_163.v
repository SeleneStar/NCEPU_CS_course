//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_163(
  input  [1:0]  _EVAL_0,
  output [2:0]  _EVAL_1,
  input  [29:0] _EVAL_2,
  output        _EVAL_3,
  output [1:0]  _EVAL_4,
  output [2:0]  _EVAL_5,
  output        _EVAL_6,
  input         _EVAL_7,
  input  [2:0]  _EVAL_8,
  output [31:0] _EVAL_9,
  input         _EVAL_10,
  output        _EVAL_11,
  output        _EVAL_12,
  input  [1:0]  _EVAL_13,
  output [2:0]  _EVAL_14,
  input         _EVAL_15,
  input         _EVAL_16,
  output [2:0]  _EVAL_17,
  output        _EVAL_18,
  output        _EVAL_19,
  output        _EVAL_20,
  output [3:0]  _EVAL_21,
  output        _EVAL_22,
  input  [2:0]  _EVAL_23,
  input  [3:0]  _EVAL_24,
  input  [2:0]  _EVAL_25,
  output        _EVAL_26,
  input         _EVAL_27,
  input         _EVAL_28,
  input         _EVAL_29,
  input  [31:0] _EVAL_30,
  input  [2:0]  _EVAL_31,
  output [1:0]  _EVAL_32,
  input  [3:0]  _EVAL_33,
  input         _EVAL_34,
  input  [31:0] _EVAL_35,
  input  [31:0] _EVAL_36,
  input         _EVAL_37,
  output [2:0]  _EVAL_38,
  input  [2:0]  _EVAL_39,
  output [31:0] _EVAL_40,
  output [2:0]  _EVAL_41,
  input  [2:0]  _EVAL_42,
  output        _EVAL_43,
  input         _EVAL_44,
  input  [29:0] _EVAL_45,
  output        _EVAL_46,
  input         _EVAL_47,
  input  [2:0]  _EVAL_48,
  input  [3:0]  _EVAL_49,
  output [29:0] _EVAL_50,
  output        _EVAL_51,
  output [2:0]  _EVAL_52,
  input  [2:0]  _EVAL_53,
  input         _EVAL_54,
  input         _EVAL_55,
  output [31:0] _EVAL_56,
  input         _EVAL_57,
  output [31:0] _EVAL_58,
  input  [1:0]  _EVAL_59,
  output        _EVAL_60,
  input  [29:0] _EVAL_61,
  input         _EVAL_62,
  input         _EVAL_63,
  input  [3:0]  _EVAL_64,
  output [3:0]  _EVAL_65,
  output [2:0]  _EVAL_66,
  input  [2:0]  _EVAL_67,
  output        _EVAL_68,
  output [3:0]  _EVAL_69,
  output [2:0]  _EVAL_70,
  input  [31:0] _EVAL_71,
  input  [2:0]  _EVAL_72,
  output [2:0]  _EVAL_73,
  output [3:0]  _EVAL_74,
  input         _EVAL_75,
  output        _EVAL_76,
  output [1:0]  _EVAL_77,
  output [29:0] _EVAL_78,
  output        _EVAL_79,
  input         _EVAL_80,
  output [29:0] _EVAL_81
);
  wire  _EVAL_82;
  wire [3:0] _EVAL_83;
  wire [12:0] _EVAL_84;
  wire [3:0] _EVAL_85;
  wire  _EVAL_86;
  wire [1:0] _EVAL_87;
  wire [4:0] _EVAL_88;
  wire  _EVAL_89;
  wire  _EVAL_90;
  wire  _EVAL_91;
  wire [4:0] _EVAL_92;
  wire [4:0] _EVAL_93;
  wire [3:0] _EVAL_94;
  wire [1:0] _EVAL_95;
  wire [3:0] _EVAL_96;
  wire [1:0] _EVAL_97;
  reg  _EVAL_98;
  reg [31:0] _GEN_15;
  wire  _EVAL_99;
  wire  _EVAL_100;
  wire [1:0] _EVAL_101;
  wire [1:0] _EVAL_102;
  wire [1:0] _EVAL_103;
  wire [1:0] _EVAL_104;
  wire [1:0] _EVAL_105;
  wire  _EVAL_106;
  wire [1:0] _EVAL_107;
  reg [3:0] _EVAL_108 [0:0];
  reg [31:0] _GEN_16;
  wire [3:0] _EVAL_108__EVAL_109_data;
  wire  _EVAL_108__EVAL_109_addr;
  wire [3:0] _EVAL_108__EVAL_110_data;
  wire  _EVAL_108__EVAL_110_addr;
  wire  _EVAL_108__EVAL_110_mask;
  wire  _EVAL_108__EVAL_110_en;
  wire [3:0] _EVAL_111;
  wire  _EVAL_112;
  wire [3:0] _EVAL_113;
  wire [3:0] _EVAL_114;
  wire  _EVAL_115;
  wire [5:0] _EVAL_116;
  wire  _EVAL_117;
  wire  _EVAL_118;
  reg  _EVAL_119;
  reg [31:0] _GEN_17;
  wire [12:0] _EVAL_120;
  reg [3:0] _EVAL_121;
  reg [31:0] _GEN_18;
  wire [3:0] _EVAL_122;
  wire [4:0] _EVAL_123;
  wire [1:0] _EVAL_124;
  wire [5:0] _EVAL_125;
  reg [3:0] _EVAL_126;
  reg [31:0] _GEN_19;
  wire  _EVAL_127;
  wire  _EVAL_128;
  wire [3:0] _EVAL_129;
  wire [1:0] _EVAL_130;
  wire  _EVAL_131;
  wire  _EVAL_132;
  wire  _EVAL_133;
  wire [5:0] _EVAL_134;
  wire [3:0] _EVAL_135;
  wire  _EVAL_136;
  wire  _EVAL_137;
  wire  _EVAL_138;
  wire [5:0] _EVAL_139;
  reg [2:0] _GEN_0;
  reg [31:0] _GEN_20;
  reg  _GEN_1;
  reg [31:0] _GEN_21;
  reg  _GEN_2;
  reg [31:0] _GEN_22;
  reg [29:0] _GEN_3;
  reg [31:0] _GEN_23;
  reg [2:0] _GEN_4;
  reg [31:0] _GEN_24;
  reg  _GEN_5;
  reg [31:0] _GEN_25;
  reg [31:0] _GEN_6;
  reg [31:0] _GEN_26;
  reg [3:0] _GEN_7;
  reg [31:0] _GEN_27;
  reg [31:0] _GEN_8;
  reg [31:0] _GEN_28;
  reg [3:0] _GEN_9;
  reg [31:0] _GEN_29;
  reg [29:0] _GEN_10;
  reg [31:0] _GEN_30;
  reg [2:0] _GEN_11;
  reg [31:0] _GEN_31;
  reg [2:0] _GEN_12;
  reg [31:0] _GEN_32;
  reg [1:0] _GEN_13;
  reg [31:0] _GEN_33;
  reg [2:0] _GEN_14;
  reg [31:0] _GEN_34;
  assign _EVAL_1 = _EVAL_48;
  assign _EVAL_3 = _EVAL_57;
  assign _EVAL_4 = _EVAL_59;
  assign _EVAL_5 = _GEN_0;
  assign _EVAL_6 = _EVAL_54;
  assign _EVAL_9 = _GEN_8;
  assign _EVAL_11 = _EVAL_63;
  assign _EVAL_12 = _GEN_5;
  assign _EVAL_14 = _EVAL_25;
  assign _EVAL_17 = _GEN_4;
  assign _EVAL_18 = _EVAL_100;
  assign _EVAL_19 = 1'h0;
  assign _EVAL_20 = _EVAL_55;
  assign _EVAL_21 = _GEN_7;
  assign _EVAL_22 = _GEN_1;
  assign _EVAL_26 = _GEN_2;
  assign _EVAL_32 = _EVAL_0;
  assign _EVAL_38 = _EVAL_42;
  assign _EVAL_40 = _EVAL_36;
  assign _EVAL_41 = _EVAL_72;
  assign _EVAL_43 = 1'h1;
  assign _EVAL_46 = 1'h0;
  assign _EVAL_50 = _EVAL_45;
  assign _EVAL_51 = _EVAL_132;
  assign _EVAL_52 = _GEN_14;
  assign _EVAL_56 = _EVAL_35;
  assign _EVAL_58 = _GEN_6;
  assign _EVAL_60 = 1'h1;
  assign _EVAL_65 = _EVAL_108__EVAL_109_data;
  assign _EVAL_66 = _GEN_12;
  assign _EVAL_68 = _EVAL_137;
  assign _EVAL_69 = _GEN_9;
  assign _EVAL_70 = _GEN_11;
  assign _EVAL_73 = _EVAL_53;
  assign _EVAL_74 = _EVAL_64;
  assign _EVAL_76 = 1'h1;
  assign _EVAL_77 = _GEN_13;
  assign _EVAL_78 = _GEN_3;
  assign _EVAL_79 = 1'h0;
  assign _EVAL_81 = _GEN_10;
  assign _EVAL_82 = _EVAL_99 == 1'h0;
  assign _EVAL_83 = _EVAL_118 ? _EVAL_96 : 4'h0;
  assign _EVAL_84 = 13'h3f << _EVAL_48;
  assign _EVAL_85 = _EVAL_86 ? _EVAL_94 : _EVAL_113;
  assign _EVAL_86 = _EVAL_126 == 4'h0;
  assign _EVAL_87 = _EVAL_104 | _EVAL_102;
  assign _EVAL_88 = _EVAL_126 - 4'h1;
  assign _EVAL_89 = _EVAL_86 & _EVAL_117;
  assign _EVAL_90 = _EVAL_86 & _EVAL_82;
  assign _EVAL_91 = _EVAL_121 == 4'h0;
  assign _EVAL_92 = _EVAL_121 - 4'h1;
  assign _EVAL_93 = $unsigned(_EVAL_88);
  assign _EVAL_94 = _EVAL_138 ? _EVAL_114 : 4'h0;
  assign _EVAL_95 = {{1'd0}, _EVAL_99};
  assign _EVAL_96 = _EVAL_134[5:2];
  assign _EVAL_97 = ~ _EVAL_103;
  assign _EVAL_99 = ~ _EVAL_98;
  assign _EVAL_100 = _EVAL_86 ? _EVAL_136 : _EVAL_119;
  assign _EVAL_101 = _EVAL_115 ? _EVAL_107 : 2'h0;
  assign _EVAL_102 = _EVAL_89 ? _EVAL_105 : 2'h0;
  assign _EVAL_103 = _EVAL_95 << 1;
  assign _EVAL_104 = {{1'd0}, _EVAL_98};
  assign _EVAL_105 = _EVAL_97 & _EVAL_95;
  assign _EVAL_106 = _EVAL_83 == 4'h0;
  assign _EVAL_107 = 2'h1 << _EVAL_10;
  assign _EVAL_108__EVAL_109_addr = 1'h0;
  assign _EVAL_108__EVAL_109_data = _EVAL_108[_EVAL_108__EVAL_109_addr];
  assign _EVAL_108__EVAL_110_data = _EVAL_49;
  assign _EVAL_108__EVAL_110_addr = 1'h0;
  assign _EVAL_108__EVAL_110_mask = _EVAL_89;
  assign _EVAL_108__EVAL_110_en = _EVAL_89;
  assign _EVAL_111 = _EVAL_131 ? _EVAL_135 : _EVAL_121;
  assign _EVAL_112 = _EVAL_90 == 1'h0;
  assign _EVAL_113 = _EVAL_93[3:0];
  assign _EVAL_114 = _EVAL_125[5:2];
  assign _EVAL_115 = _EVAL_127 & _EVAL_131;
  assign _EVAL_116 = _EVAL_120[5:0];
  assign _EVAL_117 = _EVAL_68 & _EVAL_28;
  assign _EVAL_118 = _EVAL_41[0];
  assign _EVAL_120 = 13'h3f << _EVAL_73;
  assign _EVAL_122 = _EVAL_123[3:0];
  assign _EVAL_123 = $unsigned(_EVAL_92);
  assign _EVAL_124 = ~ _EVAL_101;
  assign _EVAL_125 = ~ _EVAL_139;
  assign _EVAL_127 = _EVAL_128 | _EVAL_106;
  assign _EVAL_128 = _EVAL_121 == 4'h1;
  assign _EVAL_129 = _EVAL_117 ? _EVAL_85 : _EVAL_126;
  assign _EVAL_130 = _EVAL_87 & _EVAL_124;
  assign _EVAL_131 = _EVAL_54 & _EVAL_11;
  assign _EVAL_132 = _EVAL_28 & _EVAL_112;
  assign _EVAL_133 = _EVAL_25[2];
  assign _EVAL_134 = ~ _EVAL_116;
  assign _EVAL_135 = _EVAL_91 ? _EVAL_83 : _EVAL_122;
  assign _EVAL_136 = _EVAL_105[1];
  assign _EVAL_137 = _EVAL_44 & _EVAL_112;
  assign _EVAL_138 = _EVAL_133 == 1'h0;
  assign _EVAL_139 = _EVAL_84[5:0];
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_98 = _GEN_15[0:0];
  `endif
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_108[initvar] = _GEN_16[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_17 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_119 = _GEN_17[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_18 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_121 = _GEN_18[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_19 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_126 = _GEN_19[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_20 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_0 = _GEN_20[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_21[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_22 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_22[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_23[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_24 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_24[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_25[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_26[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_27[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_28[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_29[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_30 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_30[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_31 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_11 = _GEN_31[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_32 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_12 = _GEN_32[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_33 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_13 = _GEN_33[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_34 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_14 = _GEN_34[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_15) begin
    if (_EVAL_37) begin
      _EVAL_98 <= 1'h0;
    end else begin
      _EVAL_98 <= _EVAL_130[0];
    end
    if(_EVAL_108__EVAL_110_en & _EVAL_108__EVAL_110_mask) begin
      _EVAL_108[_EVAL_108__EVAL_110_addr] <= _EVAL_108__EVAL_110_data;
    end
    if (_EVAL_86) begin
      _EVAL_119 <= _EVAL_136;
    end
    if (_EVAL_37) begin
      _EVAL_121 <= 4'h0;
    end else begin
      if (_EVAL_131) begin
        if (_EVAL_91) begin
          if (_EVAL_118) begin
            _EVAL_121 <= _EVAL_96;
          end else begin
            _EVAL_121 <= 4'h0;
          end
        end else begin
          _EVAL_121 <= _EVAL_122;
        end
      end
    end
    if (_EVAL_37) begin
      _EVAL_126 <= 4'h0;
    end else begin
      if (_EVAL_117) begin
        if (_EVAL_86) begin
          if (_EVAL_138) begin
            _EVAL_126 <= _EVAL_114;
          end else begin
            _EVAL_126 <= 4'h0;
          end
        end else begin
          _EVAL_126 <= _EVAL_113;
        end
      end
    end
  end
endmodule
