//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_165(
  output [2:0]  _EVAL_0,
  output        _EVAL_1,
  output [1:0]  _EVAL_2,
  input  [2:0]  _EVAL_3,
  input  [29:0] _EVAL_4,
  input         _EVAL_5,
  input  [3:0]  _EVAL_6,
  output [3:0]  _EVAL_7,
  output [29:0] _EVAL_8,
  input         _EVAL_9,
  output        _EVAL_10,
  output [31:0] _EVAL_11,
  output        _EVAL_12,
  input  [31:0] _EVAL_13,
  input  [2:0]  _EVAL_14,
  input  [2:0]  _EVAL_15,
  input         _EVAL_16,
  input         _EVAL_17,
  output [2:0]  _EVAL_18,
  output [2:0]  _EVAL_19,
  input         _EVAL_20
);
  wire  _EVAL_21;
  reg  _EVAL_22 [0:1];
  reg [31:0] _GEN_0;
  wire  _EVAL_22__EVAL_23_data;
  wire  _EVAL_22__EVAL_23_addr;
  wire  _EVAL_22__EVAL_24_data;
  wire  _EVAL_22__EVAL_24_addr;
  wire  _EVAL_22__EVAL_24_mask;
  wire  _EVAL_22__EVAL_24_en;
  wire  _EVAL_25;
  wire [1:0] _EVAL_26;
  reg  _EVAL_27;
  reg [31:0] _GEN_1;
  reg [2:0] _EVAL_28 [0:1];
  reg [31:0] _GEN_2;
  wire [2:0] _EVAL_28__EVAL_29_data;
  wire  _EVAL_28__EVAL_29_addr;
  wire [2:0] _EVAL_28__EVAL_30_data;
  wire  _EVAL_28__EVAL_30_addr;
  wire  _EVAL_28__EVAL_30_mask;
  wire  _EVAL_28__EVAL_30_en;
  reg [2:0] _EVAL_31 [0:1];
  reg [31:0] _GEN_3;
  wire [2:0] _EVAL_31__EVAL_32_data;
  wire  _EVAL_31__EVAL_32_addr;
  wire [2:0] _EVAL_31__EVAL_33_data;
  wire  _EVAL_31__EVAL_33_addr;
  wire  _EVAL_31__EVAL_33_mask;
  wire  _EVAL_31__EVAL_33_en;
  wire  _EVAL_34;
  wire  _EVAL_35;
  reg [31:0] _EVAL_36 [0:1];
  reg [31:0] _GEN_4;
  wire [31:0] _EVAL_36__EVAL_37_data;
  wire  _EVAL_36__EVAL_37_addr;
  wire [31:0] _EVAL_36__EVAL_38_data;
  wire  _EVAL_36__EVAL_38_addr;
  wire  _EVAL_36__EVAL_38_mask;
  wire  _EVAL_36__EVAL_38_en;
  wire  _EVAL_39;
  reg [2:0] _EVAL_40 [0:1];
  reg [31:0] _GEN_5;
  wire [2:0] _EVAL_40__EVAL_41_data;
  wire  _EVAL_40__EVAL_41_addr;
  wire [2:0] _EVAL_40__EVAL_42_data;
  wire  _EVAL_40__EVAL_42_addr;
  wire  _EVAL_40__EVAL_42_mask;
  wire  _EVAL_40__EVAL_42_en;
  wire  _EVAL_43;
  wire [1:0] _EVAL_44;
  wire [1:0] _EVAL_45;
  wire  _EVAL_46;
  wire [1:0] _EVAL_47;
  wire [1:0] _EVAL_48;
  reg [3:0] _EVAL_49 [0:1];
  reg [31:0] _GEN_6;
  wire [3:0] _EVAL_49__EVAL_50_data;
  wire  _EVAL_49__EVAL_50_addr;
  wire [3:0] _EVAL_49__EVAL_51_data;
  wire  _EVAL_49__EVAL_51_addr;
  wire  _EVAL_49__EVAL_51_mask;
  wire  _EVAL_49__EVAL_51_en;
  wire  _EVAL_52;
  reg  _EVAL_53;
  reg [31:0] _GEN_7;
  wire  _EVAL_54;
  wire  _EVAL_55;
  wire  _EVAL_56;
  wire  _EVAL_57;
  wire  _EVAL_58;
  reg  _EVAL_59;
  reg [31:0] _GEN_8;
  reg [29:0] _EVAL_60 [0:1];
  reg [31:0] _GEN_9;
  wire [29:0] _EVAL_60__EVAL_61_data;
  wire  _EVAL_60__EVAL_61_addr;
  wire [29:0] _EVAL_60__EVAL_62_data;
  wire  _EVAL_60__EVAL_62_addr;
  wire  _EVAL_60__EVAL_62_mask;
  wire  _EVAL_60__EVAL_62_en;
  wire  _EVAL_63;
  wire  _EVAL_64;
  wire  _EVAL_65;
  wire  _EVAL_66;
  wire  _EVAL_67;
  assign _EVAL_0 = _EVAL_31__EVAL_32_data;
  assign _EVAL_1 = _EVAL_52;
  assign _EVAL_2 = _EVAL_45;
  assign _EVAL_7 = _EVAL_49__EVAL_50_data;
  assign _EVAL_8 = _EVAL_60__EVAL_61_data;
  assign _EVAL_10 = _EVAL_57;
  assign _EVAL_11 = _EVAL_36__EVAL_37_data;
  assign _EVAL_12 = _EVAL_22__EVAL_23_data;
  assign _EVAL_18 = _EVAL_40__EVAL_41_data;
  assign _EVAL_19 = _EVAL_28__EVAL_29_data;
  assign _EVAL_21 = _EVAL_56 != _EVAL_55;
  assign _EVAL_22__EVAL_23_addr = _EVAL_27;
  assign _EVAL_22__EVAL_23_data = _EVAL_22[_EVAL_22__EVAL_23_addr];
  assign _EVAL_22__EVAL_24_data = _EVAL_17;
  assign _EVAL_22__EVAL_24_addr = _EVAL_53;
  assign _EVAL_22__EVAL_24_mask = _EVAL_56;
  assign _EVAL_22__EVAL_24_en = _EVAL_56;
  assign _EVAL_25 = _EVAL_55 ? _EVAL_54 : _EVAL_27;
  assign _EVAL_26 = _EVAL_53 + 1'h1;
  assign _EVAL_28__EVAL_29_addr = _EVAL_27;
  assign _EVAL_28__EVAL_29_data = _EVAL_28[_EVAL_28__EVAL_29_addr];
  assign _EVAL_28__EVAL_30_data = _EVAL_15;
  assign _EVAL_28__EVAL_30_addr = _EVAL_53;
  assign _EVAL_28__EVAL_30_mask = _EVAL_56;
  assign _EVAL_28__EVAL_30_en = _EVAL_56;
  assign _EVAL_31__EVAL_32_addr = _EVAL_27;
  assign _EVAL_31__EVAL_32_data = _EVAL_31[_EVAL_31__EVAL_32_addr];
  assign _EVAL_31__EVAL_33_data = _EVAL_3;
  assign _EVAL_31__EVAL_33_addr = _EVAL_53;
  assign _EVAL_31__EVAL_33_mask = _EVAL_56;
  assign _EVAL_31__EVAL_33_en = _EVAL_56;
  assign _EVAL_34 = _EVAL_59 & _EVAL_66;
  assign _EVAL_35 = _EVAL_26[0:0];
  assign _EVAL_36__EVAL_37_addr = _EVAL_27;
  assign _EVAL_36__EVAL_37_data = _EVAL_36[_EVAL_36__EVAL_37_addr];
  assign _EVAL_36__EVAL_38_data = _EVAL_13;
  assign _EVAL_36__EVAL_38_addr = _EVAL_53;
  assign _EVAL_36__EVAL_38_mask = _EVAL_56;
  assign _EVAL_36__EVAL_38_en = _EVAL_56;
  assign _EVAL_39 = _EVAL_66 & _EVAL_59;
  assign _EVAL_40__EVAL_41_addr = _EVAL_27;
  assign _EVAL_40__EVAL_41_data = _EVAL_40[_EVAL_40__EVAL_41_addr];
  assign _EVAL_40__EVAL_42_data = _EVAL_14;
  assign _EVAL_40__EVAL_42_addr = _EVAL_53;
  assign _EVAL_40__EVAL_42_mask = _EVAL_56;
  assign _EVAL_40__EVAL_42_en = _EVAL_56;
  assign _EVAL_43 = _EVAL_21 ? _EVAL_56 : _EVAL_59;
  assign _EVAL_44 = $unsigned(_EVAL_47);
  assign _EVAL_45 = {_EVAL_34,_EVAL_58};
  assign _EVAL_46 = _EVAL_56 ? _EVAL_35 : _EVAL_53;
  assign _EVAL_47 = _EVAL_53 - _EVAL_27;
  assign _EVAL_48 = _EVAL_27 + 1'h1;
  assign _EVAL_49__EVAL_50_addr = _EVAL_27;
  assign _EVAL_49__EVAL_50_data = _EVAL_49[_EVAL_49__EVAL_50_addr];
  assign _EVAL_49__EVAL_51_data = _EVAL_6;
  assign _EVAL_49__EVAL_51_addr = _EVAL_53;
  assign _EVAL_49__EVAL_51_mask = _EVAL_56;
  assign _EVAL_49__EVAL_51_en = _EVAL_56;
  assign _EVAL_52 = _EVAL_39 == 1'h0;
  assign _EVAL_54 = _EVAL_48[0:0];
  assign _EVAL_55 = _EVAL_65;
  assign _EVAL_56 = _EVAL_63;
  assign _EVAL_57 = _EVAL_64 == 1'h0;
  assign _EVAL_58 = _EVAL_44[0:0];
  assign _EVAL_60__EVAL_61_addr = _EVAL_27;
  assign _EVAL_60__EVAL_61_data = _EVAL_60[_EVAL_60__EVAL_61_addr];
  assign _EVAL_60__EVAL_62_data = _EVAL_4;
  assign _EVAL_60__EVAL_62_addr = _EVAL_53;
  assign _EVAL_60__EVAL_62_mask = _EVAL_56;
  assign _EVAL_60__EVAL_62_en = _EVAL_56;
  assign _EVAL_63 = _EVAL_1 & _EVAL_16;
  assign _EVAL_64 = _EVAL_66 & _EVAL_67;
  assign _EVAL_65 = _EVAL_9 & _EVAL_10;
  assign _EVAL_66 = _EVAL_53 == _EVAL_27;
  assign _EVAL_67 = _EVAL_59 == 1'h0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_22[initvar] = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_27 = _GEN_1[0:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_28[initvar] = _GEN_2[2:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_31[initvar] = _GEN_3[2:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_36[initvar] = _GEN_4[31:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_40[initvar] = _GEN_5[2:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_49[initvar] = _GEN_6[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_53 = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_59 = _GEN_8[0:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_60[initvar] = _GEN_9[29:0];
  `endif
  end
`endif
  always @(posedge _EVAL_5) begin
    if(_EVAL_22__EVAL_24_en & _EVAL_22__EVAL_24_mask) begin
      _EVAL_22[_EVAL_22__EVAL_24_addr] <= _EVAL_22__EVAL_24_data;
    end
    if (_EVAL_20) begin
      _EVAL_27 <= 1'h0;
    end else begin
      if (_EVAL_55) begin
        _EVAL_27 <= _EVAL_54;
      end
    end
    if(_EVAL_28__EVAL_30_en & _EVAL_28__EVAL_30_mask) begin
      _EVAL_28[_EVAL_28__EVAL_30_addr] <= _EVAL_28__EVAL_30_data;
    end
    if(_EVAL_31__EVAL_33_en & _EVAL_31__EVAL_33_mask) begin
      _EVAL_31[_EVAL_31__EVAL_33_addr] <= _EVAL_31__EVAL_33_data;
    end
    if(_EVAL_36__EVAL_38_en & _EVAL_36__EVAL_38_mask) begin
      _EVAL_36[_EVAL_36__EVAL_38_addr] <= _EVAL_36__EVAL_38_data;
    end
    if(_EVAL_40__EVAL_42_en & _EVAL_40__EVAL_42_mask) begin
      _EVAL_40[_EVAL_40__EVAL_42_addr] <= _EVAL_40__EVAL_42_data;
    end
    if(_EVAL_49__EVAL_51_en & _EVAL_49__EVAL_51_mask) begin
      _EVAL_49[_EVAL_49__EVAL_51_addr] <= _EVAL_49__EVAL_51_data;
    end
    if (_EVAL_20) begin
      _EVAL_53 <= 1'h0;
    end else begin
      if (_EVAL_56) begin
        _EVAL_53 <= _EVAL_35;
      end
    end
    if (_EVAL_20) begin
      _EVAL_59 <= 1'h0;
    end else begin
      if (_EVAL_21) begin
        _EVAL_59 <= _EVAL_56;
      end
    end
    if(_EVAL_60__EVAL_62_en & _EVAL_60__EVAL_62_mask) begin
      _EVAL_60[_EVAL_60__EVAL_62_addr] <= _EVAL_60__EVAL_62_data;
    end
  end
endmodule
