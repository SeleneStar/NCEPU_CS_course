//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_166(
  output [1:0]  _EVAL_0,
  input         _EVAL_1,
  output        _EVAL_2,
  input         _EVAL_3,
  input  [1:0]  _EVAL_4,
  output [2:0]  _EVAL_5,
  output [31:0] _EVAL_6,
  output        _EVAL_7,
  input  [1:0]  _EVAL_8,
  output [1:0]  _EVAL_9,
  output        _EVAL_10,
  input  [2:0]  _EVAL_11,
  input         _EVAL_12,
  output        _EVAL_13,
  output [2:0]  _EVAL_14,
  input         _EVAL_15,
  input  [31:0] _EVAL_16,
  input         _EVAL_17,
  input         _EVAL_18,
  output        _EVAL_19,
  output [1:0]  _EVAL_20,
  input         _EVAL_21,
  input  [2:0]  _EVAL_22
);
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  reg  _EVAL_27 [0:1];
  reg [31:0] _GEN_0;
  wire  _EVAL_27__EVAL_28_data;
  wire  _EVAL_27__EVAL_28_addr;
  wire  _EVAL_27__EVAL_29_data;
  wire  _EVAL_27__EVAL_29_addr;
  wire  _EVAL_27__EVAL_29_mask;
  wire  _EVAL_27__EVAL_29_en;
  wire  _EVAL_30;
  reg  _EVAL_31;
  reg [31:0] _GEN_1;
  wire  _EVAL_32;
  wire [1:0] _EVAL_33;
  wire  _EVAL_34;
  reg  _EVAL_35 [0:1];
  reg [31:0] _GEN_2;
  wire  _EVAL_35__EVAL_36_data;
  wire  _EVAL_35__EVAL_36_addr;
  wire  _EVAL_35__EVAL_37_data;
  wire  _EVAL_35__EVAL_37_addr;
  wire  _EVAL_35__EVAL_37_mask;
  wire  _EVAL_35__EVAL_37_en;
  wire  _EVAL_38;
  reg [1:0] _EVAL_39 [0:1];
  reg [31:0] _GEN_3;
  wire [1:0] _EVAL_39__EVAL_40_data;
  wire  _EVAL_39__EVAL_40_addr;
  wire [1:0] _EVAL_39__EVAL_41_data;
  wire  _EVAL_39__EVAL_41_addr;
  wire  _EVAL_39__EVAL_41_mask;
  wire  _EVAL_39__EVAL_41_en;
  wire  _EVAL_42;
  wire [1:0] _EVAL_43;
  wire [1:0] _EVAL_44;
  wire  _EVAL_45;
  wire [1:0] _EVAL_46;
  wire  _EVAL_47;
  reg  _EVAL_48;
  reg [31:0] _GEN_4;
  reg [1:0] _EVAL_49 [0:1];
  reg [31:0] _GEN_5;
  wire [1:0] _EVAL_49__EVAL_50_data;
  wire  _EVAL_49__EVAL_50_addr;
  wire [1:0] _EVAL_49__EVAL_51_data;
  wire  _EVAL_49__EVAL_51_addr;
  wire  _EVAL_49__EVAL_51_mask;
  wire  _EVAL_49__EVAL_51_en;
  reg [2:0] _EVAL_52 [0:1];
  reg [31:0] _GEN_6;
  wire [2:0] _EVAL_52__EVAL_53_data;
  wire  _EVAL_52__EVAL_53_addr;
  wire [2:0] _EVAL_52__EVAL_54_data;
  wire  _EVAL_52__EVAL_54_addr;
  wire  _EVAL_52__EVAL_54_mask;
  wire  _EVAL_52__EVAL_54_en;
  wire  _EVAL_55;
  reg  _EVAL_56;
  reg [31:0] _GEN_7;
  wire  _EVAL_57;
  wire  _EVAL_58;
  wire  _EVAL_59;
  wire  _EVAL_60;
  reg  _EVAL_61 [0:1];
  reg [31:0] _GEN_8;
  wire  _EVAL_61__EVAL_62_data;
  wire  _EVAL_61__EVAL_62_addr;
  wire  _EVAL_61__EVAL_63_data;
  wire  _EVAL_61__EVAL_63_addr;
  wire  _EVAL_61__EVAL_63_mask;
  wire  _EVAL_61__EVAL_63_en;
  wire  _EVAL_64;
  reg [31:0] _EVAL_65 [0:1];
  reg [31:0] _GEN_9;
  wire [31:0] _EVAL_65__EVAL_66_data;
  wire  _EVAL_65__EVAL_66_addr;
  wire [31:0] _EVAL_65__EVAL_67_data;
  wire  _EVAL_65__EVAL_67_addr;
  wire  _EVAL_65__EVAL_67_mask;
  wire  _EVAL_65__EVAL_67_en;
  wire  _EVAL_68;
  wire [1:0] _EVAL_69;
  reg [2:0] _EVAL_70 [0:1];
  reg [31:0] _GEN_10;
  wire [2:0] _EVAL_70__EVAL_71_data;
  wire  _EVAL_70__EVAL_71_addr;
  wire [2:0] _EVAL_70__EVAL_72_data;
  wire  _EVAL_70__EVAL_72_addr;
  wire  _EVAL_70__EVAL_72_mask;
  wire  _EVAL_70__EVAL_72_en;
  assign _EVAL_0 = _EVAL_39__EVAL_40_data;
  assign _EVAL_2 = _EVAL_27__EVAL_28_data;
  assign _EVAL_5 = _EVAL_70__EVAL_71_data;
  assign _EVAL_6 = _EVAL_65__EVAL_66_data;
  assign _EVAL_7 = _EVAL_35__EVAL_36_data;
  assign _EVAL_9 = _EVAL_69;
  assign _EVAL_10 = _EVAL_25;
  assign _EVAL_13 = _EVAL_68;
  assign _EVAL_14 = _EVAL_52__EVAL_53_data;
  assign _EVAL_19 = _EVAL_61__EVAL_62_data;
  assign _EVAL_20 = _EVAL_49__EVAL_50_data;
  assign _EVAL_23 = _EVAL_26;
  assign _EVAL_24 = _EVAL_13 & _EVAL_21;
  assign _EVAL_25 = _EVAL_47 == 1'h0;
  assign _EVAL_26 = _EVAL_3 & _EVAL_10;
  assign _EVAL_27__EVAL_28_addr = _EVAL_31;
  assign _EVAL_27__EVAL_28_data = _EVAL_27[_EVAL_27__EVAL_28_addr];
  assign _EVAL_27__EVAL_29_data = _EVAL_12;
  assign _EVAL_27__EVAL_29_addr = _EVAL_48;
  assign _EVAL_27__EVAL_29_mask = _EVAL_34;
  assign _EVAL_27__EVAL_29_en = _EVAL_34;
  assign _EVAL_30 = _EVAL_56 == 1'h0;
  assign _EVAL_32 = _EVAL_57 ? _EVAL_34 : _EVAL_56;
  assign _EVAL_33 = _EVAL_48 - _EVAL_31;
  assign _EVAL_34 = _EVAL_24;
  assign _EVAL_35__EVAL_36_addr = _EVAL_31;
  assign _EVAL_35__EVAL_36_data = _EVAL_35[_EVAL_35__EVAL_36_addr];
  assign _EVAL_35__EVAL_37_data = _EVAL_15;
  assign _EVAL_35__EVAL_37_addr = _EVAL_48;
  assign _EVAL_35__EVAL_37_mask = _EVAL_34;
  assign _EVAL_35__EVAL_37_en = _EVAL_34;
  assign _EVAL_38 = _EVAL_44[0:0];
  assign _EVAL_39__EVAL_40_addr = _EVAL_31;
  assign _EVAL_39__EVAL_40_data = _EVAL_39[_EVAL_39__EVAL_40_addr];
  assign _EVAL_39__EVAL_41_data = _EVAL_8;
  assign _EVAL_39__EVAL_41_addr = _EVAL_48;
  assign _EVAL_39__EVAL_41_mask = _EVAL_34;
  assign _EVAL_39__EVAL_41_en = _EVAL_34;
  assign _EVAL_42 = _EVAL_64 & _EVAL_56;
  assign _EVAL_43 = _EVAL_31 + 1'h1;
  assign _EVAL_44 = $unsigned(_EVAL_33);
  assign _EVAL_45 = _EVAL_56 & _EVAL_64;
  assign _EVAL_46 = _EVAL_48 + 1'h1;
  assign _EVAL_47 = _EVAL_64 & _EVAL_30;
  assign _EVAL_49__EVAL_50_addr = _EVAL_31;
  assign _EVAL_49__EVAL_50_data = _EVAL_49[_EVAL_49__EVAL_50_addr];
  assign _EVAL_49__EVAL_51_data = _EVAL_4;
  assign _EVAL_49__EVAL_51_addr = _EVAL_48;
  assign _EVAL_49__EVAL_51_mask = _EVAL_34;
  assign _EVAL_49__EVAL_51_en = _EVAL_34;
  assign _EVAL_52__EVAL_53_addr = _EVAL_31;
  assign _EVAL_52__EVAL_53_data = _EVAL_52[_EVAL_52__EVAL_53_addr];
  assign _EVAL_52__EVAL_54_data = _EVAL_11;
  assign _EVAL_52__EVAL_54_addr = _EVAL_48;
  assign _EVAL_52__EVAL_54_mask = _EVAL_34;
  assign _EVAL_52__EVAL_54_en = _EVAL_34;
  assign _EVAL_55 = _EVAL_34 ? _EVAL_58 : _EVAL_48;
  assign _EVAL_57 = _EVAL_34 != _EVAL_23;
  assign _EVAL_58 = _EVAL_46[0:0];
  assign _EVAL_59 = _EVAL_43[0:0];
  assign _EVAL_60 = _EVAL_23 ? _EVAL_59 : _EVAL_31;
  assign _EVAL_61__EVAL_62_addr = _EVAL_31;
  assign _EVAL_61__EVAL_62_data = _EVAL_61[_EVAL_61__EVAL_62_addr];
  assign _EVAL_61__EVAL_63_data = _EVAL_1;
  assign _EVAL_61__EVAL_63_addr = _EVAL_48;
  assign _EVAL_61__EVAL_63_mask = _EVAL_34;
  assign _EVAL_61__EVAL_63_en = _EVAL_34;
  assign _EVAL_64 = _EVAL_48 == _EVAL_31;
  assign _EVAL_65__EVAL_66_addr = _EVAL_31;
  assign _EVAL_65__EVAL_66_data = _EVAL_65[_EVAL_65__EVAL_66_addr];
  assign _EVAL_65__EVAL_67_data = _EVAL_16;
  assign _EVAL_65__EVAL_67_addr = _EVAL_48;
  assign _EVAL_65__EVAL_67_mask = _EVAL_34;
  assign _EVAL_65__EVAL_67_en = _EVAL_34;
  assign _EVAL_68 = _EVAL_42 == 1'h0;
  assign _EVAL_69 = {_EVAL_45,_EVAL_38};
  assign _EVAL_70__EVAL_71_addr = _EVAL_31;
  assign _EVAL_70__EVAL_71_data = _EVAL_70[_EVAL_70__EVAL_71_addr];
  assign _EVAL_70__EVAL_72_data = _EVAL_22;
  assign _EVAL_70__EVAL_72_addr = _EVAL_48;
  assign _EVAL_70__EVAL_72_mask = _EVAL_34;
  assign _EVAL_70__EVAL_72_en = _EVAL_34;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_27[initvar] = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_31 = _GEN_1[0:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_35[initvar] = _GEN_2[0:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_39[initvar] = _GEN_3[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_4[0:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_49[initvar] = _GEN_5[1:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_52[initvar] = _GEN_6[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_56 = _GEN_7[0:0];
  `endif
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_61[initvar] = _GEN_8[0:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_65[initvar] = _GEN_9[31:0];
  `endif
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_70[initvar] = _GEN_10[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_17) begin
    if(_EVAL_27__EVAL_29_en & _EVAL_27__EVAL_29_mask) begin
      _EVAL_27[_EVAL_27__EVAL_29_addr] <= _EVAL_27__EVAL_29_data;
    end
    if (_EVAL_18) begin
      _EVAL_31 <= 1'h0;
    end else begin
      if (_EVAL_23) begin
        _EVAL_31 <= _EVAL_59;
      end
    end
    if(_EVAL_35__EVAL_37_en & _EVAL_35__EVAL_37_mask) begin
      _EVAL_35[_EVAL_35__EVAL_37_addr] <= _EVAL_35__EVAL_37_data;
    end
    if(_EVAL_39__EVAL_41_en & _EVAL_39__EVAL_41_mask) begin
      _EVAL_39[_EVAL_39__EVAL_41_addr] <= _EVAL_39__EVAL_41_data;
    end
    if (_EVAL_18) begin
      _EVAL_48 <= 1'h0;
    end else begin
      if (_EVAL_34) begin
        _EVAL_48 <= _EVAL_58;
      end
    end
    if(_EVAL_49__EVAL_51_en & _EVAL_49__EVAL_51_mask) begin
      _EVAL_49[_EVAL_49__EVAL_51_addr] <= _EVAL_49__EVAL_51_data;
    end
    if(_EVAL_52__EVAL_54_en & _EVAL_52__EVAL_54_mask) begin
      _EVAL_52[_EVAL_52__EVAL_54_addr] <= _EVAL_52__EVAL_54_data;
    end
    if (_EVAL_18) begin
      _EVAL_56 <= 1'h0;
    end else begin
      if (_EVAL_57) begin
        _EVAL_56 <= _EVAL_34;
      end
    end
    if(_EVAL_61__EVAL_63_en & _EVAL_61__EVAL_63_mask) begin
      _EVAL_61[_EVAL_61__EVAL_63_addr] <= _EVAL_61__EVAL_63_data;
    end
    if(_EVAL_65__EVAL_67_en & _EVAL_65__EVAL_67_mask) begin
      _EVAL_65[_EVAL_65__EVAL_67_addr] <= _EVAL_65__EVAL_67_data;
    end
    if(_EVAL_70__EVAL_72_en & _EVAL_70__EVAL_72_mask) begin
      _EVAL_70[_EVAL_70__EVAL_72_addr] <= _EVAL_70__EVAL_72_data;
    end
  end
endmodule
