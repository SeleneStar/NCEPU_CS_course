//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_175(
  output [3:0] _EVAL_0,
  input        _EVAL_1,
  input        _EVAL_2,
  input        _EVAL_3,
  input        _EVAL_4
);
  wire [3:0] _EVAL_5;
  wire  _EVAL_6;
  wire  _EVAL_7;
  wire [3:0] _EVAL_8;
  wire [3:0] _EVAL_9;
  wire [3:0] _EVAL_10;
  wire  _EVAL_11;
  wire [3:0] _EVAL_12;
  wire [3:0] _EVAL_13;
  wire  _EVAL_14;
  wire [3:0] _EVAL_15;
  wire [3:0] _EVAL_16;
  wire [3:0] _EVAL_17;
  wire  _EVAL_18;
  wire  _EVAL_19;
  wire [3:0] _EVAL_20;
  wire [3:0] _EVAL_21;
  wire  _EVAL_22;
  wire [3:0] _EVAL_23;
  wire [3:0] _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire [3:0] _EVAL_27;
  wire [3:0] _EVAL_28;
  wire [3:0] _EVAL_29;
  wire  _EVAL_30;
  wire [3:0] _EVAL_31;
  wire [3:0] _EVAL_32;
  wire [3:0] _EVAL_33;
  wire [3:0] _EVAL_34;
  wire [3:0] _EVAL_35;
  wire  _EVAL_36;
  wire [3:0] _EVAL_37;
  wire [3:0] _EVAL_38;
  wire [3:0] _EVAL_39;
  wire  _EVAL_40;
  wire  currStateReg__EVAL_0;
  wire [3:0] currStateReg__EVAL_1;
  wire  currStateReg__EVAL_2;
  wire [3:0] currStateReg__EVAL_3;
  wire  currStateReg__EVAL_4;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire [3:0] _EVAL_43;
  wire [3:0] _EVAL_44;
  wire [3:0] _EVAL_45;
  wire  _EVAL_46;
  wire [3:0] _EVAL_47;
  _EVAL_174 currStateReg (
    ._EVAL_0(currStateReg__EVAL_0),
    ._EVAL_1(currStateReg__EVAL_1),
    ._EVAL_2(currStateReg__EVAL_2),
    ._EVAL_3(currStateReg__EVAL_3),
    ._EVAL_4(currStateReg__EVAL_4)
  );
  assign _EVAL_0 = currStateReg__EVAL_1;
  assign _EVAL_5 = _EVAL_1 ? 4'h5 : 4'h2;
  assign _EVAL_6 = 4'h4 == currStateReg__EVAL_1;
  assign _EVAL_7 = 4'he == currStateReg__EVAL_1;
  assign _EVAL_8 = _EVAL_1 ? 4'hf : 4'hc;
  assign _EVAL_9 = _EVAL_1 ? 4'h9 : 4'ha;
  assign _EVAL_10 = _EVAL_7 ? _EVAL_9 : _EVAL_47;
  assign _EVAL_11 = 4'ha == currStateReg__EVAL_1;
  assign _EVAL_12 = _EVAL_17;
  assign _EVAL_13 = _EVAL_25 ? _EVAL_23 : _EVAL_33;
  assign _EVAL_14 = 4'h1 == currStateReg__EVAL_1;
  assign _EVAL_15 = _EVAL_18 ? _EVAL_45 : _EVAL_16;
  assign _EVAL_16 = _EVAL_19 ? _EVAL_5 : _EVAL_44;
  assign _EVAL_17 = _EVAL_42 ? _EVAL_45 : _EVAL_28;
  assign _EVAL_18 = 4'h5 == currStateReg__EVAL_1;
  assign _EVAL_19 = 4'h0 == currStateReg__EVAL_1;
  assign _EVAL_20 = _EVAL_1 ? 4'hd : 4'ha;
  assign _EVAL_21 = _EVAL_30 ? _EVAL_39 : _EVAL_29;
  assign _EVAL_22 = 4'hb == currStateReg__EVAL_1;
  assign _EVAL_23 = _EVAL_1 ? 4'h1 : 4'h2;
  assign _EVAL_24 = _EVAL_22 ? _EVAL_31 : _EVAL_21;
  assign _EVAL_25 = 4'h2 == currStateReg__EVAL_1;
  assign _EVAL_26 = 4'hc == currStateReg__EVAL_1;
  assign _EVAL_27 = _EVAL_1 ? 4'h4 : 4'h6;
  assign _EVAL_28 = _EVAL_40 ? _EVAL_20 : _EVAL_24;
  assign _EVAL_29 = _EVAL_11 ? _EVAL_9 : _EVAL_10;
  assign _EVAL_30 = 4'h9 == currStateReg__EVAL_1;
  assign _EVAL_31 = _EVAL_1 ? 4'h8 : 4'hb;
  assign _EVAL_32 = _EVAL_1 ? 4'hf : 4'he;
  assign _EVAL_33 = _EVAL_46 ? _EVAL_23 : _EVAL_43;
  assign _EVAL_34 = _EVAL_1 ? 4'h5 : 4'h3;
  assign _EVAL_35 = _EVAL_1 ? 4'h0 : 4'h3;
  assign _EVAL_36 = 4'h7 == currStateReg__EVAL_1;
  assign _EVAL_37 = _EVAL_14 ? _EVAL_34 : _EVAL_13;
  assign _EVAL_38 = _EVAL_26 ? _EVAL_45 : _EVAL_8;
  assign _EVAL_39 = _EVAL_1 ? 4'hd : 4'hb;
  assign _EVAL_40 = 4'h8 == currStateReg__EVAL_1;
  assign currStateReg__EVAL_0 = _EVAL_4;
  assign currStateReg__EVAL_2 = 1'h1;
  assign currStateReg__EVAL_3 = _EVAL_12;
  assign currStateReg__EVAL_4 = _EVAL_3;
  assign _EVAL_41 = 4'h3 == currStateReg__EVAL_1;
  assign _EVAL_42 = 4'hd == currStateReg__EVAL_1;
  assign _EVAL_43 = _EVAL_36 ? _EVAL_27 : _EVAL_38;
  assign _EVAL_44 = _EVAL_41 ? _EVAL_35 : _EVAL_37;
  assign _EVAL_45 = _EVAL_1 ? 4'h7 : 4'hc;
  assign _EVAL_46 = 4'h6 == currStateReg__EVAL_1;
  assign _EVAL_47 = _EVAL_6 ? _EVAL_32 : _EVAL_15;
endmodule
