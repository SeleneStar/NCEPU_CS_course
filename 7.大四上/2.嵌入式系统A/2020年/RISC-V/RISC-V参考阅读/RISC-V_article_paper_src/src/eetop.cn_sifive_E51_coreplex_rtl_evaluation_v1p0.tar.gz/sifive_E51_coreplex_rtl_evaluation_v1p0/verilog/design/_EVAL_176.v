//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_176(
  input  [4:0] _EVAL_0,
  input        _EVAL_1,
  output       _EVAL_2,
  output       _EVAL_3,
  output [4:0] _EVAL_4,
  input        _EVAL_5,
  input        _EVAL_6,
  input        _EVAL_7,
  output       _EVAL_8,
  input        _EVAL_9,
  output       _EVAL_10,
  output       _EVAL_11,
  input        _EVAL_12,
  output       _EVAL_13
);
  wire [1:0] _EVAL_14;
  wire  _EVAL_15;
  wire  _EVAL_16;
  reg  _EVAL_17;
  reg [31:0] _GEN_0;
  wire  _EVAL_18;
  wire  _EVAL_19;
  wire  _EVAL_21;
  wire [1:0] _EVAL_22;
  wire  _EVAL_23;
  wire [2:0] _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire  _EVAL_28;
  wire  _EVAL_29;
  reg  _EVAL_32;
  reg [31:0] _GEN_1;
  wire  _EVAL_33;
  wire  _EVAL_35;
  reg  _EVAL_36;
  reg [31:0] _GEN_2;
  wire  _EVAL_37;
  reg  _EVAL_39;
  reg [31:0] _GEN_3;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_43;
  wire [4:0] _EVAL_44;
  wire  _EVAL_45;
  wire [4:0] _EVAL_46;
  wire  _EVAL_47;
  wire  _EVAL_48;
  wire  _EVAL_49;
  wire  _EVAL_52;
  wire  _EVAL_53;
  wire  _EVAL_55;
  wire  _EVAL_56;
  wire  _EVAL_57;
  reg  _EVAL_58;
  reg [31:0] _GEN_4;
  wire  _EVAL_59;
  assign _EVAL_2 = _EVAL_39;
  assign _EVAL_3 = _EVAL_12;
  assign _EVAL_4 = _EVAL_44;
  assign _EVAL_8 = _EVAL_9;
  assign _EVAL_10 = _EVAL_18;
  assign _EVAL_11 = _EVAL_49;
  assign _EVAL_13 = _EVAL_5;
  assign _EVAL_14 = {_EVAL_58,_EVAL_39};
  assign _EVAL_15 = _EVAL_42 ? _EVAL_32 : _EVAL_35;
  assign _EVAL_16 = _EVAL_33 & _EVAL_9;
  assign _EVAL_18 = _EVAL_45 ? 1'h0 : _EVAL_57;
  assign _EVAL_19 = _EVAL_42 ? 1'h0 : _EVAL_16;
  assign _EVAL_21 = _EVAL_5 ? _EVAL_25 : _EVAL_39;
  assign _EVAL_22 = {_EVAL_36,_EVAL_17};
  assign _EVAL_23 = _EVAL_33 & _EVAL_53;
  assign _EVAL_24 = {_EVAL_22,_EVAL_32};
  assign _EVAL_25 = _EVAL_0[0];
  assign _EVAL_26 = _EVAL_42 ? _EVAL_58 : _EVAL_21;
  assign _EVAL_27 = _EVAL_0[4];
  assign _EVAL_28 = _EVAL_12 == 1'h0;
  assign _EVAL_29 = _EVAL_0[3];
  assign _EVAL_33 = _EVAL_5 == 1'h0;
  assign _EVAL_35 = _EVAL_5 ? _EVAL_37 : _EVAL_58;
  assign _EVAL_37 = _EVAL_0[1];
  assign _EVAL_41 = _EVAL_42 ? _EVAL_36 : _EVAL_48;
  assign _EVAL_42 = _EVAL_23 & _EVAL_12;
  assign _EVAL_43 = _EVAL_5 ? _EVAL_59 : _EVAL_32;
  assign _EVAL_44 = _EVAL_46;
  assign _EVAL_45 = _EVAL_23 & _EVAL_28;
  assign _EVAL_46 = {_EVAL_24,_EVAL_14};
  assign _EVAL_47 = _EVAL_16 ? 1'h0 : 1'h1;
  assign _EVAL_48 = _EVAL_5 ? _EVAL_29 : _EVAL_17;
  assign _EVAL_49 = _EVAL_45 ? 1'h0 : _EVAL_19;
  assign _EVAL_52 = _EVAL_42 ? _EVAL_6 : _EVAL_56;
  assign _EVAL_53 = _EVAL_9 == 1'h0;
  assign _EVAL_55 = _EVAL_42 ? _EVAL_17 : _EVAL_43;
  assign _EVAL_56 = _EVAL_5 ? _EVAL_27 : _EVAL_36;
  assign _EVAL_57 = _EVAL_42 ? 1'h0 : _EVAL_47;
  assign _EVAL_59 = _EVAL_0[2];
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_17 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_32 = _GEN_1[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_36 = _GEN_2[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_39 = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_58 = _GEN_4[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_1) begin
    if (_EVAL_42) begin
      _EVAL_17 <= _EVAL_36;
    end else begin
      if (_EVAL_5) begin
        _EVAL_17 <= _EVAL_29;
      end
    end
    if (_EVAL_42) begin
      _EVAL_32 <= _EVAL_17;
    end else begin
      if (_EVAL_5) begin
        _EVAL_32 <= _EVAL_59;
      end
    end
    if (_EVAL_42) begin
      _EVAL_36 <= _EVAL_6;
    end else begin
      if (_EVAL_5) begin
        _EVAL_36 <= _EVAL_27;
      end
    end
    if (_EVAL_42) begin
      _EVAL_39 <= _EVAL_58;
    end else begin
      if (_EVAL_5) begin
        _EVAL_39 <= _EVAL_25;
      end
    end
    if (_EVAL_42) begin
      _EVAL_58 <= _EVAL_32;
    end else begin
      if (_EVAL_5) begin
        _EVAL_58 <= _EVAL_37;
      end
    end
  end
endmodule
