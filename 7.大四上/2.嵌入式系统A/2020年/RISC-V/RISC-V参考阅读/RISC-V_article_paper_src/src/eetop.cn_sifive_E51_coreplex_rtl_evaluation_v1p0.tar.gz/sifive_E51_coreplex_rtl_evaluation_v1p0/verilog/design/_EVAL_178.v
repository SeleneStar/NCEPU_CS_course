//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_178(
  input        _EVAL_0,
  output       _EVAL_1,
  input        _EVAL_2,
  input        _EVAL_3,
  output       _EVAL_4,
  output       _EVAL_5,
  input        _EVAL_6,
  output [3:0] _EVAL_7,
  input        _EVAL_8,
  input        _EVAL_9,
  output       _EVAL_10,
  output       _EVAL_11,
  input        _EVAL_12,
  output       _EVAL_13,
  output [4:0] _EVAL_14,
  output       _EVAL_15,
  input        _EVAL_16,
  input        _EVAL_17,
  input        _EVAL_18
);
  wire  _EVAL_19;
  wire  _EVAL_20;
  wire  tdoeReg__EVAL_0;
  wire  tdoeReg__EVAL_1;
  wire  tdoeReg__EVAL_2;
  wire  tdoeReg__EVAL_3;
  wire  tdoeReg__EVAL_4;
  wire  _EVAL_21;
  wire  _EVAL_22;
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire [4:0] _EVAL_28;
  wire [4:0] _EVAL_29;
  wire [3:0] stateMachine__EVAL_0;
  wire  stateMachine__EVAL_1;
  wire  stateMachine__EVAL_2;
  wire  stateMachine__EVAL_3;
  wire  stateMachine__EVAL_4;
  wire  _EVAL_30;
  wire  irReg__EVAL_0;
  wire [4:0] irReg__EVAL_1;
  wire [4:0] irReg__EVAL_2;
  wire  irReg__EVAL_3;
  wire  irReg__EVAL_4;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire  _EVAL_40;
  wire  _EVAL_41;
  wire [4:0] irChain__EVAL_0;
  wire  irChain__EVAL_1;
  wire  irChain__EVAL_2;
  wire  irChain__EVAL_3;
  wire [4:0] irChain__EVAL_4;
  wire  irChain__EVAL_5;
  wire  irChain__EVAL_6;
  wire  irChain__EVAL_7;
  wire  irChain__EVAL_8;
  wire  irChain__EVAL_9;
  wire  irChain__EVAL_10;
  wire  irChain__EVAL_11;
  wire  irChain__EVAL_12;
  wire  irChain__EVAL_13;
  wire  tdoReg__EVAL_0;
  wire  tdoReg__EVAL_1;
  wire  tdoReg__EVAL_2;
  wire  tdoReg__EVAL_3;
  wire  tdoReg__EVAL_4;
  wire  _EVAL_42;
  wire  _EVAL_43;
  wire  _EVAL_44;
  _EVAL_173 tdoeReg (
    ._EVAL_0(tdoeReg__EVAL_0),
    ._EVAL_1(tdoeReg__EVAL_1),
    ._EVAL_2(tdoeReg__EVAL_2),
    ._EVAL_3(tdoeReg__EVAL_3),
    ._EVAL_4(tdoeReg__EVAL_4)
  );
  _EVAL_175 stateMachine (
    ._EVAL_0(stateMachine__EVAL_0),
    ._EVAL_1(stateMachine__EVAL_1),
    ._EVAL_2(stateMachine__EVAL_2),
    ._EVAL_3(stateMachine__EVAL_3),
    ._EVAL_4(stateMachine__EVAL_4)
  );
  _EVAL_177 irReg (
    ._EVAL_0(irReg__EVAL_0),
    ._EVAL_1(irReg__EVAL_1),
    ._EVAL_2(irReg__EVAL_2),
    ._EVAL_3(irReg__EVAL_3),
    ._EVAL_4(irReg__EVAL_4)
  );
  _EVAL_176 irChain (
    ._EVAL_0(irChain__EVAL_0),
    ._EVAL_1(irChain__EVAL_1),
    ._EVAL_2(irChain__EVAL_2),
    ._EVAL_3(irChain__EVAL_3),
    ._EVAL_4(irChain__EVAL_4),
    ._EVAL_5(irChain__EVAL_5),
    ._EVAL_6(irChain__EVAL_6),
    ._EVAL_7(irChain__EVAL_7),
    ._EVAL_8(irChain__EVAL_8),
    ._EVAL_9(irChain__EVAL_9),
    ._EVAL_10(irChain__EVAL_10),
    ._EVAL_11(irChain__EVAL_11),
    ._EVAL_12(irChain__EVAL_12),
    ._EVAL_13(irChain__EVAL_13)
  );
  _EVAL_173 tdoReg (
    ._EVAL_0(tdoReg__EVAL_0),
    ._EVAL_1(tdoReg__EVAL_1),
    ._EVAL_2(tdoReg__EVAL_2),
    ._EVAL_3(tdoReg__EVAL_3),
    ._EVAL_4(tdoReg__EVAL_4)
  );
  assign _EVAL_1 = _EVAL_20;
  assign _EVAL_4 = _EVAL_23;
  assign _EVAL_5 = tdoeReg__EVAL_0;
  assign _EVAL_7 = stateMachine__EVAL_0;
  assign _EVAL_10 = _EVAL_27;
  assign _EVAL_11 = _EVAL_35;
  assign _EVAL_13 = _EVAL_12;
  assign _EVAL_14 = irReg__EVAL_1;
  assign _EVAL_15 = tdoReg__EVAL_0;
  assign _EVAL_19 = _EVAL_35 == 1'h0;
  assign _EVAL_20 = stateMachine__EVAL_0 == 4'hf;
  assign tdoeReg__EVAL_1 = _EVAL_9;
  assign tdoeReg__EVAL_2 = 1'h1;
  assign tdoeReg__EVAL_3 = _EVAL_21;
  assign tdoeReg__EVAL_4 = _EVAL_36;
  assign _EVAL_21 = $unsigned(_EVAL_40);
  assign _EVAL_22 = _EVAL_31 & _EVAL_33;
  assign _EVAL_23 = stateMachine__EVAL_0 == 4'h5;
  assign _EVAL_24 = stateMachine__EVAL_0 == 4'hd;
  assign _EVAL_25 = stateMachine__EVAL_0 == 4'ha;
  assign _EVAL_26 = $unsigned(_EVAL_16);
  assign _EVAL_27 = stateMachine__EVAL_0 == 4'h6;
  assign _EVAL_28 = _EVAL_37 ? irChain__EVAL_4 : 5'h1;
  assign _EVAL_29 = _EVAL_28;
  assign stateMachine__EVAL_1 = _EVAL_3;
  assign stateMachine__EVAL_2 = 1'h0;
  assign stateMachine__EVAL_3 = _EVAL_17;
  assign stateMachine__EVAL_4 = _EVAL_16;
  assign _EVAL_30 = _EVAL_25 == 1'h0;
  assign irReg__EVAL_0 = _EVAL_21;
  assign irReg__EVAL_2 = _EVAL_29;
  assign irReg__EVAL_3 = _EVAL_44;
  assign irReg__EVAL_4 = _EVAL_9;
  assign _EVAL_31 = _EVAL_9 == 1'h0;
  assign _EVAL_32 = stateMachine__EVAL_0 == 4'he;
  assign _EVAL_33 = _EVAL_24 == 1'h0;
  assign _EVAL_34 = _EVAL_22 ? 1'h0 : 1'h1;
  assign _EVAL_35 = stateMachine__EVAL_0 == 4'h2;
  assign _EVAL_36 = _EVAL_43;
  assign _EVAL_37 = _EVAL_31 & _EVAL_24;
  assign _EVAL_38 = _EVAL_41;
  assign _EVAL_39 = _EVAL_19 & _EVAL_30;
  assign _EVAL_40 = _EVAL_26 == 1'h0;
  assign _EVAL_41 = _EVAL_42 ? irChain__EVAL_2 : _EVAL_6;
  assign irChain__EVAL_0 = 5'h1;
  assign irChain__EVAL_1 = _EVAL_16;
  assign irChain__EVAL_5 = _EVAL_32;
  assign irChain__EVAL_6 = _EVAL_12;
  assign irChain__EVAL_7 = _EVAL_9;
  assign irChain__EVAL_9 = _EVAL_24;
  assign irChain__EVAL_12 = _EVAL_25;
  assign tdoReg__EVAL_1 = _EVAL_9;
  assign tdoReg__EVAL_2 = 1'h1;
  assign tdoReg__EVAL_3 = _EVAL_21;
  assign tdoReg__EVAL_4 = _EVAL_38;
  assign _EVAL_42 = _EVAL_19 & _EVAL_25;
  assign _EVAL_43 = _EVAL_39 ? 1'h0 : 1'h1;
  assign _EVAL_44 = _EVAL_34;
endmodule
