//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_180(
  output [6:0]  _EVAL_0,
  output [1:0]  _EVAL_1,
  input         _EVAL_2,
  input         _EVAL_3,
  input         _EVAL_4,
  input         _EVAL_5,
  output        _EVAL_6,
  input  [10:0] _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  input  [1:0]  _EVAL_10,
  output        _EVAL_11,
  output [31:0] _EVAL_12,
  input         _EVAL_13,
  input         _EVAL_14,
  input  [31:0] _EVAL_15,
  output        _EVAL_16,
  output        _EVAL_17,
  output        _EVAL_18
);
  wire [31:0] _EVAL_20;
  wire  _EVAL_21;
  wire  _EVAL_23;
  wire  _EVAL_25;
  wire  _EVAL_27;
  wire  _EVAL_28;
  wire  _EVAL_29;
  reg  _EVAL_30;
  reg [31:0] _GEN_0;
  wire [6:0] _EVAL_33;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  dtmInfoChain__EVAL_0;
  wire  dtmInfoChain__EVAL_1;
  wire [1:0] dtmInfoChain__EVAL_2;
  wire [2:0] dtmInfoChain__EVAL_3;
  wire  dtmInfoChain__EVAL_4;
  wire  dtmInfoChain__EVAL_5;
  wire  dtmInfoChain__EVAL_6;
  wire  dtmInfoChain__EVAL_7;
  wire [3:0] dtmInfoChain__EVAL_8;
  wire  dtmInfoChain__EVAL_9;
  wire  dtmInfoChain__EVAL_10;
  wire  dtmInfoChain__EVAL_11;
  wire [3:0] dtmInfoChain__EVAL_12;
  wire  dtmInfoChain__EVAL_13;
  wire [5:0] dtmInfoChain__EVAL_14;
  wire  dtmInfoChain__EVAL_15;
  wire [2:0] dtmInfoChain__EVAL_16;
  wire  dtmInfoChain__EVAL_17;
  wire  dtmInfoChain__EVAL_18;
  wire [5:0] dtmInfoChain__EVAL_19;
  wire [14:0] dtmInfoChain__EVAL_20;
  wire  dtmInfoChain__EVAL_21;
  wire [1:0] dtmInfoChain__EVAL_22;
  wire  dtmInfoChain__EVAL_23;
  wire  dtmInfoChain__EVAL_24;
  wire [14:0] dtmInfoChain__EVAL_25;
  wire  _EVAL_37;
  wire [15:0] _EVAL_39;
  wire  _EVAL_40;
  wire [10:0] _EVAL_41;
  wire [31:0] _EVAL_43;
  wire [1:0] _EVAL_44;
  wire  _EVAL_45;
  wire  _EVAL_47;
  wire [2:0] _EVAL_48;
  wire  _EVAL_49;
  wire  _EVAL_50;
  wire [31:0] _EVAL_51;
  wire [6:0] _EVAL_52;
  wire  _EVAL_53;
  wire  _EVAL_54;
  wire  _EVAL_55;
  wire  JtagTapController__EVAL_0;
  wire  JtagTapController__EVAL_1;
  wire  JtagTapController__EVAL_2;
  wire  JtagTapController__EVAL_3;
  wire  JtagTapController__EVAL_4;
  wire  JtagTapController__EVAL_5;
  wire  JtagTapController__EVAL_6;
  wire [3:0] JtagTapController__EVAL_7;
  wire  JtagTapController__EVAL_8;
  wire  JtagTapController__EVAL_9;
  wire  JtagTapController__EVAL_10;
  wire  JtagTapController__EVAL_11;
  wire  JtagTapController__EVAL_12;
  wire  JtagTapController__EVAL_13;
  wire [4:0] JtagTapController__EVAL_14;
  wire  JtagTapController__EVAL_15;
  wire  JtagTapController__EVAL_16;
  wire  JtagTapController__EVAL_17;
  wire  JtagTapController__EVAL_18;
  wire  _EVAL_57;
  wire  _EVAL_59;
  wire  _EVAL_60;
  wire  _EVAL_61;
  wire  _EVAL_62;
  wire [1:0] _EVAL_64;
  wire  _EVAL_65;
  reg  _EVAL_66;
  reg [31:0] _GEN_1;
  wire [14:0] _EVAL_67;
  wire  _EVAL_69;
  wire [1:0] _EVAL_70;
  wire  _EVAL_72;
  wire [15:0] _EVAL_73;
  wire  _EVAL_74;
  wire  _EVAL_75;
  wire  _EVAL_76;
  wire  _EVAL_77;
  wire  _EVAL_78;
  wire  _EVAL_79;
  wire  _EVAL_80;
  wire  _EVAL_81;
  wire  _EVAL_83;
  wire  _EVAL_84;
  wire  _EVAL_85;
  wire  _EVAL_86;
  wire  _EVAL_87;
  wire [6:0] _EVAL_88;
  wire [31:0] _EVAL_89;
  wire [31:0] _EVAL_91;
  wire  _EVAL_92;
  reg [31:0] _EVAL_93;
  reg [31:0] _GEN_2;
  wire  _EVAL_94;
  wire [3:0] _EVAL_95;
  wire  _EVAL_96;
  wire  _EVAL_97;
  wire  _EVAL_98;
  wire  _EVAL_100;
  wire  _EVAL_101;
  reg [6:0] _EVAL_103;
  reg [31:0] _GEN_3;
  wire  _EVAL_104;
  wire [31:0] _EVAL_108;
  wire [6:0] _EVAL_109;
  wire  _EVAL_110;
  wire  _EVAL_111;
  wire  JtagBypassChain__EVAL_0;
  wire  JtagBypassChain__EVAL_1;
  wire  JtagBypassChain__EVAL_2;
  wire  JtagBypassChain__EVAL_3;
  wire  JtagBypassChain__EVAL_4;
  wire  JtagBypassChain__EVAL_5;
  wire  JtagBypassChain__EVAL_6;
  wire  JtagBypassChain__EVAL_7;
  wire  JtagBypassChain__EVAL_8;
  wire  JtagBypassChain__EVAL_9;
  reg  _EVAL_114;
  reg [31:0] _GEN_4;
  wire  idcodeChain__EVAL_0;
  wire  idcodeChain__EVAL_1;
  wire  idcodeChain__EVAL_2;
  wire  idcodeChain__EVAL_3;
  wire  idcodeChain__EVAL_4;
  wire  idcodeChain__EVAL_5;
  wire  idcodeChain__EVAL_6;
  wire  idcodeChain__EVAL_7;
  wire [10:0] idcodeChain__EVAL_8;
  wire [3:0] idcodeChain__EVAL_9;
  wire  idcodeChain__EVAL_10;
  wire  idcodeChain__EVAL_11;
  wire  idcodeChain__EVAL_12;
  wire  idcodeChain__EVAL_13;
  wire [15:0] idcodeChain__EVAL_14;
  wire  _EVAL_118;
  wire [6:0] _EVAL_119;
  wire  _EVAL_120;
  wire [1:0] _EVAL_121;
  wire  _EVAL_122;
  wire  _EVAL_123;
  reg  _EVAL_124;
  reg [31:0] _GEN_5;
  wire [1:0] _EVAL_125;
  wire [1:0] _EVAL_129;
  wire  _EVAL_130;
  wire  _EVAL_131;
  wire  _EVAL_132;
  wire  _EVAL_133;
  wire  _EVAL_134;
  wire  _EVAL_135;
  wire [31:0] dmiAccessChain__EVAL_0;
  wire [6:0] dmiAccessChain__EVAL_1;
  wire [1:0] dmiAccessChain__EVAL_2;
  wire  dmiAccessChain__EVAL_3;
  wire [1:0] dmiAccessChain__EVAL_4;
  wire  dmiAccessChain__EVAL_5;
  wire  dmiAccessChain__EVAL_6;
  wire  dmiAccessChain__EVAL_7;
  wire  dmiAccessChain__EVAL_8;
  wire  dmiAccessChain__EVAL_9;
  wire [6:0] dmiAccessChain__EVAL_10;
  wire  dmiAccessChain__EVAL_11;
  wire  dmiAccessChain__EVAL_12;
  wire  dmiAccessChain__EVAL_13;
  wire  dmiAccessChain__EVAL_14;
  wire  dmiAccessChain__EVAL_15;
  wire  dmiAccessChain__EVAL_16;
  wire [31:0] dmiAccessChain__EVAL_17;
  wire  _EVAL_136;
  wire [3:0] _EVAL_138;
  wire [6:0] _EVAL_139;
  wire  _EVAL_140;
  wire  _EVAL_142;
  wire [3:0] _EVAL_143;
  wire  _EVAL_144;
  wire [1:0] _EVAL_145;
  wire  _EVAL_146;
  wire  _EVAL_147;
  wire [6:0] _EVAL_148;
  reg  _EVAL_149;
  reg [31:0] _GEN_6;
  wire  _EVAL_150;
  wire  _EVAL_151;
  wire [31:0] _EVAL_152;
  wire [1:0] _EVAL_153;
  wire  _EVAL_154;
  wire  _EVAL_155;
  wire [1:0] _EVAL_156;
  reg  _EVAL_157;
  reg [31:0] _GEN_7;
  wire  _EVAL_158;
  wire  _EVAL_159;
  wire  _EVAL_162;
  wire  _EVAL_163;
  wire  _EVAL_164;
  wire  _EVAL_165;
  wire [1:0] _EVAL_166;
  wire  _EVAL_167;
  wire [1:0] _EVAL_168;
  wire  _EVAL_169;
  wire [6:0] _EVAL_171;
  wire [5:0] _EVAL_172;
  wire [31:0] _EVAL_173;
  wire  _EVAL_174;
  wire  _EVAL_175;
  wire  _EVAL_176;
  wire  _EVAL_177;
  wire  _EVAL_178;
  wire  _EVAL_180;
  wire  _EVAL_181;
  wire  _EVAL_182;
  wire  _EVAL_183;
  wire  _EVAL_184;
  wire  _EVAL_185;
  wire  _EVAL_186;
  wire  _EVAL_187;
  wire  _EVAL_189;
  wire  _EVAL_190;
  reg [1:0] _EVAL_191;
  reg [31:0] _GEN_8;
  wire  _EVAL_193;
  wire  _EVAL_194;
  wire  _EVAL_197;
  wire  _EVAL_199;
  wire [10:0] _EVAL_200;
  wire  _EVAL_201;
  wire  _EVAL_203;
  _EVAL_170 dtmInfoChain (
    ._EVAL_0(dtmInfoChain__EVAL_0),
    ._EVAL_1(dtmInfoChain__EVAL_1),
    ._EVAL_2(dtmInfoChain__EVAL_2),
    ._EVAL_3(dtmInfoChain__EVAL_3),
    ._EVAL_4(dtmInfoChain__EVAL_4),
    ._EVAL_5(dtmInfoChain__EVAL_5),
    ._EVAL_6(dtmInfoChain__EVAL_6),
    ._EVAL_7(dtmInfoChain__EVAL_7),
    ._EVAL_8(dtmInfoChain__EVAL_8),
    ._EVAL_9(dtmInfoChain__EVAL_9),
    ._EVAL_10(dtmInfoChain__EVAL_10),
    ._EVAL_11(dtmInfoChain__EVAL_11),
    ._EVAL_12(dtmInfoChain__EVAL_12),
    ._EVAL_13(dtmInfoChain__EVAL_13),
    ._EVAL_14(dtmInfoChain__EVAL_14),
    ._EVAL_15(dtmInfoChain__EVAL_15),
    ._EVAL_16(dtmInfoChain__EVAL_16),
    ._EVAL_17(dtmInfoChain__EVAL_17),
    ._EVAL_18(dtmInfoChain__EVAL_18),
    ._EVAL_19(dtmInfoChain__EVAL_19),
    ._EVAL_20(dtmInfoChain__EVAL_20),
    ._EVAL_21(dtmInfoChain__EVAL_21),
    ._EVAL_22(dtmInfoChain__EVAL_22),
    ._EVAL_23(dtmInfoChain__EVAL_23),
    ._EVAL_24(dtmInfoChain__EVAL_24),
    ._EVAL_25(dtmInfoChain__EVAL_25)
  );
  _EVAL_178 JtagTapController (
    ._EVAL_0(JtagTapController__EVAL_0),
    ._EVAL_1(JtagTapController__EVAL_1),
    ._EVAL_2(JtagTapController__EVAL_2),
    ._EVAL_3(JtagTapController__EVAL_3),
    ._EVAL_4(JtagTapController__EVAL_4),
    ._EVAL_5(JtagTapController__EVAL_5),
    ._EVAL_6(JtagTapController__EVAL_6),
    ._EVAL_7(JtagTapController__EVAL_7),
    ._EVAL_8(JtagTapController__EVAL_8),
    ._EVAL_9(JtagTapController__EVAL_9),
    ._EVAL_10(JtagTapController__EVAL_10),
    ._EVAL_11(JtagTapController__EVAL_11),
    ._EVAL_12(JtagTapController__EVAL_12),
    ._EVAL_13(JtagTapController__EVAL_13),
    ._EVAL_14(JtagTapController__EVAL_14),
    ._EVAL_15(JtagTapController__EVAL_15),
    ._EVAL_16(JtagTapController__EVAL_16),
    ._EVAL_17(JtagTapController__EVAL_17),
    ._EVAL_18(JtagTapController__EVAL_18)
  );
  _EVAL_179 JtagBypassChain (
    ._EVAL_0(JtagBypassChain__EVAL_0),
    ._EVAL_1(JtagBypassChain__EVAL_1),
    ._EVAL_2(JtagBypassChain__EVAL_2),
    ._EVAL_3(JtagBypassChain__EVAL_3),
    ._EVAL_4(JtagBypassChain__EVAL_4),
    ._EVAL_5(JtagBypassChain__EVAL_5),
    ._EVAL_6(JtagBypassChain__EVAL_6),
    ._EVAL_7(JtagBypassChain__EVAL_7),
    ._EVAL_8(JtagBypassChain__EVAL_8),
    ._EVAL_9(JtagBypassChain__EVAL_9)
  );
  _EVAL_172 idcodeChain (
    ._EVAL_0(idcodeChain__EVAL_0),
    ._EVAL_1(idcodeChain__EVAL_1),
    ._EVAL_2(idcodeChain__EVAL_2),
    ._EVAL_3(idcodeChain__EVAL_3),
    ._EVAL_4(idcodeChain__EVAL_4),
    ._EVAL_5(idcodeChain__EVAL_5),
    ._EVAL_6(idcodeChain__EVAL_6),
    ._EVAL_7(idcodeChain__EVAL_7),
    ._EVAL_8(idcodeChain__EVAL_8),
    ._EVAL_9(idcodeChain__EVAL_9),
    ._EVAL_10(idcodeChain__EVAL_10),
    ._EVAL_11(idcodeChain__EVAL_11),
    ._EVAL_12(idcodeChain__EVAL_12),
    ._EVAL_13(idcodeChain__EVAL_13),
    ._EVAL_14(idcodeChain__EVAL_14)
  );
  _EVAL_171 dmiAccessChain (
    ._EVAL_0(dmiAccessChain__EVAL_0),
    ._EVAL_1(dmiAccessChain__EVAL_1),
    ._EVAL_2(dmiAccessChain__EVAL_2),
    ._EVAL_3(dmiAccessChain__EVAL_3),
    ._EVAL_4(dmiAccessChain__EVAL_4),
    ._EVAL_5(dmiAccessChain__EVAL_5),
    ._EVAL_6(dmiAccessChain__EVAL_6),
    ._EVAL_7(dmiAccessChain__EVAL_7),
    ._EVAL_8(dmiAccessChain__EVAL_8),
    ._EVAL_9(dmiAccessChain__EVAL_9),
    ._EVAL_10(dmiAccessChain__EVAL_10),
    ._EVAL_11(dmiAccessChain__EVAL_11),
    ._EVAL_12(dmiAccessChain__EVAL_12),
    ._EVAL_13(dmiAccessChain__EVAL_13),
    ._EVAL_14(dmiAccessChain__EVAL_14),
    ._EVAL_15(dmiAccessChain__EVAL_15),
    ._EVAL_16(dmiAccessChain__EVAL_16),
    ._EVAL_17(dmiAccessChain__EVAL_17)
  );
  assign _EVAL_0 = _EVAL_103;
  assign _EVAL_1 = _EVAL_191;
  assign _EVAL_6 = _EVAL_75;
  assign _EVAL_11 = dmiAccessChain__EVAL_7;
  assign _EVAL_12 = _EVAL_93;
  assign _EVAL_16 = _EVAL_30;
  assign _EVAL_17 = _EVAL_84;
  assign _EVAL_18 = _EVAL_28;
  assign _EVAL_20 = _EVAL_57 ? 32'h0 : _EVAL_93;
  assign _EVAL_21 = _EVAL_66 & _EVAL_203;
  assign _EVAL_23 = _EVAL_9 & _EVAL_16;
  assign _EVAL_25 = dmiAccessChain__EVAL_7 ? _EVAL_96 : _EVAL_114;
  assign _EVAL_27 = JtagTapController__EVAL_4;
  assign _EVAL_28 = JtagTapController__EVAL_5;
  assign _EVAL_29 = _EVAL_53 == 1'h0;
  assign _EVAL_33 = _EVAL_57 ? 7'h0 : _EVAL_103;
  assign _EVAL_34 = dmiAccessChain__EVAL_13;
  assign _EVAL_35 = _EVAL_101 ? _EVAL_80 : _EVAL_27;
  assign dtmInfoChain__EVAL_5 = _EVAL_155;
  assign dtmInfoChain__EVAL_6 = _EVAL_13;
  assign dtmInfoChain__EVAL_7 = _EVAL_65;
  assign dtmInfoChain__EVAL_9 = _EVAL_185;
  assign dtmInfoChain__EVAL_10 = _EVAL_135;
  assign dtmInfoChain__EVAL_12 = _EVAL_95;
  assign dtmInfoChain__EVAL_13 = _EVAL_62;
  assign dtmInfoChain__EVAL_14 = _EVAL_172;
  assign dtmInfoChain__EVAL_16 = _EVAL_48;
  assign dtmInfoChain__EVAL_17 = _EVAL_3;
  assign dtmInfoChain__EVAL_20 = _EVAL_67;
  assign dtmInfoChain__EVAL_21 = _EVAL_86;
  assign dtmInfoChain__EVAL_22 = _EVAL_70;
  assign _EVAL_37 = _EVAL_55 == 1'h0;
  assign _EVAL_39 = 16'h0;
  assign _EVAL_40 = _EVAL_94 ? idcodeChain__EVAL_7 : _EVAL_136;
  assign _EVAL_41 = _EVAL_7;
  assign _EVAL_43 = dmiAccessChain__EVAL_16 ? _EVAL_108 : _EVAL_93;
  assign _EVAL_44 = dmiAccessChain__EVAL_16 ? _EVAL_125 : _EVAL_191;
  assign _EVAL_45 = 1'h0;
  assign _EVAL_47 = _EVAL_124 | _EVAL_114;
  assign _EVAL_48 = 3'h5;
  assign _EVAL_49 = _EVAL_72 ? dtmInfoChain__EVAL_18 : _EVAL_183;
  assign _EVAL_50 = _EVAL_61 == 1'h0;
  assign _EVAL_51 = _EVAL_2 ? _EVAL_89 : _EVAL_91;
  assign _EVAL_52 = _EVAL_2 ? _EVAL_139 : _EVAL_109;
  assign _EVAL_53 = JtagTapController__EVAL_14 == 5'h10;
  assign _EVAL_54 = _EVAL_50 ? _EVAL_45 : _EVAL_130;
  assign _EVAL_55 = _EVAL_157 | _EVAL_118;
  assign JtagTapController__EVAL_0 = _EVAL_140;
  assign JtagTapController__EVAL_2 = _EVAL_182;
  assign JtagTapController__EVAL_3 = _EVAL_201;
  assign JtagTapController__EVAL_6 = _EVAL_178;
  assign JtagTapController__EVAL_8 = _EVAL_194;
  assign JtagTapController__EVAL_9 = _EVAL_3;
  assign JtagTapController__EVAL_12 = _EVAL_98;
  assign JtagTapController__EVAL_16 = _EVAL_13;
  assign JtagTapController__EVAL_17 = _EVAL_193;
  assign JtagTapController__EVAL_18 = _EVAL_189;
  assign _EVAL_57 = _EVAL_144 & _EVAL_55;
  assign _EVAL_59 = dmiAccessChain__EVAL_7 ? _EVAL_77 : _EVAL_124;
  assign _EVAL_60 = 1'h0;
  assign _EVAL_61 = JtagTapController__EVAL_14 == 5'h1;
  assign _EVAL_62 = _EVAL_29 ? _EVAL_80 : _EVAL_27;
  assign _EVAL_64 = _EVAL_2 ? _EVAL_129 : _EVAL_153;
  assign _EVAL_65 = _EVAL_29 ? _EVAL_60 : _EVAL_186;
  assign _EVAL_67 = 15'h0;
  assign _EVAL_69 = JtagTapController__EVAL_13;
  assign _EVAL_70 = _EVAL_121;
  assign _EVAL_72 = _EVAL_164 & _EVAL_53;
  assign _EVAL_73 = _EVAL_39;
  assign _EVAL_74 = _EVAL_101 ? _EVAL_60 : _EVAL_186;
  assign _EVAL_75 = JtagTapController__EVAL_15;
  assign _EVAL_76 = _EVAL_110 ? 1'h1 : _EVAL_30;
  assign _EVAL_77 = _EVAL_85;
  assign _EVAL_78 = _EVAL_94 ? idcodeChain__EVAL_11 : _EVAL_34;
  assign _EVAL_79 = _EVAL_72 ? dtmInfoChain__EVAL_11 : _EVAL_40;
  assign _EVAL_80 = 1'h0;
  assign _EVAL_81 = JtagTapController__EVAL_14 == 5'h11;
  assign _EVAL_83 = _EVAL_72 ? dtmInfoChain__EVAL_1 : _EVAL_146;
  assign _EVAL_84 = JtagTapController__EVAL_1;
  assign _EVAL_85 = _EVAL_124 | _EVAL_158;
  assign _EVAL_86 = 1'h0;
  assign _EVAL_87 = _EVAL_11 & _EVAL_2;
  assign _EVAL_88 = dmiAccessChain__EVAL_16 ? _EVAL_148 : _EVAL_103;
  assign _EVAL_89 = _EVAL_15;
  assign _EVAL_91 = 32'h0;
  assign _EVAL_92 = dmiAccessChain__EVAL_7 ? _EVAL_96 : _EVAL_175;
  assign _EVAL_94 = _EVAL_101 & _EVAL_61;
  assign _EVAL_95 = 4'h1;
  assign _EVAL_96 = _EVAL_122;
  assign _EVAL_97 = dmiAccessChain__EVAL_7 ? _EVAL_96 : _EVAL_177;
  assign _EVAL_98 = _EVAL_14;
  assign _EVAL_100 = dmiAccessChain__EVAL_7 ? _EVAL_96 : _EVAL_147;
  assign _EVAL_101 = _EVAL_81 == 1'h0;
  assign _EVAL_104 = dmiAccessChain__EVAL_16 ? _EVAL_76 : _EVAL_30;
  assign _EVAL_108 = _EVAL_110 ? dmiAccessChain__EVAL_17 : _EVAL_20;
  assign _EVAL_109 = 7'h0;
  assign _EVAL_110 = _EVAL_144 & _EVAL_37;
  assign _EVAL_111 = _EVAL_10 != 2'h0;
  assign JtagBypassChain__EVAL_1 = JtagTapController__EVAL_13;
  assign JtagBypassChain__EVAL_2 = JtagTapController__EVAL_11;
  assign JtagBypassChain__EVAL_3 = JtagTapController__EVAL_10;
  assign JtagBypassChain__EVAL_4 = JtagTapController__EVAL_4;
  assign JtagBypassChain__EVAL_5 = _EVAL_3;
  assign JtagBypassChain__EVAL_7 = _EVAL_13;
  assign idcodeChain__EVAL_0 = _EVAL_54;
  assign idcodeChain__EVAL_1 = _EVAL_13;
  assign idcodeChain__EVAL_2 = _EVAL_133;
  assign idcodeChain__EVAL_6 = _EVAL_174;
  assign idcodeChain__EVAL_8 = _EVAL_200;
  assign idcodeChain__EVAL_9 = _EVAL_143;
  assign idcodeChain__EVAL_10 = _EVAL_3;
  assign idcodeChain__EVAL_12 = _EVAL_132;
  assign idcodeChain__EVAL_13 = _EVAL_190;
  assign idcodeChain__EVAL_14 = _EVAL_73;
  assign _EVAL_118 = dmiAccessChain__EVAL_4 == 2'h0;
  assign _EVAL_119 = _EVAL_96 ? _EVAL_171 : _EVAL_52;
  assign _EVAL_120 = _EVAL_23 ? 1'h0 : _EVAL_104;
  assign _EVAL_121 = _EVAL_156;
  assign _EVAL_122 = _EVAL_21 | _EVAL_114;
  assign _EVAL_123 = _EVAL_16 ? 1'h1 : _EVAL_66;
  assign _EVAL_125 = _EVAL_110 ? dmiAccessChain__EVAL_4 : _EVAL_168;
  assign _EVAL_129 = _EVAL_10;
  assign _EVAL_130 = JtagTapController__EVAL_11;
  assign _EVAL_131 = _EVAL_72 ? dtmInfoChain__EVAL_4 : _EVAL_78;
  assign _EVAL_132 = _EVAL_50 ? _EVAL_80 : _EVAL_27;
  assign _EVAL_133 = _EVAL_150;
  assign _EVAL_134 = _EVAL_101 ? _EVAL_45 : _EVAL_130;
  assign _EVAL_135 = 1'h0;
  assign dmiAccessChain__EVAL_0 = _EVAL_173;
  assign dmiAccessChain__EVAL_2 = _EVAL_145;
  assign dmiAccessChain__EVAL_3 = _EVAL_134;
  assign dmiAccessChain__EVAL_5 = _EVAL_151;
  assign dmiAccessChain__EVAL_10 = _EVAL_119;
  assign dmiAccessChain__EVAL_11 = _EVAL_3;
  assign dmiAccessChain__EVAL_12 = _EVAL_35;
  assign dmiAccessChain__EVAL_14 = _EVAL_74;
  assign dmiAccessChain__EVAL_15 = _EVAL_13;
  assign _EVAL_136 = dmiAccessChain__EVAL_8;
  assign _EVAL_138 = 4'h2;
  assign _EVAL_139 = _EVAL_103;
  assign _EVAL_140 = _EVAL_5;
  assign _EVAL_142 = _EVAL_169 & _EVAL_77;
  assign _EVAL_143 = _EVAL_138;
  assign _EVAL_144 = _EVAL_149 == 1'h0;
  assign _EVAL_145 = _EVAL_96 ? _EVAL_166 : _EVAL_64;
  assign _EVAL_146 = _EVAL_94 ? idcodeChain__EVAL_5 : _EVAL_199;
  assign _EVAL_147 = dmiAccessChain__EVAL_16 ? 1'h0 : _EVAL_92;
  assign _EVAL_148 = _EVAL_110 ? dmiAccessChain__EVAL_1 : _EVAL_33;
  assign _EVAL_150 = 1'h1;
  assign _EVAL_151 = _EVAL_101 ? _EVAL_181 : _EVAL_69;
  assign _EVAL_152 = 32'h0;
  assign _EVAL_153 = 2'h0;
  assign _EVAL_154 = dtmInfoChain__EVAL_24 ? 1'h0 : _EVAL_59;
  assign _EVAL_155 = _EVAL_29 ? _EVAL_45 : _EVAL_130;
  assign _EVAL_156 = {_EVAL_124,_EVAL_47};
  assign _EVAL_158 = _EVAL_2 & _EVAL_111;
  assign _EVAL_159 = dmiAccessChain__EVAL_7 ? _EVAL_142 : _EVAL_187;
  assign _EVAL_162 = _EVAL_87 ? 1'h0 : _EVAL_123;
  assign _EVAL_163 = dmiAccessChain__EVAL_7 ? _EVAL_77 : _EVAL_180;
  assign _EVAL_164 = _EVAL_101 & _EVAL_50;
  assign _EVAL_165 = dtmInfoChain__EVAL_24 ? 1'h0 : _EVAL_25;
  assign _EVAL_166 = 2'h3;
  assign _EVAL_167 = _EVAL_164 & _EVAL_29;
  assign _EVAL_168 = _EVAL_57 ? 2'h0 : _EVAL_191;
  assign _EVAL_169 = _EVAL_96 == 1'h0;
  assign _EVAL_171 = 7'h0;
  assign _EVAL_172 = 6'h7;
  assign _EVAL_173 = _EVAL_96 ? _EVAL_152 : _EVAL_51;
  assign _EVAL_174 = _EVAL_50 ? _EVAL_181 : _EVAL_69;
  assign _EVAL_175 = dmiAccessChain__EVAL_16 ? 1'h0 : _EVAL_149;
  assign _EVAL_176 = dmiAccessChain__EVAL_7 ? _EVAL_142 : _EVAL_197;
  assign _EVAL_177 = dtmInfoChain__EVAL_0 ? _EVAL_165 : _EVAL_25;
  assign _EVAL_178 = _EVAL_167 ? JtagBypassChain__EVAL_6 : _EVAL_49;
  assign _EVAL_180 = dtmInfoChain__EVAL_0 ? _EVAL_154 : _EVAL_59;
  assign _EVAL_181 = 1'h0;
  assign _EVAL_182 = _EVAL_167 ? JtagBypassChain__EVAL_9 : _EVAL_83;
  assign _EVAL_183 = _EVAL_94 ? idcodeChain__EVAL_3 : _EVAL_184;
  assign _EVAL_184 = dmiAccessChain__EVAL_6;
  assign _EVAL_185 = _EVAL_29 ? _EVAL_181 : _EVAL_69;
  assign _EVAL_186 = JtagTapController__EVAL_10;
  assign _EVAL_187 = dmiAccessChain__EVAL_16 ? 1'h0 : _EVAL_176;
  assign _EVAL_189 = _EVAL_167 ? JtagBypassChain__EVAL_8 : _EVAL_79;
  assign _EVAL_190 = _EVAL_50 ? _EVAL_60 : _EVAL_186;
  assign _EVAL_193 = _EVAL_8;
  assign _EVAL_194 = _EVAL_167 ? JtagBypassChain__EVAL_0 : _EVAL_131;
  assign _EVAL_197 = dmiAccessChain__EVAL_16 ? 1'h0 : _EVAL_157;
  assign _EVAL_199 = dmiAccessChain__EVAL_9;
  assign _EVAL_200 = _EVAL_41;
  assign _EVAL_201 = _EVAL_4;
  assign _EVAL_203 = _EVAL_2 == 1'h0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_30 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_66 = _GEN_1[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_93 = _GEN_2[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_103 = _GEN_3[6:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_114 = _GEN_4[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_124 = _GEN_5[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_149 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_157 = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_191 = _GEN_8[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_13) begin
    if (_EVAL_3) begin
      _EVAL_30 <= 1'h0;
    end else begin
      if (_EVAL_23) begin
        _EVAL_30 <= 1'h0;
      end else begin
        if (dmiAccessChain__EVAL_16) begin
          if (_EVAL_110) begin
            _EVAL_30 <= 1'h1;
          end
        end
      end
    end
    if (_EVAL_3) begin
      _EVAL_66 <= 1'h0;
    end else begin
      if (_EVAL_87) begin
        _EVAL_66 <= 1'h0;
      end else begin
        if (_EVAL_16) begin
          _EVAL_66 <= 1'h1;
        end
      end
    end
    if (dmiAccessChain__EVAL_16) begin
      if (_EVAL_110) begin
        _EVAL_93 <= dmiAccessChain__EVAL_17;
      end else begin
        if (_EVAL_57) begin
          _EVAL_93 <= 32'h0;
        end
      end
    end
    if (dmiAccessChain__EVAL_16) begin
      if (_EVAL_110) begin
        _EVAL_103 <= dmiAccessChain__EVAL_1;
      end else begin
        if (_EVAL_57) begin
          _EVAL_103 <= 7'h0;
        end
      end
    end
    if (_EVAL_3) begin
      _EVAL_114 <= 1'h0;
    end else begin
      if (dmiAccessChain__EVAL_7) begin
        _EVAL_114 <= _EVAL_96;
      end else begin
        if (dtmInfoChain__EVAL_0) begin
          if (dtmInfoChain__EVAL_24) begin
            _EVAL_114 <= 1'h0;
          end else begin
            if (dmiAccessChain__EVAL_7) begin
              _EVAL_114 <= _EVAL_96;
            end
          end
        end else begin
          if (dmiAccessChain__EVAL_7) begin
            _EVAL_114 <= _EVAL_96;
          end
        end
      end
    end
    if (_EVAL_3) begin
      _EVAL_124 <= 1'h0;
    end else begin
      if (dmiAccessChain__EVAL_7) begin
        _EVAL_124 <= _EVAL_77;
      end else begin
        if (dtmInfoChain__EVAL_0) begin
          if (dtmInfoChain__EVAL_24) begin
            _EVAL_124 <= 1'h0;
          end else begin
            if (dmiAccessChain__EVAL_7) begin
              _EVAL_124 <= _EVAL_77;
            end
          end
        end else begin
          if (dmiAccessChain__EVAL_7) begin
            _EVAL_124 <= _EVAL_77;
          end
        end
      end
    end
    if (_EVAL_3) begin
      _EVAL_149 <= 1'h0;
    end else begin
      if (dmiAccessChain__EVAL_7) begin
        _EVAL_149 <= _EVAL_96;
      end else begin
        if (dmiAccessChain__EVAL_16) begin
          _EVAL_149 <= 1'h0;
        end else begin
          if (dmiAccessChain__EVAL_7) begin
            _EVAL_149 <= _EVAL_96;
          end else begin
            if (dmiAccessChain__EVAL_16) begin
              _EVAL_149 <= 1'h0;
            end
          end
        end
      end
    end
    if (_EVAL_3) begin
      _EVAL_157 <= 1'h0;
    end else begin
      if (dmiAccessChain__EVAL_7) begin
        _EVAL_157 <= _EVAL_142;
      end else begin
        if (dmiAccessChain__EVAL_16) begin
          _EVAL_157 <= 1'h0;
        end else begin
          if (dmiAccessChain__EVAL_7) begin
            _EVAL_157 <= _EVAL_142;
          end else begin
            if (dmiAccessChain__EVAL_16) begin
              _EVAL_157 <= 1'h0;
            end
          end
        end
      end
    end
    if (dmiAccessChain__EVAL_16) begin
      if (_EVAL_110) begin
        _EVAL_191 <= dmiAccessChain__EVAL_4;
      end else begin
        if (_EVAL_57) begin
          _EVAL_191 <= 2'h0;
        end
      end
    end
  end
endmodule
