//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_181(
  input  [7:0]  _EVAL_0,
  input         _EVAL_1,
  input         _EVAL_2,
  output [7:0]  _EVAL_3,
  output [7:0]  _EVAL_4,
  input  [7:0]  _EVAL_5,
  input  [7:0]  _EVAL_6,
  input         _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  input  [7:0]  _EVAL_10,
  output [7:0]  _EVAL_11,
  input         _EVAL_12,
  input         _EVAL_13,
  input  [7:0]  _EVAL_14,
  output [7:0]  _EVAL_15,
  output [7:0]  _EVAL_16,
  output [7:0]  _EVAL_17,
  input  [7:0]  _EVAL_18,
  output [7:0]  _EVAL_19,
  input         _EVAL_20,
  input  [7:0]  _EVAL_21,
  output [7:0]  _EVAL_22,
  input  [10:0] _EVAL_23,
  input         _EVAL_24,
  input  [7:0]  _EVAL_25,
  input         _EVAL_26,
  input         _EVAL_27
);
  wire [15:0] _EVAL_28;
  wire  _EVAL_29;
  wire [1:0] _EVAL_30;
  wire [7:0] _EVAL_31;
  wire  _EVAL_32;
  wire [7:0] _EVAL_33;
  wire [7:0] _EVAL_34;
  wire  _EVAL_35;
  wire [7:0] _EVAL_36;
  wire [7:0] _EVAL_37;
  wire [1:0] _EVAL_38;
  wire [7:0] _EVAL_39;
  wire [15:0] _EVAL_40;
  wire [7:0] _EVAL_41;
  wire [7:0] _EVAL_42;
  wire [7:0] _EVAL_43;
  wire [3:0] _EVAL_44;
  wire  _EVAL_45;
  wire  _EVAL_46;
  wire [15:0] _EVAL_47;
  wire [7:0] _EVAL_48;
  wire  _EVAL_49;
  wire [7:0] _EVAL_50;
  wire [7:0] _EVAL_51;
  wire [7:0] _EVAL_52;
  wire [7:0] _EVAL_53;
  wire [3:0] _EVAL_54;
  wire [31:0] _EVAL_55;
  wire  _EVAL_56;
  wire [1:0] _EVAL_57;
  wire [7:0] _EVAL_58;
  wire [1:0] _EVAL_59;
  wire [7:0] _EVAL_60;
  wire  _EVAL_61;
  wire [31:0] _EVAL_62;
  wire [15:0] _EVAL_63;
  wire [10:0] E51_data_arrays_0_ext_RW0_addr;
  wire  E51_data_arrays_0_ext_RW0_en;
  wire  E51_data_arrays_0_ext_RW0_clk;
  wire  E51_data_arrays_0_ext_RW0_wmode;
  wire [63:0] E51_data_arrays_0_ext_RW0_wdata;
  wire [63:0] E51_data_arrays_0_ext_RW0_rdata;
  wire [7:0] E51_data_arrays_0_ext_RW0_wmask;
  E51_data_arrays_0_ext E51_data_arrays_0_ext (
    .RW0_addr(E51_data_arrays_0_ext_RW0_addr),
    .RW0_en(E51_data_arrays_0_ext_RW0_en),
    .RW0_clk(E51_data_arrays_0_ext_RW0_clk),
    .RW0_wmode(E51_data_arrays_0_ext_RW0_wmode),
    .RW0_wdata(E51_data_arrays_0_ext_RW0_wdata),
    .RW0_rdata(E51_data_arrays_0_ext_RW0_rdata),
    .RW0_wmask(E51_data_arrays_0_ext_RW0_wmask)
  );
  assign _EVAL_3 = $unsigned(_EVAL_50);
  assign _EVAL_4 = $unsigned(_EVAL_33);
  assign _EVAL_11 = $unsigned(_EVAL_52);
  assign _EVAL_15 = $unsigned(_EVAL_48);
  assign _EVAL_16 = $unsigned(_EVAL_58);
  assign _EVAL_17 = $unsigned(_EVAL_53);
  assign _EVAL_19 = $unsigned(_EVAL_36);
  assign _EVAL_22 = $unsigned(_EVAL_42);
  assign _EVAL_28 = {_EVAL_51,_EVAL_60};
  assign _EVAL_29 = $unsigned(_EVAL_20);
  assign _EVAL_30 = {_EVAL_49,_EVAL_45};
  assign _EVAL_31 = $unsigned(_EVAL_21);
  assign _EVAL_32 = $unsigned(_EVAL_1);
  assign _EVAL_33 = E51_data_arrays_0_ext_RW0_rdata[7:0];
  assign _EVAL_34 = $unsigned(_EVAL_10);
  assign _EVAL_35 = $unsigned(_EVAL_24);
  assign _EVAL_36 = E51_data_arrays_0_ext_RW0_rdata[39:32];
  assign _EVAL_37 = $unsigned(_EVAL_5);
  assign _EVAL_38 = {_EVAL_35,_EVAL_29};
  assign _EVAL_39 = $unsigned(_EVAL_0);
  assign _EVAL_40 = {_EVAL_41,_EVAL_43};
  assign _EVAL_41 = $unsigned(_EVAL_25);
  assign _EVAL_42 = E51_data_arrays_0_ext_RW0_rdata[31:24];
  assign _EVAL_43 = $unsigned(_EVAL_14);
  assign _EVAL_44 = {_EVAL_57,_EVAL_38};
  assign _EVAL_45 = $unsigned(_EVAL_7);
  assign _EVAL_46 = $unsigned(_EVAL_26);
  assign _EVAL_47 = {_EVAL_34,_EVAL_37};
  assign _EVAL_48 = E51_data_arrays_0_ext_RW0_rdata[63:56];
  assign _EVAL_49 = $unsigned(_EVAL_2);
  assign _EVAL_50 = E51_data_arrays_0_ext_RW0_rdata[47:40];
  assign _EVAL_51 = $unsigned(_EVAL_18);
  assign _EVAL_52 = E51_data_arrays_0_ext_RW0_rdata[23:16];
  assign _EVAL_53 = E51_data_arrays_0_ext_RW0_rdata[15:8];
  assign _EVAL_54 = {_EVAL_30,_EVAL_59};
  assign _EVAL_55 = {_EVAL_63,_EVAL_40};
  assign _EVAL_56 = $unsigned(_EVAL_13);
  assign _EVAL_57 = {_EVAL_32,_EVAL_46};
  assign _EVAL_58 = E51_data_arrays_0_ext_RW0_rdata[55:48];
  assign _EVAL_59 = {_EVAL_56,_EVAL_61};
  assign _EVAL_60 = $unsigned(_EVAL_6);
  assign _EVAL_61 = $unsigned(_EVAL_9);
  assign _EVAL_62 = {_EVAL_28,_EVAL_47};
  assign _EVAL_63 = {_EVAL_31,_EVAL_39};
  assign E51_data_arrays_0_ext_RW0_addr = _EVAL_23;
  assign E51_data_arrays_0_ext_RW0_en = _EVAL_27;
  assign E51_data_arrays_0_ext_RW0_clk = _EVAL_12;
  assign E51_data_arrays_0_ext_RW0_wmode = _EVAL_8;
  assign E51_data_arrays_0_ext_RW0_wdata = {_EVAL_62,_EVAL_55};
  assign E51_data_arrays_0_ext_RW0_wmask = {_EVAL_54,_EVAL_44};
endmodule
