//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_183(
  input  [31:0] _EVAL_0,
  input  [31:0] _EVAL_1,
  input         _EVAL_2,
  output [31:0] _EVAL_3,
  input  [9:0]  _EVAL_4,
  input         _EVAL_5,
  input         _EVAL_6,
  output [31:0] _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9
);
  wire [31:0] _EVAL_10;
  wire [9:0] E51_data_arrays_0_0_ext_RW0_addr;
  wire  E51_data_arrays_0_0_ext_RW0_en;
  wire  E51_data_arrays_0_0_ext_RW0_clk;
  wire  E51_data_arrays_0_0_ext_RW0_wmode;
  wire [63:0] E51_data_arrays_0_0_ext_RW0_wdata;
  wire [63:0] E51_data_arrays_0_0_ext_RW0_rdata;
  wire [1:0] E51_data_arrays_0_0_ext_RW0_wmask;
  wire  _EVAL_11;
  wire [31:0] _EVAL_12;
  wire [31:0] _EVAL_13;
  wire  _EVAL_14;
  wire [31:0] _EVAL_15;
  E51_data_arrays_0_0_ext E51_data_arrays_0_0_ext (
    .RW0_addr(E51_data_arrays_0_0_ext_RW0_addr),
    .RW0_en(E51_data_arrays_0_0_ext_RW0_en),
    .RW0_clk(E51_data_arrays_0_0_ext_RW0_clk),
    .RW0_wmode(E51_data_arrays_0_0_ext_RW0_wmode),
    .RW0_wdata(E51_data_arrays_0_0_ext_RW0_wdata),
    .RW0_rdata(E51_data_arrays_0_0_ext_RW0_rdata),
    .RW0_wmask(E51_data_arrays_0_0_ext_RW0_wmask)
  );
  assign _EVAL_3 = $unsigned(_EVAL_13);
  assign _EVAL_7 = $unsigned(_EVAL_10);
  assign _EVAL_10 = E51_data_arrays_0_0_ext_RW0_rdata[63:32];
  assign E51_data_arrays_0_0_ext_RW0_addr = _EVAL_4;
  assign E51_data_arrays_0_0_ext_RW0_en = _EVAL_9;
  assign E51_data_arrays_0_0_ext_RW0_clk = _EVAL_2;
  assign E51_data_arrays_0_0_ext_RW0_wmode = _EVAL_5;
  assign E51_data_arrays_0_0_ext_RW0_wdata = {_EVAL_15,_EVAL_12};
  assign E51_data_arrays_0_0_ext_RW0_wmask = {_EVAL_14,_EVAL_11};
  assign _EVAL_11 = $unsigned(_EVAL_8);
  assign _EVAL_12 = $unsigned(_EVAL_1);
  assign _EVAL_13 = E51_data_arrays_0_0_ext_RW0_rdata[31:0];
  assign _EVAL_14 = $unsigned(_EVAL_6);
  assign _EVAL_15 = $unsigned(_EVAL_0);
endmodule
