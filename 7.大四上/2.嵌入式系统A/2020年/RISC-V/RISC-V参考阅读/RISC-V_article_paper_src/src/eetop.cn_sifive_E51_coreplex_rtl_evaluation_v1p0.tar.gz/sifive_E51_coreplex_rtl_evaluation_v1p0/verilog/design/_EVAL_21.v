//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_21(
  output [31:0] _EVAL_0,
  output [3:0]  _EVAL_1,
  input         _EVAL_2,
  input  [3:0]  _EVAL_3,
  output        _EVAL_4,
  input  [63:0] _EVAL_5,
  input  [2:0]  _EVAL_6,
  input         _EVAL_7,
  output [2:0]  _EVAL_8,
  input  [2:0]  _EVAL_9,
  output [2:0]  _EVAL_10,
  input         _EVAL_11,
  output [1:0]  _EVAL_12,
  input  [2:0]  _EVAL_13,
  output [63:0] _EVAL_14,
  output        _EVAL_15,
  output [7:0]  _EVAL_16,
  input         _EVAL_17,
  output [2:0]  _EVAL_18,
  input  [7:0]  _EVAL_19,
  input  [31:0] _EVAL_20
);
  wire  _EVAL_21;
  wire  _EVAL_22;
  reg  _EVAL_23;
  reg [31:0] _GEN_0;
  wire [1:0] _EVAL_24;
  wire  _EVAL_25;
  wire [1:0] _EVAL_26;
  wire  _EVAL_27;
  wire  _EVAL_28;
  reg  _EVAL_29;
  reg [31:0] _GEN_1;
  wire  _EVAL_30;
  wire  _EVAL_31;
  wire  _EVAL_32;
  reg [7:0] _EVAL_33 [0:1];
  reg [31:0] _GEN_2;
  wire [7:0] _EVAL_33__EVAL_34_data;
  wire  _EVAL_33__EVAL_34_addr;
  wire [7:0] _EVAL_33__EVAL_35_data;
  wire  _EVAL_33__EVAL_35_addr;
  wire  _EVAL_33__EVAL_35_mask;
  wire  _EVAL_33__EVAL_35_en;
  wire  _EVAL_36;
  wire  _EVAL_37;
  reg [2:0] _EVAL_38 [0:1];
  reg [31:0] _GEN_3;
  wire [2:0] _EVAL_38__EVAL_39_data;
  wire  _EVAL_38__EVAL_39_addr;
  wire [2:0] _EVAL_38__EVAL_40_data;
  wire  _EVAL_38__EVAL_40_addr;
  wire  _EVAL_38__EVAL_40_mask;
  wire  _EVAL_38__EVAL_40_en;
  reg [2:0] _EVAL_41 [0:1];
  reg [31:0] _GEN_4;
  wire [2:0] _EVAL_41__EVAL_42_data;
  wire  _EVAL_41__EVAL_42_addr;
  wire [2:0] _EVAL_41__EVAL_43_data;
  wire  _EVAL_41__EVAL_43_addr;
  wire  _EVAL_41__EVAL_43_mask;
  wire  _EVAL_41__EVAL_43_en;
  wire  _EVAL_44;
  wire  _EVAL_45;
  wire  _EVAL_46;
  wire  _EVAL_47;
  wire [1:0] _EVAL_48;
  reg  _EVAL_49;
  reg [31:0] _GEN_5;
  reg [3:0] _EVAL_50 [0:1];
  reg [31:0] _GEN_6;
  wire [3:0] _EVAL_50__EVAL_51_data;
  wire  _EVAL_50__EVAL_51_addr;
  wire [3:0] _EVAL_50__EVAL_52_data;
  wire  _EVAL_50__EVAL_52_addr;
  wire  _EVAL_50__EVAL_52_mask;
  wire  _EVAL_50__EVAL_52_en;
  wire  _EVAL_53;
  wire  _EVAL_54;
  wire [1:0] _EVAL_55;
  wire [1:0] _EVAL_56;
  reg [2:0] _EVAL_57 [0:1];
  reg [31:0] _GEN_7;
  wire [2:0] _EVAL_57__EVAL_58_data;
  wire  _EVAL_57__EVAL_58_addr;
  wire [2:0] _EVAL_57__EVAL_59_data;
  wire  _EVAL_57__EVAL_59_addr;
  wire  _EVAL_57__EVAL_59_mask;
  wire  _EVAL_57__EVAL_59_en;
  wire  _EVAL_60;
  wire  _EVAL_61;
  reg [31:0] _EVAL_62 [0:1];
  reg [31:0] _GEN_8;
  wire [31:0] _EVAL_62__EVAL_63_data;
  wire  _EVAL_62__EVAL_63_addr;
  wire [31:0] _EVAL_62__EVAL_64_data;
  wire  _EVAL_62__EVAL_64_addr;
  wire  _EVAL_62__EVAL_64_mask;
  wire  _EVAL_62__EVAL_64_en;
  reg [63:0] _EVAL_65 [0:1];
  reg [63:0] _GEN_9;
  wire [63:0] _EVAL_65__EVAL_66_data;
  wire  _EVAL_65__EVAL_66_addr;
  wire [63:0] _EVAL_65__EVAL_67_data;
  wire  _EVAL_65__EVAL_67_addr;
  wire  _EVAL_65__EVAL_67_mask;
  wire  _EVAL_65__EVAL_67_en;
  assign _EVAL_0 = _EVAL_62__EVAL_63_data;
  assign _EVAL_1 = _EVAL_50__EVAL_51_data;
  assign _EVAL_4 = _EVAL_32;
  assign _EVAL_8 = _EVAL_57__EVAL_58_data;
  assign _EVAL_10 = _EVAL_38__EVAL_39_data;
  assign _EVAL_12 = _EVAL_48;
  assign _EVAL_14 = _EVAL_65__EVAL_66_data;
  assign _EVAL_15 = _EVAL_30;
  assign _EVAL_16 = _EVAL_33__EVAL_34_data;
  assign _EVAL_18 = _EVAL_41__EVAL_42_data;
  assign _EVAL_21 = _EVAL_29 == 1'h0;
  assign _EVAL_22 = _EVAL_37 != _EVAL_31;
  assign _EVAL_24 = _EVAL_49 + 1'h1;
  assign _EVAL_25 = _EVAL_15 & _EVAL_2;
  assign _EVAL_26 = _EVAL_49 - _EVAL_23;
  assign _EVAL_27 = _EVAL_22 ? _EVAL_37 : _EVAL_29;
  assign _EVAL_28 = _EVAL_60 & _EVAL_29;
  assign _EVAL_30 = _EVAL_28 == 1'h0;
  assign _EVAL_31 = _EVAL_36;
  assign _EVAL_32 = _EVAL_45 == 1'h0;
  assign _EVAL_33__EVAL_34_addr = _EVAL_23;
  assign _EVAL_33__EVAL_34_data = _EVAL_33[_EVAL_33__EVAL_34_addr];
  assign _EVAL_33__EVAL_35_data = _EVAL_19;
  assign _EVAL_33__EVAL_35_addr = _EVAL_49;
  assign _EVAL_33__EVAL_35_mask = _EVAL_37;
  assign _EVAL_33__EVAL_35_en = _EVAL_37;
  assign _EVAL_36 = _EVAL_7 & _EVAL_4;
  assign _EVAL_37 = _EVAL_25;
  assign _EVAL_38__EVAL_39_addr = _EVAL_23;
  assign _EVAL_38__EVAL_39_data = _EVAL_38[_EVAL_38__EVAL_39_addr];
  assign _EVAL_38__EVAL_40_data = _EVAL_9;
  assign _EVAL_38__EVAL_40_addr = _EVAL_49;
  assign _EVAL_38__EVAL_40_mask = _EVAL_37;
  assign _EVAL_38__EVAL_40_en = _EVAL_37;
  assign _EVAL_41__EVAL_42_addr = _EVAL_23;
  assign _EVAL_41__EVAL_42_data = _EVAL_41[_EVAL_41__EVAL_42_addr];
  assign _EVAL_41__EVAL_43_data = _EVAL_13;
  assign _EVAL_41__EVAL_43_addr = _EVAL_49;
  assign _EVAL_41__EVAL_43_mask = _EVAL_37;
  assign _EVAL_41__EVAL_43_en = _EVAL_37;
  assign _EVAL_44 = _EVAL_56[0:0];
  assign _EVAL_45 = _EVAL_60 & _EVAL_21;
  assign _EVAL_46 = _EVAL_55[0:0];
  assign _EVAL_47 = _EVAL_24[0:0];
  assign _EVAL_48 = {_EVAL_61,_EVAL_44};
  assign _EVAL_50__EVAL_51_addr = _EVAL_23;
  assign _EVAL_50__EVAL_51_data = _EVAL_50[_EVAL_50__EVAL_51_addr];
  assign _EVAL_50__EVAL_52_data = _EVAL_3;
  assign _EVAL_50__EVAL_52_addr = _EVAL_49;
  assign _EVAL_50__EVAL_52_mask = _EVAL_37;
  assign _EVAL_50__EVAL_52_en = _EVAL_37;
  assign _EVAL_53 = _EVAL_37 ? _EVAL_47 : _EVAL_49;
  assign _EVAL_54 = _EVAL_31 ? _EVAL_46 : _EVAL_23;
  assign _EVAL_55 = _EVAL_23 + 1'h1;
  assign _EVAL_56 = $unsigned(_EVAL_26);
  assign _EVAL_57__EVAL_58_addr = _EVAL_23;
  assign _EVAL_57__EVAL_58_data = _EVAL_57[_EVAL_57__EVAL_58_addr];
  assign _EVAL_57__EVAL_59_data = _EVAL_6;
  assign _EVAL_57__EVAL_59_addr = _EVAL_49;
  assign _EVAL_57__EVAL_59_mask = _EVAL_37;
  assign _EVAL_57__EVAL_59_en = _EVAL_37;
  assign _EVAL_60 = _EVAL_49 == _EVAL_23;
  assign _EVAL_61 = _EVAL_29 & _EVAL_60;
  assign _EVAL_62__EVAL_63_addr = _EVAL_23;
  assign _EVAL_62__EVAL_63_data = _EVAL_62[_EVAL_62__EVAL_63_addr];
  assign _EVAL_62__EVAL_64_data = _EVAL_20;
  assign _EVAL_62__EVAL_64_addr = _EVAL_49;
  assign _EVAL_62__EVAL_64_mask = _EVAL_37;
  assign _EVAL_62__EVAL_64_en = _EVAL_37;
  assign _EVAL_65__EVAL_66_addr = _EVAL_23;
  assign _EVAL_65__EVAL_66_data = _EVAL_65[_EVAL_65__EVAL_66_addr];
  assign _EVAL_65__EVAL_67_data = _EVAL_5;
  assign _EVAL_65__EVAL_67_addr = _EVAL_49;
  assign _EVAL_65__EVAL_67_mask = _EVAL_37;
  assign _EVAL_65__EVAL_67_en = _EVAL_37;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_23 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_29 = _GEN_1[0:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_33[initvar] = _GEN_2[7:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_38[initvar] = _GEN_3[2:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_41[initvar] = _GEN_4[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_49 = _GEN_5[0:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_50[initvar] = _GEN_6[3:0];
  `endif
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_57[initvar] = _GEN_7[2:0];
  `endif
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_62[initvar] = _GEN_8[31:0];
  `endif
  _GEN_9 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_65[initvar] = _GEN_9[63:0];
  `endif
  end
`endif
  always @(posedge _EVAL_11) begin
    if (_EVAL_17) begin
      _EVAL_23 <= 1'h0;
    end else begin
      if (_EVAL_31) begin
        _EVAL_23 <= _EVAL_46;
      end
    end
    if (_EVAL_17) begin
      _EVAL_29 <= 1'h0;
    end else begin
      if (_EVAL_22) begin
        _EVAL_29 <= _EVAL_37;
      end
    end
    if(_EVAL_33__EVAL_35_en & _EVAL_33__EVAL_35_mask) begin
      _EVAL_33[_EVAL_33__EVAL_35_addr] <= _EVAL_33__EVAL_35_data;
    end
    if(_EVAL_38__EVAL_40_en & _EVAL_38__EVAL_40_mask) begin
      _EVAL_38[_EVAL_38__EVAL_40_addr] <= _EVAL_38__EVAL_40_data;
    end
    if(_EVAL_41__EVAL_43_en & _EVAL_41__EVAL_43_mask) begin
      _EVAL_41[_EVAL_41__EVAL_43_addr] <= _EVAL_41__EVAL_43_data;
    end
    if (_EVAL_17) begin
      _EVAL_49 <= 1'h0;
    end else begin
      if (_EVAL_37) begin
        _EVAL_49 <= _EVAL_47;
      end
    end
    if(_EVAL_50__EVAL_52_en & _EVAL_50__EVAL_52_mask) begin
      _EVAL_50[_EVAL_50__EVAL_52_addr] <= _EVAL_50__EVAL_52_data;
    end
    if(_EVAL_57__EVAL_59_en & _EVAL_57__EVAL_59_mask) begin
      _EVAL_57[_EVAL_57__EVAL_59_addr] <= _EVAL_57__EVAL_59_data;
    end
    if(_EVAL_62__EVAL_64_en & _EVAL_62__EVAL_64_mask) begin
      _EVAL_62[_EVAL_62__EVAL_64_addr] <= _EVAL_62__EVAL_64_data;
    end
    if(_EVAL_65__EVAL_67_en & _EVAL_65__EVAL_67_mask) begin
      _EVAL_65[_EVAL_65__EVAL_67_addr] <= _EVAL_65__EVAL_67_data;
    end
  end
endmodule
