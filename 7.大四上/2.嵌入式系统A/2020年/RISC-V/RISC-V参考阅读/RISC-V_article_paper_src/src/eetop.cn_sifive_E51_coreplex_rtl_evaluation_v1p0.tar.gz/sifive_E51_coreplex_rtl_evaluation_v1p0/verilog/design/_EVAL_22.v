//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_22(
  input  [63:0] _EVAL_0,
  input  [2:0]  _EVAL_1,
  input  [2:0]  _EVAL_2,
  output        _EVAL_3,
  input         _EVAL_4,
  input         _EVAL_5,
  input         _EVAL_6,
  input         _EVAL_7,
  output [1:0]  _EVAL_8,
  output [1:0]  _EVAL_9,
  input  [2:0]  _EVAL_10,
  output        _EVAL_11,
  output [2:0]  _EVAL_12,
  input         _EVAL_13,
  output [63:0] _EVAL_14,
  input  [3:0]  _EVAL_15,
  output [2:0]  _EVAL_16,
  output        _EVAL_17,
  output        _EVAL_18,
  input         _EVAL_19,
  output [2:0]  _EVAL_20,
  output [3:0]  _EVAL_21,
  input  [1:0]  _EVAL_22
);
  wire  _EVAL_23;
  wire  _EVAL_24;
  reg [2:0] _EVAL_25 [0:1];
  reg [31:0] _GEN_0;
  wire [2:0] _EVAL_25__EVAL_26_data;
  wire  _EVAL_25__EVAL_26_addr;
  wire [2:0] _EVAL_25__EVAL_27_data;
  wire  _EVAL_25__EVAL_27_addr;
  wire  _EVAL_25__EVAL_27_mask;
  wire  _EVAL_25__EVAL_27_en;
  wire [1:0] _EVAL_28;
  wire [1:0] _EVAL_29;
  wire  _EVAL_30;
  reg [63:0] _EVAL_31 [0:1];
  reg [63:0] _GEN_1;
  wire [63:0] _EVAL_31__EVAL_32_data;
  wire  _EVAL_31__EVAL_32_addr;
  wire [63:0] _EVAL_31__EVAL_33_data;
  wire  _EVAL_31__EVAL_33_addr;
  wire  _EVAL_31__EVAL_33_mask;
  wire  _EVAL_31__EVAL_33_en;
  wire [1:0] _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  reg  _EVAL_38;
  reg [31:0] _GEN_2;
  wire  _EVAL_39;
  wire  _EVAL_40;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_43;
  reg [1:0] _EVAL_44 [0:1];
  reg [31:0] _GEN_3;
  wire [1:0] _EVAL_44__EVAL_45_data;
  wire  _EVAL_44__EVAL_45_addr;
  wire [1:0] _EVAL_44__EVAL_46_data;
  wire  _EVAL_44__EVAL_46_addr;
  wire  _EVAL_44__EVAL_46_mask;
  wire  _EVAL_44__EVAL_46_en;
  reg  _EVAL_47 [0:1];
  reg [31:0] _GEN_4;
  wire  _EVAL_47__EVAL_48_data;
  wire  _EVAL_47__EVAL_48_addr;
  wire  _EVAL_47__EVAL_49_data;
  wire  _EVAL_47__EVAL_49_addr;
  wire  _EVAL_47__EVAL_49_mask;
  wire  _EVAL_47__EVAL_49_en;
  wire  _EVAL_50;
  wire  _EVAL_51;
  wire [1:0] _EVAL_52;
  wire  _EVAL_53;
  reg [3:0] _EVAL_54 [0:1];
  reg [31:0] _GEN_5;
  wire [3:0] _EVAL_54__EVAL_55_data;
  wire  _EVAL_54__EVAL_55_addr;
  wire [3:0] _EVAL_54__EVAL_56_data;
  wire  _EVAL_54__EVAL_56_addr;
  wire  _EVAL_54__EVAL_56_mask;
  wire  _EVAL_54__EVAL_56_en;
  reg  _EVAL_57 [0:1];
  reg [31:0] _GEN_6;
  wire  _EVAL_57__EVAL_58_data;
  wire  _EVAL_57__EVAL_58_addr;
  wire  _EVAL_57__EVAL_59_data;
  wire  _EVAL_57__EVAL_59_addr;
  wire  _EVAL_57__EVAL_59_mask;
  wire  _EVAL_57__EVAL_59_en;
  wire [1:0] _EVAL_60;
  wire  _EVAL_61;
  reg  _EVAL_62;
  reg [31:0] _GEN_7;
  reg  _EVAL_63;
  reg [31:0] _GEN_8;
  reg [2:0] _EVAL_64 [0:1];
  reg [31:0] _GEN_9;
  wire [2:0] _EVAL_64__EVAL_65_data;
  wire  _EVAL_64__EVAL_65_addr;
  wire [2:0] _EVAL_64__EVAL_66_data;
  wire  _EVAL_64__EVAL_66_addr;
  wire  _EVAL_64__EVAL_66_mask;
  wire  _EVAL_64__EVAL_66_en;
  wire  _EVAL_67;
  wire  _EVAL_68;
  reg [2:0] _EVAL_69 [0:1];
  reg [31:0] _GEN_10;
  wire [2:0] _EVAL_69__EVAL_70_data;
  wire  _EVAL_69__EVAL_70_addr;
  wire [2:0] _EVAL_69__EVAL_71_data;
  wire  _EVAL_69__EVAL_71_addr;
  wire  _EVAL_69__EVAL_71_mask;
  wire  _EVAL_69__EVAL_71_en;
  wire  _EVAL_72;
  assign _EVAL_3 = _EVAL_43;
  assign _EVAL_8 = _EVAL_52;
  assign _EVAL_9 = _EVAL_44__EVAL_45_data;
  assign _EVAL_11 = _EVAL_57__EVAL_58_data;
  assign _EVAL_12 = _EVAL_25__EVAL_26_data;
  assign _EVAL_14 = _EVAL_31__EVAL_32_data;
  assign _EVAL_16 = _EVAL_69__EVAL_70_data;
  assign _EVAL_17 = _EVAL_41;
  assign _EVAL_18 = _EVAL_47__EVAL_48_data;
  assign _EVAL_20 = _EVAL_64__EVAL_65_data;
  assign _EVAL_21 = _EVAL_54__EVAL_55_data;
  assign _EVAL_23 = _EVAL_19 & _EVAL_3;
  assign _EVAL_24 = _EVAL_29[0:0];
  assign _EVAL_25__EVAL_26_addr = _EVAL_38;
  assign _EVAL_25__EVAL_26_data = _EVAL_25[_EVAL_25__EVAL_26_addr];
  assign _EVAL_25__EVAL_27_data = _EVAL_2;
  assign _EVAL_25__EVAL_27_addr = _EVAL_63;
  assign _EVAL_25__EVAL_27_mask = _EVAL_40;
  assign _EVAL_25__EVAL_27_en = _EVAL_40;
  assign _EVAL_28 = _EVAL_63 - _EVAL_38;
  assign _EVAL_29 = _EVAL_38 + 1'h1;
  assign _EVAL_30 = _EVAL_23;
  assign _EVAL_31__EVAL_32_addr = _EVAL_38;
  assign _EVAL_31__EVAL_32_data = _EVAL_31[_EVAL_31__EVAL_32_addr];
  assign _EVAL_31__EVAL_33_data = _EVAL_0;
  assign _EVAL_31__EVAL_33_addr = _EVAL_63;
  assign _EVAL_31__EVAL_33_mask = _EVAL_40;
  assign _EVAL_31__EVAL_33_en = _EVAL_40;
  assign _EVAL_34 = $unsigned(_EVAL_28);
  assign _EVAL_35 = _EVAL_40 != _EVAL_30;
  assign _EVAL_36 = _EVAL_60[0:0];
  assign _EVAL_37 = _EVAL_62 & _EVAL_50;
  assign _EVAL_39 = _EVAL_34[0:0];
  assign _EVAL_40 = _EVAL_53;
  assign _EVAL_41 = _EVAL_61 == 1'h0;
  assign _EVAL_42 = _EVAL_35 ? _EVAL_40 : _EVAL_62;
  assign _EVAL_43 = _EVAL_68 == 1'h0;
  assign _EVAL_44__EVAL_45_addr = _EVAL_38;
  assign _EVAL_44__EVAL_45_data = _EVAL_44[_EVAL_44__EVAL_45_addr];
  assign _EVAL_44__EVAL_46_data = _EVAL_22;
  assign _EVAL_44__EVAL_46_addr = _EVAL_63;
  assign _EVAL_44__EVAL_46_mask = _EVAL_40;
  assign _EVAL_44__EVAL_46_en = _EVAL_40;
  assign _EVAL_47__EVAL_48_addr = _EVAL_38;
  assign _EVAL_47__EVAL_48_data = _EVAL_47[_EVAL_47__EVAL_48_addr];
  assign _EVAL_47__EVAL_49_data = _EVAL_4;
  assign _EVAL_47__EVAL_49_addr = _EVAL_63;
  assign _EVAL_47__EVAL_49_mask = _EVAL_40;
  assign _EVAL_47__EVAL_49_en = _EVAL_40;
  assign _EVAL_50 = _EVAL_63 == _EVAL_38;
  assign _EVAL_51 = _EVAL_30 ? _EVAL_24 : _EVAL_38;
  assign _EVAL_52 = {_EVAL_37,_EVAL_39};
  assign _EVAL_53 = _EVAL_17 & _EVAL_5;
  assign _EVAL_54__EVAL_55_addr = _EVAL_38;
  assign _EVAL_54__EVAL_55_data = _EVAL_54[_EVAL_54__EVAL_55_addr];
  assign _EVAL_54__EVAL_56_data = _EVAL_15;
  assign _EVAL_54__EVAL_56_addr = _EVAL_63;
  assign _EVAL_54__EVAL_56_mask = _EVAL_40;
  assign _EVAL_54__EVAL_56_en = _EVAL_40;
  assign _EVAL_57__EVAL_58_addr = _EVAL_38;
  assign _EVAL_57__EVAL_58_data = _EVAL_57[_EVAL_57__EVAL_58_addr];
  assign _EVAL_57__EVAL_59_data = _EVAL_13;
  assign _EVAL_57__EVAL_59_addr = _EVAL_63;
  assign _EVAL_57__EVAL_59_mask = _EVAL_40;
  assign _EVAL_57__EVAL_59_en = _EVAL_40;
  assign _EVAL_60 = _EVAL_63 + 1'h1;
  assign _EVAL_61 = _EVAL_50 & _EVAL_62;
  assign _EVAL_64__EVAL_65_addr = _EVAL_38;
  assign _EVAL_64__EVAL_65_data = _EVAL_64[_EVAL_64__EVAL_65_addr];
  assign _EVAL_64__EVAL_66_data = _EVAL_10;
  assign _EVAL_64__EVAL_66_addr = _EVAL_63;
  assign _EVAL_64__EVAL_66_mask = _EVAL_40;
  assign _EVAL_64__EVAL_66_en = _EVAL_40;
  assign _EVAL_67 = _EVAL_40 ? _EVAL_36 : _EVAL_63;
  assign _EVAL_68 = _EVAL_50 & _EVAL_72;
  assign _EVAL_69__EVAL_70_addr = _EVAL_38;
  assign _EVAL_69__EVAL_70_data = _EVAL_69[_EVAL_69__EVAL_70_addr];
  assign _EVAL_69__EVAL_71_data = _EVAL_1;
  assign _EVAL_69__EVAL_71_addr = _EVAL_63;
  assign _EVAL_69__EVAL_71_mask = _EVAL_40;
  assign _EVAL_69__EVAL_71_en = _EVAL_40;
  assign _EVAL_72 = _EVAL_62 == 1'h0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_25[initvar] = _GEN_0[2:0];
  `endif
  _GEN_1 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_31[initvar] = _GEN_1[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_38 = _GEN_2[0:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_44[initvar] = _GEN_3[1:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_47[initvar] = _GEN_4[0:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_54[initvar] = _GEN_5[3:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_57[initvar] = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_62 = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_63 = _GEN_8[0:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_64[initvar] = _GEN_9[2:0];
  `endif
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_69[initvar] = _GEN_10[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_7) begin
    if(_EVAL_25__EVAL_27_en & _EVAL_25__EVAL_27_mask) begin
      _EVAL_25[_EVAL_25__EVAL_27_addr] <= _EVAL_25__EVAL_27_data;
    end
    if(_EVAL_31__EVAL_33_en & _EVAL_31__EVAL_33_mask) begin
      _EVAL_31[_EVAL_31__EVAL_33_addr] <= _EVAL_31__EVAL_33_data;
    end
    if (_EVAL_6) begin
      _EVAL_38 <= 1'h0;
    end else begin
      if (_EVAL_30) begin
        _EVAL_38 <= _EVAL_24;
      end
    end
    if(_EVAL_44__EVAL_46_en & _EVAL_44__EVAL_46_mask) begin
      _EVAL_44[_EVAL_44__EVAL_46_addr] <= _EVAL_44__EVAL_46_data;
    end
    if(_EVAL_47__EVAL_49_en & _EVAL_47__EVAL_49_mask) begin
      _EVAL_47[_EVAL_47__EVAL_49_addr] <= _EVAL_47__EVAL_49_data;
    end
    if(_EVAL_54__EVAL_56_en & _EVAL_54__EVAL_56_mask) begin
      _EVAL_54[_EVAL_54__EVAL_56_addr] <= _EVAL_54__EVAL_56_data;
    end
    if(_EVAL_57__EVAL_59_en & _EVAL_57__EVAL_59_mask) begin
      _EVAL_57[_EVAL_57__EVAL_59_addr] <= _EVAL_57__EVAL_59_data;
    end
    if (_EVAL_6) begin
      _EVAL_62 <= 1'h0;
    end else begin
      if (_EVAL_35) begin
        _EVAL_62 <= _EVAL_40;
      end
    end
    if (_EVAL_6) begin
      _EVAL_63 <= 1'h0;
    end else begin
      if (_EVAL_40) begin
        _EVAL_63 <= _EVAL_36;
      end
    end
    if(_EVAL_64__EVAL_66_en & _EVAL_64__EVAL_66_mask) begin
      _EVAL_64[_EVAL_64__EVAL_66_addr] <= _EVAL_64__EVAL_66_data;
    end
    if(_EVAL_69__EVAL_71_en & _EVAL_69__EVAL_71_mask) begin
      _EVAL_69[_EVAL_69__EVAL_71_addr] <= _EVAL_69__EVAL_71_data;
    end
  end
endmodule
