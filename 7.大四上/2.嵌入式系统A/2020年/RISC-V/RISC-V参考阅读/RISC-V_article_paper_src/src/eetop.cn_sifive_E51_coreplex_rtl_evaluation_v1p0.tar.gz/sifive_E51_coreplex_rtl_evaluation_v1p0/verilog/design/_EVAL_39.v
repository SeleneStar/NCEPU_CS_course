//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_39(
  input  [2:0]  _EVAL_0,
  input         _EVAL_1,
  input  [8:0]  _EVAL_2,
  output [2:0]  _EVAL_3,
  input         _EVAL_4,
  output [31:0] _EVAL_5,
  input         _EVAL_6,
  output        _EVAL_7,
  output [2:0]  _EVAL_8,
  input         _EVAL_9,
  output        _EVAL_10,
  input         _EVAL_11,
  output        _EVAL_12,
  output [3:0]  _EVAL_13,
  output [8:0]  _EVAL_14,
  input         _EVAL_15,
  input  [3:0]  _EVAL_16,
  output [1:0]  _EVAL_17,
  input  [31:0] _EVAL_18,
  input         _EVAL_19,
  input  [2:0]  _EVAL_20,
  input  [1:0]  _EVAL_21,
  output        _EVAL_22
);
  wire  _EVAL_23;
  wire [1:0] _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire [31:0] _EVAL_27;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  reg [31:0] _EVAL_28;
  reg [31:0] _GEN_0;
  wire  ready_reg__EVAL_0;
  wire  ready_reg__EVAL_1;
  wire  ready_reg__EVAL_2;
  wire  ready_reg__EVAL_3;
  wire  ready_reg__EVAL_4;
  reg [2:0] _EVAL_29;
  reg [31:0] _GEN_1;
  wire  widx_bin__EVAL_0;
  wire  widx_bin__EVAL_1;
  wire  widx_bin__EVAL_2;
  wire  widx_bin__EVAL_3;
  wire  widx_bin__EVAL_4;
  wire [2:0] _EVAL_30;
  wire  _EVAL_31;
  wire [1:0] _EVAL_32;
  wire  widx_gray__EVAL_0;
  wire  widx_gray__EVAL_1;
  wire  widx_gray__EVAL_2;
  wire  widx_gray__EVAL_3;
  wire  widx_gray__EVAL_4;
  reg [2:0] _EVAL_33;
  reg [31:0] _GEN_2;
  wire  ridx_gray_sync_0__EVAL_0;
  wire  ridx_gray_sync_0__EVAL_1;
  wire  ridx_gray_sync_0__EVAL_2;
  wire  ridx_gray_sync_0__EVAL_3;
  wire  ridx_gray_sync_0__EVAL_4;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  reg  _EVAL_38;
  reg [31:0] _GEN_3;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  wire  _EVAL_39;
  wire  ridx_gray_sync_1__EVAL_0;
  wire  ridx_gray_sync_1__EVAL_1;
  wire  ridx_gray_sync_1__EVAL_2;
  wire  ridx_gray_sync_1__EVAL_3;
  wire  ridx_gray_sync_1__EVAL_4;
  wire  _EVAL_40;
  wire  _EVAL_41;
  reg [3:0] _EVAL_42;
  reg [31:0] _GEN_4;
  wire [3:0] _EVAL_43;
  wire [2:0] _EVAL_44;
  wire  ridx_gray_sync_2__EVAL_0;
  wire  ridx_gray_sync_2__EVAL_1;
  wire  ridx_gray_sync_2__EVAL_2;
  wire  ridx_gray_sync_2__EVAL_3;
  wire  ridx_gray_sync_2__EVAL_4;
  wire [8:0] _EVAL_45;
  wire  _EVAL_46;
  reg [8:0] _EVAL_47;
  reg [31:0] _GEN_5;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  wire  _EVAL_48;
  reg [1:0] _EVAL_49;
  reg [31:0] _GEN_6;
  wire  _EVAL_50;
  wire  _EVAL_51;
  wire  _EVAL_52;
  _EVAL_36 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_32 ready_reg (
    ._EVAL_0(ready_reg__EVAL_0),
    ._EVAL_1(ready_reg__EVAL_1),
    ._EVAL_2(ready_reg__EVAL_2),
    ._EVAL_3(ready_reg__EVAL_3),
    ._EVAL_4(ready_reg__EVAL_4)
  );
  _EVAL_32 widx_bin (
    ._EVAL_0(widx_bin__EVAL_0),
    ._EVAL_1(widx_bin__EVAL_1),
    ._EVAL_2(widx_bin__EVAL_2),
    ._EVAL_3(widx_bin__EVAL_3),
    ._EVAL_4(widx_bin__EVAL_4)
  );
  _EVAL_32 widx_gray (
    ._EVAL_0(widx_gray__EVAL_0),
    ._EVAL_1(widx_gray__EVAL_1),
    ._EVAL_2(widx_gray__EVAL_2),
    ._EVAL_3(widx_gray__EVAL_3),
    ._EVAL_4(widx_gray__EVAL_4)
  );
  _EVAL_32 ridx_gray_sync_0 (
    ._EVAL_0(ridx_gray_sync_0__EVAL_0),
    ._EVAL_1(ridx_gray_sync_0__EVAL_1),
    ._EVAL_2(ridx_gray_sync_0__EVAL_2),
    ._EVAL_3(ridx_gray_sync_0__EVAL_3),
    ._EVAL_4(ridx_gray_sync_0__EVAL_4)
  );
  _EVAL_38 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  _EVAL_32 ridx_gray_sync_1 (
    ._EVAL_0(ridx_gray_sync_1__EVAL_0),
    ._EVAL_1(ridx_gray_sync_1__EVAL_1),
    ._EVAL_2(ridx_gray_sync_1__EVAL_2),
    ._EVAL_3(ridx_gray_sync_1__EVAL_3),
    ._EVAL_4(ridx_gray_sync_1__EVAL_4)
  );
  _EVAL_32 ridx_gray_sync_2 (
    ._EVAL_0(ridx_gray_sync_2__EVAL_0),
    ._EVAL_1(ridx_gray_sync_2__EVAL_1),
    ._EVAL_2(ridx_gray_sync_2__EVAL_2),
    ._EVAL_3(ridx_gray_sync_2__EVAL_3),
    ._EVAL_4(ridx_gray_sync_2__EVAL_4)
  );
  _EVAL_37 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  assign _EVAL_3 = _EVAL_33;
  assign _EVAL_5 = _EVAL_28;
  assign _EVAL_7 = _EVAL_46;
  assign _EVAL_8 = _EVAL_29;
  assign _EVAL_10 = widx_gray__EVAL_2;
  assign _EVAL_12 = _EVAL_38;
  assign _EVAL_13 = _EVAL_42;
  assign _EVAL_14 = _EVAL_47;
  assign _EVAL_17 = _EVAL_49;
  assign _EVAL_22 = AsyncValidSync__EVAL_0;
  assign _EVAL_23 = _EVAL_41 ? _EVAL_1 : _EVAL_38;
  assign _EVAL_24 = widx_bin__EVAL_2 + _EVAL_41;
  assign _EVAL_25 = ready_reg__EVAL_2;
  assign _EVAL_26 = AsyncValidSync_2__EVAL_2;
  assign _EVAL_27 = _EVAL_41 ? _EVAL_18 : _EVAL_28;
  assign AsyncValidSync__EVAL_1 = _EVAL_11;
  assign AsyncValidSync__EVAL_2 = 1'h1;
  assign AsyncValidSync__EVAL_3 = _EVAL_31;
  assign ready_reg__EVAL_0 = 1'h1;
  assign ready_reg__EVAL_1 = _EVAL_15;
  assign ready_reg__EVAL_3 = _EVAL_11;
  assign ready_reg__EVAL_4 = _EVAL_40;
  assign widx_bin__EVAL_0 = 1'h1;
  assign widx_bin__EVAL_1 = _EVAL_15;
  assign widx_bin__EVAL_3 = _EVAL_11;
  assign widx_bin__EVAL_4 = _EVAL_36;
  assign _EVAL_30 = _EVAL_41 ? _EVAL_20 : _EVAL_33;
  assign _EVAL_31 = _EVAL_15 | _EVAL_51;
  assign _EVAL_32 = _EVAL_41 ? _EVAL_21 : _EVAL_49;
  assign widx_gray__EVAL_0 = 1'h1;
  assign widx_gray__EVAL_1 = _EVAL_15;
  assign widx_gray__EVAL_3 = _EVAL_11;
  assign widx_gray__EVAL_4 = _EVAL_37;
  assign ridx_gray_sync_0__EVAL_0 = 1'h1;
  assign ridx_gray_sync_0__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_0__EVAL_3 = _EVAL_11;
  assign ridx_gray_sync_0__EVAL_4 = ridx_gray_sync_1__EVAL_2;
  assign _EVAL_34 = _EVAL_37 != _EVAL_35;
  assign _EVAL_35 = ridx_gray_sync_0__EVAL_2 ^ 1'h1;
  assign _EVAL_36 = _EVAL_50;
  assign _EVAL_37 = _EVAL_36 ^ _EVAL_48;
  assign AsyncValidSync_2__EVAL_0 = _EVAL_15;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_11;
  assign AsyncValidSync_2__EVAL_3 = AsyncValidSync_1__EVAL_2;
  assign _EVAL_39 = _EVAL_26 == 1'h0;
  assign ridx_gray_sync_1__EVAL_0 = 1'h1;
  assign ridx_gray_sync_1__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_1__EVAL_3 = _EVAL_11;
  assign ridx_gray_sync_1__EVAL_4 = ridx_gray_sync_2__EVAL_2;
  assign _EVAL_40 = _EVAL_26 & _EVAL_34;
  assign _EVAL_41 = _EVAL_7 & _EVAL_6;
  assign _EVAL_43 = _EVAL_41 ? _EVAL_16 : _EVAL_42;
  assign _EVAL_44 = _EVAL_41 ? _EVAL_0 : _EVAL_29;
  assign ridx_gray_sync_2__EVAL_0 = 1'h1;
  assign ridx_gray_sync_2__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_2__EVAL_3 = _EVAL_11;
  assign ridx_gray_sync_2__EVAL_4 = _EVAL_9;
  assign _EVAL_45 = _EVAL_41 ? _EVAL_2 : _EVAL_47;
  assign _EVAL_46 = _EVAL_25 & _EVAL_26;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_31;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_11;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_4;
  assign _EVAL_48 = _EVAL_36 >> 1'h1;
  assign _EVAL_50 = _EVAL_39 ? 1'h0 : _EVAL_52;
  assign _EVAL_51 = _EVAL_19 == 1'h0;
  assign _EVAL_52 = _EVAL_24[0:0];
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_28 = _GEN_0[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_29 = _GEN_1[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_33 = _GEN_2[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_38 = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_42 = _GEN_4[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_5[8:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_49 = _GEN_6[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_11) begin
    if (_EVAL_41) begin
      _EVAL_28 <= _EVAL_18;
    end
    if (_EVAL_41) begin
      _EVAL_29 <= _EVAL_0;
    end
    if (_EVAL_41) begin
      _EVAL_33 <= _EVAL_20;
    end
    if (_EVAL_41) begin
      _EVAL_38 <= _EVAL_1;
    end
    if (_EVAL_41) begin
      _EVAL_42 <= _EVAL_16;
    end
    if (_EVAL_41) begin
      _EVAL_47 <= _EVAL_2;
    end
    if (_EVAL_41) begin
      _EVAL_49 <= _EVAL_21;
    end
  end
endmodule
