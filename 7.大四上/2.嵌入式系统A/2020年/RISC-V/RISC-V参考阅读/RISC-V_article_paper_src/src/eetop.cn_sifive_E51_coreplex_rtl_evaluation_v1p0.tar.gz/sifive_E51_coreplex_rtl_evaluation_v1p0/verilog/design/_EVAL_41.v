//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_41(
  input   _EVAL_0,
  input   _EVAL_1,
  output  _EVAL_2,
  input   _EVAL_3
);
  wire  _EVAL_4;
  wire  source_extend_sync_0__EVAL_0;
  wire  source_extend_sync_0__EVAL_1;
  wire  source_extend_sync_0__EVAL_2;
  wire  source_extend_sync_0__EVAL_3;
  wire  source_extend_sync_0__EVAL_4;
  _EVAL_32 source_extend_sync_0 (
    ._EVAL_0(source_extend_sync_0__EVAL_0),
    ._EVAL_1(source_extend_sync_0__EVAL_1),
    ._EVAL_2(source_extend_sync_0__EVAL_2),
    ._EVAL_3(source_extend_sync_0__EVAL_3),
    ._EVAL_4(source_extend_sync_0__EVAL_4)
  );
  assign _EVAL_2 = _EVAL_4;
  assign _EVAL_4 = source_extend_sync_0__EVAL_2;
  assign source_extend_sync_0__EVAL_0 = 1'h1;
  assign source_extend_sync_0__EVAL_1 = _EVAL_0;
  assign source_extend_sync_0__EVAL_3 = _EVAL_1;
  assign source_extend_sync_0__EVAL_4 = _EVAL_3;
endmodule
