//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_43(
  input         _EVAL_0,
  output [1:0]  _EVAL_1,
  input  [31:0] _EVAL_2,
  output        _EVAL_3,
  input         _EVAL_4,
  input         _EVAL_5,
  input         _EVAL_6,
  input         _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  output        _EVAL_10,
  output [1:0]  _EVAL_11,
  input  [2:0]  _EVAL_12,
  output        _EVAL_13,
  output        _EVAL_14,
  input  [1:0]  _EVAL_15,
  input         _EVAL_16,
  output        _EVAL_17,
  output [31:0] _EVAL_18,
  input  [1:0]  _EVAL_19,
  output [1:0]  _EVAL_20,
  output        _EVAL_21,
  input         _EVAL_22,
  output [2:0]  _EVAL_23,
  input  [1:0]  _EVAL_24
);
  wire [1:0] _EVAL_25;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  reg  _EVAL_29;
  reg [31:0] _GEN_0;
  wire  _EVAL_31;
  wire [1:0] _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire  widx_gray_sync_0__EVAL_0;
  wire  widx_gray_sync_0__EVAL_1;
  wire  widx_gray_sync_0__EVAL_2;
  wire  widx_gray_sync_0__EVAL_3;
  wire  widx_gray_sync_0__EVAL_4;
  reg [2:0] _EVAL_37;
  reg [31:0] _GEN_1;
  wire  _EVAL_38;
  wire  widx_gray_sync_2__EVAL_0;
  wire  widx_gray_sync_2__EVAL_1;
  wire  widx_gray_sync_2__EVAL_2;
  wire  widx_gray_sync_2__EVAL_3;
  wire  widx_gray_sync_2__EVAL_4;
  wire  valid_reg__EVAL_0;
  wire  valid_reg__EVAL_1;
  wire  valid_reg__EVAL_2;
  wire  valid_reg__EVAL_3;
  wire  valid_reg__EVAL_4;
  reg [1:0] _EVAL_39;
  reg [31:0] _GEN_2;
  wire  ridx_bin__EVAL_0;
  wire  ridx_bin__EVAL_1;
  wire  ridx_bin__EVAL_2;
  wire  ridx_bin__EVAL_3;
  wire  ridx_bin__EVAL_4;
  wire [31:0] _EVAL_40;
  wire  _EVAL_41;
  wire [2:0] _EVAL_42;
  wire  _EVAL_43;
  wire  _EVAL_44;
  wire  _EVAL_45;
  wire  widx_gray_sync_1__EVAL_0;
  wire  widx_gray_sync_1__EVAL_1;
  wire  widx_gray_sync_1__EVAL_2;
  wire  widx_gray_sync_1__EVAL_3;
  wire  widx_gray_sync_1__EVAL_4;
  reg  _EVAL_46;
  reg [31:0] _GEN_3;
  reg [31:0] _EVAL_47;
  reg [31:0] _GEN_4;
  wire  _EVAL_48;
  wire  _EVAL_49;
  wire [1:0] _EVAL_50;
  wire  _EVAL_51;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  reg [1:0] _EVAL_52;
  reg [31:0] _GEN_5;
  wire  _EVAL_53;
  wire  _EVAL_55;
  reg  _EVAL_56;
  reg [31:0] _GEN_6;
  wire  _EVAL_57;
  wire  ridx_gray__EVAL_0;
  wire  ridx_gray__EVAL_1;
  wire  ridx_gray__EVAL_2;
  wire  ridx_gray__EVAL_3;
  wire  ridx_gray__EVAL_4;
  wire [1:0] _EVAL_58;
  reg [1:0] _EVAL_59;
  reg [31:0] _GEN_7;
  _EVAL_42 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  _EVAL_41 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  _EVAL_32 widx_gray_sync_0 (
    ._EVAL_0(widx_gray_sync_0__EVAL_0),
    ._EVAL_1(widx_gray_sync_0__EVAL_1),
    ._EVAL_2(widx_gray_sync_0__EVAL_2),
    ._EVAL_3(widx_gray_sync_0__EVAL_3),
    ._EVAL_4(widx_gray_sync_0__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_2 (
    ._EVAL_0(widx_gray_sync_2__EVAL_0),
    ._EVAL_1(widx_gray_sync_2__EVAL_1),
    ._EVAL_2(widx_gray_sync_2__EVAL_2),
    ._EVAL_3(widx_gray_sync_2__EVAL_3),
    ._EVAL_4(widx_gray_sync_2__EVAL_4)
  );
  _EVAL_32 valid_reg (
    ._EVAL_0(valid_reg__EVAL_0),
    ._EVAL_1(valid_reg__EVAL_1),
    ._EVAL_2(valid_reg__EVAL_2),
    ._EVAL_3(valid_reg__EVAL_3),
    ._EVAL_4(valid_reg__EVAL_4)
  );
  _EVAL_32 ridx_bin (
    ._EVAL_0(ridx_bin__EVAL_0),
    ._EVAL_1(ridx_bin__EVAL_1),
    ._EVAL_2(ridx_bin__EVAL_2),
    ._EVAL_3(ridx_bin__EVAL_3),
    ._EVAL_4(ridx_bin__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_1 (
    ._EVAL_0(widx_gray_sync_1__EVAL_0),
    ._EVAL_1(widx_gray_sync_1__EVAL_1),
    ._EVAL_2(widx_gray_sync_1__EVAL_2),
    ._EVAL_3(widx_gray_sync_1__EVAL_3),
    ._EVAL_4(widx_gray_sync_1__EVAL_4)
  );
  _EVAL_40 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_32 ridx_gray (
    ._EVAL_0(ridx_gray__EVAL_0),
    ._EVAL_1(ridx_gray__EVAL_1),
    ._EVAL_2(ridx_gray__EVAL_2),
    ._EVAL_3(ridx_gray__EVAL_3),
    ._EVAL_4(ridx_gray__EVAL_4)
  );
  assign _EVAL_1 = _EVAL_39;
  assign _EVAL_3 = _EVAL_46;
  assign _EVAL_10 = AsyncValidSync__EVAL_0;
  assign _EVAL_11 = _EVAL_52;
  assign _EVAL_13 = _EVAL_43;
  assign _EVAL_14 = _EVAL_56;
  assign _EVAL_17 = ridx_gray__EVAL_2;
  assign _EVAL_18 = _EVAL_47;
  assign _EVAL_20 = _EVAL_59;
  assign _EVAL_21 = _EVAL_29;
  assign _EVAL_23 = _EVAL_37;
  assign _EVAL_25 = _EVAL_49 ? _EVAL_19 : _EVAL_59;
  assign AsyncValidSync_2__EVAL_0 = AsyncValidSync_1__EVAL_2;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_8;
  assign AsyncValidSync_2__EVAL_2 = _EVAL_6;
  assign _EVAL_26 = _EVAL_6 | _EVAL_38;
  assign _EVAL_27 = valid_reg__EVAL_2;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_26;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_8;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_9;
  assign _EVAL_31 = _EVAL_49 ? _EVAL_4 : _EVAL_46;
  assign _EVAL_32 = _EVAL_49 ? _EVAL_15 : _EVAL_52;
  assign _EVAL_33 = _EVAL_48 != widx_gray_sync_0__EVAL_2;
  assign _EVAL_35 = _EVAL_41;
  assign _EVAL_36 = _EVAL_45 == 1'h0;
  assign widx_gray_sync_0__EVAL_0 = 1'h1;
  assign widx_gray_sync_0__EVAL_1 = _EVAL_6;
  assign widx_gray_sync_0__EVAL_3 = _EVAL_8;
  assign widx_gray_sync_0__EVAL_4 = widx_gray_sync_1__EVAL_2;
  assign _EVAL_38 = _EVAL_5 == 1'h0;
  assign widx_gray_sync_2__EVAL_0 = 1'h1;
  assign widx_gray_sync_2__EVAL_1 = _EVAL_6;
  assign widx_gray_sync_2__EVAL_3 = _EVAL_8;
  assign widx_gray_sync_2__EVAL_4 = _EVAL_16;
  assign valid_reg__EVAL_0 = 1'h1;
  assign valid_reg__EVAL_1 = _EVAL_6;
  assign valid_reg__EVAL_3 = _EVAL_8;
  assign valid_reg__EVAL_4 = _EVAL_49;
  assign ridx_bin__EVAL_0 = 1'h1;
  assign ridx_bin__EVAL_1 = _EVAL_6;
  assign ridx_bin__EVAL_3 = _EVAL_8;
  assign ridx_bin__EVAL_4 = _EVAL_35;
  assign _EVAL_40 = _EVAL_49 ? _EVAL_2 : _EVAL_47;
  assign _EVAL_41 = _EVAL_36 ? 1'h0 : _EVAL_51;
  assign _EVAL_42 = _EVAL_49 ? _EVAL_12 : _EVAL_37;
  assign _EVAL_43 = _EVAL_27 & _EVAL_45;
  assign _EVAL_44 = _EVAL_49 ? _EVAL_22 : _EVAL_56;
  assign _EVAL_45 = AsyncValidSync_2__EVAL_3;
  assign widx_gray_sync_1__EVAL_0 = 1'h1;
  assign widx_gray_sync_1__EVAL_1 = _EVAL_6;
  assign widx_gray_sync_1__EVAL_3 = _EVAL_8;
  assign widx_gray_sync_1__EVAL_4 = widx_gray_sync_2__EVAL_2;
  assign _EVAL_48 = _EVAL_35 ^ _EVAL_57;
  assign _EVAL_49 = _EVAL_45 & _EVAL_33;
  assign _EVAL_50 = ridx_bin__EVAL_2 + _EVAL_53;
  assign _EVAL_51 = _EVAL_50[0:0];
  assign AsyncValidSync__EVAL_1 = 1'h1;
  assign AsyncValidSync__EVAL_2 = _EVAL_8;
  assign AsyncValidSync__EVAL_3 = _EVAL_26;
  assign _EVAL_53 = _EVAL_7 & _EVAL_13;
  assign _EVAL_55 = _EVAL_49 ? _EVAL_0 : _EVAL_29;
  assign _EVAL_57 = _EVAL_35 >> 1'h1;
  assign ridx_gray__EVAL_0 = 1'h1;
  assign ridx_gray__EVAL_1 = _EVAL_6;
  assign ridx_gray__EVAL_3 = _EVAL_8;
  assign ridx_gray__EVAL_4 = _EVAL_48;
  assign _EVAL_58 = _EVAL_49 ? _EVAL_24 : _EVAL_39;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_29 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_1[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_39 = _GEN_2[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_46 = _GEN_3[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_4[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_52 = _GEN_5[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_56 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_59 = _GEN_7[1:0];
  `endif
  end
`endif
  always @(posedge _EVAL_8) begin
    if (_EVAL_49) begin
      _EVAL_29 <= _EVAL_0;
    end
    if (_EVAL_49) begin
      _EVAL_37 <= _EVAL_12;
    end
    if (_EVAL_49) begin
      _EVAL_39 <= _EVAL_24;
    end
    if (_EVAL_49) begin
      _EVAL_46 <= _EVAL_4;
    end
    if (_EVAL_49) begin
      _EVAL_47 <= _EVAL_2;
    end
    if (_EVAL_49) begin
      _EVAL_52 <= _EVAL_15;
    end
    if (_EVAL_49) begin
      _EVAL_56 <= _EVAL_22;
    end
    if (_EVAL_49) begin
      _EVAL_59 <= _EVAL_19;
    end
  end
endmodule
