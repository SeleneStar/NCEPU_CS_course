//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_46(
  input        _EVAL_0,
  input        _EVAL_1,
  output       _EVAL_2,
  input        _EVAL_3,
  input  [9:0] _EVAL_4,
  output       _EVAL_5,
  output [9:0] _EVAL_6,
  output       _EVAL_7,
  output       _EVAL_8,
  input        _EVAL_9,
  input        _EVAL_10,
  input        _EVAL_11,
  input        _EVAL_12
);
  wire  _EVAL_13;
  wire  _EVAL_14;
  reg [9:0] _EVAL_15;
  reg [31:0] _GEN_0;
  wire [9:0] _EVAL_16;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  wire  _EVAL_17;
  wire  _EVAL_18;
  wire  ridx_gray_sync_1__EVAL_0;
  wire  ridx_gray_sync_1__EVAL_1;
  wire  ridx_gray_sync_1__EVAL_2;
  wire  ridx_gray_sync_1__EVAL_3;
  wire  ridx_gray_sync_1__EVAL_4;
  wire  _EVAL_19;
  wire  _EVAL_20;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  wire  _EVAL_21;
  wire  _EVAL_22;
  wire  _EVAL_23;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  wire  _EVAL_24;
  wire  ridx_gray_sync_2__EVAL_0;
  wire  ridx_gray_sync_2__EVAL_1;
  wire  ridx_gray_sync_2__EVAL_2;
  wire  ridx_gray_sync_2__EVAL_3;
  wire  ridx_gray_sync_2__EVAL_4;
  wire  _EVAL_25;
  wire  widx_gray__EVAL_0;
  wire  widx_gray__EVAL_1;
  wire  widx_gray__EVAL_2;
  wire  widx_gray__EVAL_3;
  wire  widx_gray__EVAL_4;
  wire  _EVAL_26;
  wire [1:0] _EVAL_27;
  wire  _EVAL_28;
  wire  _EVAL_29;
  wire  widx_bin__EVAL_0;
  wire  widx_bin__EVAL_1;
  wire  widx_bin__EVAL_2;
  wire  widx_bin__EVAL_3;
  wire  widx_bin__EVAL_4;
  wire  ready_reg__EVAL_0;
  wire  ready_reg__EVAL_1;
  wire  ready_reg__EVAL_2;
  wire  ready_reg__EVAL_3;
  wire  ready_reg__EVAL_4;
  wire  ridx_gray_sync_0__EVAL_0;
  wire  ridx_gray_sync_0__EVAL_1;
  wire  ridx_gray_sync_0__EVAL_2;
  wire  ridx_gray_sync_0__EVAL_3;
  wire  ridx_gray_sync_0__EVAL_4;
  reg  _EVAL_30;
  reg [31:0] _GEN_1;
  wire  _EVAL_31;
  wire  _EVAL_32;
  _EVAL_37 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  _EVAL_32 ridx_gray_sync_1 (
    ._EVAL_0(ridx_gray_sync_1__EVAL_0),
    ._EVAL_1(ridx_gray_sync_1__EVAL_1),
    ._EVAL_2(ridx_gray_sync_1__EVAL_2),
    ._EVAL_3(ridx_gray_sync_1__EVAL_3),
    ._EVAL_4(ridx_gray_sync_1__EVAL_4)
  );
  _EVAL_38 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  _EVAL_36 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_32 ridx_gray_sync_2 (
    ._EVAL_0(ridx_gray_sync_2__EVAL_0),
    ._EVAL_1(ridx_gray_sync_2__EVAL_1),
    ._EVAL_2(ridx_gray_sync_2__EVAL_2),
    ._EVAL_3(ridx_gray_sync_2__EVAL_3),
    ._EVAL_4(ridx_gray_sync_2__EVAL_4)
  );
  _EVAL_32 widx_gray (
    ._EVAL_0(widx_gray__EVAL_0),
    ._EVAL_1(widx_gray__EVAL_1),
    ._EVAL_2(widx_gray__EVAL_2),
    ._EVAL_3(widx_gray__EVAL_3),
    ._EVAL_4(widx_gray__EVAL_4)
  );
  _EVAL_32 widx_bin (
    ._EVAL_0(widx_bin__EVAL_0),
    ._EVAL_1(widx_bin__EVAL_1),
    ._EVAL_2(widx_bin__EVAL_2),
    ._EVAL_3(widx_bin__EVAL_3),
    ._EVAL_4(widx_bin__EVAL_4)
  );
  _EVAL_32 ready_reg (
    ._EVAL_0(ready_reg__EVAL_0),
    ._EVAL_1(ready_reg__EVAL_1),
    ._EVAL_2(ready_reg__EVAL_2),
    ._EVAL_3(ready_reg__EVAL_3),
    ._EVAL_4(ready_reg__EVAL_4)
  );
  _EVAL_32 ridx_gray_sync_0 (
    ._EVAL_0(ridx_gray_sync_0__EVAL_0),
    ._EVAL_1(ridx_gray_sync_0__EVAL_1),
    ._EVAL_2(ridx_gray_sync_0__EVAL_2),
    ._EVAL_3(ridx_gray_sync_0__EVAL_3),
    ._EVAL_4(ridx_gray_sync_0__EVAL_4)
  );
  assign _EVAL_2 = widx_gray__EVAL_2;
  assign _EVAL_5 = _EVAL_13;
  assign _EVAL_6 = _EVAL_15;
  assign _EVAL_7 = AsyncValidSync__EVAL_0;
  assign _EVAL_8 = _EVAL_30;
  assign _EVAL_13 = _EVAL_17 & _EVAL_21;
  assign _EVAL_14 = _EVAL_21 == 1'h0;
  assign _EVAL_16 = _EVAL_24 ? _EVAL_4 : _EVAL_15;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_31;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_3;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_0;
  assign _EVAL_17 = ready_reg__EVAL_2;
  assign _EVAL_18 = _EVAL_20 != _EVAL_22;
  assign ridx_gray_sync_1__EVAL_0 = 1'h1;
  assign ridx_gray_sync_1__EVAL_1 = _EVAL_11;
  assign ridx_gray_sync_1__EVAL_3 = _EVAL_3;
  assign ridx_gray_sync_1__EVAL_4 = ridx_gray_sync_2__EVAL_2;
  assign _EVAL_19 = _EVAL_9 == 1'h0;
  assign _EVAL_20 = _EVAL_32 ^ _EVAL_28;
  assign AsyncValidSync_2__EVAL_0 = _EVAL_11;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_3;
  assign AsyncValidSync_2__EVAL_3 = AsyncValidSync_1__EVAL_2;
  assign _EVAL_21 = AsyncValidSync_2__EVAL_2;
  assign _EVAL_22 = ridx_gray_sync_0__EVAL_2 ^ 1'h1;
  assign _EVAL_23 = _EVAL_21 & _EVAL_18;
  assign AsyncValidSync__EVAL_1 = _EVAL_3;
  assign AsyncValidSync__EVAL_2 = 1'h1;
  assign AsyncValidSync__EVAL_3 = _EVAL_31;
  assign _EVAL_24 = _EVAL_5 & _EVAL_10;
  assign ridx_gray_sync_2__EVAL_0 = 1'h1;
  assign ridx_gray_sync_2__EVAL_1 = _EVAL_11;
  assign ridx_gray_sync_2__EVAL_3 = _EVAL_3;
  assign ridx_gray_sync_2__EVAL_4 = _EVAL_12;
  assign _EVAL_25 = _EVAL_24 ? _EVAL_1 : _EVAL_30;
  assign widx_gray__EVAL_0 = 1'h1;
  assign widx_gray__EVAL_1 = _EVAL_11;
  assign widx_gray__EVAL_3 = _EVAL_3;
  assign widx_gray__EVAL_4 = _EVAL_20;
  assign _EVAL_26 = _EVAL_14 ? 1'h0 : _EVAL_29;
  assign _EVAL_27 = widx_bin__EVAL_2 + _EVAL_24;
  assign _EVAL_28 = _EVAL_32 >> 1'h1;
  assign _EVAL_29 = _EVAL_27[0:0];
  assign widx_bin__EVAL_0 = 1'h1;
  assign widx_bin__EVAL_1 = _EVAL_11;
  assign widx_bin__EVAL_3 = _EVAL_3;
  assign widx_bin__EVAL_4 = _EVAL_32;
  assign ready_reg__EVAL_0 = 1'h1;
  assign ready_reg__EVAL_1 = _EVAL_11;
  assign ready_reg__EVAL_3 = _EVAL_3;
  assign ready_reg__EVAL_4 = _EVAL_23;
  assign ridx_gray_sync_0__EVAL_0 = 1'h1;
  assign ridx_gray_sync_0__EVAL_1 = _EVAL_11;
  assign ridx_gray_sync_0__EVAL_3 = _EVAL_3;
  assign ridx_gray_sync_0__EVAL_4 = ridx_gray_sync_1__EVAL_2;
  assign _EVAL_31 = _EVAL_11 | _EVAL_19;
  assign _EVAL_32 = _EVAL_26;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_15 = _GEN_0[9:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_30 = _GEN_1[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_3) begin
    if (_EVAL_24) begin
      _EVAL_15 <= _EVAL_4;
    end
    if (_EVAL_24) begin
      _EVAL_30 <= _EVAL_1;
    end
  end
endmodule
