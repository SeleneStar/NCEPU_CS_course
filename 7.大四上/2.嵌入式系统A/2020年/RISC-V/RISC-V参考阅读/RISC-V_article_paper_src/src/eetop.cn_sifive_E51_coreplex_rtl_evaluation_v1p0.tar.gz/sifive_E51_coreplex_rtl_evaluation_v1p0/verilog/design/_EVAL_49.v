//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_49(
  output [3:0]  _EVAL_0,
  output        _EVAL_1,
  input         _EVAL_2,
  output [1:0]  _EVAL_3,
  output        _EVAL_4,
  input  [2:0]  _EVAL_5,
  input  [8:0]  _EVAL_6,
  input  [3:0]  _EVAL_7,
  output        _EVAL_8,
  output [8:0]  _EVAL_9,
  output [31:0] _EVAL_10,
  input  [2:0]  _EVAL_11,
  output [2:0]  _EVAL_12,
  input         _EVAL_13,
  input  [31:0] _EVAL_14,
  input         _EVAL_15,
  input  [1:0]  _EVAL_16,
  input         _EVAL_17,
  input         _EVAL_18,
  input         _EVAL_19,
  input         _EVAL_20,
  output [2:0]  _EVAL_21,
  output        _EVAL_22
);
  wire [8:0] _EVAL_23;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  wire [2:0] _EVAL_27;
  wire [31:0] _EVAL_29;
  wire  _EVAL_30;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  reg [2:0] _EVAL_34;
  reg [31:0] _GEN_0;
  wire [1:0] _EVAL_35;
  wire  _EVAL_36;
  reg [2:0] _EVAL_37;
  reg [31:0] _GEN_1;
  wire  valid_reg__EVAL_0;
  wire  valid_reg__EVAL_1;
  wire  valid_reg__EVAL_2;
  wire  valid_reg__EVAL_3;
  wire  valid_reg__EVAL_4;
  wire  _EVAL_39;
  wire  ridx_bin__EVAL_0;
  wire  ridx_bin__EVAL_1;
  wire  ridx_bin__EVAL_2;
  wire  ridx_bin__EVAL_3;
  wire  ridx_bin__EVAL_4;
  reg [3:0] _EVAL_41;
  reg [31:0] _GEN_2;
  wire  _EVAL_42;
  wire [2:0] _EVAL_43;
  wire  _EVAL_44;
  wire  _EVAL_45;
  wire  ridx_gray__EVAL_0;
  wire  ridx_gray__EVAL_1;
  wire  ridx_gray__EVAL_2;
  wire  ridx_gray__EVAL_3;
  wire  ridx_gray__EVAL_4;
  reg [8:0] _EVAL_46;
  reg [31:0] _GEN_3;
  reg [1:0] _EVAL_47;
  reg [31:0] _GEN_4;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  wire  widx_gray_sync_1__EVAL_0;
  wire  widx_gray_sync_1__EVAL_1;
  wire  widx_gray_sync_1__EVAL_2;
  wire  widx_gray_sync_1__EVAL_3;
  wire  widx_gray_sync_1__EVAL_4;
  reg  _EVAL_48;
  reg [31:0] _GEN_5;
  wire  _EVAL_49;
  reg [31:0] _EVAL_50;
  reg [31:0] _GEN_6;
  wire  _EVAL_51;
  wire [3:0] _EVAL_52;
  wire [1:0] _EVAL_53;
  wire  widx_gray_sync_2__EVAL_0;
  wire  widx_gray_sync_2__EVAL_1;
  wire  widx_gray_sync_2__EVAL_2;
  wire  widx_gray_sync_2__EVAL_3;
  wire  widx_gray_sync_2__EVAL_4;
  wire  widx_gray_sync_0__EVAL_0;
  wire  widx_gray_sync_0__EVAL_1;
  wire  widx_gray_sync_0__EVAL_2;
  wire  widx_gray_sync_0__EVAL_3;
  wire  widx_gray_sync_0__EVAL_4;
  wire  _EVAL_54;
  wire  _EVAL_55;
  _EVAL_40 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_42 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  _EVAL_32 valid_reg (
    ._EVAL_0(valid_reg__EVAL_0),
    ._EVAL_1(valid_reg__EVAL_1),
    ._EVAL_2(valid_reg__EVAL_2),
    ._EVAL_3(valid_reg__EVAL_3),
    ._EVAL_4(valid_reg__EVAL_4)
  );
  _EVAL_32 ridx_bin (
    ._EVAL_0(ridx_bin__EVAL_0),
    ._EVAL_1(ridx_bin__EVAL_1),
    ._EVAL_2(ridx_bin__EVAL_2),
    ._EVAL_3(ridx_bin__EVAL_3),
    ._EVAL_4(ridx_bin__EVAL_4)
  );
  _EVAL_32 ridx_gray (
    ._EVAL_0(ridx_gray__EVAL_0),
    ._EVAL_1(ridx_gray__EVAL_1),
    ._EVAL_2(ridx_gray__EVAL_2),
    ._EVAL_3(ridx_gray__EVAL_3),
    ._EVAL_4(ridx_gray__EVAL_4)
  );
  _EVAL_41 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  _EVAL_32 widx_gray_sync_1 (
    ._EVAL_0(widx_gray_sync_1__EVAL_0),
    ._EVAL_1(widx_gray_sync_1__EVAL_1),
    ._EVAL_2(widx_gray_sync_1__EVAL_2),
    ._EVAL_3(widx_gray_sync_1__EVAL_3),
    ._EVAL_4(widx_gray_sync_1__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_2 (
    ._EVAL_0(widx_gray_sync_2__EVAL_0),
    ._EVAL_1(widx_gray_sync_2__EVAL_1),
    ._EVAL_2(widx_gray_sync_2__EVAL_2),
    ._EVAL_3(widx_gray_sync_2__EVAL_3),
    ._EVAL_4(widx_gray_sync_2__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_0 (
    ._EVAL_0(widx_gray_sync_0__EVAL_0),
    ._EVAL_1(widx_gray_sync_0__EVAL_1),
    ._EVAL_2(widx_gray_sync_0__EVAL_2),
    ._EVAL_3(widx_gray_sync_0__EVAL_3),
    ._EVAL_4(widx_gray_sync_0__EVAL_4)
  );
  assign _EVAL_0 = _EVAL_41;
  assign _EVAL_1 = _EVAL_48;
  assign _EVAL_3 = _EVAL_47;
  assign _EVAL_4 = ridx_gray__EVAL_2;
  assign _EVAL_8 = _EVAL_49;
  assign _EVAL_9 = _EVAL_46;
  assign _EVAL_10 = _EVAL_50;
  assign _EVAL_12 = _EVAL_37;
  assign _EVAL_21 = _EVAL_34;
  assign _EVAL_22 = AsyncValidSync__EVAL_0;
  assign _EVAL_23 = _EVAL_42 ? _EVAL_6 : _EVAL_46;
  assign _EVAL_25 = _EVAL_53[0:0];
  assign _EVAL_26 = _EVAL_55 != widx_gray_sync_0__EVAL_2;
  assign AsyncValidSync__EVAL_1 = 1'h1;
  assign AsyncValidSync__EVAL_2 = _EVAL_18;
  assign AsyncValidSync__EVAL_3 = _EVAL_36;
  assign _EVAL_27 = _EVAL_42 ? _EVAL_5 : _EVAL_37;
  assign _EVAL_29 = _EVAL_42 ? _EVAL_14 : _EVAL_50;
  assign _EVAL_30 = _EVAL_54;
  assign AsyncValidSync_2__EVAL_0 = AsyncValidSync_1__EVAL_2;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_18;
  assign AsyncValidSync_2__EVAL_2 = _EVAL_17;
  assign _EVAL_31 = _EVAL_2 == 1'h0;
  assign _EVAL_32 = AsyncValidSync_2__EVAL_3;
  assign _EVAL_33 = _EVAL_30 >> 1'h1;
  assign _EVAL_35 = _EVAL_42 ? _EVAL_16 : _EVAL_47;
  assign _EVAL_36 = _EVAL_17 | _EVAL_31;
  assign valid_reg__EVAL_0 = 1'h1;
  assign valid_reg__EVAL_1 = _EVAL_17;
  assign valid_reg__EVAL_3 = _EVAL_18;
  assign valid_reg__EVAL_4 = _EVAL_42;
  assign _EVAL_39 = _EVAL_42 ? _EVAL_13 : _EVAL_48;
  assign ridx_bin__EVAL_0 = 1'h1;
  assign ridx_bin__EVAL_1 = _EVAL_17;
  assign ridx_bin__EVAL_3 = _EVAL_18;
  assign ridx_bin__EVAL_4 = _EVAL_30;
  assign _EVAL_42 = _EVAL_32 & _EVAL_26;
  assign _EVAL_43 = _EVAL_42 ? _EVAL_11 : _EVAL_34;
  assign _EVAL_44 = _EVAL_32 == 1'h0;
  assign _EVAL_45 = _EVAL_20 & _EVAL_8;
  assign ridx_gray__EVAL_0 = 1'h1;
  assign ridx_gray__EVAL_1 = _EVAL_17;
  assign ridx_gray__EVAL_3 = _EVAL_18;
  assign ridx_gray__EVAL_4 = _EVAL_55;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_36;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_18;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_19;
  assign widx_gray_sync_1__EVAL_0 = 1'h1;
  assign widx_gray_sync_1__EVAL_1 = _EVAL_17;
  assign widx_gray_sync_1__EVAL_3 = _EVAL_18;
  assign widx_gray_sync_1__EVAL_4 = widx_gray_sync_2__EVAL_2;
  assign _EVAL_49 = _EVAL_51 & _EVAL_32;
  assign _EVAL_51 = valid_reg__EVAL_2;
  assign _EVAL_52 = _EVAL_42 ? _EVAL_7 : _EVAL_41;
  assign _EVAL_53 = ridx_bin__EVAL_2 + _EVAL_45;
  assign widx_gray_sync_2__EVAL_0 = 1'h1;
  assign widx_gray_sync_2__EVAL_1 = _EVAL_17;
  assign widx_gray_sync_2__EVAL_3 = _EVAL_18;
  assign widx_gray_sync_2__EVAL_4 = _EVAL_15;
  assign widx_gray_sync_0__EVAL_0 = 1'h1;
  assign widx_gray_sync_0__EVAL_1 = _EVAL_17;
  assign widx_gray_sync_0__EVAL_3 = _EVAL_18;
  assign widx_gray_sync_0__EVAL_4 = widx_gray_sync_1__EVAL_2;
  assign _EVAL_54 = _EVAL_44 ? 1'h0 : _EVAL_25;
  assign _EVAL_55 = _EVAL_30 ^ _EVAL_33;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_34 = _GEN_0[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_1[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_41 = _GEN_2[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_46 = _GEN_3[8:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_4[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_5[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_50 = _GEN_6[31:0];
  `endif
  end
`endif
  always @(posedge _EVAL_18) begin
    if (_EVAL_42) begin
      _EVAL_34 <= _EVAL_11;
    end
    if (_EVAL_42) begin
      _EVAL_37 <= _EVAL_5;
    end
    if (_EVAL_42) begin
      _EVAL_41 <= _EVAL_7;
    end
    if (_EVAL_42) begin
      _EVAL_46 <= _EVAL_6;
    end
    if (_EVAL_42) begin
      _EVAL_47 <= _EVAL_16;
    end
    if (_EVAL_42) begin
      _EVAL_48 <= _EVAL_13;
    end
    if (_EVAL_42) begin
      _EVAL_50 <= _EVAL_14;
    end
  end
endmodule
