//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_50(
  output        _EVAL_0,
  output [1:0]  _EVAL_1,
  input         _EVAL_2,
  output        _EVAL_3,
  input  [1:0]  _EVAL_4,
  input  [2:0]  _EVAL_5,
  output [2:0]  _EVAL_6,
  output [31:0] _EVAL_7,
  output        _EVAL_8,
  output [1:0]  _EVAL_9,
  input         _EVAL_10,
  input  [31:0] _EVAL_11,
  input         _EVAL_12,
  output        _EVAL_13,
  input         _EVAL_14,
  input         _EVAL_15,
  output        _EVAL_16,
  input         _EVAL_17,
  input         _EVAL_18,
  input         _EVAL_19,
  input  [1:0]  _EVAL_20,
  input         _EVAL_21,
  output [1:0]  _EVAL_22,
  output        _EVAL_23,
  input  [1:0]  _EVAL_24
);
  reg [31:0] _EVAL_25;
  reg [31:0] _GEN_0;
  wire [1:0] _EVAL_26;
  wire  _EVAL_27;
  wire  _EVAL_28;
  wire  widx_gray__EVAL_0;
  wire  widx_gray__EVAL_1;
  wire  widx_gray__EVAL_2;
  wire  widx_gray__EVAL_3;
  wire  widx_gray__EVAL_4;
  wire  ready_reg__EVAL_0;
  wire  ready_reg__EVAL_1;
  wire  ready_reg__EVAL_2;
  wire  ready_reg__EVAL_3;
  wire  ready_reg__EVAL_4;
  wire  _EVAL_29;
  wire [1:0] _EVAL_30;
  reg [1:0] _EVAL_31;
  reg [31:0] _GEN_1;
  wire  _EVAL_32;
  reg  _EVAL_33;
  reg [31:0] _GEN_2;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  wire  ridx_gray_sync_2__EVAL_0;
  wire  ridx_gray_sync_2__EVAL_1;
  wire  ridx_gray_sync_2__EVAL_2;
  wire  ridx_gray_sync_2__EVAL_3;
  wire  ridx_gray_sync_2__EVAL_4;
  wire  _EVAL_36;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  wire  _EVAL_37;
  wire [1:0] _EVAL_38;
  wire  _EVAL_39;
  wire  ridx_gray_sync_0__EVAL_0;
  wire  ridx_gray_sync_0__EVAL_1;
  wire  ridx_gray_sync_0__EVAL_2;
  wire  ridx_gray_sync_0__EVAL_3;
  wire  ridx_gray_sync_0__EVAL_4;
  reg [1:0] _EVAL_40;
  reg [31:0] _GEN_3;
  wire  _EVAL_41;
  wire  _EVAL_42;
  reg [2:0] _EVAL_43;
  reg [31:0] _GEN_4;
  wire  _EVAL_44;
  wire  widx_bin__EVAL_0;
  wire  widx_bin__EVAL_1;
  wire  widx_bin__EVAL_2;
  wire  widx_bin__EVAL_3;
  wire  widx_bin__EVAL_4;
  wire  _EVAL_45;
  reg [1:0] _EVAL_46;
  reg [31:0] _GEN_5;
  wire  _EVAL_47;
  wire [31:0] _EVAL_48;
  reg  _EVAL_49;
  reg [31:0] _GEN_6;
  wire [1:0] _EVAL_50;
  wire  _EVAL_51;
  wire  ridx_gray_sync_1__EVAL_0;
  wire  ridx_gray_sync_1__EVAL_1;
  wire  ridx_gray_sync_1__EVAL_2;
  wire  ridx_gray_sync_1__EVAL_3;
  wire  ridx_gray_sync_1__EVAL_4;
  wire  _EVAL_52;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  reg  _EVAL_53;
  reg [31:0] _GEN_7;
  wire [2:0] _EVAL_54;
  wire  _EVAL_55;
  wire  _EVAL_56;
  _EVAL_32 widx_gray (
    ._EVAL_0(widx_gray__EVAL_0),
    ._EVAL_1(widx_gray__EVAL_1),
    ._EVAL_2(widx_gray__EVAL_2),
    ._EVAL_3(widx_gray__EVAL_3),
    ._EVAL_4(widx_gray__EVAL_4)
  );
  _EVAL_32 ready_reg (
    ._EVAL_0(ready_reg__EVAL_0),
    ._EVAL_1(ready_reg__EVAL_1),
    ._EVAL_2(ready_reg__EVAL_2),
    ._EVAL_3(ready_reg__EVAL_3),
    ._EVAL_4(ready_reg__EVAL_4)
  );
  _EVAL_36 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_32 ridx_gray_sync_2 (
    ._EVAL_0(ridx_gray_sync_2__EVAL_0),
    ._EVAL_1(ridx_gray_sync_2__EVAL_1),
    ._EVAL_2(ridx_gray_sync_2__EVAL_2),
    ._EVAL_3(ridx_gray_sync_2__EVAL_3),
    ._EVAL_4(ridx_gray_sync_2__EVAL_4)
  );
  _EVAL_38 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  _EVAL_32 ridx_gray_sync_0 (
    ._EVAL_0(ridx_gray_sync_0__EVAL_0),
    ._EVAL_1(ridx_gray_sync_0__EVAL_1),
    ._EVAL_2(ridx_gray_sync_0__EVAL_2),
    ._EVAL_3(ridx_gray_sync_0__EVAL_3),
    ._EVAL_4(ridx_gray_sync_0__EVAL_4)
  );
  _EVAL_32 widx_bin (
    ._EVAL_0(widx_bin__EVAL_0),
    ._EVAL_1(widx_bin__EVAL_1),
    ._EVAL_2(widx_bin__EVAL_2),
    ._EVAL_3(widx_bin__EVAL_3),
    ._EVAL_4(widx_bin__EVAL_4)
  );
  _EVAL_32 ridx_gray_sync_1 (
    ._EVAL_0(ridx_gray_sync_1__EVAL_0),
    ._EVAL_1(ridx_gray_sync_1__EVAL_1),
    ._EVAL_2(ridx_gray_sync_1__EVAL_2),
    ._EVAL_3(ridx_gray_sync_1__EVAL_3),
    ._EVAL_4(ridx_gray_sync_1__EVAL_4)
  );
  _EVAL_37 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  assign _EVAL_0 = _EVAL_49;
  assign _EVAL_1 = _EVAL_31;
  assign _EVAL_3 = AsyncValidSync__EVAL_0;
  assign _EVAL_6 = _EVAL_43;
  assign _EVAL_7 = _EVAL_25;
  assign _EVAL_8 = _EVAL_33;
  assign _EVAL_9 = _EVAL_46;
  assign _EVAL_13 = _EVAL_55;
  assign _EVAL_16 = widx_gray__EVAL_2;
  assign _EVAL_22 = _EVAL_40;
  assign _EVAL_23 = _EVAL_53;
  assign _EVAL_26 = _EVAL_35 ? _EVAL_4 : _EVAL_31;
  assign _EVAL_27 = _EVAL_30[0:0];
  assign _EVAL_28 = _EVAL_35 ? _EVAL_14 : _EVAL_33;
  assign widx_gray__EVAL_0 = 1'h1;
  assign widx_gray__EVAL_1 = _EVAL_15;
  assign widx_gray__EVAL_3 = _EVAL_2;
  assign widx_gray__EVAL_4 = _EVAL_44;
  assign ready_reg__EVAL_0 = 1'h1;
  assign ready_reg__EVAL_1 = _EVAL_15;
  assign ready_reg__EVAL_3 = _EVAL_2;
  assign ready_reg__EVAL_4 = _EVAL_45;
  assign _EVAL_29 = _EVAL_41 == 1'h0;
  assign _EVAL_30 = widx_bin__EVAL_2 + _EVAL_35;
  assign _EVAL_32 = _EVAL_34 >> 1'h1;
  assign _EVAL_34 = _EVAL_36;
  assign _EVAL_35 = _EVAL_13 & _EVAL_10;
  assign AsyncValidSync__EVAL_1 = _EVAL_2;
  assign AsyncValidSync__EVAL_2 = 1'h1;
  assign AsyncValidSync__EVAL_3 = _EVAL_39;
  assign ridx_gray_sync_2__EVAL_0 = 1'h1;
  assign ridx_gray_sync_2__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_2__EVAL_3 = _EVAL_2;
  assign ridx_gray_sync_2__EVAL_4 = _EVAL_12;
  assign _EVAL_36 = _EVAL_29 ? 1'h0 : _EVAL_27;
  assign AsyncValidSync_2__EVAL_0 = _EVAL_15;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_2;
  assign AsyncValidSync_2__EVAL_3 = AsyncValidSync_1__EVAL_2;
  assign _EVAL_37 = ridx_gray_sync_0__EVAL_2 ^ 1'h1;
  assign _EVAL_38 = _EVAL_35 ? _EVAL_24 : _EVAL_40;
  assign _EVAL_39 = _EVAL_15 | _EVAL_42;
  assign ridx_gray_sync_0__EVAL_0 = 1'h1;
  assign ridx_gray_sync_0__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_0__EVAL_3 = _EVAL_2;
  assign ridx_gray_sync_0__EVAL_4 = ridx_gray_sync_1__EVAL_2;
  assign _EVAL_41 = AsyncValidSync_2__EVAL_2;
  assign _EVAL_42 = _EVAL_19 == 1'h0;
  assign _EVAL_44 = _EVAL_34 ^ _EVAL_32;
  assign widx_bin__EVAL_0 = 1'h1;
  assign widx_bin__EVAL_1 = _EVAL_15;
  assign widx_bin__EVAL_3 = _EVAL_2;
  assign widx_bin__EVAL_4 = _EVAL_34;
  assign _EVAL_45 = _EVAL_41 & _EVAL_56;
  assign _EVAL_47 = _EVAL_35 ? _EVAL_18 : _EVAL_53;
  assign _EVAL_48 = _EVAL_35 ? _EVAL_11 : _EVAL_25;
  assign _EVAL_50 = _EVAL_35 ? _EVAL_20 : _EVAL_46;
  assign _EVAL_51 = _EVAL_35 ? _EVAL_17 : _EVAL_49;
  assign ridx_gray_sync_1__EVAL_0 = 1'h1;
  assign ridx_gray_sync_1__EVAL_1 = _EVAL_15;
  assign ridx_gray_sync_1__EVAL_3 = _EVAL_2;
  assign ridx_gray_sync_1__EVAL_4 = ridx_gray_sync_2__EVAL_2;
  assign _EVAL_52 = ready_reg__EVAL_2;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_39;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_2;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_21;
  assign _EVAL_54 = _EVAL_35 ? _EVAL_5 : _EVAL_43;
  assign _EVAL_55 = _EVAL_52 & _EVAL_41;
  assign _EVAL_56 = _EVAL_44 != _EVAL_37;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_25 = _GEN_0[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_31 = _GEN_1[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_33 = _GEN_2[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_40 = _GEN_3[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_43 = _GEN_4[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_46 = _GEN_5[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_49 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_53 = _GEN_7[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_2) begin
    if (_EVAL_35) begin
      _EVAL_25 <= _EVAL_11;
    end
    if (_EVAL_35) begin
      _EVAL_31 <= _EVAL_4;
    end
    if (_EVAL_35) begin
      _EVAL_33 <= _EVAL_14;
    end
    if (_EVAL_35) begin
      _EVAL_40 <= _EVAL_24;
    end
    if (_EVAL_35) begin
      _EVAL_43 <= _EVAL_5;
    end
    if (_EVAL_35) begin
      _EVAL_46 <= _EVAL_20;
    end
    if (_EVAL_35) begin
      _EVAL_49 <= _EVAL_17;
    end
    if (_EVAL_35) begin
      _EVAL_53 <= _EVAL_18;
    end
  end
endmodule
