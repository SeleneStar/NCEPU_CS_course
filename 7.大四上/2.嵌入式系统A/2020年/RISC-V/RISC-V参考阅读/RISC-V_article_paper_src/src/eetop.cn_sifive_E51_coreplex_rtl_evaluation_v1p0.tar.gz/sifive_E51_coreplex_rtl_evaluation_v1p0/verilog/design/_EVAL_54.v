//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_54(
  input        _EVAL_0,
  output       _EVAL_1,
  input        _EVAL_2,
  input        _EVAL_3,
  output       _EVAL_4,
  input  [9:0] _EVAL_5,
  output       _EVAL_6,
  input        _EVAL_7,
  output [9:0] _EVAL_8,
  input        _EVAL_9,
  input        _EVAL_10,
  output       _EVAL_11,
  input        _EVAL_12
);
  wire  widx_gray_sync_1__EVAL_0;
  wire  widx_gray_sync_1__EVAL_1;
  wire  widx_gray_sync_1__EVAL_2;
  wire  widx_gray_sync_1__EVAL_3;
  wire  widx_gray_sync_1__EVAL_4;
  wire [9:0] _EVAL_13;
  wire  ridx_gray__EVAL_0;
  wire  ridx_gray__EVAL_1;
  wire  ridx_gray__EVAL_2;
  wire  ridx_gray__EVAL_3;
  wire  ridx_gray__EVAL_4;
  wire  _EVAL_14;
  wire  _EVAL_15;
  reg [9:0] _EVAL_16;
  reg [31:0] _GEN_0;
  wire  _EVAL_17;
  wire  _EVAL_18;
  wire  AsyncValidSync_1__EVAL_0;
  wire  AsyncValidSync_1__EVAL_1;
  wire  AsyncValidSync_1__EVAL_2;
  wire  AsyncValidSync_1__EVAL_3;
  wire  _EVAL_19;
  wire  _EVAL_20;
  wire  _EVAL_21;
  wire  valid_reg__EVAL_0;
  wire  valid_reg__EVAL_1;
  wire  valid_reg__EVAL_2;
  wire  valid_reg__EVAL_3;
  wire  valid_reg__EVAL_4;
  wire  _EVAL_23;
  wire  widx_gray_sync_0__EVAL_0;
  wire  widx_gray_sync_0__EVAL_1;
  wire  widx_gray_sync_0__EVAL_2;
  wire  widx_gray_sync_0__EVAL_3;
  wire  widx_gray_sync_0__EVAL_4;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire  AsyncValidSync__EVAL_0;
  wire  AsyncValidSync__EVAL_1;
  wire  AsyncValidSync__EVAL_2;
  wire  AsyncValidSync__EVAL_3;
  wire  _EVAL_27;
  wire  ridx_bin__EVAL_0;
  wire  ridx_bin__EVAL_1;
  wire  ridx_bin__EVAL_2;
  wire  ridx_bin__EVAL_3;
  wire  ridx_bin__EVAL_4;
  wire  _EVAL_29;
  wire  _EVAL_31;
  wire [1:0] _EVAL_32;
  wire  _EVAL_33;
  wire  widx_gray_sync_2__EVAL_0;
  wire  widx_gray_sync_2__EVAL_1;
  wire  widx_gray_sync_2__EVAL_2;
  wire  widx_gray_sync_2__EVAL_3;
  wire  widx_gray_sync_2__EVAL_4;
  wire  _EVAL_34;
  reg  _EVAL_35;
  reg [31:0] _GEN_1;
  wire  AsyncValidSync_2__EVAL_0;
  wire  AsyncValidSync_2__EVAL_1;
  wire  AsyncValidSync_2__EVAL_2;
  wire  AsyncValidSync_2__EVAL_3;
  _EVAL_32 widx_gray_sync_1 (
    ._EVAL_0(widx_gray_sync_1__EVAL_0),
    ._EVAL_1(widx_gray_sync_1__EVAL_1),
    ._EVAL_2(widx_gray_sync_1__EVAL_2),
    ._EVAL_3(widx_gray_sync_1__EVAL_3),
    ._EVAL_4(widx_gray_sync_1__EVAL_4)
  );
  _EVAL_32 ridx_gray (
    ._EVAL_0(ridx_gray__EVAL_0),
    ._EVAL_1(ridx_gray__EVAL_1),
    ._EVAL_2(ridx_gray__EVAL_2),
    ._EVAL_3(ridx_gray__EVAL_3),
    ._EVAL_4(ridx_gray__EVAL_4)
  );
  _EVAL_41 AsyncValidSync_1 (
    ._EVAL_0(AsyncValidSync_1__EVAL_0),
    ._EVAL_1(AsyncValidSync_1__EVAL_1),
    ._EVAL_2(AsyncValidSync_1__EVAL_2),
    ._EVAL_3(AsyncValidSync_1__EVAL_3)
  );
  _EVAL_32 valid_reg (
    ._EVAL_0(valid_reg__EVAL_0),
    ._EVAL_1(valid_reg__EVAL_1),
    ._EVAL_2(valid_reg__EVAL_2),
    ._EVAL_3(valid_reg__EVAL_3),
    ._EVAL_4(valid_reg__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_0 (
    ._EVAL_0(widx_gray_sync_0__EVAL_0),
    ._EVAL_1(widx_gray_sync_0__EVAL_1),
    ._EVAL_2(widx_gray_sync_0__EVAL_2),
    ._EVAL_3(widx_gray_sync_0__EVAL_3),
    ._EVAL_4(widx_gray_sync_0__EVAL_4)
  );
  _EVAL_40 AsyncValidSync (
    ._EVAL_0(AsyncValidSync__EVAL_0),
    ._EVAL_1(AsyncValidSync__EVAL_1),
    ._EVAL_2(AsyncValidSync__EVAL_2),
    ._EVAL_3(AsyncValidSync__EVAL_3)
  );
  _EVAL_32 ridx_bin (
    ._EVAL_0(ridx_bin__EVAL_0),
    ._EVAL_1(ridx_bin__EVAL_1),
    ._EVAL_2(ridx_bin__EVAL_2),
    ._EVAL_3(ridx_bin__EVAL_3),
    ._EVAL_4(ridx_bin__EVAL_4)
  );
  _EVAL_32 widx_gray_sync_2 (
    ._EVAL_0(widx_gray_sync_2__EVAL_0),
    ._EVAL_1(widx_gray_sync_2__EVAL_1),
    ._EVAL_2(widx_gray_sync_2__EVAL_2),
    ._EVAL_3(widx_gray_sync_2__EVAL_3),
    ._EVAL_4(widx_gray_sync_2__EVAL_4)
  );
  _EVAL_42 AsyncValidSync_2 (
    ._EVAL_0(AsyncValidSync_2__EVAL_0),
    ._EVAL_1(AsyncValidSync_2__EVAL_1),
    ._EVAL_2(AsyncValidSync_2__EVAL_2),
    ._EVAL_3(AsyncValidSync_2__EVAL_3)
  );
  assign _EVAL_1 = AsyncValidSync__EVAL_0;
  assign _EVAL_4 = _EVAL_35;
  assign _EVAL_6 = ridx_gray__EVAL_2;
  assign _EVAL_8 = _EVAL_16;
  assign _EVAL_11 = _EVAL_23;
  assign widx_gray_sync_1__EVAL_0 = 1'h1;
  assign widx_gray_sync_1__EVAL_1 = _EVAL_10;
  assign widx_gray_sync_1__EVAL_3 = _EVAL_0;
  assign widx_gray_sync_1__EVAL_4 = widx_gray_sync_2__EVAL_2;
  assign _EVAL_13 = _EVAL_25 ? _EVAL_5 : _EVAL_16;
  assign ridx_gray__EVAL_0 = 1'h1;
  assign ridx_gray__EVAL_1 = _EVAL_10;
  assign ridx_gray__EVAL_3 = _EVAL_0;
  assign ridx_gray__EVAL_4 = _EVAL_34;
  assign _EVAL_14 = _EVAL_25 ? _EVAL_2 : _EVAL_35;
  assign _EVAL_15 = _EVAL_32[0:0];
  assign _EVAL_17 = _EVAL_12 == 1'h0;
  assign _EVAL_18 = _EVAL_24 ? 1'h0 : _EVAL_15;
  assign AsyncValidSync_1__EVAL_0 = _EVAL_21;
  assign AsyncValidSync_1__EVAL_1 = _EVAL_0;
  assign AsyncValidSync_1__EVAL_3 = _EVAL_9;
  assign _EVAL_19 = _EVAL_18;
  assign _EVAL_20 = _EVAL_19 >> 1'h1;
  assign _EVAL_21 = _EVAL_10 | _EVAL_17;
  assign valid_reg__EVAL_0 = 1'h1;
  assign valid_reg__EVAL_1 = _EVAL_10;
  assign valid_reg__EVAL_3 = _EVAL_0;
  assign valid_reg__EVAL_4 = _EVAL_25;
  assign _EVAL_23 = _EVAL_27 & _EVAL_29;
  assign widx_gray_sync_0__EVAL_0 = 1'h1;
  assign widx_gray_sync_0__EVAL_1 = _EVAL_10;
  assign widx_gray_sync_0__EVAL_3 = _EVAL_0;
  assign widx_gray_sync_0__EVAL_4 = widx_gray_sync_1__EVAL_2;
  assign _EVAL_24 = _EVAL_29 == 1'h0;
  assign _EVAL_25 = _EVAL_29 & _EVAL_31;
  assign AsyncValidSync__EVAL_1 = 1'h1;
  assign AsyncValidSync__EVAL_2 = _EVAL_0;
  assign AsyncValidSync__EVAL_3 = _EVAL_21;
  assign _EVAL_27 = valid_reg__EVAL_2;
  assign ridx_bin__EVAL_0 = 1'h1;
  assign ridx_bin__EVAL_1 = _EVAL_10;
  assign ridx_bin__EVAL_3 = _EVAL_0;
  assign ridx_bin__EVAL_4 = _EVAL_19;
  assign _EVAL_29 = AsyncValidSync_2__EVAL_3;
  assign _EVAL_31 = _EVAL_34 != widx_gray_sync_0__EVAL_2;
  assign _EVAL_32 = ridx_bin__EVAL_2 + _EVAL_33;
  assign _EVAL_33 = _EVAL_3 & _EVAL_11;
  assign widx_gray_sync_2__EVAL_0 = 1'h1;
  assign widx_gray_sync_2__EVAL_1 = _EVAL_10;
  assign widx_gray_sync_2__EVAL_3 = _EVAL_0;
  assign widx_gray_sync_2__EVAL_4 = _EVAL_7;
  assign _EVAL_34 = _EVAL_19 ^ _EVAL_20;
  assign AsyncValidSync_2__EVAL_0 = AsyncValidSync_1__EVAL_2;
  assign AsyncValidSync_2__EVAL_1 = _EVAL_0;
  assign AsyncValidSync_2__EVAL_2 = _EVAL_10;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_16 = _GEN_0[9:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_35 = _GEN_1[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_0) begin
    if (_EVAL_25) begin
      _EVAL_16 <= _EVAL_5;
    end
    if (_EVAL_25) begin
      _EVAL_35 <= _EVAL_2;
    end
  end
endmodule
