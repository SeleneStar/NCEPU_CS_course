//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_55(
  input        _EVAL_0,
  output [2:0] _EVAL_1,
  input        _EVAL_2,
  input        _EVAL_3,
  input  [2:0] _EVAL_4
);
  wire [2:0] _EVAL_5;
  wire  _EVAL_6;
  wire  _EVAL_7;
  wire  reg_2_rst;
  wire  reg_2_clk;
  wire  reg_2_en;
  wire  reg_2_q;
  wire  reg_2_d;
  wire  reg_1_rst;
  wire  reg_1_clk;
  wire  reg_1_en;
  wire  reg_1_q;
  wire  reg_1_d;
  wire  reg_0_rst;
  wire  reg_0_clk;
  wire  reg_0_en;
  wire  reg_0_q;
  wire  reg_0_d;
  wire [1:0] _EVAL_8;
  wire  _EVAL_9;
  AsyncResetReg reg_2 (
    .rst(reg_2_rst),
    .clk(reg_2_clk),
    .en(reg_2_en),
    .q(reg_2_q),
    .d(reg_2_d)
  );
  AsyncResetReg reg_1 (
    .rst(reg_1_rst),
    .clk(reg_1_clk),
    .en(reg_1_en),
    .q(reg_1_q),
    .d(reg_1_d)
  );
  AsyncResetReg reg_0 (
    .rst(reg_0_rst),
    .clk(reg_0_clk),
    .en(reg_0_en),
    .q(reg_0_q),
    .d(reg_0_d)
  );
  assign _EVAL_1 = _EVAL_5;
  assign _EVAL_5 = {_EVAL_8,reg_0_q};
  assign _EVAL_6 = _EVAL_4[2];
  assign _EVAL_7 = _EVAL_4[0];
  assign reg_2_rst = _EVAL_3;
  assign reg_2_clk = _EVAL_0;
  assign reg_2_en = _EVAL_2;
  assign reg_2_d = _EVAL_6;
  assign reg_1_rst = _EVAL_3;
  assign reg_1_clk = _EVAL_0;
  assign reg_1_en = _EVAL_2;
  assign reg_1_d = _EVAL_9;
  assign reg_0_rst = _EVAL_3;
  assign reg_0_clk = _EVAL_0;
  assign reg_0_en = _EVAL_2;
  assign reg_0_d = _EVAL_7;
  assign _EVAL_8 = {reg_2_q,reg_1_q};
  assign _EVAL_9 = _EVAL_4[1];
endmodule
