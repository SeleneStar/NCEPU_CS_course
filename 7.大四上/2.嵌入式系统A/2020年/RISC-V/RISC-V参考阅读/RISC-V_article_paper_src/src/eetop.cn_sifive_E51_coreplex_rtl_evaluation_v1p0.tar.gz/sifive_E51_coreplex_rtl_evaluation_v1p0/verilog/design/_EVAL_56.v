//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_56(
  output  _EVAL_0,
  input   _EVAL_1,
  input   _EVAL_2
);
  wire  _EVAL_3;
  wire [2:0] _EVAL_4;
  wire  _EVAL_5;
  wire  reset_n_catch_reg__EVAL_0;
  wire [2:0] reset_n_catch_reg__EVAL_1;
  wire  reset_n_catch_reg__EVAL_2;
  wire  reset_n_catch_reg__EVAL_3;
  wire [2:0] reset_n_catch_reg__EVAL_4;
  wire [1:0] _EVAL_6;
  _EVAL_55 reset_n_catch_reg (
    ._EVAL_0(reset_n_catch_reg__EVAL_0),
    ._EVAL_1(reset_n_catch_reg__EVAL_1),
    ._EVAL_2(reset_n_catch_reg__EVAL_2),
    ._EVAL_3(reset_n_catch_reg__EVAL_3),
    ._EVAL_4(reset_n_catch_reg__EVAL_4)
  );
  assign _EVAL_0 = _EVAL_5;
  assign _EVAL_3 = reset_n_catch_reg__EVAL_1[0];
  assign _EVAL_4 = {1'h1,_EVAL_6};
  assign _EVAL_5 = ~ _EVAL_3;
  assign reset_n_catch_reg__EVAL_0 = _EVAL_1;
  assign reset_n_catch_reg__EVAL_2 = 1'h1;
  assign reset_n_catch_reg__EVAL_3 = _EVAL_2;
  assign reset_n_catch_reg__EVAL_4 = _EVAL_4;
  assign _EVAL_6 = reset_n_catch_reg__EVAL_1[2:1];
endmodule
