//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_6(
  input         _EVAL_0,
  input         _EVAL_1,
  output [63:0] _EVAL_2,
  output [2:0]  _EVAL_3,
  output [2:0]  _EVAL_4,
  input  [3:0]  _EVAL_5,
  output [3:0]  _EVAL_6,
  input  [29:0] _EVAL_7,
  input  [63:0] _EVAL_8,
  output [7:0]  _EVAL_9,
  input  [2:0]  _EVAL_10,
  input  [3:0]  _EVAL_11,
  output        _EVAL_12,
  input  [7:0]  _EVAL_13,
  input         _EVAL_14,
  output        _EVAL_15,
  input         _EVAL_16,
  output        _EVAL_17,
  output [3:0]  _EVAL_18,
  output [29:0] _EVAL_19,
  input  [2:0]  _EVAL_20,
  input         _EVAL_21
);
  reg [29:0] _EVAL_22;
  reg [31:0] _GEN_0;
  reg [2:0] _EVAL_23;
  reg [31:0] _GEN_1;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire  _EVAL_26;
  wire [2:0] _EVAL_27;
  wire [7:0] _EVAL_28;
  wire [29:0] _EVAL_29;
  reg  _EVAL_30;
  reg [31:0] _GEN_2;
  reg [7:0] _EVAL_31;
  reg [31:0] _GEN_3;
  wire [63:0] _EVAL_32;
  wire  _EVAL_33;
  wire [2:0] _EVAL_34;
  wire [3:0] _EVAL_35;
  reg [2:0] _EVAL_36;
  reg [31:0] _GEN_4;
  wire [29:0] _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire [2:0] _EVAL_40;
  wire [7:0] _EVAL_41;
  wire [3:0] _EVAL_42;
  wire  _EVAL_43;
  reg [3:0] _EVAL_44;
  reg [31:0] _GEN_5;
  wire  _EVAL_45;
  wire [63:0] _EVAL_46;
  reg [63:0] _EVAL_47;
  reg [63:0] _GEN_6;
  wire  _EVAL_48;
  wire [3:0] _EVAL_49;
  wire [3:0] _EVAL_50;
  wire  _EVAL_51;
  wire [2:0] _EVAL_52;
  reg [3:0] _EVAL_53;
  reg [31:0] _GEN_7;
  assign _EVAL_2 = _EVAL_32;
  assign _EVAL_3 = _EVAL_52;
  assign _EVAL_4 = _EVAL_40;
  assign _EVAL_6 = _EVAL_49;
  assign _EVAL_9 = _EVAL_28;
  assign _EVAL_12 = _EVAL_30;
  assign _EVAL_15 = _EVAL_39;
  assign _EVAL_17 = _EVAL_51;
  assign _EVAL_18 = _EVAL_50;
  assign _EVAL_19 = _EVAL_37;
  assign _EVAL_24 = _EVAL_48 & _EVAL_43;
  assign _EVAL_25 = _EVAL_30 == 1'h0;
  assign _EVAL_26 = _EVAL_15 & _EVAL_0;
  assign _EVAL_27 = _EVAL_45 ? _EVAL_10 : _EVAL_23;
  assign _EVAL_28 = _EVAL_30 ? _EVAL_31 : _EVAL_13;
  assign _EVAL_29 = _EVAL_45 ? _EVAL_7 : _EVAL_22;
  assign _EVAL_32 = _EVAL_30 ? _EVAL_47 : _EVAL_8;
  assign _EVAL_33 = _EVAL_45 ? 1'h1 : _EVAL_30;
  assign _EVAL_34 = _EVAL_45 ? _EVAL_20 : _EVAL_36;
  assign _EVAL_35 = _EVAL_45 ? _EVAL_11 : _EVAL_53;
  assign _EVAL_37 = _EVAL_30 ? _EVAL_22 : _EVAL_7;
  assign _EVAL_38 = _EVAL_24 ? 1'h0 : _EVAL_33;
  assign _EVAL_39 = _EVAL_1 & _EVAL_25;
  assign _EVAL_40 = _EVAL_30 ? _EVAL_36 : _EVAL_20;
  assign _EVAL_41 = _EVAL_45 ? _EVAL_13 : _EVAL_31;
  assign _EVAL_42 = _EVAL_45 ? _EVAL_5 : _EVAL_44;
  assign _EVAL_43 = _EVAL_21 == 1'h0;
  assign _EVAL_45 = _EVAL_26 & _EVAL_21;
  assign _EVAL_46 = _EVAL_45 ? _EVAL_8 : _EVAL_47;
  assign _EVAL_48 = _EVAL_1 & _EVAL_17;
  assign _EVAL_49 = _EVAL_30 ? _EVAL_44 : _EVAL_5;
  assign _EVAL_50 = _EVAL_30 ? _EVAL_53 : _EVAL_11;
  assign _EVAL_51 = _EVAL_0 | _EVAL_30;
  assign _EVAL_52 = _EVAL_30 ? _EVAL_23 : _EVAL_10;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_22 = _GEN_0[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_23 = _GEN_1[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_30 = _GEN_2[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_31 = _GEN_3[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_36 = _GEN_4[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_44 = _GEN_5[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_47 = _GEN_6[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_53 = _GEN_7[3:0];
  `endif
  end
`endif
  always @(posedge _EVAL_16) begin
    if (_EVAL_45) begin
      _EVAL_22 <= _EVAL_7;
    end
    if (_EVAL_45) begin
      _EVAL_23 <= _EVAL_10;
    end
    if (_EVAL_14) begin
      _EVAL_30 <= 1'h0;
    end else begin
      if (_EVAL_24) begin
        _EVAL_30 <= 1'h0;
      end else begin
        if (_EVAL_45) begin
          _EVAL_30 <= 1'h1;
        end
      end
    end
    if (_EVAL_45) begin
      _EVAL_31 <= _EVAL_13;
    end
    if (_EVAL_45) begin
      _EVAL_36 <= _EVAL_20;
    end
    if (_EVAL_45) begin
      _EVAL_44 <= _EVAL_5;
    end
    if (_EVAL_45) begin
      _EVAL_47 <= _EVAL_8;
    end
    if (_EVAL_45) begin
      _EVAL_53 <= _EVAL_11;
    end
  end
endmodule
