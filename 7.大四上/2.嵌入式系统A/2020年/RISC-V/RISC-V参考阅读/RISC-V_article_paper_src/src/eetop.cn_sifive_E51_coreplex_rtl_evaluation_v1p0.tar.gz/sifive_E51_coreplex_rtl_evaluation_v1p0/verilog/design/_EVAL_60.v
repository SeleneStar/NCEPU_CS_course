//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_60(
  input   _EVAL_0,
  output  _EVAL_1,
  input   _EVAL_2,
  input   _EVAL_3,
  input   _EVAL_4,
  input   _EVAL_5
);
  wire  _EVAL_6;
  reg  _EVAL_7;
  reg [31:0] _GEN_0;
  wire  _EVAL_8;
  wire  _EVAL_9;
  wire  _EVAL_10;
  wire  _EVAL_11;
  assign _EVAL_1 = _EVAL_11;
  assign _EVAL_6 = _EVAL_2 & _EVAL_0;
  assign _EVAL_8 = _EVAL_6 ? 1'h1 : _EVAL_7;
  assign _EVAL_9 = _EVAL_5 ? 1'h0 : _EVAL_8;
  assign _EVAL_10 = _EVAL_7 == 1'h0;
  assign _EVAL_11 = _EVAL_2 & _EVAL_10;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_7 = _GEN_0[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_3) begin
    if (_EVAL_4) begin
      _EVAL_7 <= 1'h0;
    end else begin
      if (_EVAL_5) begin
        _EVAL_7 <= 1'h0;
      end else begin
        if (_EVAL_6) begin
          _EVAL_7 <= 1'h1;
        end
      end
    end
  end
endmodule
