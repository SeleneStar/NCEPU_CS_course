//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_61(
  output [22:0] _EVAL_0,
  input  [7:0]  _EVAL_1,
  output [63:0] _EVAL_2,
  output        _EVAL_3,
  output        _EVAL_4,
  output        _EVAL_5,
  input         _EVAL_6,
  input         _EVAL_7,
  input         _EVAL_8,
  input  [10:0] _EVAL_9,
  output [7:0]  _EVAL_10,
  input         _EVAL_11,
  input  [22:0] _EVAL_12,
  input  [63:0] _EVAL_13,
  output [10:0] _EVAL_14,
  output        _EVAL_15,
  input         _EVAL_16
);
  reg [10:0] _EVAL_17 [0:0];
  reg [31:0] _GEN_0;
  wire [10:0] _EVAL_17__EVAL_18_data;
  wire  _EVAL_17__EVAL_18_addr;
  wire [10:0] _EVAL_17__EVAL_19_data;
  wire  _EVAL_17__EVAL_19_addr;
  wire  _EVAL_17__EVAL_19_mask;
  wire  _EVAL_17__EVAL_19_en;
  reg [63:0] _EVAL_20 [0:0];
  reg [63:0] _GEN_1;
  wire [63:0] _EVAL_20__EVAL_21_data;
  wire  _EVAL_20__EVAL_21_addr;
  wire [63:0] _EVAL_20__EVAL_22_data;
  wire  _EVAL_20__EVAL_22_addr;
  wire  _EVAL_20__EVAL_22_mask;
  wire  _EVAL_20__EVAL_22_en;
  wire  _EVAL_23;
  reg [7:0] _EVAL_24 [0:0];
  reg [31:0] _GEN_2;
  wire [7:0] _EVAL_24__EVAL_25_data;
  wire  _EVAL_24__EVAL_25_addr;
  wire [7:0] _EVAL_24__EVAL_26_data;
  wire  _EVAL_24__EVAL_26_addr;
  wire  _EVAL_24__EVAL_26_mask;
  wire  _EVAL_24__EVAL_26_en;
  wire [1:0] _EVAL_27;
  reg  _EVAL_28 [0:0];
  reg [31:0] _GEN_3;
  wire  _EVAL_28__EVAL_29_data;
  wire  _EVAL_28__EVAL_29_addr;
  wire  _EVAL_28__EVAL_30_data;
  wire  _EVAL_28__EVAL_30_addr;
  wire  _EVAL_28__EVAL_30_mask;
  wire  _EVAL_28__EVAL_30_en;
  reg [22:0] _EVAL_31 [0:0];
  reg [31:0] _GEN_4;
  wire [22:0] _EVAL_31__EVAL_32_data;
  wire  _EVAL_31__EVAL_32_addr;
  wire [22:0] _EVAL_31__EVAL_33_data;
  wire  _EVAL_31__EVAL_33_addr;
  wire  _EVAL_31__EVAL_33_mask;
  wire  _EVAL_31__EVAL_33_en;
  wire [1:0] _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_36;
  reg  _EVAL_37;
  reg [31:0] _GEN_5;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire [1:0] _EVAL_40;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire  _EVAL_43;
  wire  _EVAL_44;
  assign _EVAL_0 = _EVAL_31__EVAL_32_data;
  assign _EVAL_2 = _EVAL_20__EVAL_21_data;
  assign _EVAL_3 = _EVAL_36;
  assign _EVAL_4 = _EVAL_28__EVAL_29_data;
  assign _EVAL_5 = _EVAL_34[0];
  assign _EVAL_10 = _EVAL_24__EVAL_25_data;
  assign _EVAL_14 = _EVAL_17__EVAL_18_data;
  assign _EVAL_15 = _EVAL_41;
  assign _EVAL_17__EVAL_18_addr = 1'h0;
  assign _EVAL_17__EVAL_18_data = _EVAL_17[_EVAL_17__EVAL_18_addr];
  assign _EVAL_17__EVAL_19_data = _EVAL_9;
  assign _EVAL_17__EVAL_19_addr = 1'h0;
  assign _EVAL_17__EVAL_19_mask = _EVAL_38;
  assign _EVAL_17__EVAL_19_en = _EVAL_38;
  assign _EVAL_20__EVAL_21_addr = 1'h0;
  assign _EVAL_20__EVAL_21_data = _EVAL_20[_EVAL_20__EVAL_21_addr];
  assign _EVAL_20__EVAL_22_data = _EVAL_13;
  assign _EVAL_20__EVAL_22_addr = 1'h0;
  assign _EVAL_20__EVAL_22_mask = _EVAL_38;
  assign _EVAL_20__EVAL_22_en = _EVAL_38;
  assign _EVAL_23 = _EVAL_7 & _EVAL_3;
  assign _EVAL_24__EVAL_25_addr = 1'h0;
  assign _EVAL_24__EVAL_25_data = _EVAL_24[_EVAL_24__EVAL_25_addr];
  assign _EVAL_24__EVAL_26_data = _EVAL_1;
  assign _EVAL_24__EVAL_26_addr = 1'h0;
  assign _EVAL_24__EVAL_26_mask = _EVAL_38;
  assign _EVAL_24__EVAL_26_en = _EVAL_38;
  assign _EVAL_27 = $unsigned(_EVAL_40);
  assign _EVAL_28__EVAL_29_addr = 1'h0;
  assign _EVAL_28__EVAL_29_data = _EVAL_28[_EVAL_28__EVAL_29_addr];
  assign _EVAL_28__EVAL_30_data = _EVAL_11;
  assign _EVAL_28__EVAL_30_addr = 1'h0;
  assign _EVAL_28__EVAL_30_mask = _EVAL_38;
  assign _EVAL_28__EVAL_30_en = _EVAL_38;
  assign _EVAL_31__EVAL_32_addr = 1'h0;
  assign _EVAL_31__EVAL_32_data = _EVAL_31[_EVAL_31__EVAL_32_addr];
  assign _EVAL_31__EVAL_33_data = _EVAL_12;
  assign _EVAL_31__EVAL_33_addr = 1'h0;
  assign _EVAL_31__EVAL_33_mask = _EVAL_38;
  assign _EVAL_31__EVAL_33_en = _EVAL_38;
  assign _EVAL_34 = {_EVAL_37,_EVAL_39};
  assign _EVAL_35 = _EVAL_15 & _EVAL_16;
  assign _EVAL_36 = _EVAL_41 == 1'h0;
  assign _EVAL_38 = _EVAL_35;
  assign _EVAL_39 = _EVAL_27[0:0];
  assign _EVAL_40 = 1'h0 - 1'h0;
  assign _EVAL_41 = _EVAL_37 == 1'h0;
  assign _EVAL_42 = _EVAL_38 != _EVAL_44;
  assign _EVAL_43 = _EVAL_42 ? _EVAL_38 : _EVAL_37;
  assign _EVAL_44 = _EVAL_23;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_17[initvar] = _GEN_0[10:0];
  `endif
  _GEN_1 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_20[initvar] = _GEN_1[63:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_24[initvar] = _GEN_2[7:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_28[initvar] = _GEN_3[0:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 1; initvar = initvar+1)
    _EVAL_31[initvar] = _GEN_4[22:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_5[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_6) begin
    if(_EVAL_17__EVAL_19_en & _EVAL_17__EVAL_19_mask) begin
      _EVAL_17[_EVAL_17__EVAL_19_addr] <= _EVAL_17__EVAL_19_data;
    end
    if(_EVAL_20__EVAL_22_en & _EVAL_20__EVAL_22_mask) begin
      _EVAL_20[_EVAL_20__EVAL_22_addr] <= _EVAL_20__EVAL_22_data;
    end
    if(_EVAL_24__EVAL_26_en & _EVAL_24__EVAL_26_mask) begin
      _EVAL_24[_EVAL_24__EVAL_26_addr] <= _EVAL_24__EVAL_26_data;
    end
    if(_EVAL_28__EVAL_30_en & _EVAL_28__EVAL_30_mask) begin
      _EVAL_28[_EVAL_28__EVAL_30_addr] <= _EVAL_28__EVAL_30_data;
    end
    if(_EVAL_31__EVAL_33_en & _EVAL_31__EVAL_33_mask) begin
      _EVAL_31[_EVAL_31__EVAL_33_addr] <= _EVAL_31__EVAL_33_data;
    end
    if (_EVAL_8) begin
      _EVAL_37 <= 1'h0;
    end else begin
      if (_EVAL_42) begin
        _EVAL_37 <= _EVAL_38;
      end
    end
  end
endmodule
