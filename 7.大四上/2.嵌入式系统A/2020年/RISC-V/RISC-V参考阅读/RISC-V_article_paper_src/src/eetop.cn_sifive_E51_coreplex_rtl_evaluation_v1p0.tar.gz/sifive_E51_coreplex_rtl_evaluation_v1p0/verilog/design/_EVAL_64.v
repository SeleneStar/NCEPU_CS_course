//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_64(
  input         _EVAL_0,
  input         _EVAL_1,
  input  [3:0]  _EVAL_2,
  input  [2:0]  _EVAL_3,
  input  [11:0] _EVAL_4,
  output [2:0]  _EVAL_5,
  output [3:0]  _EVAL_6,
  output [11:0] _EVAL_7,
  output [63:0] _EVAL_8,
  output [2:0]  _EVAL_9,
  output        _EVAL_10,
  output        _EVAL_11,
  input         _EVAL_12,
  input  [63:0] _EVAL_13,
  output [7:0]  _EVAL_14,
  input         _EVAL_15,
  input  [2:0]  _EVAL_16,
  input  [7:0]  _EVAL_17,
  output [2:0]  _EVAL_18,
  input  [2:0]  _EVAL_19,
  input         _EVAL_20,
  output        _EVAL_21
);
  reg [3:0] _EVAL_22;
  reg [31:0] _GEN_0;
  wire  _EVAL_23;
  wire [7:0] _EVAL_24;
  wire [7:0] _EVAL_25;
  wire [2:0] _EVAL_26;
  wire [63:0] _EVAL_27;
  wire  _EVAL_28;
  reg [7:0] _EVAL_29;
  reg [31:0] _GEN_1;
  wire [2:0] _EVAL_30;
  wire [2:0] _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire [2:0] _EVAL_34;
  wire  _EVAL_35;
  wire [11:0] _EVAL_36;
  reg [2:0] _EVAL_37;
  reg [31:0] _GEN_2;
  wire  _EVAL_38;
  wire [63:0] _EVAL_39;
  wire [3:0] _EVAL_40;
  wire [11:0] _EVAL_41;
  wire [2:0] _EVAL_42;
  reg [63:0] _EVAL_43;
  reg [63:0] _GEN_3;
  reg [2:0] _EVAL_44;
  reg [31:0] _GEN_4;
  wire  _EVAL_45;
  wire [3:0] _EVAL_46;
  wire  _EVAL_47;
  wire [2:0] _EVAL_48;
  reg  _EVAL_49;
  reg [31:0] _GEN_5;
  wire  _EVAL_50;
  wire  _EVAL_51;
  reg [2:0] _EVAL_52;
  reg [31:0] _GEN_6;
  reg [11:0] _EVAL_53;
  reg [31:0] _GEN_7;
  assign _EVAL_5 = _EVAL_48;
  assign _EVAL_6 = _EVAL_46;
  assign _EVAL_7 = _EVAL_41;
  assign _EVAL_8 = _EVAL_27;
  assign _EVAL_9 = _EVAL_42;
  assign _EVAL_10 = _EVAL_38;
  assign _EVAL_11 = _EVAL_51;
  assign _EVAL_14 = _EVAL_24;
  assign _EVAL_18 = _EVAL_26;
  assign _EVAL_21 = _EVAL_49;
  assign _EVAL_23 = _EVAL_50 ? 1'h0 : _EVAL_45;
  assign _EVAL_24 = _EVAL_49 ? _EVAL_29 : _EVAL_17;
  assign _EVAL_25 = _EVAL_35 ? _EVAL_17 : _EVAL_29;
  assign _EVAL_26 = _EVAL_49 ? _EVAL_37 : _EVAL_16;
  assign _EVAL_27 = _EVAL_49 ? _EVAL_43 : _EVAL_13;
  assign _EVAL_28 = _EVAL_0 == 1'h0;
  assign _EVAL_30 = _EVAL_35 ? _EVAL_3 : _EVAL_44;
  assign _EVAL_31 = _EVAL_35 ? _EVAL_19 : _EVAL_52;
  assign _EVAL_32 = _EVAL_20 & _EVAL_10;
  assign _EVAL_33 = _EVAL_11 & _EVAL_15;
  assign _EVAL_34 = _EVAL_35 ? _EVAL_16 : _EVAL_37;
  assign _EVAL_35 = _EVAL_33 & _EVAL_0;
  assign _EVAL_36 = _EVAL_35 ? _EVAL_4 : _EVAL_53;
  assign _EVAL_38 = _EVAL_15 | _EVAL_49;
  assign _EVAL_39 = _EVAL_35 ? _EVAL_13 : _EVAL_43;
  assign _EVAL_40 = _EVAL_35 ? _EVAL_2 : _EVAL_22;
  assign _EVAL_41 = _EVAL_49 ? _EVAL_53 : _EVAL_4;
  assign _EVAL_42 = _EVAL_49 ? _EVAL_52 : _EVAL_19;
  assign _EVAL_45 = _EVAL_35 ? 1'h1 : _EVAL_49;
  assign _EVAL_46 = _EVAL_49 ? _EVAL_22 : _EVAL_2;
  assign _EVAL_47 = _EVAL_49 == 1'h0;
  assign _EVAL_48 = _EVAL_49 ? _EVAL_44 : _EVAL_3;
  assign _EVAL_50 = _EVAL_32 & _EVAL_28;
  assign _EVAL_51 = _EVAL_20 & _EVAL_47;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_22 = _GEN_0[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_29 = _GEN_1[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_37 = _GEN_2[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_43 = _GEN_3[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_44 = _GEN_4[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_49 = _GEN_5[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_52 = _GEN_6[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_53 = _GEN_7[11:0];
  `endif
  end
`endif
  always @(posedge _EVAL_12) begin
    if (_EVAL_35) begin
      _EVAL_22 <= _EVAL_2;
    end
    if (_EVAL_35) begin
      _EVAL_29 <= _EVAL_17;
    end
    if (_EVAL_35) begin
      _EVAL_37 <= _EVAL_16;
    end
    if (_EVAL_35) begin
      _EVAL_43 <= _EVAL_13;
    end
    if (_EVAL_35) begin
      _EVAL_44 <= _EVAL_3;
    end
    if (_EVAL_1) begin
      _EVAL_49 <= 1'h0;
    end else begin
      if (_EVAL_50) begin
        _EVAL_49 <= 1'h0;
      end else begin
        if (_EVAL_35) begin
          _EVAL_49 <= 1'h1;
        end
      end
    end
    if (_EVAL_35) begin
      _EVAL_52 <= _EVAL_19;
    end
    if (_EVAL_35) begin
      _EVAL_53 <= _EVAL_4;
    end
  end
endmodule
