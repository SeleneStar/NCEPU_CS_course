//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_79(
  output        _EVAL_0,
  input         _EVAL_1,
  output        _EVAL_2,
  input         _EVAL_3,
  output        _EVAL_4,
  input  [8:0]  _EVAL_5,
  output [8:0]  _EVAL_6,
  input         _EVAL_7,
  output        _EVAL_8,
  input         _EVAL_9,
  input  [17:0] _EVAL_10,
  output [1:0]  _EVAL_11,
  output        _EVAL_12,
  input         _EVAL_13,
  input  [17:0] _EVAL_14,
  input         _EVAL_15,
  output [17:0] _EVAL_16,
  input  [17:0] _EVAL_17,
  input  [8:0]  _EVAL_18,
  input         _EVAL_19,
  input  [8:0]  _EVAL_20,
  input         _EVAL_21,
  input         _EVAL_22
);
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire [8:0] _EVAL_25;
  wire [17:0] _EVAL_26;
  wire [17:0] _EVAL_27;
  wire [1:0] _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  wire [1:0] _EVAL_31;
  wire  _EVAL_32;
  wire [8:0] _EVAL_33;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  assign _EVAL_0 = _EVAL_32;
  assign _EVAL_2 = _EVAL_29;
  assign _EVAL_4 = _EVAL_37;
  assign _EVAL_6 = _EVAL_33;
  assign _EVAL_8 = _EVAL_1;
  assign _EVAL_11 = _EVAL_28;
  assign _EVAL_12 = _EVAL_24;
  assign _EVAL_16 = _EVAL_26;
  assign _EVAL_23 = _EVAL_3 ? _EVAL_19 : _EVAL_15;
  assign _EVAL_24 = _EVAL_13 ? _EVAL_7 : _EVAL_23;
  assign _EVAL_25 = _EVAL_3 ? _EVAL_20 : _EVAL_5;
  assign _EVAL_26 = _EVAL_13 ? _EVAL_14 : _EVAL_27;
  assign _EVAL_27 = _EVAL_3 ? _EVAL_10 : _EVAL_17;
  assign _EVAL_28 = _EVAL_13 ? 2'h0 : _EVAL_31;
  assign _EVAL_29 = _EVAL_35 & _EVAL_1;
  assign _EVAL_30 = _EVAL_36 == 1'h0;
  assign _EVAL_31 = _EVAL_3 ? 2'h1 : 2'h2;
  assign _EVAL_32 = _EVAL_30 & _EVAL_1;
  assign _EVAL_33 = _EVAL_13 ? _EVAL_18 : _EVAL_25;
  assign _EVAL_34 = _EVAL_30 == 1'h0;
  assign _EVAL_35 = _EVAL_13 == 1'h0;
  assign _EVAL_36 = _EVAL_13 | _EVAL_3;
  assign _EVAL_37 = _EVAL_34 | _EVAL_21;
endmodule
