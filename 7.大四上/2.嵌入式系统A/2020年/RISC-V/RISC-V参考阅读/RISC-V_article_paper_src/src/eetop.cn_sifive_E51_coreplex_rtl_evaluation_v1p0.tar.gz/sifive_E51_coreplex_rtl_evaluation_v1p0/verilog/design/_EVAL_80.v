//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_80(
  output        _EVAL_0,
  input         _EVAL_1,
  output [8:0]  _EVAL_2,
  output        _EVAL_3,
  input  [17:0] _EVAL_4,
  input  [8:0]  _EVAL_5,
  input         _EVAL_6,
  input  [17:0] _EVAL_7,
  output        _EVAL_8,
  input  [17:0] _EVAL_9,
  input  [1:0]  _EVAL_10,
  input         _EVAL_11,
  output        _EVAL_12,
  input         _EVAL_13,
  input         _EVAL_14,
  input  [8:0]  _EVAL_15,
  input         _EVAL_16,
  output        _EVAL_17,
  input  [1:0]  _EVAL_18,
  input  [8:0]  _EVAL_19,
  input  [17:0] _EVAL_20,
  input  [17:0] _EVAL_21,
  output [17:0] _EVAL_22,
  output [1:0]  _EVAL_23,
  input         _EVAL_24,
  input  [17:0] _EVAL_25,
  input  [1:0]  _EVAL_26,
  output [17:0] _EVAL_27,
  input         _EVAL_28,
  input         _EVAL_29,
  output [1:0]  _EVAL_30
);
  wire [17:0] _EVAL_31;
  wire [1:0] _EVAL_32;
  wire [1:0] _EVAL_33;
  wire [17:0] _EVAL_34;
  wire [1:0] _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  wire  _EVAL_38;
  wire  _EVAL_39;
  wire  _EVAL_40;
  wire [17:0] _EVAL_41;
  wire  _EVAL_42;
  wire [17:0] _EVAL_43;
  wire  _EVAL_44;
  wire [8:0] _EVAL_45;
  wire [8:0] _EVAL_46;
  wire [1:0] _EVAL_47;
  wire  _EVAL_48;
  wire  _EVAL_49;
  assign _EVAL_0 = _EVAL_39;
  assign _EVAL_2 = _EVAL_46;
  assign _EVAL_3 = _EVAL_49;
  assign _EVAL_8 = _EVAL_29;
  assign _EVAL_12 = _EVAL_42;
  assign _EVAL_17 = _EVAL_40;
  assign _EVAL_22 = _EVAL_41;
  assign _EVAL_23 = _EVAL_33;
  assign _EVAL_27 = _EVAL_43;
  assign _EVAL_30 = _EVAL_47;
  assign _EVAL_31 = _EVAL_13 ? _EVAL_9 : _EVAL_7;
  assign _EVAL_32 = _EVAL_13 ? 2'h1 : 2'h2;
  assign _EVAL_33 = _EVAL_24 ? _EVAL_26 : _EVAL_35;
  assign _EVAL_34 = _EVAL_13 ? _EVAL_4 : _EVAL_20;
  assign _EVAL_35 = _EVAL_13 ? _EVAL_10 : _EVAL_18;
  assign _EVAL_36 = _EVAL_38 == 1'h0;
  assign _EVAL_37 = _EVAL_36 == 1'h0;
  assign _EVAL_38 = _EVAL_24 | _EVAL_13;
  assign _EVAL_39 = _EVAL_37 | _EVAL_28;
  assign _EVAL_40 = _EVAL_44 & _EVAL_29;
  assign _EVAL_41 = _EVAL_24 ? _EVAL_21 : _EVAL_31;
  assign _EVAL_42 = _EVAL_36 & _EVAL_29;
  assign _EVAL_43 = _EVAL_24 ? _EVAL_25 : _EVAL_34;
  assign _EVAL_44 = _EVAL_24 == 1'h0;
  assign _EVAL_45 = _EVAL_13 ? _EVAL_19 : _EVAL_5;
  assign _EVAL_46 = _EVAL_24 ? _EVAL_15 : _EVAL_45;
  assign _EVAL_47 = _EVAL_24 ? 2'h0 : _EVAL_32;
  assign _EVAL_48 = _EVAL_13 ? _EVAL_1 : _EVAL_11;
  assign _EVAL_49 = _EVAL_24 ? _EVAL_16 : _EVAL_48;
endmodule
