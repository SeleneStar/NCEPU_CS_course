//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_81(
  input         _EVAL_0,
  input         _EVAL_1,
  output [63:0] _EVAL_2,
  input         _EVAL_3,
  input         _EVAL_4,
  input  [7:0]  _EVAL_5,
  input  [13:0] _EVAL_6,
  input  [63:0] _EVAL_7,
  input         _EVAL_8
);
  wire [7:0] _EVAL_9;
  wire [7:0] _EVAL_10;
  wire [31:0] _EVAL_11;
  wire [7:0] _EVAL_12;
  wire  _EVAL_13;
  wire  _EVAL_14;
  wire  _EVAL_15;
  wire [7:0] _EVAL_16;
  wire  _EVAL_17;
  wire [7:0] _EVAL_18;
  wire [7:0] E51_data_arrays_0__EVAL_0;
  wire  E51_data_arrays_0__EVAL_1;
  wire  E51_data_arrays_0__EVAL_2;
  wire [7:0] E51_data_arrays_0__EVAL_3;
  wire [7:0] E51_data_arrays_0__EVAL_4;
  wire [7:0] E51_data_arrays_0__EVAL_5;
  wire [7:0] E51_data_arrays_0__EVAL_6;
  wire  E51_data_arrays_0__EVAL_7;
  wire  E51_data_arrays_0__EVAL_8;
  wire  E51_data_arrays_0__EVAL_9;
  wire [7:0] E51_data_arrays_0__EVAL_10;
  wire [7:0] E51_data_arrays_0__EVAL_11;
  wire  E51_data_arrays_0__EVAL_12;
  wire  E51_data_arrays_0__EVAL_13;
  wire [7:0] E51_data_arrays_0__EVAL_14;
  wire [7:0] E51_data_arrays_0__EVAL_15;
  wire [7:0] E51_data_arrays_0__EVAL_16;
  wire [7:0] E51_data_arrays_0__EVAL_17;
  wire [7:0] E51_data_arrays_0__EVAL_18;
  wire [7:0] E51_data_arrays_0__EVAL_19;
  wire  E51_data_arrays_0__EVAL_20;
  wire [7:0] E51_data_arrays_0__EVAL_21;
  wire [7:0] E51_data_arrays_0__EVAL_22;
  wire [10:0] E51_data_arrays_0__EVAL_23;
  wire  E51_data_arrays_0__EVAL_24;
  wire [7:0] E51_data_arrays_0__EVAL_25;
  wire  E51_data_arrays_0__EVAL_26;
  wire  E51_data_arrays_0__EVAL_27;
  wire [15:0] _EVAL_19;
  wire [10:0] _EVAL_20;
  wire [7:0] _EVAL_21;
  wire [31:0] _EVAL_22;
  wire  _EVAL_23;
  wire  _EVAL_24;
  wire  _EVAL_25;
  wire [7:0] _EVAL_26;
  wire [7:0] _EVAL_27;
  wire [7:0] _EVAL_28;
  wire  _EVAL_29;
  wire [15:0] _EVAL_30;
  wire  _EVAL_31;
  wire [7:0] _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  wire [63:0] _EVAL_35;
  wire [7:0] _EVAL_36;
  wire [10:0] _EVAL_37;
  wire [7:0] _EVAL_38;
  wire  _EVAL_39;
  wire  _EVAL_40;
  wire  _EVAL_41;
  wire  _EVAL_42;
  wire [7:0] _EVAL_43;
  wire  _EVAL_44;
  wire [7:0] _EVAL_45;
  wire  _EVAL_46;
  wire  _EVAL_47;
  wire [15:0] _EVAL_48;
  wire [7:0] _EVAL_49;
  wire [7:0] _EVAL_50;
  wire [15:0] _EVAL_51;
  wire  _EVAL_52;
  _EVAL_181 E51_data_arrays_0 (
    ._EVAL_0(E51_data_arrays_0__EVAL_0),
    ._EVAL_1(E51_data_arrays_0__EVAL_1),
    ._EVAL_2(E51_data_arrays_0__EVAL_2),
    ._EVAL_3(E51_data_arrays_0__EVAL_3),
    ._EVAL_4(E51_data_arrays_0__EVAL_4),
    ._EVAL_5(E51_data_arrays_0__EVAL_5),
    ._EVAL_6(E51_data_arrays_0__EVAL_6),
    ._EVAL_7(E51_data_arrays_0__EVAL_7),
    ._EVAL_8(E51_data_arrays_0__EVAL_8),
    ._EVAL_9(E51_data_arrays_0__EVAL_9),
    ._EVAL_10(E51_data_arrays_0__EVAL_10),
    ._EVAL_11(E51_data_arrays_0__EVAL_11),
    ._EVAL_12(E51_data_arrays_0__EVAL_12),
    ._EVAL_13(E51_data_arrays_0__EVAL_13),
    ._EVAL_14(E51_data_arrays_0__EVAL_14),
    ._EVAL_15(E51_data_arrays_0__EVAL_15),
    ._EVAL_16(E51_data_arrays_0__EVAL_16),
    ._EVAL_17(E51_data_arrays_0__EVAL_17),
    ._EVAL_18(E51_data_arrays_0__EVAL_18),
    ._EVAL_19(E51_data_arrays_0__EVAL_19),
    ._EVAL_20(E51_data_arrays_0__EVAL_20),
    ._EVAL_21(E51_data_arrays_0__EVAL_21),
    ._EVAL_22(E51_data_arrays_0__EVAL_22),
    ._EVAL_23(E51_data_arrays_0__EVAL_23),
    ._EVAL_24(E51_data_arrays_0__EVAL_24),
    ._EVAL_25(E51_data_arrays_0__EVAL_25),
    ._EVAL_26(E51_data_arrays_0__EVAL_26),
    ._EVAL_27(E51_data_arrays_0__EVAL_27)
  );
  assign _EVAL_2 = _EVAL_35;
  assign _EVAL_9 = _EVAL_18;
  assign _EVAL_10 = _EVAL_7[15:8];
  assign _EVAL_11 = {_EVAL_48,_EVAL_30};
  assign _EVAL_12 = _EVAL_7[47:40];
  assign _EVAL_13 = _EVAL_42 ? _EVAL_41 : 1'h0;
  assign _EVAL_14 = _EVAL_5[4];
  assign _EVAL_15 = _EVAL_42 ? _EVAL_52 : 1'h0;
  assign _EVAL_16 = _EVAL_45;
  assign _EVAL_17 = _EVAL_42 ? _EVAL_31 : 1'h0;
  assign _EVAL_18 = _EVAL_7[39:32];
  assign E51_data_arrays_0__EVAL_0 = _EVAL_50;
  assign E51_data_arrays_0__EVAL_1 = _EVAL_13;
  assign E51_data_arrays_0__EVAL_2 = _EVAL_34;
  assign E51_data_arrays_0__EVAL_5 = _EVAL_9;
  assign E51_data_arrays_0__EVAL_6 = _EVAL_16;
  assign E51_data_arrays_0__EVAL_7 = _EVAL_25;
  assign E51_data_arrays_0__EVAL_8 = _EVAL_42;
  assign E51_data_arrays_0__EVAL_9 = _EVAL_24;
  assign E51_data_arrays_0__EVAL_10 = _EVAL_36;
  assign E51_data_arrays_0__EVAL_12 = _EVAL_8;
  assign E51_data_arrays_0__EVAL_13 = _EVAL_39;
  assign E51_data_arrays_0__EVAL_14 = _EVAL_26;
  assign E51_data_arrays_0__EVAL_18 = _EVAL_21;
  assign E51_data_arrays_0__EVAL_20 = _EVAL_15;
  assign E51_data_arrays_0__EVAL_21 = _EVAL_32;
  assign E51_data_arrays_0__EVAL_23 = _EVAL_42 ? _EVAL_37 : _EVAL_20;
  assign E51_data_arrays_0__EVAL_24 = _EVAL_17;
  assign E51_data_arrays_0__EVAL_25 = _EVAL_28;
  assign E51_data_arrays_0__EVAL_26 = _EVAL_46;
  assign E51_data_arrays_0__EVAL_27 = _EVAL_29 | _EVAL_42;
  assign _EVAL_19 = {E51_data_arrays_0__EVAL_22,E51_data_arrays_0__EVAL_11};
  assign _EVAL_20 = _EVAL_37;
  assign _EVAL_21 = _EVAL_43;
  assign _EVAL_22 = {_EVAL_19,_EVAL_51};
  assign _EVAL_23 = _EVAL_4 == 1'h0;
  assign _EVAL_24 = _EVAL_42 ? _EVAL_14 : 1'h0;
  assign _EVAL_25 = _EVAL_42 ? _EVAL_44 : 1'h0;
  assign _EVAL_26 = _EVAL_49;
  assign _EVAL_27 = _EVAL_7[31:24];
  assign _EVAL_28 = _EVAL_10;
  assign _EVAL_29 = _EVAL_0 & _EVAL_23;
  assign _EVAL_30 = {E51_data_arrays_0__EVAL_3,E51_data_arrays_0__EVAL_19};
  assign _EVAL_31 = _EVAL_5[1];
  assign _EVAL_32 = _EVAL_27;
  assign _EVAL_33 = _EVAL_5[2];
  assign _EVAL_34 = _EVAL_42 ? _EVAL_47 : 1'h0;
  assign _EVAL_35 = {_EVAL_11,_EVAL_22};
  assign _EVAL_36 = _EVAL_12;
  assign _EVAL_37 = _EVAL_6[13:3];
  assign _EVAL_38 = _EVAL_7[23:16];
  assign _EVAL_39 = _EVAL_42 ? _EVAL_40 : 1'h0;
  assign _EVAL_40 = _EVAL_5[5];
  assign _EVAL_41 = _EVAL_5[3];
  assign _EVAL_42 = _EVAL_0 & _EVAL_4;
  assign _EVAL_43 = _EVAL_7[63:56];
  assign _EVAL_44 = _EVAL_5[6];
  assign _EVAL_45 = _EVAL_7[55:48];
  assign _EVAL_46 = _EVAL_42 ? _EVAL_33 : 1'h0;
  assign _EVAL_47 = _EVAL_5[7];
  assign _EVAL_48 = {E51_data_arrays_0__EVAL_15,E51_data_arrays_0__EVAL_16};
  assign _EVAL_49 = _EVAL_7[7:0];
  assign _EVAL_50 = _EVAL_38;
  assign _EVAL_51 = {E51_data_arrays_0__EVAL_17,E51_data_arrays_0__EVAL_4};
  assign _EVAL_52 = _EVAL_5[0];
endmodule
