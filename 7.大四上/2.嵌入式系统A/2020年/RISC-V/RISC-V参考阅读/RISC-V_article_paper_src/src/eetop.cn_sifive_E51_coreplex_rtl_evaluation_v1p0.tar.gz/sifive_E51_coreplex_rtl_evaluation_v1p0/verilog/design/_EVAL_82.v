//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_82(
  input  [7:0]  _EVAL_0,
  input  [13:0] _EVAL_1,
  input         _EVAL_2,
  input  [13:0] _EVAL_3,
  input         _EVAL_4,
  input         _EVAL_5,
  input         _EVAL_6,
  output        _EVAL_7,
  input         _EVAL_8,
  input         _EVAL_9,
  input  [63:0] _EVAL_10,
  output [13:0] _EVAL_11,
  output        _EVAL_12,
  output        _EVAL_13,
  input  [7:0]  _EVAL_14,
  input         _EVAL_15,
  input  [7:0]  _EVAL_16,
  input  [7:0]  _EVAL_17,
  input  [63:0] _EVAL_18,
  input         _EVAL_19,
  output        _EVAL_20,
  input         _EVAL_21,
  input         _EVAL_22,
  output        _EVAL_23,
  input         _EVAL_24,
  input         _EVAL_25,
  output [7:0]  _EVAL_26,
  output        _EVAL_27,
  input  [63:0] _EVAL_28,
  output        _EVAL_29,
  input  [13:0] _EVAL_30,
  input         _EVAL_31,
  input  [63:0] _EVAL_32,
  output [1:0]  _EVAL_33,
  input         _EVAL_34,
  output [63:0] _EVAL_35,
  input  [13:0] _EVAL_36,
  input         _EVAL_37
);
  wire  _EVAL_38;
  wire [1:0] _EVAL_39;
  wire [13:0] _EVAL_40;
  wire [1:0] _EVAL_41;
  wire  _EVAL_42;
  wire [7:0] _EVAL_43;
  wire  _EVAL_44;
  wire [7:0] _EVAL_45;
  wire  _EVAL_46;
  wire  _EVAL_47;
  wire [63:0] _EVAL_48;
  wire  _EVAL_49;
  wire [13:0] _EVAL_50;
  wire  _EVAL_51;
  wire [13:0] _EVAL_52;
  wire  _EVAL_53;
  wire  _EVAL_54;
  wire  _EVAL_55;
  wire  _EVAL_56;
  wire  _EVAL_57;
  wire  _EVAL_58;
  wire  _EVAL_59;
  wire [7:0] _EVAL_60;
  wire  _EVAL_61;
  wire  _EVAL_62;
  wire [1:0] _EVAL_63;
  wire [63:0] _EVAL_64;
  wire [63:0] _EVAL_65;
  assign _EVAL_7 = _EVAL_59;
  assign _EVAL_11 = _EVAL_50;
  assign _EVAL_12 = _EVAL_58;
  assign _EVAL_13 = _EVAL_54;
  assign _EVAL_20 = _EVAL_46;
  assign _EVAL_23 = _EVAL_61;
  assign _EVAL_26 = _EVAL_60;
  assign _EVAL_27 = _EVAL_51;
  assign _EVAL_29 = _EVAL_19;
  assign _EVAL_33 = _EVAL_63;
  assign _EVAL_35 = _EVAL_64;
  assign _EVAL_38 = _EVAL_62 == 1'h0;
  assign _EVAL_39 = _EVAL_25 ? 2'h2 : 2'h3;
  assign _EVAL_40 = _EVAL_31 ? _EVAL_3 : _EVAL_52;
  assign _EVAL_41 = _EVAL_31 ? 2'h1 : _EVAL_39;
  assign _EVAL_42 = _EVAL_8 == 1'h0;
  assign _EVAL_43 = _EVAL_31 ? _EVAL_14 : _EVAL_45;
  assign _EVAL_44 = _EVAL_38 == 1'h0;
  assign _EVAL_45 = _EVAL_25 ? _EVAL_0 : _EVAL_16;
  assign _EVAL_46 = _EVAL_8 ? _EVAL_5 : _EVAL_57;
  assign _EVAL_47 = _EVAL_8 | _EVAL_31;
  assign _EVAL_48 = _EVAL_25 ? _EVAL_10 : _EVAL_32;
  assign _EVAL_49 = _EVAL_31 ? _EVAL_24 : _EVAL_53;
  assign _EVAL_50 = _EVAL_8 ? _EVAL_30 : _EVAL_40;
  assign _EVAL_51 = _EVAL_55 & _EVAL_19;
  assign _EVAL_52 = _EVAL_25 ? _EVAL_1 : _EVAL_36;
  assign _EVAL_53 = _EVAL_25 ? _EVAL_9 : _EVAL_15;
  assign _EVAL_54 = _EVAL_42 & _EVAL_19;
  assign _EVAL_55 = _EVAL_47 == 1'h0;
  assign _EVAL_56 = _EVAL_25 ? _EVAL_21 : _EVAL_37;
  assign _EVAL_57 = _EVAL_31 ? _EVAL_4 : _EVAL_56;
  assign _EVAL_58 = _EVAL_44 | _EVAL_34;
  assign _EVAL_59 = _EVAL_8 ? _EVAL_2 : _EVAL_49;
  assign _EVAL_60 = _EVAL_8 ? _EVAL_17 : _EVAL_43;
  assign _EVAL_61 = _EVAL_38 & _EVAL_19;
  assign _EVAL_62 = _EVAL_47 | _EVAL_25;
  assign _EVAL_63 = _EVAL_8 ? 2'h0 : _EVAL_41;
  assign _EVAL_64 = _EVAL_8 ? _EVAL_18 : _EVAL_65;
  assign _EVAL_65 = _EVAL_31 ? _EVAL_28 : _EVAL_48;
endmodule
