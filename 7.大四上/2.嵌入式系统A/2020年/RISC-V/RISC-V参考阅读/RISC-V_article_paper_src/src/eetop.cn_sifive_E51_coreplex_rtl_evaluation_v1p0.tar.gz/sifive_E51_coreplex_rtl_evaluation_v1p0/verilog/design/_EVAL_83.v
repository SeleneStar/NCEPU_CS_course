//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_83(
  input         _EVAL_0,
  input         _EVAL_1,
  output [7:0]  _EVAL_2,
  output [31:0] _EVAL_3,
  input  [2:0]  _EVAL_4,
  output [1:0]  _EVAL_5,
  input         _EVAL_6,
  output [63:0] _EVAL_7,
  input  [7:0]  _EVAL_8,
  input  [3:0]  _EVAL_9,
  input  [2:0]  _EVAL_10,
  output        _EVAL_11,
  output [2:0]  _EVAL_12,
  input  [2:0]  _EVAL_13,
  output        _EVAL_14,
  input  [31:0] _EVAL_15,
  output [3:0]  _EVAL_16,
  input  [63:0] _EVAL_17,
  output [2:0]  _EVAL_18,
  input         _EVAL_19,
  output [2:0]  _EVAL_20
);
  wire  _EVAL_21;
  wire  _EVAL_22;
  wire [1:0] _EVAL_23;
  reg [7:0] _EVAL_24 [0:1];
  reg [31:0] _GEN_0;
  wire [7:0] _EVAL_24__EVAL_25_data;
  wire  _EVAL_24__EVAL_25_addr;
  wire [7:0] _EVAL_24__EVAL_26_data;
  wire  _EVAL_24__EVAL_26_addr;
  wire  _EVAL_24__EVAL_26_mask;
  wire  _EVAL_24__EVAL_26_en;
  wire  _EVAL_27;
  wire [3:0] _EVAL_28;
  wire  _EVAL_29;
  wire  _EVAL_30;
  wire  _EVAL_31;
  wire  _EVAL_32;
  reg  _EVAL_33;
  reg [31:0] _GEN_1;
  reg [63:0] _EVAL_34 [0:1];
  reg [63:0] _GEN_2;
  wire [63:0] _EVAL_34__EVAL_35_data;
  wire  _EVAL_34__EVAL_35_addr;
  wire [63:0] _EVAL_34__EVAL_36_data;
  wire  _EVAL_34__EVAL_36_addr;
  wire  _EVAL_34__EVAL_36_mask;
  wire  _EVAL_34__EVAL_36_en;
  wire [2:0] _EVAL_37;
  wire  _EVAL_38;
  wire [1:0] _EVAL_39;
  wire [2:0] _EVAL_40;
  wire  _EVAL_41;
  wire [1:0] _EVAL_42;
  wire  _EVAL_43;
  wire  _EVAL_44;
  wire  _EVAL_45;
  reg  _EVAL_46;
  reg [31:0] _GEN_3;
  wire  _EVAL_47;
  wire  _EVAL_48;
  wire  _EVAL_49;
  reg [3:0] _EVAL_50 [0:1];
  reg [31:0] _GEN_4;
  wire [3:0] _EVAL_50__EVAL_51_data;
  wire  _EVAL_50__EVAL_51_addr;
  wire [3:0] _EVAL_50__EVAL_52_data;
  wire  _EVAL_50__EVAL_52_addr;
  wire  _EVAL_50__EVAL_52_mask;
  wire  _EVAL_50__EVAL_52_en;
  reg [31:0] _EVAL_53 [0:1];
  reg [31:0] _GEN_5;
  wire [31:0] _EVAL_53__EVAL_54_data;
  wire  _EVAL_53__EVAL_54_addr;
  wire [31:0] _EVAL_53__EVAL_55_data;
  wire  _EVAL_53__EVAL_55_addr;
  wire  _EVAL_53__EVAL_55_mask;
  wire  _EVAL_53__EVAL_55_en;
  wire [7:0] _EVAL_56;
  wire [63:0] _EVAL_57;
  wire  _EVAL_58;
  wire  _EVAL_59;
  wire  _EVAL_60;
  wire  _EVAL_61;
  wire [2:0] _EVAL_62;
  wire [31:0] _EVAL_63;
  wire  _EVAL_64;
  wire  _EVAL_65;
  reg [2:0] _EVAL_66 [0:1];
  reg [31:0] _GEN_6;
  wire [2:0] _EVAL_66__EVAL_67_data;
  wire  _EVAL_66__EVAL_67_addr;
  wire [2:0] _EVAL_66__EVAL_68_data;
  wire  _EVAL_66__EVAL_68_addr;
  wire  _EVAL_66__EVAL_68_mask;
  wire  _EVAL_66__EVAL_68_en;
  wire [1:0] _EVAL_69;
  reg [2:0] _EVAL_70 [0:1];
  reg [31:0] _GEN_7;
  wire [2:0] _EVAL_70__EVAL_71_data;
  wire  _EVAL_70__EVAL_71_addr;
  wire [2:0] _EVAL_70__EVAL_72_data;
  wire  _EVAL_70__EVAL_72_addr;
  wire  _EVAL_70__EVAL_72_mask;
  wire  _EVAL_70__EVAL_72_en;
  wire [1:0] _EVAL_73;
  reg  _EVAL_74;
  reg [31:0] _GEN_8;
  wire  _EVAL_75;
  reg [2:0] _EVAL_76 [0:1];
  reg [31:0] _GEN_9;
  wire [2:0] _EVAL_76__EVAL_77_data;
  wire  _EVAL_76__EVAL_77_addr;
  wire [2:0] _EVAL_76__EVAL_78_data;
  wire  _EVAL_76__EVAL_78_addr;
  wire  _EVAL_76__EVAL_78_mask;
  wire  _EVAL_76__EVAL_78_en;
  wire  _EVAL_79;
  assign _EVAL_2 = _EVAL_56;
  assign _EVAL_3 = _EVAL_63;
  assign _EVAL_5 = _EVAL_39;
  assign _EVAL_7 = _EVAL_57;
  assign _EVAL_11 = _EVAL_79;
  assign _EVAL_12 = _EVAL_62;
  assign _EVAL_14 = _EVAL_30;
  assign _EVAL_16 = _EVAL_28;
  assign _EVAL_18 = _EVAL_40;
  assign _EVAL_20 = _EVAL_37;
  assign _EVAL_21 = _EVAL_49 & _EVAL_45;
  assign _EVAL_22 = _EVAL_42[0:0];
  assign _EVAL_23 = $unsigned(_EVAL_73);
  assign _EVAL_24__EVAL_25_addr = _EVAL_33;
  assign _EVAL_24__EVAL_25_data = _EVAL_24[_EVAL_24__EVAL_25_addr];
  assign _EVAL_24__EVAL_26_data = _EVAL_8;
  assign _EVAL_24__EVAL_26_addr = _EVAL_74;
  assign _EVAL_24__EVAL_26_mask = _EVAL_65;
  assign _EVAL_24__EVAL_26_en = _EVAL_65;
  assign _EVAL_27 = _EVAL_49 & _EVAL_46;
  assign _EVAL_28 = _EVAL_21 ? _EVAL_9 : _EVAL_50__EVAL_51_data;
  assign _EVAL_29 = _EVAL_59 ? _EVAL_43 : _EVAL_33;
  assign _EVAL_30 = _EVAL_1 ? 1'h1 : _EVAL_64;
  assign _EVAL_31 = _EVAL_65 ? _EVAL_22 : _EVAL_74;
  assign _EVAL_32 = _EVAL_21 ? 1'h0 : _EVAL_44;
  assign _EVAL_34__EVAL_35_addr = _EVAL_33;
  assign _EVAL_34__EVAL_35_data = _EVAL_34[_EVAL_34__EVAL_35_addr];
  assign _EVAL_34__EVAL_36_data = _EVAL_17;
  assign _EVAL_34__EVAL_36_addr = _EVAL_74;
  assign _EVAL_34__EVAL_36_mask = _EVAL_65;
  assign _EVAL_34__EVAL_36_en = _EVAL_65;
  assign _EVAL_37 = _EVAL_21 ? _EVAL_10 : _EVAL_66__EVAL_67_data;
  assign _EVAL_38 = _EVAL_65 != _EVAL_59;
  assign _EVAL_39 = {_EVAL_61,_EVAL_47};
  assign _EVAL_40 = _EVAL_21 ? _EVAL_4 : _EVAL_76__EVAL_77_data;
  assign _EVAL_41 = _EVAL_21 == 1'h0;
  assign _EVAL_42 = _EVAL_74 + 1'h1;
  assign _EVAL_43 = _EVAL_69[0:0];
  assign _EVAL_44 = _EVAL_1 & _EVAL_11;
  assign _EVAL_45 = _EVAL_46 == 1'h0;
  assign _EVAL_47 = _EVAL_23[0:0];
  assign _EVAL_48 = _EVAL_38 ? _EVAL_65 : _EVAL_46;
  assign _EVAL_49 = _EVAL_74 == _EVAL_33;
  assign _EVAL_50__EVAL_51_addr = _EVAL_33;
  assign _EVAL_50__EVAL_51_data = _EVAL_50[_EVAL_50__EVAL_51_addr];
  assign _EVAL_50__EVAL_52_data = _EVAL_9;
  assign _EVAL_50__EVAL_52_addr = _EVAL_74;
  assign _EVAL_50__EVAL_52_mask = _EVAL_65;
  assign _EVAL_50__EVAL_52_en = _EVAL_65;
  assign _EVAL_53__EVAL_54_addr = _EVAL_33;
  assign _EVAL_53__EVAL_54_data = _EVAL_53[_EVAL_53__EVAL_54_addr];
  assign _EVAL_53__EVAL_55_data = _EVAL_15;
  assign _EVAL_53__EVAL_55_addr = _EVAL_74;
  assign _EVAL_53__EVAL_55_mask = _EVAL_65;
  assign _EVAL_53__EVAL_55_en = _EVAL_65;
  assign _EVAL_56 = _EVAL_21 ? _EVAL_8 : _EVAL_24__EVAL_25_data;
  assign _EVAL_57 = _EVAL_21 ? _EVAL_17 : _EVAL_34__EVAL_35_data;
  assign _EVAL_58 = _EVAL_21 ? _EVAL_60 : _EVAL_75;
  assign _EVAL_59 = _EVAL_32;
  assign _EVAL_60 = _EVAL_1 ? 1'h0 : _EVAL_75;
  assign _EVAL_61 = _EVAL_46 & _EVAL_49;
  assign _EVAL_62 = _EVAL_21 ? _EVAL_13 : _EVAL_70__EVAL_71_data;
  assign _EVAL_63 = _EVAL_21 ? _EVAL_15 : _EVAL_53__EVAL_54_data;
  assign _EVAL_64 = _EVAL_27 == 1'h0;
  assign _EVAL_65 = _EVAL_58;
  assign _EVAL_66__EVAL_67_addr = _EVAL_33;
  assign _EVAL_66__EVAL_67_data = _EVAL_66[_EVAL_66__EVAL_67_addr];
  assign _EVAL_66__EVAL_68_data = _EVAL_10;
  assign _EVAL_66__EVAL_68_addr = _EVAL_74;
  assign _EVAL_66__EVAL_68_mask = _EVAL_65;
  assign _EVAL_66__EVAL_68_en = _EVAL_65;
  assign _EVAL_69 = _EVAL_33 + 1'h1;
  assign _EVAL_70__EVAL_71_addr = _EVAL_33;
  assign _EVAL_70__EVAL_71_data = _EVAL_70[_EVAL_70__EVAL_71_addr];
  assign _EVAL_70__EVAL_72_data = _EVAL_13;
  assign _EVAL_70__EVAL_72_addr = _EVAL_74;
  assign _EVAL_70__EVAL_72_mask = _EVAL_65;
  assign _EVAL_70__EVAL_72_en = _EVAL_65;
  assign _EVAL_73 = _EVAL_74 - _EVAL_33;
  assign _EVAL_75 = _EVAL_14 & _EVAL_19;
  assign _EVAL_76__EVAL_77_addr = _EVAL_33;
  assign _EVAL_76__EVAL_77_data = _EVAL_76[_EVAL_76__EVAL_77_addr];
  assign _EVAL_76__EVAL_78_data = _EVAL_4;
  assign _EVAL_76__EVAL_78_addr = _EVAL_74;
  assign _EVAL_76__EVAL_78_mask = _EVAL_65;
  assign _EVAL_76__EVAL_78_en = _EVAL_65;
  assign _EVAL_79 = _EVAL_19 ? 1'h1 : _EVAL_41;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_24[initvar] = _GEN_0[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_33 = _GEN_1[0:0];
  `endif
  _GEN_2 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_34[initvar] = _GEN_2[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_46 = _GEN_3[0:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_50[initvar] = _GEN_4[3:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_53[initvar] = _GEN_5[31:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_66[initvar] = _GEN_6[2:0];
  `endif
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_70[initvar] = _GEN_7[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_74 = _GEN_8[0:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_76[initvar] = _GEN_9[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_6) begin
    if(_EVAL_24__EVAL_26_en & _EVAL_24__EVAL_26_mask) begin
      _EVAL_24[_EVAL_24__EVAL_26_addr] <= _EVAL_24__EVAL_26_data;
    end
    if (_EVAL_0) begin
      _EVAL_33 <= 1'h0;
    end else begin
      if (_EVAL_59) begin
        _EVAL_33 <= _EVAL_43;
      end
    end
    if(_EVAL_34__EVAL_36_en & _EVAL_34__EVAL_36_mask) begin
      _EVAL_34[_EVAL_34__EVAL_36_addr] <= _EVAL_34__EVAL_36_data;
    end
    if (_EVAL_0) begin
      _EVAL_46 <= 1'h0;
    end else begin
      if (_EVAL_38) begin
        _EVAL_46 <= _EVAL_65;
      end
    end
    if(_EVAL_50__EVAL_52_en & _EVAL_50__EVAL_52_mask) begin
      _EVAL_50[_EVAL_50__EVAL_52_addr] <= _EVAL_50__EVAL_52_data;
    end
    if(_EVAL_53__EVAL_55_en & _EVAL_53__EVAL_55_mask) begin
      _EVAL_53[_EVAL_53__EVAL_55_addr] <= _EVAL_53__EVAL_55_data;
    end
    if(_EVAL_66__EVAL_68_en & _EVAL_66__EVAL_68_mask) begin
      _EVAL_66[_EVAL_66__EVAL_68_addr] <= _EVAL_66__EVAL_68_data;
    end
    if(_EVAL_70__EVAL_72_en & _EVAL_70__EVAL_72_mask) begin
      _EVAL_70[_EVAL_70__EVAL_72_addr] <= _EVAL_70__EVAL_72_data;
    end
    if (_EVAL_0) begin
      _EVAL_74 <= 1'h0;
    end else begin
      if (_EVAL_65) begin
        _EVAL_74 <= _EVAL_22;
      end
    end
    if(_EVAL_76__EVAL_78_en & _EVAL_76__EVAL_78_mask) begin
      _EVAL_76[_EVAL_76__EVAL_78_addr] <= _EVAL_76__EVAL_78_data;
    end
  end
endmodule
