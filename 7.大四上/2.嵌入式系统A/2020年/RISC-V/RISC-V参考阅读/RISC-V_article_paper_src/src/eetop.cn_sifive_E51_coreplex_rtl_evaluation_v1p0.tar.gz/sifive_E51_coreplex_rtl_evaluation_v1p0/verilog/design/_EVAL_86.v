//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_86(
  input         _EVAL_0,
  input         _EVAL_1,
  input  [7:0]  _EVAL_2,
  input  [4:0]  _EVAL_3,
  input  [63:0] _EVAL_4,
  input  [63:0] _EVAL_5,
  output [63:0] _EVAL_6
);
  wire  _EVAL_7;
  wire [7:0] _EVAL_8;
  wire  _EVAL_9;
  wire [31:0] _EVAL_10;
  wire  _EVAL_11;
  wire  _EVAL_12;
  wire [7:0] _EVAL_13;
  wire  _EVAL_14;
  wire  _EVAL_15;
  wire [15:0] _EVAL_16;
  wire  _EVAL_17;
  wire [63:0] _EVAL_18;
  wire  _EVAL_19;
  wire [15:0] _EVAL_20;
  wire [31:0] _EVAL_21;
  wire  _EVAL_22;
  wire  _EVAL_23;
  wire [7:0] _EVAL_24;
  wire [15:0] _EVAL_25;
  wire  _EVAL_26;
  wire  _EVAL_27;
  wire [63:0] _EVAL_28;
  wire [31:0] _EVAL_29;
  wire [63:0] _EVAL_30;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  wire [63:0] _EVAL_35;
  wire  _EVAL_36;
  wire  _EVAL_37;
  wire [63:0] _EVAL_38;
  wire  _EVAL_39;
  wire [63:0] _EVAL_40;
  wire [63:0] _EVAL_41;
  wire [31:0] _EVAL_42;
  wire [15:0] _EVAL_43;
  wire [7:0] _EVAL_44;
  wire [63:0] _EVAL_45;
  wire [31:0] _EVAL_46;
  wire  _EVAL_47;
  wire  _EVAL_48;
  wire [31:0] _EVAL_49;
  wire  _EVAL_50;
  wire [4:0] _EVAL_51;
  wire  _EVAL_52;
  wire [63:0] _EVAL_53;
  wire  _EVAL_54;
  wire [63:0] _EVAL_55;
  wire [7:0] _EVAL_56;
  wire [7:0] _EVAL_57;
  wire  _EVAL_58;
  wire [63:0] _EVAL_59;
  wire [63:0] _EVAL_60;
  wire  _EVAL_61;
  wire  _EVAL_62;
  wire  _EVAL_63;
  wire  _EVAL_64;
  wire [63:0] _EVAL_65;
  wire  _EVAL_66;
  wire  _EVAL_67;
  wire  _EVAL_68;
  wire  _EVAL_69;
  wire [63:0] _EVAL_70;
  wire  _EVAL_71;
  wire  _EVAL_72;
  wire [63:0] _EVAL_73;
  wire  _EVAL_74;
  wire  _EVAL_75;
  wire [7:0] _EVAL_76;
  wire [31:0] _EVAL_77;
  wire [7:0] _EVAL_78;
  wire  _EVAL_79;
  wire  _EVAL_80;
  wire  _EVAL_81;
  wire [31:0] _EVAL_82;
  wire [63:0] _EVAL_83;
  wire [64:0] _EVAL_84;
  wire  _EVAL_85;
  wire [63:0] _EVAL_86;
  wire [63:0] _EVAL_87;
  wire  _EVAL_88;
  assign _EVAL_6 = _EVAL_60;
  assign _EVAL_7 = _EVAL_2[7];
  assign _EVAL_8 = _EVAL_68 ? 8'hff : 8'h0;
  assign _EVAL_9 = _EVAL_3 == 5'hc;
  assign _EVAL_10 = {{31'd0}, _EVAL_64};
  assign _EVAL_11 = _EVAL_21 < _EVAL_82;
  assign _EVAL_12 = _EVAL_2[5];
  assign _EVAL_13 = _EVAL_34 ? 8'hff : 8'h0;
  assign _EVAL_14 = _EVAL_9 | _EVAL_48;
  assign _EVAL_15 = _EVAL_3 == 5'ha;
  assign _EVAL_16 = {_EVAL_76,_EVAL_8};
  assign _EVAL_17 = _EVAL_2[2];
  assign _EVAL_18 = _EVAL_5 & _EVAL_70;
  assign _EVAL_19 = _EVAL_22 ? _EVAL_74 : _EVAL_11;
  assign _EVAL_20 = {_EVAL_24,_EVAL_78};
  assign _EVAL_21 = _EVAL_4[31:0];
  assign _EVAL_22 = _EVAL_2[4];
  assign _EVAL_23 = _EVAL_5[31];
  assign _EVAL_24 = _EVAL_7 ? 8'hff : 8'h0;
  assign _EVAL_25 = {_EVAL_57,_EVAL_44};
  assign _EVAL_26 = _EVAL_67 | _EVAL_15;
  assign _EVAL_27 = _EVAL_85 & _EVAL_11;
  assign _EVAL_28 = _EVAL_4 ^ _EVAL_5;
  assign _EVAL_29 = _EVAL_4[63:32];
  assign _EVAL_30 = _EVAL_71 ? _EVAL_73 : _EVAL_65;
  assign _EVAL_31 = _EVAL_2[1];
  assign _EVAL_32 = _EVAL_74 | _EVAL_27;
  assign _EVAL_33 = _EVAL_4[63];
  assign _EVAL_34 = _EVAL_2[3];
  assign _EVAL_35 = _EVAL_4 & _EVAL_70;
  assign _EVAL_36 = _EVAL_66 ? _EVAL_23 : _EVAL_58;
  assign _EVAL_37 = _EVAL_39 ? _EVAL_14 : _EVAL_52;
  assign _EVAL_38 = _EVAL_45 & _EVAL_4;
  assign _EVAL_39 = _EVAL_63 ? _EVAL_54 : _EVAL_80;
  assign _EVAL_40 = _EVAL_72 ? _EVAL_86 : _EVAL_30;
  assign _EVAL_41 = _EVAL_4 & _EVAL_5;
  assign _EVAL_42 = _EVAL_10 << 31;
  assign _EVAL_43 = {_EVAL_13,_EVAL_56};
  assign _EVAL_44 = _EVAL_22 ? 8'hff : 8'h0;
  assign _EVAL_45 = ~ _EVAL_55;
  assign _EVAL_46 = {_EVAL_20,_EVAL_25};
  assign _EVAL_47 = _EVAL_3 == 5'hb;
  assign _EVAL_48 = _EVAL_3 == 5'he;
  assign _EVAL_49 = {_EVAL_43,_EVAL_16};
  assign _EVAL_50 = _EVAL_2[6];
  assign _EVAL_51 = _EVAL_3 & 5'h2;
  assign _EVAL_52 = _EVAL_81 | _EVAL_75;
  assign _EVAL_53 = {{32'd0}, _EVAL_42};
  assign _EVAL_54 = _EVAL_61 ? _EVAL_32 : _EVAL_19;
  assign _EVAL_55 = {_EVAL_46,_EVAL_49};
  assign _EVAL_56 = _EVAL_17 ? 8'hff : 8'h0;
  assign _EVAL_57 = _EVAL_12 ? 8'hff : 8'h0;
  assign _EVAL_58 = _EVAL_5[63];
  assign _EVAL_59 = _EVAL_26 ? _EVAL_28 : 64'h0;
  assign _EVAL_60 = _EVAL_87 | _EVAL_38;
  assign _EVAL_61 = _EVAL_22 & _EVAL_34;
  assign _EVAL_62 = _EVAL_66 ? _EVAL_88 : _EVAL_33;
  assign _EVAL_63 = _EVAL_62 == _EVAL_36;
  assign _EVAL_64 = _EVAL_34 == 1'h0;
  assign _EVAL_65 = _EVAL_37 ? _EVAL_4 : _EVAL_5;
  assign _EVAL_66 = _EVAL_22 == 1'h0;
  assign _EVAL_67 = _EVAL_3 == 5'h9;
  assign _EVAL_68 = _EVAL_2[0];
  assign _EVAL_69 = _EVAL_15 | _EVAL_47;
  assign _EVAL_70 = 64'hffffffffffffffff ^ _EVAL_53;
  assign _EVAL_71 = _EVAL_69 | _EVAL_26;
  assign _EVAL_72 = _EVAL_3 == 5'h8;
  assign _EVAL_73 = _EVAL_83 | _EVAL_59;
  assign _EVAL_74 = _EVAL_29 < _EVAL_77;
  assign _EVAL_75 = _EVAL_3 == 5'hf;
  assign _EVAL_76 = _EVAL_31 ? 8'hff : 8'h0;
  assign _EVAL_77 = _EVAL_5[63:32];
  assign _EVAL_78 = _EVAL_50 ? 8'hff : 8'h0;
  assign _EVAL_79 = _EVAL_51 == 5'h0;
  assign _EVAL_80 = _EVAL_79 ? _EVAL_62 : _EVAL_36;
  assign _EVAL_81 = _EVAL_3 == 5'hd;
  assign _EVAL_82 = _EVAL_5[31:0];
  assign _EVAL_83 = _EVAL_69 ? _EVAL_41 : 64'h0;
  assign _EVAL_84 = _EVAL_35 + _EVAL_18;
  assign _EVAL_85 = _EVAL_29 == _EVAL_77;
  assign _EVAL_86 = _EVAL_84[63:0];
  assign _EVAL_87 = _EVAL_55 & _EVAL_40;
  assign _EVAL_88 = _EVAL_4[31];
endmodule
