//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_9(
  output [3:0]  _EVAL_0,
  output [1:0]  _EVAL_1,
  input  [3:0]  _EVAL_2,
  input         _EVAL_3,
  input  [31:0] _EVAL_4,
  input  [3:0]  _EVAL_5,
  output [2:0]  _EVAL_6,
  output        _EVAL_7,
  input  [2:0]  _EVAL_8,
  input         _EVAL_9,
  input  [3:0]  _EVAL_10,
  output [3:0]  _EVAL_11,
  output [3:0]  _EVAL_12,
  input         _EVAL_13,
  output [2:0]  _EVAL_14,
  output        _EVAL_15,
  input  [2:0]  _EVAL_16,
  input  [29:0] _EVAL_17,
  input         _EVAL_18,
  output [31:0] _EVAL_19,
  output [29:0] _EVAL_20
);
  reg [2:0] _EVAL_21 [0:1];
  reg [31:0] _GEN_0;
  wire [2:0] _EVAL_21__EVAL_22_data;
  wire  _EVAL_21__EVAL_22_addr;
  wire [2:0] _EVAL_21__EVAL_23_data;
  wire  _EVAL_21__EVAL_23_addr;
  wire  _EVAL_21__EVAL_23_mask;
  wire  _EVAL_21__EVAL_23_en;
  wire  _EVAL_24;
  wire [1:0] _EVAL_25;
  wire [1:0] _EVAL_26;
  wire [1:0] _EVAL_27;
  wire  _EVAL_28;
  reg [3:0] _EVAL_29 [0:1];
  reg [31:0] _GEN_1;
  wire [3:0] _EVAL_29__EVAL_30_data;
  wire  _EVAL_29__EVAL_30_addr;
  wire [3:0] _EVAL_29__EVAL_31_data;
  wire  _EVAL_29__EVAL_31_addr;
  wire  _EVAL_29__EVAL_31_mask;
  wire  _EVAL_29__EVAL_31_en;
  wire  _EVAL_32;
  wire  _EVAL_33;
  wire  _EVAL_34;
  reg [3:0] _EVAL_35 [0:1];
  reg [31:0] _GEN_2;
  wire [3:0] _EVAL_35__EVAL_36_data;
  wire  _EVAL_35__EVAL_36_addr;
  wire [3:0] _EVAL_35__EVAL_37_data;
  wire  _EVAL_35__EVAL_37_addr;
  wire  _EVAL_35__EVAL_37_mask;
  wire  _EVAL_35__EVAL_37_en;
  reg  _EVAL_38;
  reg [31:0] _GEN_3;
  wire  _EVAL_39;
  reg [3:0] _EVAL_40 [0:1];
  reg [31:0] _GEN_4;
  wire [3:0] _EVAL_40__EVAL_41_data;
  wire  _EVAL_40__EVAL_41_addr;
  wire [3:0] _EVAL_40__EVAL_42_data;
  wire  _EVAL_40__EVAL_42_addr;
  wire  _EVAL_40__EVAL_42_mask;
  wire  _EVAL_40__EVAL_42_en;
  reg [29:0] _EVAL_43 [0:1];
  reg [31:0] _GEN_5;
  wire [29:0] _EVAL_43__EVAL_44_data;
  wire  _EVAL_43__EVAL_44_addr;
  wire [29:0] _EVAL_43__EVAL_45_data;
  wire  _EVAL_43__EVAL_45_addr;
  wire  _EVAL_43__EVAL_45_mask;
  wire  _EVAL_43__EVAL_45_en;
  wire  _EVAL_46;
  wire  _EVAL_47;
  reg  _EVAL_48;
  reg [31:0] _GEN_6;
  wire  _EVAL_49;
  wire  _EVAL_50;
  wire  _EVAL_51;
  wire  _EVAL_52;
  wire  _EVAL_53;
  wire  _EVAL_54;
  reg  _EVAL_55;
  reg [31:0] _GEN_7;
  wire  _EVAL_56;
  wire  _EVAL_57;
  wire  _EVAL_58;
  wire [1:0] _EVAL_59;
  reg [31:0] _EVAL_60 [0:1];
  reg [31:0] _GEN_8;
  wire [31:0] _EVAL_60__EVAL_61_data;
  wire  _EVAL_60__EVAL_61_addr;
  wire [31:0] _EVAL_60__EVAL_62_data;
  wire  _EVAL_60__EVAL_62_addr;
  wire  _EVAL_60__EVAL_62_mask;
  wire  _EVAL_60__EVAL_62_en;
  wire  _EVAL_63;
  wire [1:0] _EVAL_64;
  reg [2:0] _EVAL_65 [0:1];
  reg [31:0] _GEN_9;
  wire [2:0] _EVAL_65__EVAL_66_data;
  wire  _EVAL_65__EVAL_66_addr;
  wire [2:0] _EVAL_65__EVAL_67_data;
  wire  _EVAL_65__EVAL_67_addr;
  wire  _EVAL_65__EVAL_67_mask;
  wire  _EVAL_65__EVAL_67_en;
  assign _EVAL_0 = _EVAL_29__EVAL_30_data;
  assign _EVAL_1 = _EVAL_26;
  assign _EVAL_6 = _EVAL_21__EVAL_22_data;
  assign _EVAL_7 = _EVAL_33;
  assign _EVAL_11 = _EVAL_40__EVAL_41_data;
  assign _EVAL_12 = _EVAL_35__EVAL_36_data;
  assign _EVAL_14 = _EVAL_65__EVAL_66_data;
  assign _EVAL_15 = _EVAL_57;
  assign _EVAL_19 = _EVAL_60__EVAL_61_data;
  assign _EVAL_20 = _EVAL_43__EVAL_44_data;
  assign _EVAL_21__EVAL_22_addr = _EVAL_55;
  assign _EVAL_21__EVAL_22_data = _EVAL_21[_EVAL_21__EVAL_22_addr];
  assign _EVAL_21__EVAL_23_data = _EVAL_8;
  assign _EVAL_21__EVAL_23_addr = _EVAL_38;
  assign _EVAL_21__EVAL_23_mask = _EVAL_54;
  assign _EVAL_21__EVAL_23_en = _EVAL_54;
  assign _EVAL_24 = _EVAL_18 & _EVAL_15;
  assign _EVAL_25 = _EVAL_38 - _EVAL_55;
  assign _EVAL_26 = {_EVAL_49,_EVAL_28};
  assign _EVAL_27 = _EVAL_55 + 1'h1;
  assign _EVAL_28 = _EVAL_64[0:0];
  assign _EVAL_29__EVAL_30_addr = _EVAL_55;
  assign _EVAL_29__EVAL_30_data = _EVAL_29[_EVAL_29__EVAL_30_addr];
  assign _EVAL_29__EVAL_31_data = _EVAL_5;
  assign _EVAL_29__EVAL_31_addr = _EVAL_38;
  assign _EVAL_29__EVAL_31_mask = _EVAL_54;
  assign _EVAL_29__EVAL_31_en = _EVAL_54;
  assign _EVAL_32 = _EVAL_59[0:0];
  assign _EVAL_33 = _EVAL_39 == 1'h0;
  assign _EVAL_34 = _EVAL_63 ? _EVAL_54 : _EVAL_48;
  assign _EVAL_35__EVAL_36_addr = _EVAL_55;
  assign _EVAL_35__EVAL_36_data = _EVAL_35[_EVAL_35__EVAL_36_addr];
  assign _EVAL_35__EVAL_37_data = _EVAL_2;
  assign _EVAL_35__EVAL_37_addr = _EVAL_38;
  assign _EVAL_35__EVAL_37_mask = _EVAL_54;
  assign _EVAL_35__EVAL_37_en = _EVAL_54;
  assign _EVAL_39 = _EVAL_58 & _EVAL_48;
  assign _EVAL_40__EVAL_41_addr = _EVAL_55;
  assign _EVAL_40__EVAL_41_data = _EVAL_40[_EVAL_40__EVAL_41_addr];
  assign _EVAL_40__EVAL_42_data = _EVAL_10;
  assign _EVAL_40__EVAL_42_addr = _EVAL_38;
  assign _EVAL_40__EVAL_42_mask = _EVAL_54;
  assign _EVAL_40__EVAL_42_en = _EVAL_54;
  assign _EVAL_43__EVAL_44_addr = _EVAL_55;
  assign _EVAL_43__EVAL_44_data = _EVAL_43[_EVAL_43__EVAL_44_addr];
  assign _EVAL_43__EVAL_45_data = _EVAL_17;
  assign _EVAL_43__EVAL_45_addr = _EVAL_38;
  assign _EVAL_43__EVAL_45_mask = _EVAL_54;
  assign _EVAL_43__EVAL_45_en = _EVAL_54;
  assign _EVAL_46 = _EVAL_27[0:0];
  assign _EVAL_47 = _EVAL_54 ? _EVAL_32 : _EVAL_38;
  assign _EVAL_49 = _EVAL_48 & _EVAL_58;
  assign _EVAL_50 = _EVAL_24;
  assign _EVAL_51 = _EVAL_48 == 1'h0;
  assign _EVAL_52 = _EVAL_50 ? _EVAL_46 : _EVAL_55;
  assign _EVAL_53 = _EVAL_7 & _EVAL_9;
  assign _EVAL_54 = _EVAL_53;
  assign _EVAL_56 = _EVAL_58 & _EVAL_51;
  assign _EVAL_57 = _EVAL_56 == 1'h0;
  assign _EVAL_58 = _EVAL_38 == _EVAL_55;
  assign _EVAL_59 = _EVAL_38 + 1'h1;
  assign _EVAL_60__EVAL_61_addr = _EVAL_55;
  assign _EVAL_60__EVAL_61_data = _EVAL_60[_EVAL_60__EVAL_61_addr];
  assign _EVAL_60__EVAL_62_data = _EVAL_4;
  assign _EVAL_60__EVAL_62_addr = _EVAL_38;
  assign _EVAL_60__EVAL_62_mask = _EVAL_54;
  assign _EVAL_60__EVAL_62_en = _EVAL_54;
  assign _EVAL_63 = _EVAL_54 != _EVAL_50;
  assign _EVAL_64 = $unsigned(_EVAL_25);
  assign _EVAL_65__EVAL_66_addr = _EVAL_55;
  assign _EVAL_65__EVAL_66_data = _EVAL_65[_EVAL_65__EVAL_66_addr];
  assign _EVAL_65__EVAL_67_data = _EVAL_16;
  assign _EVAL_65__EVAL_67_addr = _EVAL_38;
  assign _EVAL_65__EVAL_67_mask = _EVAL_54;
  assign _EVAL_65__EVAL_67_en = _EVAL_54;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_21[initvar] = _GEN_0[2:0];
  `endif
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_29[initvar] = _GEN_1[3:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_35[initvar] = _GEN_2[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_38 = _GEN_3[0:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_40[initvar] = _GEN_4[3:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_43[initvar] = _GEN_5[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_48 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_55 = _GEN_7[0:0];
  `endif
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_60[initvar] = _GEN_8[31:0];
  `endif
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    _EVAL_65[initvar] = _GEN_9[2:0];
  `endif
  end
`endif
  always @(posedge _EVAL_3) begin
    if(_EVAL_21__EVAL_23_en & _EVAL_21__EVAL_23_mask) begin
      _EVAL_21[_EVAL_21__EVAL_23_addr] <= _EVAL_21__EVAL_23_data;
    end
    if(_EVAL_29__EVAL_31_en & _EVAL_29__EVAL_31_mask) begin
      _EVAL_29[_EVAL_29__EVAL_31_addr] <= _EVAL_29__EVAL_31_data;
    end
    if(_EVAL_35__EVAL_37_en & _EVAL_35__EVAL_37_mask) begin
      _EVAL_35[_EVAL_35__EVAL_37_addr] <= _EVAL_35__EVAL_37_data;
    end
    if (_EVAL_13) begin
      _EVAL_38 <= 1'h0;
    end else begin
      if (_EVAL_54) begin
        _EVAL_38 <= _EVAL_32;
      end
    end
    if(_EVAL_40__EVAL_42_en & _EVAL_40__EVAL_42_mask) begin
      _EVAL_40[_EVAL_40__EVAL_42_addr] <= _EVAL_40__EVAL_42_data;
    end
    if(_EVAL_43__EVAL_45_en & _EVAL_43__EVAL_45_mask) begin
      _EVAL_43[_EVAL_43__EVAL_45_addr] <= _EVAL_43__EVAL_45_data;
    end
    if (_EVAL_13) begin
      _EVAL_48 <= 1'h0;
    end else begin
      if (_EVAL_63) begin
        _EVAL_48 <= _EVAL_54;
      end
    end
    if (_EVAL_13) begin
      _EVAL_55 <= 1'h0;
    end else begin
      if (_EVAL_50) begin
        _EVAL_55 <= _EVAL_46;
      end
    end
    if(_EVAL_60__EVAL_62_en & _EVAL_60__EVAL_62_mask) begin
      _EVAL_60[_EVAL_60__EVAL_62_addr] <= _EVAL_60__EVAL_62_data;
    end
    if(_EVAL_65__EVAL_67_en & _EVAL_65__EVAL_67_mask) begin
      _EVAL_65[_EVAL_65__EVAL_67_addr] <= _EVAL_65__EVAL_67_data;
    end
  end
endmodule
