//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_97(
  input  [2:0]  _EVAL_0,
  input         _EVAL_1,
  output [1:0]  _EVAL_2,
  input  [63:0] _EVAL_3,
  input  [63:0] _EVAL_4,
  output [2:0]  _EVAL_5,
  output        _EVAL_6,
  input         _EVAL_7,
  output [63:0] _EVAL_8,
  input  [5:0]  _EVAL_9,
  input         _EVAL_10,
  input         _EVAL_11,
  output        _EVAL_12,
  output        _EVAL_13,
  input  [31:0] _EVAL_14,
  input  [2:0]  _EVAL_15,
  input  [39:0] _EVAL_16,
  output        _EVAL_17,
  input         _EVAL_18,
  output        _EVAL_19,
  output        _EVAL_20,
  input  [63:0] _EVAL_21,
  output [1:0]  _EVAL_22,
  output [7:0]  _EVAL_23,
  input         _EVAL_24,
  input  [2:0]  _EVAL_25,
  output [6:0]  _EVAL_26,
  input         _EVAL_27,
  output [1:0]  _EVAL_28,
  output [63:0] _EVAL_29,
  input         _EVAL_30,
  output        _EVAL_31,
  input  [31:0] _EVAL_32,
  input  [1:0]  _EVAL_33,
  output [39:0] _EVAL_34,
  output [2:0]  _EVAL_35,
  input  [2:0]  _EVAL_36,
  input         _EVAL_37,
  input         _EVAL_38,
  output [63:0] _EVAL_39,
  output [4:0]  _EVAL_40,
  output [5:0]  _EVAL_41,
  input         _EVAL_42,
  output        _EVAL_43,
  input         _EVAL_44,
  output [7:0]  _EVAL_45,
  input  [2:0]  _EVAL_46,
  input         _EVAL_47,
  input  [7:0]  _EVAL_48,
  input         _EVAL_49,
  input  [5:0]  _EVAL_50,
  input         _EVAL_51,
  input         _EVAL_52,
  output [2:0]  _EVAL_53,
  input  [63:0] _EVAL_54,
  input         _EVAL_55,
  output [5:0]  _EVAL_56,
  input  [4:0]  _EVAL_57,
  output [31:0] _EVAL_58,
  input         _EVAL_59,
  output        _EVAL_60,
  output [2:0]  _EVAL_61,
  input  [63:0] _EVAL_62,
  input         _EVAL_63,
  input         _EVAL_64,
  input  [6:0]  _EVAL_65,
  output [1:0]  _EVAL_66,
  output        _EVAL_67,
  input         _EVAL_68,
  output [63:0] _EVAL_69,
  input  [63:0] _EVAL_70,
  input  [1:0]  _EVAL_71,
  output        _EVAL_72,
  input         _EVAL_73,
  input         _EVAL_74,
  input         _EVAL_75
);
  reg [31:0] _EVAL_76;
  reg [31:0] _GEN_11;
  reg [1:0] _EVAL_77;
  reg [31:0] _GEN_12;
  wire  _EVAL_78;
  wire [1:0] _EVAL_79;
  wire  _EVAL_80;
  wire [3:0] _EVAL_81;
  wire  _EVAL_82;
  wire [2:0] _EVAL_83;
  wire [1:0] _EVAL_84;
  wire [31:0] _EVAL_85;
  wire [2:0] _EVAL_86;
  wire [5:0] _EVAL_87;
  wire [5:0] _EVAL_88;
  wire  _EVAL_89;
  wire [1:0] _EVAL_90;
  wire [2:0] _EVAL_91;
  wire [1:0] _EVAL_92;
  wire [2:0] _EVAL_93;
  wire  _EVAL_94;
  wire [2:0] _EVAL_95;
  wire [2:0] _EVAL_96;
  wire  _EVAL_97;
  wire [3:0] _EVAL_99;
  wire  _EVAL_100;
  wire  _EVAL_101;
  wire  _EVAL_102;
  wire [5:0] _EVAL_103;
  wire [3:0] _EVAL_104;
  wire  _EVAL_105;
  wire [2:0] _EVAL_106;
  wire [3:0] _EVAL_107;
  reg [1:0] _EVAL_108;
  reg [31:0] _GEN_13;
  wire [1:0] _EVAL_109;
  wire [2:0] _EVAL_110;
  wire [2:0] _EVAL_111;
  reg [2:0] _EVAL_112;
  reg [31:0] _GEN_14;
  wire  _EVAL_113;
  reg [7:0] _EVAL_115;
  reg [31:0] _GEN_15;
  wire [1:0] _EVAL_116;
  wire  _EVAL_117;
  wire [2:0] _EVAL_118;
  wire [3:0] _EVAL_119;
  wire  _EVAL_120;
  wire  _EVAL_121;
  wire  _EVAL_122;
  wire  _EVAL_123;
  wire [3:0] _EVAL_124;
  wire [1:0] _EVAL_125;
  wire [1:0] _EVAL_126;
  wire  _EVAL_127;
  wire [3:0] _EVAL_128;
  wire  _EVAL_129;
  wire [63:0] _EVAL_130;
  wire [2:0] _EVAL_131;
  wire [31:0] _EVAL_132;
  wire [2:0] _EVAL_133;
  wire  _EVAL_134;
  reg [2:0] _EVAL_135;
  reg [31:0] _GEN_16;
  wire [3:0] _EVAL_136;
  wire [6:0] _EVAL_137;
  wire  _EVAL_138;
  reg [63:0] _EVAL_139;
  reg [63:0] _GEN_17;
  wire [3:0] _EVAL_140;
  wire [1:0] _EVAL_141;
  wire  _EVAL_142;
  wire  _EVAL_143;
  wire [2:0] _EVAL_144;
  wire  _EVAL_145;
  wire  _EVAL_146;
  wire  _EVAL_147;
  wire  _EVAL_148;
  wire  _EVAL_149;
  wire  _EVAL_150;
  wire [1:0] _EVAL_151;
  wire [4:0] _EVAL_152;
  wire [4:0] _EVAL_153;
  wire  _EVAL_154;
  wire [63:0] _EVAL_155;
  wire  _EVAL_156;
  wire [7:0] _EVAL_157;
  wire  _EVAL_158;
  wire  _EVAL_159;
  wire [5:0] _EVAL_160;
  wire [1:0] _EVAL_161;
  wire [4:0] _EVAL_162;
  wire  _EVAL_163;
  wire  _EVAL_164;
  wire [39:0] _EVAL_165;
  wire  _EVAL_166;
  wire [63:0] _EVAL_167;
  wire [1:0] _EVAL_168;
  reg [5:0] _EVAL_169;
  reg [31:0] _GEN_18;
  wire [3:0] _EVAL_170;
  reg  _GEN_0;
  reg [31:0] _GEN_19;
  reg  _GEN_1;
  reg [31:0] _GEN_20;
  reg [1:0] _GEN_2;
  reg [31:0] _GEN_21;
  reg  _GEN_3;
  reg [31:0] _GEN_22;
  reg [5:0] _GEN_4;
  reg [31:0] _GEN_23;
  reg [63:0] _GEN_5;
  reg [63:0] _GEN_24;
  reg [2:0] _GEN_6;
  reg [31:0] _GEN_25;
  reg [31:0] _GEN_7;
  reg [31:0] _GEN_26;
  reg [1:0] _GEN_8;
  reg [31:0] _GEN_27;
  reg [63:0] _GEN_9;
  reg [63:0] _GEN_28;
  reg [7:0] _GEN_10;
  reg [31:0] _GEN_29;
  assign _EVAL_2 = _EVAL_92;
  assign _EVAL_5 = _EVAL_144;
  assign _EVAL_6 = 1'h1;
  assign _EVAL_8 = _EVAL_155;
  assign _EVAL_12 = _EVAL_166;
  assign _EVAL_13 = _EVAL_147;
  assign _EVAL_17 = 1'h0;
  assign _EVAL_19 = 1'h1;
  assign _EVAL_20 = _EVAL_122;
  assign _EVAL_22 = _GEN_2;
  assign _EVAL_23 = _GEN_10;
  assign _EVAL_26 = _EVAL_137;
  assign _EVAL_28 = _EVAL_84;
  assign _EVAL_29 = _EVAL_139;
  assign _EVAL_31 = _EVAL_82;
  assign _EVAL_34 = _EVAL_165;
  assign _EVAL_35 = _GEN_6;
  assign _EVAL_39 = _GEN_5;
  assign _EVAL_40 = _EVAL_153;
  assign _EVAL_41 = _GEN_4;
  assign _EVAL_43 = _EVAL_121;
  assign _EVAL_45 = _EVAL_115;
  assign _EVAL_53 = _EVAL_86;
  assign _EVAL_56 = _EVAL_103;
  assign _EVAL_58 = _GEN_7;
  assign _EVAL_60 = 1'h0;
  assign _EVAL_61 = _EVAL_93;
  assign _EVAL_66 = _GEN_8;
  assign _EVAL_67 = _EVAL_150;
  assign _EVAL_69 = _EVAL_130;
  assign _EVAL_72 = 1'h0;
  assign _EVAL_78 = 1'h0;
  assign _EVAL_79 = _EVAL_146 ? 2'h1 : _EVAL_116;
  assign _EVAL_80 = _EVAL_13 & _EVAL_38;
  assign _EVAL_81 = _EVAL_102 ? 4'h9 : _EVAL_170;
  assign _EVAL_82 = _EVAL_27 | _EVAL_154;
  assign _EVAL_83 = _EVAL_96;
  assign _EVAL_84 = _EVAL_164 ? _EVAL_141 : _EVAL_125;
  assign _EVAL_85 = _EVAL_80 ? _EVAL_32 : _EVAL_76;
  assign _EVAL_86 = _EVAL_164 ? _EVAL_133 : _EVAL_83;
  assign _EVAL_87 = _EVAL_169;
  assign _EVAL_88 = _EVAL_169;
  assign _EVAL_89 = _EVAL_44 & _EVAL_31;
  assign _EVAL_90 = _EVAL_77;
  assign _EVAL_91 = 3'h1;
  assign _EVAL_92 = _EVAL_164 ? _EVAL_90 : _EVAL_168;
  assign _EVAL_93 = {{1'd0}, _EVAL_126};
  assign _EVAL_94 = _GEN_1;
  assign _EVAL_95 = _EVAL_80 ? _EVAL_36 : _EVAL_112;
  assign _EVAL_96 = _EVAL_76[2:0];
  assign _EVAL_97 = 3'h1 == _EVAL_131;
  assign _EVAL_99 = _EVAL_123 ? 4'h8 : {{3'd0}, _EVAL_94};
  assign _EVAL_100 = _EVAL_38 & _EVAL_138;
  assign _EVAL_101 = _EVAL_135 == 3'h1;
  assign _EVAL_102 = 3'h0 == _EVAL_131;
  assign _EVAL_103 = _EVAL_164 ? _EVAL_87 : _EVAL_88;
  assign _EVAL_104 = _EVAL_102 ? 4'hc : _EVAL_128;
  assign _EVAL_105 = _EVAL_108 == 2'h2;
  assign _EVAL_106 = _EVAL_148 ? 3'h4 : {{2'd0}, _EVAL_129};
  assign _EVAL_107 = _EVAL_143 ? _EVAL_104 : _EVAL_136;
  assign _EVAL_109 = _EVAL_80 ? _EVAL_33 : _EVAL_77;
  assign _EVAL_110 = _EVAL_80 ? _EVAL_0 : _EVAL_135;
  assign _EVAL_111 = 3'h0;
  assign _EVAL_113 = 3'h2 == _EVAL_131;
  assign _EVAL_116 = _EVAL_74 ? 2'h2 : _EVAL_161;
  assign _EVAL_117 = _GEN_3;
  assign _EVAL_118 = _EVAL_105 ? _EVAL_135 : _EVAL_0;
  assign _EVAL_119 = _EVAL_113 ? 4'he : _EVAL_124;
  assign _EVAL_120 = 1'h0;
  assign _EVAL_121 = 1'h1;
  assign _EVAL_122 = _EVAL_100 | _EVAL_105;
  assign _EVAL_123 = 3'h4 == _EVAL_131;
  assign _EVAL_124 = _EVAL_148 ? 4'hf : _EVAL_99;
  assign _EVAL_125 = 2'h0;
  assign _EVAL_126 = _EVAL_105 ? _EVAL_77 : _EVAL_33;
  assign _EVAL_127 = 3'h4 == _EVAL_118;
  assign _EVAL_128 = _EVAL_97 ? 4'hd : _EVAL_119;
  assign _EVAL_129 = _GEN_0;
  assign _EVAL_130 = _EVAL_27 ? _EVAL_4 : _EVAL_139;
  assign _EVAL_131 = _EVAL_105 ? _EVAL_112 : _EVAL_36;
  assign _EVAL_132 = _EVAL_105 ? _EVAL_76 : _EVAL_32;
  assign _EVAL_133 = _EVAL_96;
  assign _EVAL_134 = 1'h0;
  assign _EVAL_136 = _EVAL_142 ? _EVAL_81 : {{3'd0}, _EVAL_158};
  assign _EVAL_137 = 7'h0;
  assign _EVAL_138 = _EVAL_145 | _EVAL_89;
  assign _EVAL_140 = _EVAL_113 ? 4'hb : {{1'd0}, _EVAL_106};
  assign _EVAL_141 = 2'h0;
  assign _EVAL_142 = 3'h3 == _EVAL_118;
  assign _EVAL_143 = 3'h2 == _EVAL_118;
  assign _EVAL_144 = _EVAL_164 ? _EVAL_111 : _EVAL_91;
  assign _EVAL_145 = _EVAL_108 == 2'h0;
  assign _EVAL_146 = _EVAL_47 & _EVAL_20;
  assign _EVAL_147 = _EVAL_47 & _EVAL_138;
  assign _EVAL_148 = 3'h3 == _EVAL_131;
  assign _EVAL_149 = _EVAL_135 == 3'h0;
  assign _EVAL_150 = _EVAL_164 ? _EVAL_134 : _EVAL_120;
  assign _EVAL_151 = _EVAL_27 ? 2'h3 : _EVAL_108;
  assign _EVAL_152 = _EVAL_159 ? 5'h11 : {{1'd0}, _EVAL_107};
  assign _EVAL_153 = _EVAL_162;
  assign _EVAL_154 = _EVAL_108 == 2'h3;
  assign _EVAL_155 = _GEN_9;
  assign _EVAL_156 = 1'h0;
  assign _EVAL_157 = _EVAL_80 ? _EVAL_48 : _EVAL_115;
  assign _EVAL_158 = _EVAL_127 ? 1'h0 : _EVAL_117;
  assign _EVAL_159 = 3'h1 == _EVAL_118;
  assign _EVAL_160 = _EVAL_80 ? _EVAL_9 : _EVAL_169;
  assign _EVAL_161 = _EVAL_89 ? 2'h0 : _EVAL_151;
  assign _EVAL_162 = _EVAL_163 ? 5'h1 : _EVAL_152;
  assign _EVAL_163 = 3'h0 == _EVAL_118;
  assign _EVAL_164 = _EVAL_149 | _EVAL_101;
  assign _EVAL_165 = {{8'd0}, _EVAL_132};
  assign _EVAL_166 = _EVAL_164 ? _EVAL_78 : _EVAL_156;
  assign _EVAL_167 = _EVAL_80 ? _EVAL_54 : _EVAL_130;
  assign _EVAL_168 = _EVAL_77;
  assign _EVAL_170 = _EVAL_97 ? 4'ha : _EVAL_140;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_11 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_76 = _GEN_11[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_12 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_77 = _GEN_12[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_13 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_108 = _GEN_13[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_14 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_112 = _GEN_14[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_115 = _GEN_15[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_135 = _GEN_16[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_17 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_139 = _GEN_17[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_18 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_169 = _GEN_18[5:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_19 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_0 = _GEN_19[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_20 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_20[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_21[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_22 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_22[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_23[5:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_24 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_24[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_25[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_26[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_27[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_28[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_29[7:0];
  `endif
  end
`endif
  always @(posedge _EVAL_30) begin
    if (_EVAL_80) begin
      _EVAL_76 <= _EVAL_32;
    end
    if (_EVAL_80) begin
      _EVAL_77 <= _EVAL_33;
    end
    if (_EVAL_11) begin
      _EVAL_108 <= 2'h0;
    end else begin
      if (_EVAL_146) begin
        _EVAL_108 <= 2'h1;
      end else begin
        if (_EVAL_74) begin
          _EVAL_108 <= 2'h2;
        end else begin
          if (_EVAL_89) begin
            _EVAL_108 <= 2'h0;
          end else begin
            if (_EVAL_27) begin
              _EVAL_108 <= 2'h3;
            end
          end
        end
      end
    end
    if (_EVAL_80) begin
      _EVAL_112 <= _EVAL_36;
    end
    if (_EVAL_80) begin
      _EVAL_115 <= _EVAL_48;
    end
    if (_EVAL_80) begin
      _EVAL_135 <= _EVAL_0;
    end
    if (_EVAL_80) begin
      _EVAL_139 <= _EVAL_54;
    end else begin
      if (_EVAL_27) begin
        _EVAL_139 <= _EVAL_4;
      end
    end
    if (_EVAL_80) begin
      _EVAL_169 <= _EVAL_9;
    end
  end
endmodule
