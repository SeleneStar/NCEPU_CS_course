//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module ECoreplexIPAllPortRAMTestHarness(
  input   clock,
  input   reset,
  output  io_success
);
  wire  system_clock;
  wire  system_reset;
  wire  system_io_periph_port_tl_0_a_ready;
  wire  system_io_periph_port_tl_0_a_valid;
  wire [2:0] system_io_periph_port_tl_0_a_bits_opcode;
  wire [2:0] system_io_periph_port_tl_0_a_bits_param;
  wire [2:0] system_io_periph_port_tl_0_a_bits_size;
  wire  system_io_periph_port_tl_0_a_bits_source;
  wire [29:0] system_io_periph_port_tl_0_a_bits_address;
  wire [3:0] system_io_periph_port_tl_0_a_bits_mask;
  wire [31:0] system_io_periph_port_tl_0_a_bits_data;
  wire  system_io_periph_port_tl_0_b_ready;
  wire  system_io_periph_port_tl_0_b_valid;
  wire [2:0] system_io_periph_port_tl_0_b_bits_opcode;
  wire [1:0] system_io_periph_port_tl_0_b_bits_param;
  wire [2:0] system_io_periph_port_tl_0_b_bits_size;
  wire  system_io_periph_port_tl_0_b_bits_source;
  wire [29:0] system_io_periph_port_tl_0_b_bits_address;
  wire [3:0] system_io_periph_port_tl_0_b_bits_mask;
  wire [31:0] system_io_periph_port_tl_0_b_bits_data;
  wire  system_io_periph_port_tl_0_c_ready;
  wire  system_io_periph_port_tl_0_c_valid;
  wire [2:0] system_io_periph_port_tl_0_c_bits_opcode;
  wire [2:0] system_io_periph_port_tl_0_c_bits_param;
  wire [2:0] system_io_periph_port_tl_0_c_bits_size;
  wire  system_io_periph_port_tl_0_c_bits_source;
  wire [29:0] system_io_periph_port_tl_0_c_bits_address;
  wire [31:0] system_io_periph_port_tl_0_c_bits_data;
  wire  system_io_periph_port_tl_0_c_bits_error;
  wire  system_io_periph_port_tl_0_d_ready;
  wire  system_io_periph_port_tl_0_d_valid;
  wire [2:0] system_io_periph_port_tl_0_d_bits_opcode;
  wire [1:0] system_io_periph_port_tl_0_d_bits_param;
  wire [2:0] system_io_periph_port_tl_0_d_bits_size;
  wire  system_io_periph_port_tl_0_d_bits_source;
  wire  system_io_periph_port_tl_0_d_bits_sink;
  wire [1:0] system_io_periph_port_tl_0_d_bits_addr_lo;
  wire [31:0] system_io_periph_port_tl_0_d_bits_data;
  wire  system_io_periph_port_tl_0_d_bits_error;
  wire  system_io_periph_port_tl_0_e_ready;
  wire  system_io_periph_port_tl_0_e_valid;
  wire  system_io_periph_port_tl_0_e_bits_sink;
  wire  system_io_jtag_TCK;
  wire  system_io_jtag_TMS;
  wire  system_io_jtag_TDI;
  wire  system_io_jtag_TDO_data;
  wire  system_io_jtag_TDO_driven;
  wire  system_io_jtag_reset;
  wire [10:0] system_io_jtag_mfr_id;
  wire  system_io_ndreset;
  wire  system_io_dmactive;
  wire  system_io_coreClock;
  wire  system_io_rtcToggle;
  wire [31:0] system_io_resetVector;
  wire [510:0] system_io_global_interrupts;
  wire [15:0] system_io_local_interrupts_0;
  wire  Pow2ClockDivider_clock;
  wire  Pow2ClockDivider_reset;
  wire  Pow2ClockDivider_io_clock_out;
  reg [4:0] _T_7;
  reg [31:0] _GEN_0;
  wire [5:0] _T_9;
  wire [4:0] _T_10;
  wire  _T_12;
  wire  _T_14;
  wire  testRAM_clock;
  wire  testRAM_reset;
  wire  testRAM_io_tl_0_a_ready;
  wire  testRAM_io_tl_0_a_valid;
  wire [2:0] testRAM_io_tl_0_a_bits_opcode;
  wire [2:0] testRAM_io_tl_0_a_bits_param;
  wire [2:0] testRAM_io_tl_0_a_bits_size;
  wire  testRAM_io_tl_0_a_bits_source;
  wire [29:0] testRAM_io_tl_0_a_bits_address;
  wire [3:0] testRAM_io_tl_0_a_bits_mask;
  wire [31:0] testRAM_io_tl_0_a_bits_data;
  wire  testRAM_io_tl_0_b_ready;
  wire  testRAM_io_tl_0_b_valid;
  wire [2:0] testRAM_io_tl_0_b_bits_opcode;
  wire [1:0] testRAM_io_tl_0_b_bits_param;
  wire [2:0] testRAM_io_tl_0_b_bits_size;
  wire  testRAM_io_tl_0_b_bits_source;
  wire [29:0] testRAM_io_tl_0_b_bits_address;
  wire [3:0] testRAM_io_tl_0_b_bits_mask;
  wire [31:0] testRAM_io_tl_0_b_bits_data;
  wire  testRAM_io_tl_0_c_ready;
  wire  testRAM_io_tl_0_c_valid;
  wire [2:0] testRAM_io_tl_0_c_bits_opcode;
  wire [2:0] testRAM_io_tl_0_c_bits_param;
  wire [2:0] testRAM_io_tl_0_c_bits_size;
  wire  testRAM_io_tl_0_c_bits_source;
  wire [29:0] testRAM_io_tl_0_c_bits_address;
  wire [31:0] testRAM_io_tl_0_c_bits_data;
  wire  testRAM_io_tl_0_c_bits_error;
  wire  testRAM_io_tl_0_d_ready;
  wire  testRAM_io_tl_0_d_valid;
  wire [2:0] testRAM_io_tl_0_d_bits_opcode;
  wire [1:0] testRAM_io_tl_0_d_bits_param;
  wire [2:0] testRAM_io_tl_0_d_bits_size;
  wire  testRAM_io_tl_0_d_bits_source;
  wire  testRAM_io_tl_0_d_bits_sink;
  wire [1:0] testRAM_io_tl_0_d_bits_addr_lo;
  wire [31:0] testRAM_io_tl_0_d_bits_data;
  wire  testRAM_io_tl_0_d_bits_error;
  wire  testRAM_io_tl_0_e_ready;
  wire  testRAM_io_tl_0_e_valid;
  wire  testRAM_io_tl_0_e_bits_sink;
  E51_ECoreplexIP_system system (
    .clock(system_clock),
    .reset(system_reset),
    .io_periph_port_tl_0_a_ready(system_io_periph_port_tl_0_a_ready),
    .io_periph_port_tl_0_a_valid(system_io_periph_port_tl_0_a_valid),
    .io_periph_port_tl_0_a_bits_opcode(system_io_periph_port_tl_0_a_bits_opcode),
    .io_periph_port_tl_0_a_bits_param(system_io_periph_port_tl_0_a_bits_param),
    .io_periph_port_tl_0_a_bits_size(system_io_periph_port_tl_0_a_bits_size),
    .io_periph_port_tl_0_a_bits_source(system_io_periph_port_tl_0_a_bits_source),
    .io_periph_port_tl_0_a_bits_address(system_io_periph_port_tl_0_a_bits_address),
    .io_periph_port_tl_0_a_bits_mask(system_io_periph_port_tl_0_a_bits_mask),
    .io_periph_port_tl_0_a_bits_data(system_io_periph_port_tl_0_a_bits_data),
    .io_periph_port_tl_0_b_ready(system_io_periph_port_tl_0_b_ready),
    .io_periph_port_tl_0_b_valid(system_io_periph_port_tl_0_b_valid),
    .io_periph_port_tl_0_b_bits_opcode(system_io_periph_port_tl_0_b_bits_opcode),
    .io_periph_port_tl_0_b_bits_param(system_io_periph_port_tl_0_b_bits_param),
    .io_periph_port_tl_0_b_bits_size(system_io_periph_port_tl_0_b_bits_size),
    .io_periph_port_tl_0_b_bits_source(system_io_periph_port_tl_0_b_bits_source),
    .io_periph_port_tl_0_b_bits_address(system_io_periph_port_tl_0_b_bits_address),
    .io_periph_port_tl_0_b_bits_mask(system_io_periph_port_tl_0_b_bits_mask),
    .io_periph_port_tl_0_b_bits_data(system_io_periph_port_tl_0_b_bits_data),
    .io_periph_port_tl_0_c_ready(system_io_periph_port_tl_0_c_ready),
    .io_periph_port_tl_0_c_valid(system_io_periph_port_tl_0_c_valid),
    .io_periph_port_tl_0_c_bits_opcode(system_io_periph_port_tl_0_c_bits_opcode),
    .io_periph_port_tl_0_c_bits_param(system_io_periph_port_tl_0_c_bits_param),
    .io_periph_port_tl_0_c_bits_size(system_io_periph_port_tl_0_c_bits_size),
    .io_periph_port_tl_0_c_bits_source(system_io_periph_port_tl_0_c_bits_source),
    .io_periph_port_tl_0_c_bits_address(system_io_periph_port_tl_0_c_bits_address),
    .io_periph_port_tl_0_c_bits_data(system_io_periph_port_tl_0_c_bits_data),
    .io_periph_port_tl_0_c_bits_error(system_io_periph_port_tl_0_c_bits_error),
    .io_periph_port_tl_0_d_ready(system_io_periph_port_tl_0_d_ready),
    .io_periph_port_tl_0_d_valid(system_io_periph_port_tl_0_d_valid),
    .io_periph_port_tl_0_d_bits_opcode(system_io_periph_port_tl_0_d_bits_opcode),
    .io_periph_port_tl_0_d_bits_param(system_io_periph_port_tl_0_d_bits_param),
    .io_periph_port_tl_0_d_bits_size(system_io_periph_port_tl_0_d_bits_size),
    .io_periph_port_tl_0_d_bits_source(system_io_periph_port_tl_0_d_bits_source),
    .io_periph_port_tl_0_d_bits_sink(system_io_periph_port_tl_0_d_bits_sink),
    .io_periph_port_tl_0_d_bits_addr_lo(system_io_periph_port_tl_0_d_bits_addr_lo),
    .io_periph_port_tl_0_d_bits_data(system_io_periph_port_tl_0_d_bits_data),
    .io_periph_port_tl_0_d_bits_error(system_io_periph_port_tl_0_d_bits_error),
    .io_periph_port_tl_0_e_ready(system_io_periph_port_tl_0_e_ready),
    .io_periph_port_tl_0_e_valid(system_io_periph_port_tl_0_e_valid),
    .io_periph_port_tl_0_e_bits_sink(system_io_periph_port_tl_0_e_bits_sink),
    .io_jtag_TCK(system_io_jtag_TCK),
    .io_jtag_TMS(system_io_jtag_TMS),
    .io_jtag_TDI(system_io_jtag_TDI),
    .io_jtag_TDO_data(system_io_jtag_TDO_data),
    .io_jtag_TDO_driven(system_io_jtag_TDO_driven),
    .io_jtag_reset(system_io_jtag_reset),
    .io_jtag_mfr_id(system_io_jtag_mfr_id),
    .io_ndreset(system_io_ndreset),
    .io_dmactive(system_io_dmactive),
    .io_coreClock(system_io_coreClock),
    .io_rtcToggle(system_io_rtcToggle),
    .io_resetVector(system_io_resetVector),
    .io_global_interrupts(system_io_global_interrupts),
    .io_local_interrupts_0(system_io_local_interrupts_0)
  );
  Pow2ClockDivider Pow2ClockDivider (
    .clock(Pow2ClockDivider_clock),
    .reset(Pow2ClockDivider_reset),
    .io_clock_out(Pow2ClockDivider_io_clock_out)
  );
  TLPortRAMSlave_testRAM testRAM (
    .clock(testRAM_clock),
    .reset(testRAM_reset),
    .io_tl_0_a_ready(testRAM_io_tl_0_a_ready),
    .io_tl_0_a_valid(testRAM_io_tl_0_a_valid),
    .io_tl_0_a_bits_opcode(testRAM_io_tl_0_a_bits_opcode),
    .io_tl_0_a_bits_param(testRAM_io_tl_0_a_bits_param),
    .io_tl_0_a_bits_size(testRAM_io_tl_0_a_bits_size),
    .io_tl_0_a_bits_source(testRAM_io_tl_0_a_bits_source),
    .io_tl_0_a_bits_address(testRAM_io_tl_0_a_bits_address),
    .io_tl_0_a_bits_mask(testRAM_io_tl_0_a_bits_mask),
    .io_tl_0_a_bits_data(testRAM_io_tl_0_a_bits_data),
    .io_tl_0_b_ready(testRAM_io_tl_0_b_ready),
    .io_tl_0_b_valid(testRAM_io_tl_0_b_valid),
    .io_tl_0_b_bits_opcode(testRAM_io_tl_0_b_bits_opcode),
    .io_tl_0_b_bits_param(testRAM_io_tl_0_b_bits_param),
    .io_tl_0_b_bits_size(testRAM_io_tl_0_b_bits_size),
    .io_tl_0_b_bits_source(testRAM_io_tl_0_b_bits_source),
    .io_tl_0_b_bits_address(testRAM_io_tl_0_b_bits_address),
    .io_tl_0_b_bits_mask(testRAM_io_tl_0_b_bits_mask),
    .io_tl_0_b_bits_data(testRAM_io_tl_0_b_bits_data),
    .io_tl_0_c_ready(testRAM_io_tl_0_c_ready),
    .io_tl_0_c_valid(testRAM_io_tl_0_c_valid),
    .io_tl_0_c_bits_opcode(testRAM_io_tl_0_c_bits_opcode),
    .io_tl_0_c_bits_param(testRAM_io_tl_0_c_bits_param),
    .io_tl_0_c_bits_size(testRAM_io_tl_0_c_bits_size),
    .io_tl_0_c_bits_source(testRAM_io_tl_0_c_bits_source),
    .io_tl_0_c_bits_address(testRAM_io_tl_0_c_bits_address),
    .io_tl_0_c_bits_data(testRAM_io_tl_0_c_bits_data),
    .io_tl_0_c_bits_error(testRAM_io_tl_0_c_bits_error),
    .io_tl_0_d_ready(testRAM_io_tl_0_d_ready),
    .io_tl_0_d_valid(testRAM_io_tl_0_d_valid),
    .io_tl_0_d_bits_opcode(testRAM_io_tl_0_d_bits_opcode),
    .io_tl_0_d_bits_param(testRAM_io_tl_0_d_bits_param),
    .io_tl_0_d_bits_size(testRAM_io_tl_0_d_bits_size),
    .io_tl_0_d_bits_source(testRAM_io_tl_0_d_bits_source),
    .io_tl_0_d_bits_sink(testRAM_io_tl_0_d_bits_sink),
    .io_tl_0_d_bits_addr_lo(testRAM_io_tl_0_d_bits_addr_lo),
    .io_tl_0_d_bits_data(testRAM_io_tl_0_d_bits_data),
    .io_tl_0_d_bits_error(testRAM_io_tl_0_d_bits_error),
    .io_tl_0_e_ready(testRAM_io_tl_0_e_ready),
    .io_tl_0_e_valid(testRAM_io_tl_0_e_valid),
    .io_tl_0_e_bits_sink(testRAM_io_tl_0_e_bits_sink)
  );
  assign io_success = 1'h0;
  assign system_clock = Pow2ClockDivider_io_clock_out;
  assign system_reset = reset;
  assign system_io_periph_port_tl_0_a_ready = testRAM_io_tl_0_a_ready;
  assign system_io_periph_port_tl_0_b_valid = testRAM_io_tl_0_b_valid;
  assign system_io_periph_port_tl_0_b_bits_opcode = testRAM_io_tl_0_b_bits_opcode;
  assign system_io_periph_port_tl_0_b_bits_param = testRAM_io_tl_0_b_bits_param;
  assign system_io_periph_port_tl_0_b_bits_size = testRAM_io_tl_0_b_bits_size;
  assign system_io_periph_port_tl_0_b_bits_source = testRAM_io_tl_0_b_bits_source;
  assign system_io_periph_port_tl_0_b_bits_address = testRAM_io_tl_0_b_bits_address;
  assign system_io_periph_port_tl_0_b_bits_mask = testRAM_io_tl_0_b_bits_mask;
  assign system_io_periph_port_tl_0_b_bits_data = testRAM_io_tl_0_b_bits_data;
  assign system_io_periph_port_tl_0_c_ready = testRAM_io_tl_0_c_ready;
  assign system_io_periph_port_tl_0_d_valid = testRAM_io_tl_0_d_valid;
  assign system_io_periph_port_tl_0_d_bits_opcode = testRAM_io_tl_0_d_bits_opcode;
  assign system_io_periph_port_tl_0_d_bits_param = testRAM_io_tl_0_d_bits_param;
  assign system_io_periph_port_tl_0_d_bits_size = testRAM_io_tl_0_d_bits_size;
  assign system_io_periph_port_tl_0_d_bits_source = testRAM_io_tl_0_d_bits_source;
  assign system_io_periph_port_tl_0_d_bits_sink = testRAM_io_tl_0_d_bits_sink;
  assign system_io_periph_port_tl_0_d_bits_addr_lo = testRAM_io_tl_0_d_bits_addr_lo;
  assign system_io_periph_port_tl_0_d_bits_data = testRAM_io_tl_0_d_bits_data;
  assign system_io_periph_port_tl_0_d_bits_error = testRAM_io_tl_0_d_bits_error;
  assign system_io_periph_port_tl_0_e_ready = testRAM_io_tl_0_e_ready;
  assign system_io_jtag_TCK = _T_14;
  assign system_io_jtag_TMS = 1'h1;
  assign system_io_jtag_TDI = 1'h1;
  assign system_io_jtag_reset = 1'h1;
  assign system_io_jtag_mfr_id = 11'h0;
  assign system_io_coreClock = clock;
  assign system_io_rtcToggle = _T_12;
  assign system_io_resetVector = 32'h20000000;
  assign system_io_global_interrupts = 511'h0;
  assign system_io_local_interrupts_0 = 16'h0;
  assign Pow2ClockDivider_clock = clock;
  assign Pow2ClockDivider_reset = reset;
  assign _T_9 = _T_7 + 5'h1;
  assign _T_10 = _T_9[4:0];
  assign _T_12 = _T_7 == 5'h0;
  assign _T_14 = $unsigned(1'h1);
  assign testRAM_clock = Pow2ClockDivider_io_clock_out;
  assign testRAM_reset = reset;
  assign testRAM_io_tl_0_a_valid = system_io_periph_port_tl_0_a_valid;
  assign testRAM_io_tl_0_a_bits_opcode = system_io_periph_port_tl_0_a_bits_opcode;
  assign testRAM_io_tl_0_a_bits_param = system_io_periph_port_tl_0_a_bits_param;
  assign testRAM_io_tl_0_a_bits_size = system_io_periph_port_tl_0_a_bits_size;
  assign testRAM_io_tl_0_a_bits_source = system_io_periph_port_tl_0_a_bits_source;
  assign testRAM_io_tl_0_a_bits_address = system_io_periph_port_tl_0_a_bits_address;
  assign testRAM_io_tl_0_a_bits_mask = system_io_periph_port_tl_0_a_bits_mask;
  assign testRAM_io_tl_0_a_bits_data = system_io_periph_port_tl_0_a_bits_data;
  assign testRAM_io_tl_0_b_ready = system_io_periph_port_tl_0_b_ready;
  assign testRAM_io_tl_0_c_valid = system_io_periph_port_tl_0_c_valid;
  assign testRAM_io_tl_0_c_bits_opcode = system_io_periph_port_tl_0_c_bits_opcode;
  assign testRAM_io_tl_0_c_bits_param = system_io_periph_port_tl_0_c_bits_param;
  assign testRAM_io_tl_0_c_bits_size = system_io_periph_port_tl_0_c_bits_size;
  assign testRAM_io_tl_0_c_bits_source = system_io_periph_port_tl_0_c_bits_source;
  assign testRAM_io_tl_0_c_bits_address = system_io_periph_port_tl_0_c_bits_address;
  assign testRAM_io_tl_0_c_bits_data = system_io_periph_port_tl_0_c_bits_data;
  assign testRAM_io_tl_0_c_bits_error = system_io_periph_port_tl_0_c_bits_error;
  assign testRAM_io_tl_0_d_ready = system_io_periph_port_tl_0_d_ready;
  assign testRAM_io_tl_0_e_valid = system_io_periph_port_tl_0_e_valid;
  assign testRAM_io_tl_0_e_bits_sink = system_io_periph_port_tl_0_e_bits_sink;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_7 = _GEN_0[4:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      _T_7 <= 5'h0;
    end else begin
      _T_7 <= _T_10;
    end
  end
endmodule
