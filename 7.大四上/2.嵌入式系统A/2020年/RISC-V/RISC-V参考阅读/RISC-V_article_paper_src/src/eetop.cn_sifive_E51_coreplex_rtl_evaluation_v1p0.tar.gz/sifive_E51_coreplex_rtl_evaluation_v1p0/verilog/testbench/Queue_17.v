//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module Queue_17(
  input         clock,
  input         reset,
  output        io_enq_ready,
  input         io_enq_valid,
  input  [2:0]  io_enq_bits_opcode,
  input  [1:0]  io_enq_bits_param,
  input  [1:0]  io_enq_bits_size,
  input  [3:0]  io_enq_bits_source,
  input         io_enq_bits_sink,
  input  [1:0]  io_enq_bits_addr_lo,
  input  [31:0] io_enq_bits_data,
  input         io_enq_bits_error,
  input         io_deq_ready,
  output        io_deq_valid,
  output [2:0]  io_deq_bits_opcode,
  output [1:0]  io_deq_bits_param,
  output [1:0]  io_deq_bits_size,
  output [3:0]  io_deq_bits_source,
  output        io_deq_bits_sink,
  output [1:0]  io_deq_bits_addr_lo,
  output [31:0] io_deq_bits_data,
  output        io_deq_bits_error,
  output [1:0]  io_count
);
  reg [2:0] ram_opcode [0:1];
  reg [31:0] _GEN_0;
  wire [2:0] ram_opcode__T_43_data;
  wire  ram_opcode__T_43_addr;
  wire [2:0] ram_opcode__T_29_data;
  wire  ram_opcode__T_29_addr;
  wire  ram_opcode__T_29_mask;
  wire  ram_opcode__T_29_en;
  reg [1:0] ram_param [0:1];
  reg [31:0] _GEN_1;
  wire [1:0] ram_param__T_43_data;
  wire  ram_param__T_43_addr;
  wire [1:0] ram_param__T_29_data;
  wire  ram_param__T_29_addr;
  wire  ram_param__T_29_mask;
  wire  ram_param__T_29_en;
  reg [1:0] ram_size [0:1];
  reg [31:0] _GEN_2;
  wire [1:0] ram_size__T_43_data;
  wire  ram_size__T_43_addr;
  wire [1:0] ram_size__T_29_data;
  wire  ram_size__T_29_addr;
  wire  ram_size__T_29_mask;
  wire  ram_size__T_29_en;
  reg [3:0] ram_source [0:1];
  reg [31:0] _GEN_3;
  wire [3:0] ram_source__T_43_data;
  wire  ram_source__T_43_addr;
  wire [3:0] ram_source__T_29_data;
  wire  ram_source__T_29_addr;
  wire  ram_source__T_29_mask;
  wire  ram_source__T_29_en;
  reg  ram_sink [0:1];
  reg [31:0] _GEN_4;
  wire  ram_sink__T_43_data;
  wire  ram_sink__T_43_addr;
  wire  ram_sink__T_29_data;
  wire  ram_sink__T_29_addr;
  wire  ram_sink__T_29_mask;
  wire  ram_sink__T_29_en;
  reg [1:0] ram_addr_lo [0:1];
  reg [31:0] _GEN_5;
  wire [1:0] ram_addr_lo__T_43_data;
  wire  ram_addr_lo__T_43_addr;
  wire [1:0] ram_addr_lo__T_29_data;
  wire  ram_addr_lo__T_29_addr;
  wire  ram_addr_lo__T_29_mask;
  wire  ram_addr_lo__T_29_en;
  reg [31:0] ram_data [0:1];
  reg [31:0] _GEN_6;
  wire [31:0] ram_data__T_43_data;
  wire  ram_data__T_43_addr;
  wire [31:0] ram_data__T_29_data;
  wire  ram_data__T_29_addr;
  wire  ram_data__T_29_mask;
  wire  ram_data__T_29_en;
  reg  ram_error [0:1];
  reg [31:0] _GEN_7;
  wire  ram_error__T_43_data;
  wire  ram_error__T_43_addr;
  wire  ram_error__T_29_data;
  wire  ram_error__T_29_addr;
  wire  ram_error__T_29_mask;
  wire  ram_error__T_29_en;
  reg  value;
  reg [31:0] _GEN_8;
  reg  value_1;
  reg [31:0] _GEN_9;
  reg  maybe_full;
  reg [31:0] _GEN_10;
  wire  _T_20;
  wire  _T_22;
  wire  _T_23;
  wire  _T_24;
  wire  _T_25;
  wire  do_enq;
  wire  _T_27;
  wire  do_deq;
  wire [1:0] _T_32;
  wire  _T_33;
  wire  _GEN_11;
  wire [1:0] _T_36;
  wire  _T_37;
  wire  _GEN_12;
  wire  _T_38;
  wire  _GEN_13;
  wire  _T_40;
  wire  _T_42;
  wire [1:0] _T_44;
  wire [1:0] _T_45;
  wire  _T_46;
  wire  _T_47;
  wire [1:0] _T_48;
  assign io_enq_ready = _T_42;
  assign io_deq_valid = _T_40;
  assign io_deq_bits_opcode = ram_opcode__T_43_data;
  assign io_deq_bits_param = ram_param__T_43_data;
  assign io_deq_bits_size = ram_size__T_43_data;
  assign io_deq_bits_source = ram_source__T_43_data;
  assign io_deq_bits_sink = ram_sink__T_43_data;
  assign io_deq_bits_addr_lo = ram_addr_lo__T_43_data;
  assign io_deq_bits_data = ram_data__T_43_data;
  assign io_deq_bits_error = ram_error__T_43_data;
  assign io_count = _T_48;
  assign ram_opcode__T_43_addr = value_1;
  assign ram_opcode__T_43_data = ram_opcode[ram_opcode__T_43_addr];
  assign ram_opcode__T_29_data = io_enq_bits_opcode;
  assign ram_opcode__T_29_addr = value;
  assign ram_opcode__T_29_mask = do_enq;
  assign ram_opcode__T_29_en = do_enq;
  assign ram_param__T_43_addr = value_1;
  assign ram_param__T_43_data = ram_param[ram_param__T_43_addr];
  assign ram_param__T_29_data = io_enq_bits_param;
  assign ram_param__T_29_addr = value;
  assign ram_param__T_29_mask = do_enq;
  assign ram_param__T_29_en = do_enq;
  assign ram_size__T_43_addr = value_1;
  assign ram_size__T_43_data = ram_size[ram_size__T_43_addr];
  assign ram_size__T_29_data = io_enq_bits_size;
  assign ram_size__T_29_addr = value;
  assign ram_size__T_29_mask = do_enq;
  assign ram_size__T_29_en = do_enq;
  assign ram_source__T_43_addr = value_1;
  assign ram_source__T_43_data = ram_source[ram_source__T_43_addr];
  assign ram_source__T_29_data = io_enq_bits_source;
  assign ram_source__T_29_addr = value;
  assign ram_source__T_29_mask = do_enq;
  assign ram_source__T_29_en = do_enq;
  assign ram_sink__T_43_addr = value_1;
  assign ram_sink__T_43_data = ram_sink[ram_sink__T_43_addr];
  assign ram_sink__T_29_data = io_enq_bits_sink;
  assign ram_sink__T_29_addr = value;
  assign ram_sink__T_29_mask = do_enq;
  assign ram_sink__T_29_en = do_enq;
  assign ram_addr_lo__T_43_addr = value_1;
  assign ram_addr_lo__T_43_data = ram_addr_lo[ram_addr_lo__T_43_addr];
  assign ram_addr_lo__T_29_data = io_enq_bits_addr_lo;
  assign ram_addr_lo__T_29_addr = value;
  assign ram_addr_lo__T_29_mask = do_enq;
  assign ram_addr_lo__T_29_en = do_enq;
  assign ram_data__T_43_addr = value_1;
  assign ram_data__T_43_data = ram_data[ram_data__T_43_addr];
  assign ram_data__T_29_data = io_enq_bits_data;
  assign ram_data__T_29_addr = value;
  assign ram_data__T_29_mask = do_enq;
  assign ram_data__T_29_en = do_enq;
  assign ram_error__T_43_addr = value_1;
  assign ram_error__T_43_data = ram_error[ram_error__T_43_addr];
  assign ram_error__T_29_data = io_enq_bits_error;
  assign ram_error__T_29_addr = value;
  assign ram_error__T_29_mask = do_enq;
  assign ram_error__T_29_en = do_enq;
  assign _T_20 = value == value_1;
  assign _T_22 = maybe_full == 1'h0;
  assign _T_23 = _T_20 & _T_22;
  assign _T_24 = _T_20 & maybe_full;
  assign _T_25 = io_enq_ready & io_enq_valid;
  assign do_enq = _T_25;
  assign _T_27 = io_deq_ready & io_deq_valid;
  assign do_deq = _T_27;
  assign _T_32 = value + 1'h1;
  assign _T_33 = _T_32[0:0];
  assign _GEN_11 = do_enq ? _T_33 : value;
  assign _T_36 = value_1 + 1'h1;
  assign _T_37 = _T_36[0:0];
  assign _GEN_12 = do_deq ? _T_37 : value_1;
  assign _T_38 = do_enq != do_deq;
  assign _GEN_13 = _T_38 ? do_enq : maybe_full;
  assign _T_40 = _T_23 == 1'h0;
  assign _T_42 = _T_24 == 1'h0;
  assign _T_44 = value - value_1;
  assign _T_45 = $unsigned(_T_44);
  assign _T_46 = _T_45[0:0];
  assign _T_47 = maybe_full & _T_20;
  assign _T_48 = {_T_47,_T_46};
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_opcode[initvar] = _GEN_0[2:0];
  `endif
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_param[initvar] = _GEN_1[1:0];
  `endif
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_size[initvar] = _GEN_2[1:0];
  `endif
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_source[initvar] = _GEN_3[3:0];
  `endif
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_sink[initvar] = _GEN_4[0:0];
  `endif
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_addr_lo[initvar] = _GEN_5[1:0];
  `endif
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_data[initvar] = _GEN_6[31:0];
  `endif
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  `ifdef RANDOMIZE_MEM_INIT
  for (initvar = 0; initvar < 2; initvar = initvar+1)
    ram_error[initvar] = _GEN_7[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  value = _GEN_8[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  value_1 = _GEN_9[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  maybe_full = _GEN_10[0:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if(ram_opcode__T_29_en & ram_opcode__T_29_mask) begin
      ram_opcode[ram_opcode__T_29_addr] <= ram_opcode__T_29_data;
    end
    if(ram_param__T_29_en & ram_param__T_29_mask) begin
      ram_param[ram_param__T_29_addr] <= ram_param__T_29_data;
    end
    if(ram_size__T_29_en & ram_size__T_29_mask) begin
      ram_size[ram_size__T_29_addr] <= ram_size__T_29_data;
    end
    if(ram_source__T_29_en & ram_source__T_29_mask) begin
      ram_source[ram_source__T_29_addr] <= ram_source__T_29_data;
    end
    if(ram_sink__T_29_en & ram_sink__T_29_mask) begin
      ram_sink[ram_sink__T_29_addr] <= ram_sink__T_29_data;
    end
    if(ram_addr_lo__T_29_en & ram_addr_lo__T_29_mask) begin
      ram_addr_lo[ram_addr_lo__T_29_addr] <= ram_addr_lo__T_29_data;
    end
    if(ram_data__T_29_en & ram_data__T_29_mask) begin
      ram_data[ram_data__T_29_addr] <= ram_data__T_29_data;
    end
    if(ram_error__T_29_en & ram_error__T_29_mask) begin
      ram_error[ram_error__T_29_addr] <= ram_error__T_29_data;
    end
    if (reset) begin
      value <= 1'h0;
    end else begin
      if (do_enq) begin
        value <= _T_33;
      end
    end
    if (reset) begin
      value_1 <= 1'h0;
    end else begin
      if (do_deq) begin
        value_1 <= _T_37;
      end
    end
    if (reset) begin
      maybe_full <= 1'h0;
    end else begin
      if (_T_38) begin
        maybe_full <= do_enq;
      end
    end
  end
endmodule
