//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module Repeater_7(
  input         clock,
  input         reset,
  input         io_repeat,
  output        io_full,
  output        io_enq_ready,
  input         io_enq_valid,
  input  [2:0]  io_enq_bits_opcode,
  input  [2:0]  io_enq_bits_param,
  input  [2:0]  io_enq_bits_size,
  input         io_enq_bits_source,
  input  [29:0] io_enq_bits_address,
  input  [3:0]  io_enq_bits_mask,
  input  [31:0] io_enq_bits_data,
  input         io_deq_ready,
  output        io_deq_valid,
  output [2:0]  io_deq_bits_opcode,
  output [2:0]  io_deq_bits_param,
  output [2:0]  io_deq_bits_size,
  output        io_deq_bits_source,
  output [29:0] io_deq_bits_address,
  output [3:0]  io_deq_bits_mask,
  output [31:0] io_deq_bits_data
);
  reg  full;
  reg [31:0] _GEN_9;
  reg [2:0] saved_opcode;
  reg [31:0] _GEN_10;
  reg [2:0] saved_param;
  reg [31:0] _GEN_11;
  reg [2:0] saved_size;
  reg [31:0] _GEN_12;
  reg  saved_source;
  reg [31:0] _GEN_13;
  reg [29:0] saved_address;
  reg [31:0] _GEN_14;
  reg [3:0] saved_mask;
  reg [31:0] _GEN_15;
  reg [31:0] saved_data;
  reg [31:0] _GEN_16;
  wire  _T_16;
  wire  _T_18;
  wire  _T_19;
  wire [2:0] _T_20_opcode;
  wire [2:0] _T_20_param;
  wire [2:0] _T_20_size;
  wire  _T_20_source;
  wire [29:0] _T_20_address;
  wire [3:0] _T_20_mask;
  wire [31:0] _T_20_data;
  wire  _T_21;
  wire  _T_22;
  wire  _GEN_0;
  wire [2:0] _GEN_1;
  wire [2:0] _GEN_2;
  wire [2:0] _GEN_3;
  wire  _GEN_4;
  wire [29:0] _GEN_5;
  wire [3:0] _GEN_6;
  wire [31:0] _GEN_7;
  wire  _T_24;
  wire  _T_26;
  wire  _T_27;
  wire  _GEN_8;
  assign io_full = full;
  assign io_enq_ready = _T_19;
  assign io_deq_valid = _T_16;
  assign io_deq_bits_opcode = _T_20_opcode;
  assign io_deq_bits_param = _T_20_param;
  assign io_deq_bits_size = _T_20_size;
  assign io_deq_bits_source = _T_20_source;
  assign io_deq_bits_address = _T_20_address;
  assign io_deq_bits_mask = _T_20_mask;
  assign io_deq_bits_data = _T_20_data;
  assign _T_16 = io_enq_valid | full;
  assign _T_18 = full == 1'h0;
  assign _T_19 = io_deq_ready & _T_18;
  assign _T_20_opcode = full ? saved_opcode : io_enq_bits_opcode;
  assign _T_20_param = full ? saved_param : io_enq_bits_param;
  assign _T_20_size = full ? saved_size : io_enq_bits_size;
  assign _T_20_source = full ? saved_source : io_enq_bits_source;
  assign _T_20_address = full ? saved_address : io_enq_bits_address;
  assign _T_20_mask = full ? saved_mask : io_enq_bits_mask;
  assign _T_20_data = full ? saved_data : io_enq_bits_data;
  assign _T_21 = io_enq_ready & io_enq_valid;
  assign _T_22 = _T_21 & io_repeat;
  assign _GEN_0 = _T_22 ? 1'h1 : full;
  assign _GEN_1 = _T_22 ? io_enq_bits_opcode : saved_opcode;
  assign _GEN_2 = _T_22 ? io_enq_bits_param : saved_param;
  assign _GEN_3 = _T_22 ? io_enq_bits_size : saved_size;
  assign _GEN_4 = _T_22 ? io_enq_bits_source : saved_source;
  assign _GEN_5 = _T_22 ? io_enq_bits_address : saved_address;
  assign _GEN_6 = _T_22 ? io_enq_bits_mask : saved_mask;
  assign _GEN_7 = _T_22 ? io_enq_bits_data : saved_data;
  assign _T_24 = io_deq_ready & io_deq_valid;
  assign _T_26 = io_repeat == 1'h0;
  assign _T_27 = _T_24 & _T_26;
  assign _GEN_8 = _T_27 ? 1'h0 : _GEN_0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  full = _GEN_9[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_10 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_opcode = _GEN_10[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_11 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_param = _GEN_11[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_12 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_size = _GEN_12[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_13 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_source = _GEN_13[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_14 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_address = _GEN_14[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_mask = _GEN_15[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  saved_data = _GEN_16[31:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      full <= 1'h0;
    end else begin
      if (_T_27) begin
        full <= 1'h0;
      end else begin
        if (_T_22) begin
          full <= 1'h1;
        end
      end
    end
    if (_T_22) begin
      saved_opcode <= io_enq_bits_opcode;
    end
    if (_T_22) begin
      saved_param <= io_enq_bits_param;
    end
    if (_T_22) begin
      saved_size <= io_enq_bits_size;
    end
    if (_T_22) begin
      saved_source <= io_enq_bits_source;
    end
    if (_T_22) begin
      saved_address <= io_enq_bits_address;
    end
    if (_T_22) begin
      saved_mask <= io_enq_bits_mask;
    end
    if (_T_22) begin
      saved_data <= io_enq_bits_data;
    end
  end
endmodule
