//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLBuffer_sram(
  input         clock,
  input         reset,
  output        io_in_0_a_ready,
  input         io_in_0_a_valid,
  input  [2:0]  io_in_0_a_bits_opcode,
  input  [2:0]  io_in_0_a_bits_param,
  input  [1:0]  io_in_0_a_bits_size,
  input  [3:0]  io_in_0_a_bits_source,
  input  [29:0] io_in_0_a_bits_address,
  input  [3:0]  io_in_0_a_bits_mask,
  input  [31:0] io_in_0_a_bits_data,
  input         io_in_0_b_ready,
  output        io_in_0_b_valid,
  output [2:0]  io_in_0_b_bits_opcode,
  output [1:0]  io_in_0_b_bits_param,
  output [1:0]  io_in_0_b_bits_size,
  output [3:0]  io_in_0_b_bits_source,
  output [29:0] io_in_0_b_bits_address,
  output [3:0]  io_in_0_b_bits_mask,
  output [31:0] io_in_0_b_bits_data,
  output        io_in_0_c_ready,
  input         io_in_0_c_valid,
  input  [2:0]  io_in_0_c_bits_opcode,
  input  [2:0]  io_in_0_c_bits_param,
  input  [1:0]  io_in_0_c_bits_size,
  input  [3:0]  io_in_0_c_bits_source,
  input  [29:0] io_in_0_c_bits_address,
  input  [31:0] io_in_0_c_bits_data,
  input         io_in_0_c_bits_error,
  input         io_in_0_d_ready,
  output        io_in_0_d_valid,
  output [2:0]  io_in_0_d_bits_opcode,
  output [1:0]  io_in_0_d_bits_param,
  output [1:0]  io_in_0_d_bits_size,
  output [3:0]  io_in_0_d_bits_source,
  output        io_in_0_d_bits_sink,
  output [1:0]  io_in_0_d_bits_addr_lo,
  output [31:0] io_in_0_d_bits_data,
  output        io_in_0_d_bits_error,
  output        io_in_0_e_ready,
  input         io_in_0_e_valid,
  input         io_in_0_e_bits_sink,
  input         io_out_0_a_ready,
  output        io_out_0_a_valid,
  output [2:0]  io_out_0_a_bits_opcode,
  output [2:0]  io_out_0_a_bits_param,
  output [1:0]  io_out_0_a_bits_size,
  output [3:0]  io_out_0_a_bits_source,
  output [29:0] io_out_0_a_bits_address,
  output [3:0]  io_out_0_a_bits_mask,
  output [31:0] io_out_0_a_bits_data,
  output        io_out_0_b_ready,
  input         io_out_0_b_valid,
  input  [2:0]  io_out_0_b_bits_opcode,
  input  [1:0]  io_out_0_b_bits_param,
  input  [1:0]  io_out_0_b_bits_size,
  input  [3:0]  io_out_0_b_bits_source,
  input  [29:0] io_out_0_b_bits_address,
  input  [3:0]  io_out_0_b_bits_mask,
  input  [31:0] io_out_0_b_bits_data,
  input         io_out_0_c_ready,
  output        io_out_0_c_valid,
  output [2:0]  io_out_0_c_bits_opcode,
  output [2:0]  io_out_0_c_bits_param,
  output [1:0]  io_out_0_c_bits_size,
  output [3:0]  io_out_0_c_bits_source,
  output [29:0] io_out_0_c_bits_address,
  output [31:0] io_out_0_c_bits_data,
  output        io_out_0_c_bits_error,
  output        io_out_0_d_ready,
  input         io_out_0_d_valid,
  input  [2:0]  io_out_0_d_bits_opcode,
  input  [1:0]  io_out_0_d_bits_param,
  input  [1:0]  io_out_0_d_bits_size,
  input  [3:0]  io_out_0_d_bits_source,
  input         io_out_0_d_bits_sink,
  input  [1:0]  io_out_0_d_bits_addr_lo,
  input  [31:0] io_out_0_d_bits_data,
  input         io_out_0_d_bits_error,
  input         io_out_0_e_ready,
  output        io_out_0_e_valid,
  output        io_out_0_e_bits_sink
);
  wire  Queue_clock;
  wire  Queue_reset;
  wire  Queue_io_enq_ready;
  wire  Queue_io_enq_valid;
  wire [2:0] Queue_io_enq_bits_opcode;
  wire [2:0] Queue_io_enq_bits_param;
  wire [1:0] Queue_io_enq_bits_size;
  wire [3:0] Queue_io_enq_bits_source;
  wire [29:0] Queue_io_enq_bits_address;
  wire [3:0] Queue_io_enq_bits_mask;
  wire [31:0] Queue_io_enq_bits_data;
  wire  Queue_io_deq_ready;
  wire  Queue_io_deq_valid;
  wire [2:0] Queue_io_deq_bits_opcode;
  wire [2:0] Queue_io_deq_bits_param;
  wire [1:0] Queue_io_deq_bits_size;
  wire [3:0] Queue_io_deq_bits_source;
  wire [29:0] Queue_io_deq_bits_address;
  wire [3:0] Queue_io_deq_bits_mask;
  wire [31:0] Queue_io_deq_bits_data;
  wire [1:0] Queue_io_count;
  wire  Queue_1_clock;
  wire  Queue_1_reset;
  wire  Queue_1_io_enq_ready;
  wire  Queue_1_io_enq_valid;
  wire [2:0] Queue_1_io_enq_bits_opcode;
  wire [1:0] Queue_1_io_enq_bits_param;
  wire [1:0] Queue_1_io_enq_bits_size;
  wire [3:0] Queue_1_io_enq_bits_source;
  wire  Queue_1_io_enq_bits_sink;
  wire [1:0] Queue_1_io_enq_bits_addr_lo;
  wire [31:0] Queue_1_io_enq_bits_data;
  wire  Queue_1_io_enq_bits_error;
  wire  Queue_1_io_deq_ready;
  wire  Queue_1_io_deq_valid;
  wire [2:0] Queue_1_io_deq_bits_opcode;
  wire [1:0] Queue_1_io_deq_bits_param;
  wire [1:0] Queue_1_io_deq_bits_size;
  wire [3:0] Queue_1_io_deq_bits_source;
  wire  Queue_1_io_deq_bits_sink;
  wire [1:0] Queue_1_io_deq_bits_addr_lo;
  wire [31:0] Queue_1_io_deq_bits_data;
  wire  Queue_1_io_deq_bits_error;
  wire [1:0] Queue_1_io_count;
  reg [2:0] _GEN_0;
  reg [31:0] _GEN_15;
  reg [1:0] _GEN_1;
  reg [31:0] _GEN_16;
  reg [1:0] _GEN_2;
  reg [31:0] _GEN_17;
  reg [3:0] _GEN_3;
  reg [31:0] _GEN_18;
  reg [29:0] _GEN_4;
  reg [31:0] _GEN_19;
  reg [3:0] _GEN_5;
  reg [31:0] _GEN_20;
  reg [31:0] _GEN_6;
  reg [31:0] _GEN_21;
  reg [2:0] _GEN_7;
  reg [31:0] _GEN_22;
  reg [2:0] _GEN_8;
  reg [31:0] _GEN_23;
  reg [1:0] _GEN_9;
  reg [31:0] _GEN_24;
  reg [3:0] _GEN_10;
  reg [31:0] _GEN_25;
  reg [29:0] _GEN_11;
  reg [31:0] _GEN_26;
  reg [31:0] _GEN_12;
  reg [31:0] _GEN_27;
  reg  _GEN_13;
  reg [31:0] _GEN_28;
  reg  _GEN_14;
  reg [31:0] _GEN_29;
  Queue_16 Queue (
    .clock(Queue_clock),
    .reset(Queue_reset),
    .io_enq_ready(Queue_io_enq_ready),
    .io_enq_valid(Queue_io_enq_valid),
    .io_enq_bits_opcode(Queue_io_enq_bits_opcode),
    .io_enq_bits_param(Queue_io_enq_bits_param),
    .io_enq_bits_size(Queue_io_enq_bits_size),
    .io_enq_bits_source(Queue_io_enq_bits_source),
    .io_enq_bits_address(Queue_io_enq_bits_address),
    .io_enq_bits_mask(Queue_io_enq_bits_mask),
    .io_enq_bits_data(Queue_io_enq_bits_data),
    .io_deq_ready(Queue_io_deq_ready),
    .io_deq_valid(Queue_io_deq_valid),
    .io_deq_bits_opcode(Queue_io_deq_bits_opcode),
    .io_deq_bits_param(Queue_io_deq_bits_param),
    .io_deq_bits_size(Queue_io_deq_bits_size),
    .io_deq_bits_source(Queue_io_deq_bits_source),
    .io_deq_bits_address(Queue_io_deq_bits_address),
    .io_deq_bits_mask(Queue_io_deq_bits_mask),
    .io_deq_bits_data(Queue_io_deq_bits_data),
    .io_count(Queue_io_count)
  );
  Queue_17 Queue_1 (
    .clock(Queue_1_clock),
    .reset(Queue_1_reset),
    .io_enq_ready(Queue_1_io_enq_ready),
    .io_enq_valid(Queue_1_io_enq_valid),
    .io_enq_bits_opcode(Queue_1_io_enq_bits_opcode),
    .io_enq_bits_param(Queue_1_io_enq_bits_param),
    .io_enq_bits_size(Queue_1_io_enq_bits_size),
    .io_enq_bits_source(Queue_1_io_enq_bits_source),
    .io_enq_bits_sink(Queue_1_io_enq_bits_sink),
    .io_enq_bits_addr_lo(Queue_1_io_enq_bits_addr_lo),
    .io_enq_bits_data(Queue_1_io_enq_bits_data),
    .io_enq_bits_error(Queue_1_io_enq_bits_error),
    .io_deq_ready(Queue_1_io_deq_ready),
    .io_deq_valid(Queue_1_io_deq_valid),
    .io_deq_bits_opcode(Queue_1_io_deq_bits_opcode),
    .io_deq_bits_param(Queue_1_io_deq_bits_param),
    .io_deq_bits_size(Queue_1_io_deq_bits_size),
    .io_deq_bits_source(Queue_1_io_deq_bits_source),
    .io_deq_bits_sink(Queue_1_io_deq_bits_sink),
    .io_deq_bits_addr_lo(Queue_1_io_deq_bits_addr_lo),
    .io_deq_bits_data(Queue_1_io_deq_bits_data),
    .io_deq_bits_error(Queue_1_io_deq_bits_error),
    .io_count(Queue_1_io_count)
  );
  assign io_in_0_a_ready = Queue_io_enq_ready;
  assign io_in_0_b_valid = 1'h0;
  assign io_in_0_b_bits_opcode = _GEN_0;
  assign io_in_0_b_bits_param = _GEN_1;
  assign io_in_0_b_bits_size = _GEN_2;
  assign io_in_0_b_bits_source = _GEN_3;
  assign io_in_0_b_bits_address = _GEN_4;
  assign io_in_0_b_bits_mask = _GEN_5;
  assign io_in_0_b_bits_data = _GEN_6;
  assign io_in_0_c_ready = 1'h1;
  assign io_in_0_d_valid = Queue_1_io_deq_valid;
  assign io_in_0_d_bits_opcode = Queue_1_io_deq_bits_opcode;
  assign io_in_0_d_bits_param = Queue_1_io_deq_bits_param;
  assign io_in_0_d_bits_size = Queue_1_io_deq_bits_size;
  assign io_in_0_d_bits_source = Queue_1_io_deq_bits_source;
  assign io_in_0_d_bits_sink = Queue_1_io_deq_bits_sink;
  assign io_in_0_d_bits_addr_lo = Queue_1_io_deq_bits_addr_lo;
  assign io_in_0_d_bits_data = Queue_1_io_deq_bits_data;
  assign io_in_0_d_bits_error = Queue_1_io_deq_bits_error;
  assign io_in_0_e_ready = 1'h1;
  assign io_out_0_a_valid = Queue_io_deq_valid;
  assign io_out_0_a_bits_opcode = Queue_io_deq_bits_opcode;
  assign io_out_0_a_bits_param = Queue_io_deq_bits_param;
  assign io_out_0_a_bits_size = Queue_io_deq_bits_size;
  assign io_out_0_a_bits_source = Queue_io_deq_bits_source;
  assign io_out_0_a_bits_address = Queue_io_deq_bits_address;
  assign io_out_0_a_bits_mask = Queue_io_deq_bits_mask;
  assign io_out_0_a_bits_data = Queue_io_deq_bits_data;
  assign io_out_0_b_ready = 1'h1;
  assign io_out_0_c_valid = 1'h0;
  assign io_out_0_c_bits_opcode = _GEN_7;
  assign io_out_0_c_bits_param = _GEN_8;
  assign io_out_0_c_bits_size = _GEN_9;
  assign io_out_0_c_bits_source = _GEN_10;
  assign io_out_0_c_bits_address = _GEN_11;
  assign io_out_0_c_bits_data = _GEN_12;
  assign io_out_0_c_bits_error = _GEN_13;
  assign io_out_0_d_ready = Queue_1_io_enq_ready;
  assign io_out_0_e_valid = 1'h0;
  assign io_out_0_e_bits_sink = _GEN_14;
  assign Queue_clock = clock;
  assign Queue_reset = reset;
  assign Queue_io_enq_valid = io_in_0_a_valid;
  assign Queue_io_enq_bits_opcode = io_in_0_a_bits_opcode;
  assign Queue_io_enq_bits_param = io_in_0_a_bits_param;
  assign Queue_io_enq_bits_size = io_in_0_a_bits_size;
  assign Queue_io_enq_bits_source = io_in_0_a_bits_source;
  assign Queue_io_enq_bits_address = io_in_0_a_bits_address;
  assign Queue_io_enq_bits_mask = io_in_0_a_bits_mask;
  assign Queue_io_enq_bits_data = io_in_0_a_bits_data;
  assign Queue_io_deq_ready = io_out_0_a_ready;
  assign Queue_1_clock = clock;
  assign Queue_1_reset = reset;
  assign Queue_1_io_enq_valid = io_out_0_d_valid;
  assign Queue_1_io_enq_bits_opcode = io_out_0_d_bits_opcode;
  assign Queue_1_io_enq_bits_param = io_out_0_d_bits_param;
  assign Queue_1_io_enq_bits_size = io_out_0_d_bits_size;
  assign Queue_1_io_enq_bits_source = io_out_0_d_bits_source;
  assign Queue_1_io_enq_bits_sink = io_out_0_d_bits_sink;
  assign Queue_1_io_enq_bits_addr_lo = io_out_0_d_bits_addr_lo;
  assign Queue_1_io_enq_bits_data = io_out_0_d_bits_data;
  assign Queue_1_io_enq_bits_error = io_out_0_d_bits_error;
  assign Queue_1_io_deq_ready = io_in_0_d_ready;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_0 = _GEN_15[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_16[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_17 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_17[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_18 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_18[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_19 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_19[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_20 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_20[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_21[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_22 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_22[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_23[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_24 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_24[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_25[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_11 = _GEN_26[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_12 = _GEN_27[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_13 = _GEN_28[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_14 = _GEN_29[0:0];
  `endif
  end
`endif
endmodule
