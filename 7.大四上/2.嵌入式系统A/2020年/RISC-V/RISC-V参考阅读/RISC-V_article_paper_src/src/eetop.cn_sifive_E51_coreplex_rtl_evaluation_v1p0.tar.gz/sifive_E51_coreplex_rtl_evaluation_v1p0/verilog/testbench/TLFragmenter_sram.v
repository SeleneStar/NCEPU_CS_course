//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLFragmenter_sram(
  input         clock,
  input         reset,
  output        io_in_0_a_ready,
  input         io_in_0_a_valid,
  input  [2:0]  io_in_0_a_bits_opcode,
  input  [2:0]  io_in_0_a_bits_param,
  input  [2:0]  io_in_0_a_bits_size,
  input         io_in_0_a_bits_source,
  input  [29:0] io_in_0_a_bits_address,
  input  [3:0]  io_in_0_a_bits_mask,
  input  [31:0] io_in_0_a_bits_data,
  input         io_in_0_b_ready,
  output        io_in_0_b_valid,
  output [2:0]  io_in_0_b_bits_opcode,
  output [1:0]  io_in_0_b_bits_param,
  output [2:0]  io_in_0_b_bits_size,
  output        io_in_0_b_bits_source,
  output [29:0] io_in_0_b_bits_address,
  output [3:0]  io_in_0_b_bits_mask,
  output [31:0] io_in_0_b_bits_data,
  output        io_in_0_c_ready,
  input         io_in_0_c_valid,
  input  [2:0]  io_in_0_c_bits_opcode,
  input  [2:0]  io_in_0_c_bits_param,
  input  [2:0]  io_in_0_c_bits_size,
  input         io_in_0_c_bits_source,
  input  [29:0] io_in_0_c_bits_address,
  input  [31:0] io_in_0_c_bits_data,
  input         io_in_0_c_bits_error,
  input         io_in_0_d_ready,
  output        io_in_0_d_valid,
  output [2:0]  io_in_0_d_bits_opcode,
  output [1:0]  io_in_0_d_bits_param,
  output [2:0]  io_in_0_d_bits_size,
  output        io_in_0_d_bits_source,
  output        io_in_0_d_bits_sink,
  output [1:0]  io_in_0_d_bits_addr_lo,
  output [31:0] io_in_0_d_bits_data,
  output        io_in_0_d_bits_error,
  output        io_in_0_e_ready,
  input         io_in_0_e_valid,
  input         io_in_0_e_bits_sink,
  input         io_out_0_a_ready,
  output        io_out_0_a_valid,
  output [2:0]  io_out_0_a_bits_opcode,
  output [2:0]  io_out_0_a_bits_param,
  output [1:0]  io_out_0_a_bits_size,
  output [3:0]  io_out_0_a_bits_source,
  output [29:0] io_out_0_a_bits_address,
  output [3:0]  io_out_0_a_bits_mask,
  output [31:0] io_out_0_a_bits_data,
  output        io_out_0_b_ready,
  input         io_out_0_b_valid,
  input  [2:0]  io_out_0_b_bits_opcode,
  input  [1:0]  io_out_0_b_bits_param,
  input  [1:0]  io_out_0_b_bits_size,
  input  [3:0]  io_out_0_b_bits_source,
  input  [29:0] io_out_0_b_bits_address,
  input  [3:0]  io_out_0_b_bits_mask,
  input  [31:0] io_out_0_b_bits_data,
  input         io_out_0_c_ready,
  output        io_out_0_c_valid,
  output [2:0]  io_out_0_c_bits_opcode,
  output [2:0]  io_out_0_c_bits_param,
  output [1:0]  io_out_0_c_bits_size,
  output [3:0]  io_out_0_c_bits_source,
  output [29:0] io_out_0_c_bits_address,
  output [31:0] io_out_0_c_bits_data,
  output        io_out_0_c_bits_error,
  output        io_out_0_d_ready,
  input         io_out_0_d_valid,
  input  [2:0]  io_out_0_d_bits_opcode,
  input  [1:0]  io_out_0_d_bits_param,
  input  [1:0]  io_out_0_d_bits_size,
  input  [3:0]  io_out_0_d_bits_source,
  input         io_out_0_d_bits_sink,
  input  [1:0]  io_out_0_d_bits_addr_lo,
  input  [31:0] io_out_0_d_bits_data,
  input         io_out_0_d_bits_error,
  input         io_out_0_e_ready,
  output        io_out_0_e_valid,
  output        io_out_0_e_bits_sink
);
  reg [2:0] _T_92;
  reg [31:0] _GEN_28;
  reg [2:0] _T_94;
  reg [31:0] _GEN_29;
  wire [2:0] _T_95;
  wire  _T_97;
  wire  _T_99;
  wire [3:0] _T_102;
  wire [2:0] _T_103;
  wire [4:0] _T_106;
  wire [1:0] _T_107;
  wire [1:0] _T_108;
  wire  _T_109;
  wire  _T_125;
  wire  _T_126;
  wire [4:0] _GEN_5;
  wire [4:0] _T_127;
  wire [4:0] _GEN_6;
  wire [4:0] _T_128;
  wire [5:0] _GEN_7;
  wire [5:0] _T_129;
  wire [5:0] _T_131;
  wire [5:0] _T_133;
  wire [5:0] _T_134;
  wire [5:0] _T_135;
  wire [1:0] _T_136;
  wire [3:0] _T_137;
  wire  _T_139;
  wire [3:0] _GEN_8;
  wire [3:0] _T_140;
  wire [1:0] _T_141;
  wire [1:0] _T_142;
  wire  _T_144;
  wire [1:0] _T_145;
  wire  _T_146;
  wire [1:0] _T_147;
  wire [2:0] _T_148;
  wire  _T_149;
  wire [2:0] _GEN_9;
  wire [3:0] _T_150;
  wire [3:0] _T_151;
  wire [2:0] _T_152;
  wire [2:0] _T_153;
  wire [2:0] _GEN_0;
  wire [2:0] _GEN_1;
  wire [2:0] _GEN_2;
  wire  _T_155;
  wire  _T_157;
  wire  _T_158;
  wire  _T_159;
  wire  _T_161;
  wire  _T_162;
  wire [1:0] _T_163;
  wire [1:0] _T_164;
  wire  _T_165;
  reg  _T_169;
  reg [31:0] _GEN_30;
  wire  _T_170;
  wire  _T_173;
  wire  _GEN_3;
  wire  Repeater_clock;
  wire  Repeater_reset;
  wire  Repeater_io_repeat;
  wire  Repeater_io_full;
  wire  Repeater_io_enq_ready;
  wire  Repeater_io_enq_valid;
  wire [2:0] Repeater_io_enq_bits_opcode;
  wire [2:0] Repeater_io_enq_bits_param;
  wire [2:0] Repeater_io_enq_bits_size;
  wire  Repeater_io_enq_bits_source;
  wire [29:0] Repeater_io_enq_bits_address;
  wire [3:0] Repeater_io_enq_bits_mask;
  wire [31:0] Repeater_io_enq_bits_data;
  wire  Repeater_io_deq_ready;
  wire  Repeater_io_deq_valid;
  wire [2:0] Repeater_io_deq_bits_opcode;
  wire [2:0] Repeater_io_deq_bits_param;
  wire [2:0] Repeater_io_deq_bits_size;
  wire  Repeater_io_deq_bits_source;
  wire [29:0] Repeater_io_deq_bits_address;
  wire [3:0] Repeater_io_deq_bits_mask;
  wire [31:0] Repeater_io_deq_bits_data;
  wire  _T_188_0;
  wire  _T_210;
  wire [2:0] _T_211;
  wire [11:0] _T_214;
  wire [4:0] _T_215;
  wire [4:0] _T_216;
  wire [8:0] _T_219;
  wire [1:0] _T_220;
  wire [1:0] _T_221;
  wire  _T_222;
  wire  _T_224;
  reg [2:0] _T_229;
  reg [31:0] _GEN_31;
  wire  _T_231;
  wire [2:0] _T_232;
  wire [3:0] _T_234;
  wire [3:0] _T_235;
  wire [2:0] _T_236;
  wire [2:0] _T_237;
  wire [2:0] _T_238;
  wire [2:0] _T_241;
  wire  _T_247;
  wire [2:0] _GEN_4;
  wire  _T_249;
  wire  _T_251;
  wire  _T_252;
  wire [4:0] _GEN_10;
  wire [4:0] _T_253;
  wire [4:0] _T_254;
  wire [4:0] _T_255;
  wire [4:0] _GEN_11;
  wire [4:0] _T_256;
  wire [4:0] _T_258;
  wire [4:0] _T_259;
  wire [29:0] _GEN_12;
  wire [29:0] _T_260;
  wire [3:0] _T_261;
  wire  _T_263;
  wire  _T_266;
  wire  _T_267;
  wire  _T_269;
  wire  _T_273;
  wire  _T_274;
  wire  _T_275;
  wire  _T_277;
  wire [3:0] _T_278;
  reg [2:0] _GEN_13;
  reg [31:0] _GEN_32;
  reg [1:0] _GEN_14;
  reg [31:0] _GEN_33;
  reg [2:0] _GEN_15;
  reg [31:0] _GEN_34;
  reg  _GEN_16;
  reg [31:0] _GEN_35;
  reg [29:0] _GEN_17;
  reg [31:0] _GEN_36;
  reg [3:0] _GEN_18;
  reg [31:0] _GEN_37;
  reg [31:0] _GEN_19;
  reg [31:0] _GEN_38;
  reg [2:0] _GEN_20;
  reg [31:0] _GEN_39;
  reg [2:0] _GEN_21;
  reg [31:0] _GEN_40;
  reg [1:0] _GEN_22;
  reg [31:0] _GEN_41;
  reg [3:0] _GEN_23;
  reg [31:0] _GEN_42;
  reg [29:0] _GEN_24;
  reg [31:0] _GEN_43;
  reg [31:0] _GEN_25;
  reg [31:0] _GEN_44;
  reg  _GEN_26;
  reg [31:0] _GEN_45;
  reg  _GEN_27;
  reg [31:0] _GEN_46;
  Repeater_7 Repeater (
    .clock(Repeater_clock),
    .reset(Repeater_reset),
    .io_repeat(Repeater_io_repeat),
    .io_full(Repeater_io_full),
    .io_enq_ready(Repeater_io_enq_ready),
    .io_enq_valid(Repeater_io_enq_valid),
    .io_enq_bits_opcode(Repeater_io_enq_bits_opcode),
    .io_enq_bits_param(Repeater_io_enq_bits_param),
    .io_enq_bits_size(Repeater_io_enq_bits_size),
    .io_enq_bits_source(Repeater_io_enq_bits_source),
    .io_enq_bits_address(Repeater_io_enq_bits_address),
    .io_enq_bits_mask(Repeater_io_enq_bits_mask),
    .io_enq_bits_data(Repeater_io_enq_bits_data),
    .io_deq_ready(Repeater_io_deq_ready),
    .io_deq_valid(Repeater_io_deq_valid),
    .io_deq_bits_opcode(Repeater_io_deq_bits_opcode),
    .io_deq_bits_param(Repeater_io_deq_bits_param),
    .io_deq_bits_size(Repeater_io_deq_bits_size),
    .io_deq_bits_source(Repeater_io_deq_bits_source),
    .io_deq_bits_address(Repeater_io_deq_bits_address),
    .io_deq_bits_mask(Repeater_io_deq_bits_mask),
    .io_deq_bits_data(Repeater_io_deq_bits_data)
  );
  assign io_in_0_a_ready = Repeater_io_enq_ready;
  assign io_in_0_b_valid = 1'h0;
  assign io_in_0_b_bits_opcode = _GEN_13;
  assign io_in_0_b_bits_param = _GEN_14;
  assign io_in_0_b_bits_size = _GEN_15;
  assign io_in_0_b_bits_source = _GEN_16;
  assign io_in_0_b_bits_address = _GEN_17;
  assign io_in_0_b_bits_mask = _GEN_18;
  assign io_in_0_b_bits_data = _GEN_19;
  assign io_in_0_c_ready = 1'h1;
  assign io_in_0_d_valid = _T_162;
  assign io_in_0_d_bits_opcode = io_out_0_d_bits_opcode;
  assign io_in_0_d_bits_param = io_out_0_d_bits_param;
  assign io_in_0_d_bits_size = _GEN_0;
  assign io_in_0_d_bits_source = _T_165;
  assign io_in_0_d_bits_sink = io_out_0_d_bits_sink;
  assign io_in_0_d_bits_addr_lo = _T_164;
  assign io_in_0_d_bits_data = io_out_0_d_bits_data;
  assign io_in_0_d_bits_error = _T_170;
  assign io_in_0_e_ready = 1'h1;
  assign io_out_0_a_valid = Repeater_io_deq_valid;
  assign io_out_0_a_bits_opcode = Repeater_io_deq_bits_opcode;
  assign io_out_0_a_bits_param = Repeater_io_deq_bits_param;
  assign io_out_0_a_bits_size = _T_211[1:0];
  assign io_out_0_a_bits_source = _T_261;
  assign io_out_0_a_bits_address = _T_260;
  assign io_out_0_a_bits_mask = _T_278;
  assign io_out_0_a_bits_data = io_in_0_a_bits_data;
  assign io_out_0_b_ready = 1'h1;
  assign io_out_0_c_valid = 1'h0;
  assign io_out_0_c_bits_opcode = _GEN_20;
  assign io_out_0_c_bits_param = _GEN_21;
  assign io_out_0_c_bits_size = _GEN_22;
  assign io_out_0_c_bits_source = _GEN_23;
  assign io_out_0_c_bits_address = _GEN_24;
  assign io_out_0_c_bits_data = _GEN_25;
  assign io_out_0_c_bits_error = _GEN_26;
  assign io_out_0_d_ready = _T_159;
  assign io_out_0_e_valid = 1'h0;
  assign io_out_0_e_bits_sink = _GEN_27;
  assign _T_95 = io_out_0_d_bits_source[2:0];
  assign _T_97 = _T_92 == 3'h0;
  assign _T_99 = _T_95 == 3'h0;
  assign _T_102 = 4'h1 << io_out_0_d_bits_size;
  assign _T_103 = _T_102[2:0];
  assign _T_106 = 5'h3 << io_out_0_d_bits_size;
  assign _T_107 = _T_106[1:0];
  assign _T_108 = ~ _T_107;
  assign _T_109 = io_out_0_d_bits_opcode[0];
  assign _T_125 = _T_103[2:2];
  assign _T_126 = _T_109 ? 1'h1 : _T_125;
  assign _GEN_5 = {{2'd0}, _T_95};
  assign _T_127 = _GEN_5 << 2;
  assign _GEN_6 = {{3'd0}, _T_108};
  assign _T_128 = _T_127 | _GEN_6;
  assign _GEN_7 = {{1'd0}, _T_128};
  assign _T_129 = _GEN_7 << 1;
  assign _T_131 = _T_129 | 6'h1;
  assign _T_133 = {1'h0,_T_128};
  assign _T_134 = ~ _T_133;
  assign _T_135 = _T_131 & _T_134;
  assign _T_136 = _T_135[5:4];
  assign _T_137 = _T_135[3:0];
  assign _T_139 = _T_136 != 2'h0;
  assign _GEN_8 = {{2'd0}, _T_136};
  assign _T_140 = _GEN_8 | _T_137;
  assign _T_141 = _T_140[3:2];
  assign _T_142 = _T_140[1:0];
  assign _T_144 = _T_141 != 2'h0;
  assign _T_145 = _T_141 | _T_142;
  assign _T_146 = _T_145[1];
  assign _T_147 = {_T_144,_T_146};
  assign _T_148 = {_T_139,_T_147};
  assign _T_149 = io_out_0_d_ready & io_out_0_d_valid;
  assign _GEN_9 = {{2'd0}, _T_126};
  assign _T_150 = _T_92 - _GEN_9;
  assign _T_151 = $unsigned(_T_150);
  assign _T_152 = _T_151[2:0];
  assign _T_153 = _T_97 ? _T_95 : _T_152;
  assign _GEN_0 = _T_97 ? _T_148 : _T_94;
  assign _GEN_1 = _T_149 ? _T_153 : _T_92;
  assign _GEN_2 = _T_149 ? _GEN_0 : _T_94;
  assign _T_155 = _T_109 == 1'h0;
  assign _T_157 = _T_99 == 1'h0;
  assign _T_158 = _T_155 & _T_157;
  assign _T_159 = io_in_0_d_ready | _T_158;
  assign _T_161 = _T_158 == 1'h0;
  assign _T_162 = io_out_0_d_valid & _T_161;
  assign _T_163 = ~ _T_108;
  assign _T_164 = io_out_0_d_bits_addr_lo & _T_163;
  assign _T_165 = io_out_0_d_bits_source[3:3];
  assign _T_170 = _T_169 | io_out_0_d_bits_error;
  assign _T_173 = _T_158 ? _T_170 : 1'h0;
  assign _GEN_3 = _T_149 ? _T_173 : _T_169;
  assign Repeater_clock = clock;
  assign Repeater_reset = reset;
  assign Repeater_io_repeat = _T_252;
  assign Repeater_io_enq_valid = io_in_0_a_valid;
  assign Repeater_io_enq_bits_opcode = io_in_0_a_bits_opcode;
  assign Repeater_io_enq_bits_param = io_in_0_a_bits_param;
  assign Repeater_io_enq_bits_size = io_in_0_a_bits_size;
  assign Repeater_io_enq_bits_source = io_in_0_a_bits_source;
  assign Repeater_io_enq_bits_address = io_in_0_a_bits_address;
  assign Repeater_io_enq_bits_mask = io_in_0_a_bits_mask;
  assign Repeater_io_enq_bits_data = io_in_0_a_bits_data;
  assign Repeater_io_deq_ready = io_out_0_a_ready;
  assign _T_188_0 = 1'h1;
  assign _T_210 = Repeater_io_deq_bits_size > 3'h2;
  assign _T_211 = _T_210 ? 3'h2 : Repeater_io_deq_bits_size;
  assign _T_214 = 12'h1f << Repeater_io_deq_bits_size;
  assign _T_215 = _T_214[4:0];
  assign _T_216 = ~ _T_215;
  assign _T_219 = 9'h3 << _T_211;
  assign _T_220 = _T_219[1:0];
  assign _T_221 = ~ _T_220;
  assign _T_222 = Repeater_io_deq_bits_opcode[2];
  assign _T_224 = _T_222 == 1'h0;
  assign _T_231 = _T_229 == 3'h0;
  assign _T_232 = _T_216[4:2];
  assign _T_234 = _T_229 - 3'h1;
  assign _T_235 = $unsigned(_T_234);
  assign _T_236 = _T_235[2:0];
  assign _T_237 = _T_231 ? _T_232 : _T_236;
  assign _T_238 = ~ _T_237;
  assign _T_241 = ~ _T_238;
  assign _T_247 = io_out_0_a_ready & io_out_0_a_valid;
  assign _GEN_4 = _T_247 ? _T_241 : _T_229;
  assign _T_249 = _T_224 == 1'h0;
  assign _T_251 = _T_241 != 3'h0;
  assign _T_252 = _T_249 & _T_251;
  assign _GEN_10 = {{2'd0}, _T_237};
  assign _T_253 = _GEN_10 << 2;
  assign _T_254 = ~ _T_216;
  assign _T_255 = _T_253 | _T_254;
  assign _GEN_11 = {{3'd0}, _T_221};
  assign _T_256 = _T_255 | _GEN_11;
  assign _T_258 = _T_256 | 5'h3;
  assign _T_259 = ~ _T_258;
  assign _GEN_12 = {{25'd0}, _T_259};
  assign _T_260 = Repeater_io_deq_bits_address | _GEN_12;
  assign _T_261 = {Repeater_io_deq_bits_source,_T_241};
  assign _T_263 = Repeater_io_full == 1'h0;
  assign _T_266 = _T_263 | _T_249;
  assign _T_267 = _T_266 | reset;
  assign _T_269 = _T_267 == 1'h0;
  assign _T_273 = Repeater_io_deq_bits_mask == 4'hf;
  assign _T_274 = _T_263 | _T_273;
  assign _T_275 = _T_274 | reset;
  assign _T_277 = _T_275 == 1'h0;
  assign _T_278 = Repeater_io_full ? 4'hf : io_in_0_a_bits_mask;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_92 = _GEN_28[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_94 = _GEN_29[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_30 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_169 = _GEN_30[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_31 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_229 = _GEN_31[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_32 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_13 = _GEN_32[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_33 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_14 = _GEN_33[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_34 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_15 = _GEN_34[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_35 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_16 = _GEN_35[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_36 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_17 = _GEN_36[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_37 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_18 = _GEN_37[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_38 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_19 = _GEN_38[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_39 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_20 = _GEN_39[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_40 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_21 = _GEN_40[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_41 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_22 = _GEN_41[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_42 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_23 = _GEN_42[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_43 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_24 = _GEN_43[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_44 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_25 = _GEN_44[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_45 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_26 = _GEN_45[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_46 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_27 = _GEN_46[0:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      _T_92 <= 3'h0;
    end else begin
      if (_T_149) begin
        if (_T_97) begin
          _T_92 <= _T_95;
        end else begin
          _T_92 <= _T_152;
        end
      end
    end
    if (_T_149) begin
      if (_T_97) begin
        _T_94 <= _T_148;
      end
    end
    if (reset) begin
      _T_169 <= 1'h0;
    end else begin
      if (_T_149) begin
        if (_T_158) begin
          _T_169 <= _T_170;
        end else begin
          _T_169 <= 1'h0;
        end
      end
    end
    if (reset) begin
      _T_229 <= 3'h0;
    end else begin
      if (_T_247) begin
        _T_229 <= _T_241;
      end
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Fragmenter.scala:148 assert (!out.d.valid || (acknum_fragment & acknum_size) === UInt(0))\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_269) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Fragmenter.scala:243 assert (!repeater.io.full || !aHasData)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_269) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_277) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Fragmenter.scala:246 assert (!repeater.io.full || in_a.bits.mask === fullMask)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_277) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
