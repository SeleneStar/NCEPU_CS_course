//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLMonitor_54(
  input         clock,
  input         reset,
  input         io_in_0_a_ready,
  input         io_in_0_a_valid,
  input  [2:0]  io_in_0_a_bits_opcode,
  input  [2:0]  io_in_0_a_bits_param,
  input  [2:0]  io_in_0_a_bits_size,
  input         io_in_0_a_bits_source,
  input  [29:0] io_in_0_a_bits_address,
  input  [3:0]  io_in_0_a_bits_mask,
  input  [31:0] io_in_0_a_bits_data,
  input         io_in_0_b_ready,
  input         io_in_0_b_valid,
  input  [2:0]  io_in_0_b_bits_opcode,
  input  [1:0]  io_in_0_b_bits_param,
  input  [2:0]  io_in_0_b_bits_size,
  input         io_in_0_b_bits_source,
  input  [29:0] io_in_0_b_bits_address,
  input  [3:0]  io_in_0_b_bits_mask,
  input  [31:0] io_in_0_b_bits_data,
  input         io_in_0_c_ready,
  input         io_in_0_c_valid,
  input  [2:0]  io_in_0_c_bits_opcode,
  input  [2:0]  io_in_0_c_bits_param,
  input  [2:0]  io_in_0_c_bits_size,
  input         io_in_0_c_bits_source,
  input  [29:0] io_in_0_c_bits_address,
  input  [31:0] io_in_0_c_bits_data,
  input         io_in_0_c_bits_error,
  input         io_in_0_d_ready,
  input         io_in_0_d_valid,
  input  [2:0]  io_in_0_d_bits_opcode,
  input  [1:0]  io_in_0_d_bits_param,
  input  [2:0]  io_in_0_d_bits_size,
  input         io_in_0_d_bits_source,
  input         io_in_0_d_bits_sink,
  input  [1:0]  io_in_0_d_bits_addr_lo,
  input  [31:0] io_in_0_d_bits_data,
  input         io_in_0_d_bits_error,
  input         io_in_0_e_ready,
  input         io_in_0_e_valid,
  input         io_in_0_e_bits_sink
);
  wire  _T_104;
  wire  _T_105;
  wire  _T_107;
  wire  _T_118_0;
  wire [11:0] _T_124;
  wire [4:0] _T_125;
  wire [4:0] _T_126;
  wire [29:0] _GEN_17;
  wire [29:0] _T_127;
  wire  _T_129;
  wire  _T_130;
  wire [1:0] _T_132;
  wire [1:0] _T_135;
  wire  _T_137;
  wire  _T_139;
  wire  _T_140;
  wire  _T_142;
  wire  _T_144;
  wire  _T_145;
  wire  _T_147;
  wire  _T_148;
  wire  _T_149;
  wire  _T_150;
  wire  _T_152;
  wire  _T_153;
  wire  _T_154;
  wire  _T_155;
  wire  _T_156;
  wire  _T_157;
  wire  _T_158;
  wire  _T_159;
  wire  _T_160;
  wire  _T_161;
  wire  _T_162;
  wire  _T_163;
  wire  _T_164;
  wire [1:0] _T_165;
  wire [1:0] _T_166;
  wire [3:0] _T_167;
  wire  _T_169;
  wire [29:0] _T_174;
  wire [30:0] _T_175;
  wire [30:0] _T_177;
  wire [30:0] _T_178;
  wire  _T_180;
  wire  _T_186;
  wire  _T_191;
  wire  _T_193;
  wire  _T_196;
  wire  _T_198;
  wire  _T_199;
  wire  _T_201;
  wire  _T_203;
  wire  _T_204;
  wire  _T_206;
  wire [3:0] _T_207;
  wire  _T_209;
  wire  _T_210;
  wire  _T_212;
  wire  _T_214;
  wire  _T_219;
  wire  _T_230;
  wire  _T_233;
  wire  _T_235;
  wire  _T_243;
  wire  _T_244;
  wire  _T_246;
  wire  _T_247;
  wire  _T_248;
  wire  _T_250;
  wire  _T_252;
  wire  _T_290;
  wire [3:0] _T_323;
  wire [3:0] _T_324;
  wire  _T_326;
  wire  _T_327;
  wire  _T_329;
  wire  _T_331;
  wire  _T_356;
  wire  _T_357;
  wire  _T_359;
  wire  _T_365;
  wire  _T_390;
  wire  _T_391;
  wire  _T_393;
  wire  _T_399;
  wire  _T_428;
  wire  _T_429;
  wire  _T_431;
  wire  _T_442_0;
  wire [11:0] _T_448;
  wire [4:0] _T_449;
  wire [4:0] _T_450;
  wire [4:0] _GEN_18;
  wire [4:0] _T_451;
  wire  _T_453;
  wire  _T_459;
  wire  _T_460;
  wire  _T_462;
  wire  _T_463;
  wire  _T_465;
  wire  _T_470;
  wire  _T_471;
  wire  _T_473;
  wire  _T_475;
  wire  _T_476;
  wire  _T_478;
  wire  _T_480;
  wire  _T_481;
  wire  _T_483;
  wire  _T_485;
  wire  _T_501;
  wire  _T_502;
  wire  _T_504;
  wire  _T_506;
  wire  _T_527;
  wire  _T_543;
  wire  _T_559;
  wire  _T_580;
  wire  _T_581;
  wire  _T_583;
  wire  _T_585;
  wire  _T_586;
  wire  _T_588;
  wire  _T_590;
  wire  _T_591;
  wire  _T_593;
  wire  _T_594;
  wire [2:0] _T_600;
  wire  _T_601;
  wire  _T_603;
  wire [2:0] _T_605;
  reg [2:0] _T_608;
  reg [31:0] _GEN_20;
  wire [3:0] _T_610;
  wire [3:0] _T_611;
  wire [2:0] _T_612;
  wire  _T_614;
  wire [2:0] _T_623;
  wire [2:0] _GEN_0;
  reg [2:0] _T_625;
  reg [31:0] _GEN_21;
  reg [2:0] _T_627;
  reg [31:0] _GEN_22;
  reg [2:0] _T_629;
  reg [31:0] _GEN_23;
  reg  _T_631;
  reg [31:0] _GEN_24;
  reg [29:0] _T_633;
  reg [31:0] _GEN_25;
  wire  _T_635;
  wire  _T_636;
  wire  _T_637;
  wire  _T_638;
  wire  _T_640;
  wire  _T_641;
  wire  _T_642;
  wire  _T_644;
  wire  _T_645;
  wire  _T_646;
  wire  _T_648;
  wire  _T_649;
  wire  _T_650;
  wire  _T_652;
  wire  _T_653;
  wire  _T_654;
  wire  _T_656;
  wire  _T_658;
  wire [2:0] _GEN_1;
  wire [2:0] _GEN_2;
  wire [2:0] _GEN_3;
  wire  _GEN_4;
  wire [29:0] _GEN_5;
  wire  _T_659;
  wire [2:0] _T_665;
  wire  _T_666;
  wire [2:0] _T_668;
  reg [2:0] _T_671;
  reg [31:0] _GEN_26;
  wire [3:0] _T_673;
  wire [3:0] _T_674;
  wire [2:0] _T_675;
  wire  _T_677;
  wire [2:0] _T_686;
  wire [2:0] _GEN_6;
  reg [2:0] _T_688;
  reg [31:0] _GEN_27;
  reg [1:0] _T_690;
  reg [31:0] _GEN_28;
  reg [2:0] _T_692;
  reg [31:0] _GEN_29;
  reg  _T_694;
  reg [31:0] _GEN_30;
  reg  _T_696;
  reg [31:0] _GEN_31;
  reg [1:0] _T_698;
  reg [31:0] _GEN_32;
  wire  _T_700;
  wire  _T_701;
  wire  _T_702;
  wire  _T_703;
  wire  _T_705;
  wire  _T_706;
  wire  _T_707;
  wire  _T_709;
  wire  _T_710;
  wire  _T_711;
  wire  _T_713;
  wire  _T_714;
  wire  _T_715;
  wire  _T_717;
  wire  _T_718;
  wire  _T_719;
  wire  _T_721;
  wire  _T_722;
  wire  _T_723;
  wire  _T_725;
  wire  _T_727;
  wire [2:0] _GEN_7;
  wire [1:0] _GEN_8;
  wire [2:0] _GEN_9;
  wire  _GEN_10;
  wire  _GEN_11;
  wire [1:0] _GEN_12;
  reg [1:0] _T_730;
  reg [31:0] _GEN_34;
  reg [2:0] _T_745;
  reg [31:0] _GEN_35;
  wire [3:0] _T_747;
  wire [3:0] _T_748;
  wire [2:0] _T_749;
  wire  _T_751;
  wire [2:0] _T_760;
  wire [2:0] _GEN_13;
  reg [2:0] _T_773;
  reg [31:0] _GEN_36;
  wire [3:0] _T_775;
  wire [3:0] _T_776;
  wire [2:0] _T_777;
  wire  _T_779;
  wire [2:0] _T_788;
  wire [2:0] _GEN_14;
  wire [1:0] _T_791;
  wire  _T_793;
  wire [1:0] _T_797;
  wire [1:0] _T_798;
  wire  _T_799;
  wire  _T_801;
  wire  _T_802;
  wire  _T_804;
  wire [1:0] _GEN_15;
  wire [1:0] _T_807;
  wire  _T_811;
  wire  _T_815;
  wire  _T_816;
  wire [1:0] _T_818;
  wire [1:0] _T_819;
  wire [1:0] _T_820;
  wire  _T_821;
  wire  _T_822;
  wire  _T_824;
  wire [1:0] _GEN_16;
  wire  _T_825;
  wire  _T_827;
  wire  _T_829;
  wire  _T_830;
  wire  _T_831;
  wire  _T_833;
  wire [1:0] _T_834;
  wire [1:0] _T_835;
  wire [1:0] _T_836;
  wire  _GEN_19;
  wire  _GEN_33;
  wire  _GEN_43;
  wire  _GEN_53;
  wire  _GEN_63;
  wire  _GEN_73;
  wire  _GEN_83;
  wire  _GEN_91;
  wire  _GEN_101;
  wire  _GEN_109;
  wire  _GEN_117;
  wire  _GEN_123;
  wire  _GEN_129;
  assign _T_104 = io_in_0_a_bits_opcode <= 3'h6;
  assign _T_105 = _T_104 | reset;
  assign _T_107 = _T_105 == 1'h0;
  assign _T_118_0 = 1'h1;
  assign _T_124 = 12'h1f << io_in_0_a_bits_size;
  assign _T_125 = _T_124[4:0];
  assign _T_126 = ~ _T_125;
  assign _GEN_17 = {{25'd0}, _T_126};
  assign _T_127 = io_in_0_a_bits_address & _GEN_17;
  assign _T_129 = _T_127 == 30'h0;
  assign _T_130 = io_in_0_a_bits_size[0];
  assign _T_132 = 2'h1 << _T_130;
  assign _T_135 = _T_132 | 2'h1;
  assign _T_137 = io_in_0_a_bits_size >= 3'h2;
  assign _T_139 = _T_135[1];
  assign _T_140 = io_in_0_a_bits_address[1];
  assign _T_142 = _T_140 == 1'h0;
  assign _T_144 = _T_139 & _T_142;
  assign _T_145 = _T_137 | _T_144;
  assign _T_147 = _T_139 & _T_140;
  assign _T_148 = _T_137 | _T_147;
  assign _T_149 = _T_135[0];
  assign _T_150 = io_in_0_a_bits_address[0];
  assign _T_152 = _T_150 == 1'h0;
  assign _T_153 = _T_142 & _T_152;
  assign _T_154 = _T_149 & _T_153;
  assign _T_155 = _T_145 | _T_154;
  assign _T_156 = _T_142 & _T_150;
  assign _T_157 = _T_149 & _T_156;
  assign _T_158 = _T_145 | _T_157;
  assign _T_159 = _T_140 & _T_152;
  assign _T_160 = _T_149 & _T_159;
  assign _T_161 = _T_148 | _T_160;
  assign _T_162 = _T_140 & _T_150;
  assign _T_163 = _T_149 & _T_162;
  assign _T_164 = _T_148 | _T_163;
  assign _T_165 = {_T_158,_T_155};
  assign _T_166 = {_T_164,_T_161};
  assign _T_167 = {_T_166,_T_165};
  assign _T_169 = io_in_0_a_bits_opcode == 3'h6;
  assign _T_174 = io_in_0_a_bits_address ^ 30'h20000000;
  assign _T_175 = {1'b0,$signed(_T_174)};
  assign _T_177 = $signed(_T_175) & $signed(-31'sh2000);
  assign _T_178 = $signed(_T_177);
  assign _T_180 = $signed(_T_178) == $signed(31'sh0);
  assign _T_186 = reset == 1'h0;
  assign _T_191 = _T_118_0 | reset;
  assign _T_193 = _T_191 == 1'h0;
  assign _T_196 = _T_137 | reset;
  assign _T_198 = _T_196 == 1'h0;
  assign _T_199 = _T_129 | reset;
  assign _T_201 = _T_199 == 1'h0;
  assign _T_203 = io_in_0_a_bits_param <= 3'h2;
  assign _T_204 = _T_203 | reset;
  assign _T_206 = _T_204 == 1'h0;
  assign _T_207 = ~ io_in_0_a_bits_mask;
  assign _T_209 = _T_207 == 4'h0;
  assign _T_210 = _T_209 | reset;
  assign _T_212 = _T_210 == 1'h0;
  assign _T_214 = io_in_0_a_bits_opcode == 3'h4;
  assign _T_219 = io_in_0_a_bits_size <= 3'h5;
  assign _T_230 = _T_219 & _T_180;
  assign _T_233 = _T_230 | reset;
  assign _T_235 = _T_233 == 1'h0;
  assign _T_243 = io_in_0_a_bits_param == 3'h0;
  assign _T_244 = _T_243 | reset;
  assign _T_246 = _T_244 == 1'h0;
  assign _T_247 = io_in_0_a_bits_mask == _T_167;
  assign _T_248 = _T_247 | reset;
  assign _T_250 = _T_248 == 1'h0;
  assign _T_252 = io_in_0_a_bits_opcode == 3'h0;
  assign _T_290 = io_in_0_a_bits_opcode == 3'h1;
  assign _T_323 = ~ _T_167;
  assign _T_324 = io_in_0_a_bits_mask & _T_323;
  assign _T_326 = _T_324 == 4'h0;
  assign _T_327 = _T_326 | reset;
  assign _T_329 = _T_327 == 1'h0;
  assign _T_331 = io_in_0_a_bits_opcode == 3'h2;
  assign _T_356 = io_in_0_a_bits_param <= 3'h4;
  assign _T_357 = _T_356 | reset;
  assign _T_359 = _T_357 == 1'h0;
  assign _T_365 = io_in_0_a_bits_opcode == 3'h3;
  assign _T_390 = io_in_0_a_bits_param <= 3'h3;
  assign _T_391 = _T_390 | reset;
  assign _T_393 = _T_391 == 1'h0;
  assign _T_399 = io_in_0_a_bits_opcode == 3'h5;
  assign _T_428 = io_in_0_d_bits_opcode <= 3'h6;
  assign _T_429 = _T_428 | reset;
  assign _T_431 = _T_429 == 1'h0;
  assign _T_442_0 = 1'h1;
  assign _T_448 = 12'h1f << io_in_0_d_bits_size;
  assign _T_449 = _T_448[4:0];
  assign _T_450 = ~ _T_449;
  assign _GEN_18 = {{3'd0}, io_in_0_d_bits_addr_lo};
  assign _T_451 = _GEN_18 & _T_450;
  assign _T_453 = _T_451 == 5'h0;
  assign _T_459 = io_in_0_d_bits_opcode == 3'h6;
  assign _T_460 = _T_442_0 | reset;
  assign _T_462 = _T_460 == 1'h0;
  assign _T_463 = _T_453 | reset;
  assign _T_465 = _T_463 == 1'h0;
  assign _T_470 = io_in_0_d_bits_size >= 3'h2;
  assign _T_471 = _T_470 | reset;
  assign _T_473 = _T_471 == 1'h0;
  assign _T_475 = io_in_0_d_bits_param == 2'h0;
  assign _T_476 = _T_475 | reset;
  assign _T_478 = _T_476 == 1'h0;
  assign _T_480 = io_in_0_d_bits_error == 1'h0;
  assign _T_481 = _T_480 | reset;
  assign _T_483 = _T_481 == 1'h0;
  assign _T_485 = io_in_0_d_bits_opcode == 3'h4;
  assign _T_501 = io_in_0_d_bits_param <= 2'h2;
  assign _T_502 = _T_501 | reset;
  assign _T_504 = _T_502 == 1'h0;
  assign _T_506 = io_in_0_d_bits_opcode == 3'h5;
  assign _T_527 = io_in_0_d_bits_opcode == 3'h0;
  assign _T_543 = io_in_0_d_bits_opcode == 3'h1;
  assign _T_559 = io_in_0_d_bits_opcode == 3'h2;
  assign _T_580 = io_in_0_b_valid == 1'h0;
  assign _T_581 = _T_580 | reset;
  assign _T_583 = _T_581 == 1'h0;
  assign _T_585 = io_in_0_c_valid == 1'h0;
  assign _T_586 = _T_585 | reset;
  assign _T_588 = _T_586 == 1'h0;
  assign _T_590 = io_in_0_e_valid == 1'h0;
  assign _T_591 = _T_590 | reset;
  assign _T_593 = _T_591 == 1'h0;
  assign _T_594 = io_in_0_a_ready & io_in_0_a_valid;
  assign _T_600 = _T_126[4:2];
  assign _T_601 = io_in_0_a_bits_opcode[2];
  assign _T_603 = _T_601 == 1'h0;
  assign _T_605 = _T_603 ? _T_600 : 3'h0;
  assign _T_610 = _T_608 - 3'h1;
  assign _T_611 = $unsigned(_T_610);
  assign _T_612 = _T_611[2:0];
  assign _T_614 = _T_608 == 3'h0;
  assign _T_623 = _T_614 ? _T_605 : _T_612;
  assign _GEN_0 = _T_594 ? _T_623 : _T_608;
  assign _T_635 = _T_614 == 1'h0;
  assign _T_636 = io_in_0_a_valid & _T_635;
  assign _T_637 = io_in_0_a_bits_opcode == _T_625;
  assign _T_638 = _T_637 | reset;
  assign _T_640 = _T_638 == 1'h0;
  assign _T_641 = io_in_0_a_bits_param == _T_627;
  assign _T_642 = _T_641 | reset;
  assign _T_644 = _T_642 == 1'h0;
  assign _T_645 = io_in_0_a_bits_size == _T_629;
  assign _T_646 = _T_645 | reset;
  assign _T_648 = _T_646 == 1'h0;
  assign _T_649 = io_in_0_a_bits_source == _T_631;
  assign _T_650 = _T_649 | reset;
  assign _T_652 = _T_650 == 1'h0;
  assign _T_653 = io_in_0_a_bits_address == _T_633;
  assign _T_654 = _T_653 | reset;
  assign _T_656 = _T_654 == 1'h0;
  assign _T_658 = _T_594 & _T_614;
  assign _GEN_1 = _T_658 ? io_in_0_a_bits_opcode : _T_625;
  assign _GEN_2 = _T_658 ? io_in_0_a_bits_param : _T_627;
  assign _GEN_3 = _T_658 ? io_in_0_a_bits_size : _T_629;
  assign _GEN_4 = _T_658 ? io_in_0_a_bits_source : _T_631;
  assign _GEN_5 = _T_658 ? io_in_0_a_bits_address : _T_633;
  assign _T_659 = io_in_0_d_ready & io_in_0_d_valid;
  assign _T_665 = _T_450[4:2];
  assign _T_666 = io_in_0_d_bits_opcode[0];
  assign _T_668 = _T_666 ? _T_665 : 3'h0;
  assign _T_673 = _T_671 - 3'h1;
  assign _T_674 = $unsigned(_T_673);
  assign _T_675 = _T_674[2:0];
  assign _T_677 = _T_671 == 3'h0;
  assign _T_686 = _T_677 ? _T_668 : _T_675;
  assign _GEN_6 = _T_659 ? _T_686 : _T_671;
  assign _T_700 = _T_677 == 1'h0;
  assign _T_701 = io_in_0_d_valid & _T_700;
  assign _T_702 = io_in_0_d_bits_opcode == _T_688;
  assign _T_703 = _T_702 | reset;
  assign _T_705 = _T_703 == 1'h0;
  assign _T_706 = io_in_0_d_bits_param == _T_690;
  assign _T_707 = _T_706 | reset;
  assign _T_709 = _T_707 == 1'h0;
  assign _T_710 = io_in_0_d_bits_size == _T_692;
  assign _T_711 = _T_710 | reset;
  assign _T_713 = _T_711 == 1'h0;
  assign _T_714 = io_in_0_d_bits_source == _T_694;
  assign _T_715 = _T_714 | reset;
  assign _T_717 = _T_715 == 1'h0;
  assign _T_718 = io_in_0_d_bits_sink == _T_696;
  assign _T_719 = _T_718 | reset;
  assign _T_721 = _T_719 == 1'h0;
  assign _T_722 = io_in_0_d_bits_addr_lo == _T_698;
  assign _T_723 = _T_722 | reset;
  assign _T_725 = _T_723 == 1'h0;
  assign _T_727 = _T_659 & _T_677;
  assign _GEN_7 = _T_727 ? io_in_0_d_bits_opcode : _T_688;
  assign _GEN_8 = _T_727 ? io_in_0_d_bits_param : _T_690;
  assign _GEN_9 = _T_727 ? io_in_0_d_bits_size : _T_692;
  assign _GEN_10 = _T_727 ? io_in_0_d_bits_source : _T_694;
  assign _GEN_11 = _T_727 ? io_in_0_d_bits_sink : _T_696;
  assign _GEN_12 = _T_727 ? io_in_0_d_bits_addr_lo : _T_698;
  assign _T_747 = _T_745 - 3'h1;
  assign _T_748 = $unsigned(_T_747);
  assign _T_749 = _T_748[2:0];
  assign _T_751 = _T_745 == 3'h0;
  assign _T_760 = _T_751 ? _T_605 : _T_749;
  assign _GEN_13 = _T_594 ? _T_760 : _T_745;
  assign _T_775 = _T_773 - 3'h1;
  assign _T_776 = $unsigned(_T_775);
  assign _T_777 = _T_776[2:0];
  assign _T_779 = _T_773 == 3'h0;
  assign _T_788 = _T_779 ? _T_668 : _T_777;
  assign _GEN_14 = _T_659 ? _T_788 : _T_773;
  assign _T_791 = _GEN_15;
  assign _T_793 = _T_594 & _T_751;
  assign _T_797 = 2'h1 << io_in_0_a_bits_source;
  assign _T_798 = _T_730 >> io_in_0_a_bits_source;
  assign _T_799 = _T_798[0];
  assign _T_801 = _T_799 == 1'h0;
  assign _T_802 = _T_801 | reset;
  assign _T_804 = _T_802 == 1'h0;
  assign _GEN_15 = _T_793 ? _T_797 : 2'h0;
  assign _T_807 = _GEN_16;
  assign _T_811 = _T_659 & _T_779;
  assign _T_815 = _T_459 == 1'h0;
  assign _T_816 = _T_811 & _T_815;
  assign _T_818 = 2'h1 << io_in_0_d_bits_source;
  assign _T_819 = _T_791 | _T_730;
  assign _T_820 = _T_819 >> io_in_0_d_bits_source;
  assign _T_821 = _T_820[0];
  assign _T_822 = _T_821 | reset;
  assign _T_824 = _T_822 == 1'h0;
  assign _GEN_16 = _T_816 ? _T_818 : 2'h0;
  assign _T_825 = _T_791 != _T_807;
  assign _T_827 = _T_791 != 2'h0;
  assign _T_829 = _T_827 == 1'h0;
  assign _T_830 = _T_825 | _T_829;
  assign _T_831 = _T_830 | reset;
  assign _T_833 = _T_831 == 1'h0;
  assign _T_834 = _T_730 | _T_791;
  assign _T_835 = ~ _T_807;
  assign _T_836 = _T_834 & _T_835;
  assign _GEN_19 = io_in_0_a_valid & _T_169;
  assign _GEN_33 = io_in_0_a_valid & _T_214;
  assign _GEN_43 = io_in_0_a_valid & _T_252;
  assign _GEN_53 = io_in_0_a_valid & _T_290;
  assign _GEN_63 = io_in_0_a_valid & _T_331;
  assign _GEN_73 = io_in_0_a_valid & _T_365;
  assign _GEN_83 = io_in_0_a_valid & _T_399;
  assign _GEN_91 = io_in_0_d_valid & _T_459;
  assign _GEN_101 = io_in_0_d_valid & _T_485;
  assign _GEN_109 = io_in_0_d_valid & _T_506;
  assign _GEN_117 = io_in_0_d_valid & _T_527;
  assign _GEN_123 = io_in_0_d_valid & _T_543;
  assign _GEN_129 = io_in_0_d_valid & _T_559;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_20 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_608 = _GEN_20[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_625 = _GEN_21[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_22 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_627 = _GEN_22[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_629 = _GEN_23[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_24 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_631 = _GEN_24[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_633 = _GEN_25[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_671 = _GEN_26[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_688 = _GEN_27[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_690 = _GEN_28[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_29 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_692 = _GEN_29[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_30 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_694 = _GEN_30[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_31 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_696 = _GEN_31[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_32 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_698 = _GEN_32[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_34 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_730 = _GEN_34[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_35 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_745 = _GEN_35[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_36 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_773 = _GEN_36[2:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      _T_608 <= 3'h0;
    end else begin
      if (_T_594) begin
        if (_T_614) begin
          if (_T_603) begin
            _T_608 <= _T_600;
          end else begin
            _T_608 <= 3'h0;
          end
        end else begin
          _T_608 <= _T_612;
        end
      end
    end
    if (_T_658) begin
      _T_625 <= io_in_0_a_bits_opcode;
    end
    if (_T_658) begin
      _T_627 <= io_in_0_a_bits_param;
    end
    if (_T_658) begin
      _T_629 <= io_in_0_a_bits_size;
    end
    if (_T_658) begin
      _T_631 <= io_in_0_a_bits_source;
    end
    if (_T_658) begin
      _T_633 <= io_in_0_a_bits_address;
    end
    if (reset) begin
      _T_671 <= 3'h0;
    end else begin
      if (_T_659) begin
        if (_T_677) begin
          if (_T_666) begin
            _T_671 <= _T_665;
          end else begin
            _T_671 <= 3'h0;
          end
        end else begin
          _T_671 <= _T_675;
        end
      end
    end
    if (_T_727) begin
      _T_688 <= io_in_0_d_bits_opcode;
    end
    if (_T_727) begin
      _T_690 <= io_in_0_d_bits_param;
    end
    if (_T_727) begin
      _T_692 <= io_in_0_d_bits_size;
    end
    if (_T_727) begin
      _T_694 <= io_in_0_d_bits_source;
    end
    if (_T_727) begin
      _T_696 <= io_in_0_d_bits_sink;
    end
    if (_T_727) begin
      _T_698 <= io_in_0_d_bits_addr_lo;
    end
    if (reset) begin
      _T_730 <= 2'h0;
    end else begin
      _T_730 <= _T_836;
    end
    if (reset) begin
      _T_745 <= 3'h0;
    end else begin
      if (_T_594) begin
        if (_T_751) begin
          if (_T_603) begin
            _T_745 <= _T_600;
          end else begin
            _T_745 <= 3'h0;
          end
        end else begin
          _T_745 <= _T_749;
        end
      end
    end
    if (reset) begin
      _T_773 <= 3'h0;
    end else begin
      if (_T_659) begin
        if (_T_779) begin
          if (_T_666) begin
            _T_773 <= _T_665;
          end else begin
            _T_773 <= 3'h0;
          end
        end else begin
          _T_773 <= _T_777;
        end
      end
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (io_in_0_a_valid & _T_107) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel has invalid opcode (connected at TileLink.scala:245:13)\n    at Monitor.scala:38 assert (TLMessages.isA(bundle.opcode), \"'A' channel has invalid opcode\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (io_in_0_a_valid & _T_107) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_186) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Acquire type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:46 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries Acquire type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_186) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_186) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Acquire from a client which does not support Probe (connected at TileLink.scala:245:13)\n    at Monitor.scala:47 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries Acquire from a client which does not support Probe\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_186) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Acquire carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:48 assert (source_ok, \"'A' channel Acquire carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_198) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Acquire smaller than a beat (connected at TileLink.scala:245:13)\n    at Monitor.scala:49 assert (bundle.size >= UInt(log2Ceil(edge.manager.beatBytes)), \"'A' channel Acquire smaller than a beat\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_198) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Acquire address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:50 assert (is_aligned, \"'A' channel Acquire address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_206) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Acquire carries invalid grow param (connected at TileLink.scala:245:13)\n    at Monitor.scala:51 assert (TLPermissions.isGrow(bundle.param), \"'A' channel Acquire carries invalid grow param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_206) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_19 & _T_212) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Acquire contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:52 assert (~bundle.mask === UInt(0), \"'A' channel Acquire contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_19 & _T_212) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_33 & _T_235) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Get type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:56 assert (edge.manager.supportsGetSafe(edge.address(bundle), bundle.size), \"'A' channel carries Get type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_33 & _T_235) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_33 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Get carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:57 assert (source_ok, \"'A' channel Get carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_33 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_33 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Get address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:58 assert (is_aligned, \"'A' channel Get address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_33 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_33 & _T_246) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Get carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:59 assert (bundle.param === UInt(0), \"'A' channel Get carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_33 & _T_246) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_33 & _T_250) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Get contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:60 assert (bundle.mask === mask, \"'A' channel Get contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_33 & _T_250) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_43 & _T_235) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries PutFull type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:64 assert (edge.manager.supportsPutFullSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutFull type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_43 & _T_235) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_43 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutFull carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:65 assert (source_ok, \"'A' channel PutFull carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_43 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_43 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutFull address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:66 assert (is_aligned, \"'A' channel PutFull address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_43 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_43 & _T_246) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutFull carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:67 assert (bundle.param === UInt(0), \"'A' channel PutFull carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_43 & _T_246) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_43 & _T_250) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutFull contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:68 assert (bundle.mask === mask, \"'A' channel PutFull contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_43 & _T_250) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_53 & _T_235) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries PutPartial type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:72 assert (edge.manager.supportsPutPartialSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutPartial type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_53 & _T_235) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_53 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutPartial carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:73 assert (source_ok, \"'A' channel PutPartial carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_53 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_53 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutPartial address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:74 assert (is_aligned, \"'A' channel PutPartial address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_53 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_53 & _T_246) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutPartial carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:75 assert (bundle.param === UInt(0), \"'A' channel PutPartial carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_53 & _T_246) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_53 & _T_329) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel PutPartial contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:76 assert ((bundle.mask & ~mask) === UInt(0), \"'A' channel PutPartial contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_53 & _T_329) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_63 & _T_186) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Arithmetic type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:80 assert (edge.manager.supportsArithmeticSafe(edge.address(bundle), bundle.size), \"'A' channel carries Arithmetic type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_63 & _T_186) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_63 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Arithmetic carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:81 assert (source_ok, \"'A' channel Arithmetic carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_63 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_63 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Arithmetic address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:82 assert (is_aligned, \"'A' channel Arithmetic address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_63 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_63 & _T_359) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Arithmetic carries invalid opcode param (connected at TileLink.scala:245:13)\n    at Monitor.scala:83 assert (TLAtomics.isArithmetic(bundle.param), \"'A' channel Arithmetic carries invalid opcode param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_63 & _T_359) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_63 & _T_250) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Arithmetic contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:84 assert (bundle.mask === mask, \"'A' channel Arithmetic contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_63 & _T_250) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_73 & _T_186) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Logical type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:88 assert (edge.manager.supportsLogicalSafe(edge.address(bundle), bundle.size), \"'A' channel carries Logical type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_73 & _T_186) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_73 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Logical carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:89 assert (source_ok, \"'A' channel Logical carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_73 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_73 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Logical address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:90 assert (is_aligned, \"'A' channel Logical address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_73 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_73 & _T_393) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Logical carries invalid opcode param (connected at TileLink.scala:245:13)\n    at Monitor.scala:91 assert (TLAtomics.isLogical(bundle.param), \"'A' channel Logical carries invalid opcode param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_73 & _T_393) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_73 & _T_250) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Logical contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:92 assert (bundle.mask === mask, \"'A' channel Logical contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_73 & _T_250) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_83 & _T_186) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel carries Hint type unsupported by manager (connected at TileLink.scala:245:13)\n    at Monitor.scala:96 assert (edge.manager.supportsHintSafe(edge.address(bundle), bundle.size), \"'A' channel carries Hint type unsupported by manager\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_83 & _T_186) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_83 & _T_193) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Hint carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:97 assert (source_ok, \"'A' channel Hint carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_83 & _T_193) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_83 & _T_201) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Hint address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:98 assert (is_aligned, \"'A' channel Hint address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_83 & _T_201) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_83 & _T_250) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel Hint contains invalid mask (connected at TileLink.scala:245:13)\n    at Monitor.scala:99 assert (bundle.mask === mask, \"'A' channel Hint contains invalid mask\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_83 & _T_250) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (io_in_0_d_valid & _T_431) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel has invalid opcode (connected at TileLink.scala:245:13)\n    at Monitor.scala:234 assert (TLMessages.isD(bundle.opcode), \"'D' channel has invalid opcode\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (io_in_0_d_valid & _T_431) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_91 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseAck carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:241 assert (source_ok, \"'D' channel ReleaseAck carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_91 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_91 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseAck address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:242 assert (is_aligned, \"'D' channel ReleaseAck address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_91 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseAck carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:243 assert (sink_ok, \"'D' channel ReleaseAck carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_91 & _T_473) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseAck smaller than a beat (connected at TileLink.scala:245:13)\n    at Monitor.scala:244 assert (bundle.size >= UInt(log2Ceil(edge.manager.beatBytes)), \"'D' channel ReleaseAck smaller than a beat\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_91 & _T_473) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_91 & _T_478) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseeAck carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:245 assert (bundle.param === UInt(0), \"'D' channel ReleaseeAck carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_91 & _T_478) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_91 & _T_483) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel ReleaseAck carries an error (connected at TileLink.scala:245:13)\n    at Monitor.scala:246 assert (!bundle.error, \"'D' channel ReleaseAck carries an error\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_91 & _T_483) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_101 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel Grant carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:250 assert (source_ok, \"'D' channel Grant carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_101 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_101 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel Grant address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:251 assert (is_aligned, \"'D' channel Grant address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_101 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel Grant carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:252 assert (sink_ok, \"'D' channel Grant carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_101 & _T_473) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel Grant smaller than a beat (connected at TileLink.scala:245:13)\n    at Monitor.scala:253 assert (bundle.size >= UInt(log2Ceil(edge.manager.beatBytes)), \"'D' channel Grant smaller than a beat\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_101 & _T_473) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_101 & _T_504) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel Grant carries invalid cap param (connected at TileLink.scala:245:13)\n    at Monitor.scala:254 assert (TLPermissions.isCap(bundle.param), \"'D' channel Grant carries invalid cap param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_101 & _T_504) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_109 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel GrantData carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:258 assert (source_ok, \"'D' channel GrantData carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_109 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_109 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel GrantData address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:259 assert (is_aligned, \"'D' channel GrantData address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_109 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel GrantData carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:260 assert (sink_ok, \"'D' channel GrantData carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_109 & _T_473) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel GrantData smaller than a beat (connected at TileLink.scala:245:13)\n    at Monitor.scala:261 assert (bundle.size >= UInt(log2Ceil(edge.manager.beatBytes)), \"'D' channel GrantData smaller than a beat\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_109 & _T_473) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_109 & _T_504) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel GrantData carries invalid cap param (connected at TileLink.scala:245:13)\n    at Monitor.scala:262 assert (TLPermissions.isCap(bundle.param), \"'D' channel GrantData carries invalid cap param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_109 & _T_504) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_117 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAck carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:266 assert (source_ok, \"'D' channel AccessAck carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_117 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_117 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAck address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:267 assert (is_aligned, \"'D' channel AccessAck address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_117 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAck carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:268 assert (sink_ok, \"'D' channel AccessAck carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_117 & _T_478) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAck carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:270 assert (bundle.param === UInt(0), \"'D' channel AccessAck carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_117 & _T_478) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_123 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAckData carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:274 assert (source_ok, \"'D' channel AccessAckData carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_123 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_123 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAckData address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:275 assert (is_aligned, \"'D' channel AccessAckData address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_123 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAckData carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:276 assert (sink_ok, \"'D' channel AccessAckData carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_123 & _T_478) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel AccessAckData carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:278 assert (bundle.param === UInt(0), \"'D' channel AccessAckData carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_123 & _T_478) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_129 & _T_462) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel HintAck carries invalid source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:282 assert (source_ok, \"'D' channel HintAck carries invalid source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_129 & _T_462) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_129 & _T_465) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel HintAck address not aligned to size (connected at TileLink.scala:245:13)\n    at Monitor.scala:283 assert (is_aligned, \"'D' channel HintAck address not aligned to size\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_129 & _T_465) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel HintAck carries invalid sink ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:284 assert (sink_ok, \"'D' channel HintAck carries invalid sink ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_129 & _T_478) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel HintAck carries invalid param (connected at TileLink.scala:245:13)\n    at Monitor.scala:286 assert (bundle.param === UInt(0), \"'D' channel HintAck carries invalid param\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_129 & _T_478) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_GEN_129 & _T_483) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel HintAck carries an error (connected at TileLink.scala:245:13)\n    at Monitor.scala:287 assert (!bundle.error, \"'D' channel HintAck carries an error\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_GEN_129 & _T_483) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_583) begin
          $fwrite(32'h80000002,"Assertion failed: 'B' channel valid and not TL-C (connected at TileLink.scala:245:13)\n    at Monitor.scala:304 assert (!bundle.b.valid, \"'B' channel valid and not TL-C\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_583) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_588) begin
          $fwrite(32'h80000002,"Assertion failed: 'C' channel valid and not TL-C (connected at TileLink.scala:245:13)\n    at Monitor.scala:305 assert (!bundle.c.valid, \"'C' channel valid and not TL-C\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_588) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_593) begin
          $fwrite(32'h80000002,"Assertion failed: 'E' channel valid and not TL-C (connected at TileLink.scala:245:13)\n    at Monitor.scala:306 assert (!bundle.e.valid, \"'E' channel valid and not TL-C\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_593) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_636 & _T_640) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel opcode changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:318 assert (a.bits.opcode === opcode, \"'A' channel opcode changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_636 & _T_640) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_636 & _T_644) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel param changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:319 assert (a.bits.param  === param,  \"'A' channel param changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_636 & _T_644) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_636 & _T_648) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel size changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:320 assert (a.bits.size   === size,   \"'A' channel size changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_636 & _T_648) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_636 & _T_652) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel source changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:321 assert (a.bits.source === source, \"'A' channel source changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_636 & _T_652) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_636 & _T_656) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel address changed with multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:322 assert (a.bits.address=== address,\"'A' channel address changed with multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_636 & _T_656) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_705) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel opcode changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:388 assert (d.bits.opcode === opcode, \"'D' channel opcode changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_705) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_709) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel param changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:389 assert (d.bits.param  === param,  \"'D' channel param changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_709) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_713) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel size changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:390 assert (d.bits.size   === size,   \"'D' channel size changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_713) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_717) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel source changed within multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:391 assert (d.bits.source === source, \"'D' channel source changed within multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_717) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_721) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel sink changed with multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:392 assert (d.bits.sink   === sink,   \"'D' channel sink changed with multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_721) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_701 & _T_725) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel addr_lo changed with multibeat operation (connected at TileLink.scala:245:13)\n    at Monitor.scala:393 assert (d.bits.addr_lo=== addr_lo,\"'D' channel addr_lo changed with multibeat operation\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_701 & _T_725) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_793 & _T_804) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' channel re-used a source ID (connected at TileLink.scala:245:13)\n    at Monitor.scala:423 assert(!inflight(bundle.a.bits.source), \"'A' channel re-used a source ID\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_793 & _T_804) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_816 & _T_824) begin
          $fwrite(32'h80000002,"Assertion failed: 'D' channel acknowledged for nothing inflight (connected at TileLink.scala:245:13)\n    at Monitor.scala:430 assert((a_set | inflight)(bundle.d.bits.source), \"'D' channel acknowledged for nothing inflight\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_816 & _T_824) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_833) begin
          $fwrite(32'h80000002,"Assertion failed: 'A' and 'D' concurrent, despite minlatency 3 (connected at TileLink.scala:245:13)\n    at Monitor.scala:434 assert(a_set =/= d_clr || !a_set.orR, s\"'A' and 'D' concurrent, despite minlatency ${edge.manager.minLatency}\" + extra)\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_833) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
