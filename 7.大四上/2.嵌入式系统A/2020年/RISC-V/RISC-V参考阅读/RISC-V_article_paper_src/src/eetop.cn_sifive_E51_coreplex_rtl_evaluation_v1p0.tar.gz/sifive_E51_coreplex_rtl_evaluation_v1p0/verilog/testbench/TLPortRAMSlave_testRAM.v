//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLPortRAMSlave_testRAM(
  input         clock,
  input         reset,
  output        io_tl_0_a_ready,
  input         io_tl_0_a_valid,
  input  [2:0]  io_tl_0_a_bits_opcode,
  input  [2:0]  io_tl_0_a_bits_param,
  input  [2:0]  io_tl_0_a_bits_size,
  input         io_tl_0_a_bits_source,
  input  [29:0] io_tl_0_a_bits_address,
  input  [3:0]  io_tl_0_a_bits_mask,
  input  [31:0] io_tl_0_a_bits_data,
  input         io_tl_0_b_ready,
  output        io_tl_0_b_valid,
  output [2:0]  io_tl_0_b_bits_opcode,
  output [1:0]  io_tl_0_b_bits_param,
  output [2:0]  io_tl_0_b_bits_size,
  output        io_tl_0_b_bits_source,
  output [29:0] io_tl_0_b_bits_address,
  output [3:0]  io_tl_0_b_bits_mask,
  output [31:0] io_tl_0_b_bits_data,
  output        io_tl_0_c_ready,
  input         io_tl_0_c_valid,
  input  [2:0]  io_tl_0_c_bits_opcode,
  input  [2:0]  io_tl_0_c_bits_param,
  input  [2:0]  io_tl_0_c_bits_size,
  input         io_tl_0_c_bits_source,
  input  [29:0] io_tl_0_c_bits_address,
  input  [31:0] io_tl_0_c_bits_data,
  input         io_tl_0_c_bits_error,
  input         io_tl_0_d_ready,
  output        io_tl_0_d_valid,
  output [2:0]  io_tl_0_d_bits_opcode,
  output [1:0]  io_tl_0_d_bits_param,
  output [2:0]  io_tl_0_d_bits_size,
  output        io_tl_0_d_bits_source,
  output        io_tl_0_d_bits_sink,
  output [1:0]  io_tl_0_d_bits_addr_lo,
  output [31:0] io_tl_0_d_bits_data,
  output        io_tl_0_d_bits_error,
  output        io_tl_0_e_ready,
  input         io_tl_0_e_valid,
  input         io_tl_0_e_bits_sink
);
  wire  xbar_clock;
  wire  xbar_reset;
  wire  xbar_io_in_0_a_ready;
  wire  xbar_io_in_0_a_valid;
  wire [2:0] xbar_io_in_0_a_bits_opcode;
  wire [2:0] xbar_io_in_0_a_bits_param;
  wire [2:0] xbar_io_in_0_a_bits_size;
  wire  xbar_io_in_0_a_bits_source;
  wire [29:0] xbar_io_in_0_a_bits_address;
  wire [3:0] xbar_io_in_0_a_bits_mask;
  wire [31:0] xbar_io_in_0_a_bits_data;
  wire  xbar_io_in_0_b_ready;
  wire  xbar_io_in_0_b_valid;
  wire [2:0] xbar_io_in_0_b_bits_opcode;
  wire [1:0] xbar_io_in_0_b_bits_param;
  wire [2:0] xbar_io_in_0_b_bits_size;
  wire  xbar_io_in_0_b_bits_source;
  wire [29:0] xbar_io_in_0_b_bits_address;
  wire [3:0] xbar_io_in_0_b_bits_mask;
  wire [31:0] xbar_io_in_0_b_bits_data;
  wire  xbar_io_in_0_c_ready;
  wire  xbar_io_in_0_c_valid;
  wire [2:0] xbar_io_in_0_c_bits_opcode;
  wire [2:0] xbar_io_in_0_c_bits_param;
  wire [2:0] xbar_io_in_0_c_bits_size;
  wire  xbar_io_in_0_c_bits_source;
  wire [29:0] xbar_io_in_0_c_bits_address;
  wire [31:0] xbar_io_in_0_c_bits_data;
  wire  xbar_io_in_0_c_bits_error;
  wire  xbar_io_in_0_d_ready;
  wire  xbar_io_in_0_d_valid;
  wire [2:0] xbar_io_in_0_d_bits_opcode;
  wire [1:0] xbar_io_in_0_d_bits_param;
  wire [2:0] xbar_io_in_0_d_bits_size;
  wire  xbar_io_in_0_d_bits_source;
  wire  xbar_io_in_0_d_bits_sink;
  wire [1:0] xbar_io_in_0_d_bits_addr_lo;
  wire [31:0] xbar_io_in_0_d_bits_data;
  wire  xbar_io_in_0_d_bits_error;
  wire  xbar_io_in_0_e_ready;
  wire  xbar_io_in_0_e_valid;
  wire  xbar_io_in_0_e_bits_sink;
  wire  xbar_io_out_0_a_ready;
  wire  xbar_io_out_0_a_valid;
  wire [2:0] xbar_io_out_0_a_bits_opcode;
  wire [2:0] xbar_io_out_0_a_bits_param;
  wire [2:0] xbar_io_out_0_a_bits_size;
  wire  xbar_io_out_0_a_bits_source;
  wire [29:0] xbar_io_out_0_a_bits_address;
  wire [3:0] xbar_io_out_0_a_bits_mask;
  wire [31:0] xbar_io_out_0_a_bits_data;
  wire  xbar_io_out_0_b_ready;
  wire  xbar_io_out_0_b_valid;
  wire [2:0] xbar_io_out_0_b_bits_opcode;
  wire [1:0] xbar_io_out_0_b_bits_param;
  wire [2:0] xbar_io_out_0_b_bits_size;
  wire  xbar_io_out_0_b_bits_source;
  wire [29:0] xbar_io_out_0_b_bits_address;
  wire [3:0] xbar_io_out_0_b_bits_mask;
  wire [31:0] xbar_io_out_0_b_bits_data;
  wire  xbar_io_out_0_c_ready;
  wire  xbar_io_out_0_c_valid;
  wire [2:0] xbar_io_out_0_c_bits_opcode;
  wire [2:0] xbar_io_out_0_c_bits_param;
  wire [2:0] xbar_io_out_0_c_bits_size;
  wire  xbar_io_out_0_c_bits_source;
  wire [29:0] xbar_io_out_0_c_bits_address;
  wire [31:0] xbar_io_out_0_c_bits_data;
  wire  xbar_io_out_0_c_bits_error;
  wire  xbar_io_out_0_d_ready;
  wire  xbar_io_out_0_d_valid;
  wire [2:0] xbar_io_out_0_d_bits_opcode;
  wire [1:0] xbar_io_out_0_d_bits_param;
  wire [2:0] xbar_io_out_0_d_bits_size;
  wire  xbar_io_out_0_d_bits_source;
  wire  xbar_io_out_0_d_bits_sink;
  wire [1:0] xbar_io_out_0_d_bits_addr_lo;
  wire [31:0] xbar_io_out_0_d_bits_data;
  wire  xbar_io_out_0_d_bits_error;
  wire  xbar_io_out_0_e_ready;
  wire  xbar_io_out_0_e_valid;
  wire  xbar_io_out_0_e_bits_sink;
  wire  TLMonitor_clock;
  wire  TLMonitor_reset;
  wire  TLMonitor_io_in_0_a_ready;
  wire  TLMonitor_io_in_0_a_valid;
  wire [2:0] TLMonitor_io_in_0_a_bits_opcode;
  wire [2:0] TLMonitor_io_in_0_a_bits_param;
  wire [2:0] TLMonitor_io_in_0_a_bits_size;
  wire  TLMonitor_io_in_0_a_bits_source;
  wire [29:0] TLMonitor_io_in_0_a_bits_address;
  wire [3:0] TLMonitor_io_in_0_a_bits_mask;
  wire [31:0] TLMonitor_io_in_0_a_bits_data;
  wire  TLMonitor_io_in_0_b_ready;
  wire  TLMonitor_io_in_0_b_valid;
  wire [2:0] TLMonitor_io_in_0_b_bits_opcode;
  wire [1:0] TLMonitor_io_in_0_b_bits_param;
  wire [2:0] TLMonitor_io_in_0_b_bits_size;
  wire  TLMonitor_io_in_0_b_bits_source;
  wire [29:0] TLMonitor_io_in_0_b_bits_address;
  wire [3:0] TLMonitor_io_in_0_b_bits_mask;
  wire [31:0] TLMonitor_io_in_0_b_bits_data;
  wire  TLMonitor_io_in_0_c_ready;
  wire  TLMonitor_io_in_0_c_valid;
  wire [2:0] TLMonitor_io_in_0_c_bits_opcode;
  wire [2:0] TLMonitor_io_in_0_c_bits_param;
  wire [2:0] TLMonitor_io_in_0_c_bits_size;
  wire  TLMonitor_io_in_0_c_bits_source;
  wire [29:0] TLMonitor_io_in_0_c_bits_address;
  wire [31:0] TLMonitor_io_in_0_c_bits_data;
  wire  TLMonitor_io_in_0_c_bits_error;
  wire  TLMonitor_io_in_0_d_ready;
  wire  TLMonitor_io_in_0_d_valid;
  wire [2:0] TLMonitor_io_in_0_d_bits_opcode;
  wire [1:0] TLMonitor_io_in_0_d_bits_param;
  wire [2:0] TLMonitor_io_in_0_d_bits_size;
  wire  TLMonitor_io_in_0_d_bits_source;
  wire  TLMonitor_io_in_0_d_bits_sink;
  wire [1:0] TLMonitor_io_in_0_d_bits_addr_lo;
  wire [31:0] TLMonitor_io_in_0_d_bits_data;
  wire  TLMonitor_io_in_0_d_bits_error;
  wire  TLMonitor_io_in_0_e_ready;
  wire  TLMonitor_io_in_0_e_valid;
  wire  TLMonitor_io_in_0_e_bits_sink;
  wire  sram_clock;
  wire  sram_reset;
  wire  sram_io_in_0_a_ready;
  wire  sram_io_in_0_a_valid;
  wire [2:0] sram_io_in_0_a_bits_opcode;
  wire [2:0] sram_io_in_0_a_bits_param;
  wire [1:0] sram_io_in_0_a_bits_size;
  wire [3:0] sram_io_in_0_a_bits_source;
  wire [29:0] sram_io_in_0_a_bits_address;
  wire [3:0] sram_io_in_0_a_bits_mask;
  wire [31:0] sram_io_in_0_a_bits_data;
  wire  sram_io_in_0_b_ready;
  wire  sram_io_in_0_b_valid;
  wire [2:0] sram_io_in_0_b_bits_opcode;
  wire [1:0] sram_io_in_0_b_bits_param;
  wire [1:0] sram_io_in_0_b_bits_size;
  wire [3:0] sram_io_in_0_b_bits_source;
  wire [29:0] sram_io_in_0_b_bits_address;
  wire [3:0] sram_io_in_0_b_bits_mask;
  wire [31:0] sram_io_in_0_b_bits_data;
  wire  sram_io_in_0_c_ready;
  wire  sram_io_in_0_c_valid;
  wire [2:0] sram_io_in_0_c_bits_opcode;
  wire [2:0] sram_io_in_0_c_bits_param;
  wire [1:0] sram_io_in_0_c_bits_size;
  wire [3:0] sram_io_in_0_c_bits_source;
  wire [29:0] sram_io_in_0_c_bits_address;
  wire [31:0] sram_io_in_0_c_bits_data;
  wire  sram_io_in_0_c_bits_error;
  wire  sram_io_in_0_d_ready;
  wire  sram_io_in_0_d_valid;
  wire [2:0] sram_io_in_0_d_bits_opcode;
  wire [1:0] sram_io_in_0_d_bits_param;
  wire [1:0] sram_io_in_0_d_bits_size;
  wire [3:0] sram_io_in_0_d_bits_source;
  wire  sram_io_in_0_d_bits_sink;
  wire [1:0] sram_io_in_0_d_bits_addr_lo;
  wire [31:0] sram_io_in_0_d_bits_data;
  wire  sram_io_in_0_d_bits_error;
  wire  sram_io_in_0_e_ready;
  wire  sram_io_in_0_e_valid;
  wire  sram_io_in_0_e_bits_sink;
  wire  sram_TLFragmenter_clock;
  wire  sram_TLFragmenter_reset;
  wire  sram_TLFragmenter_io_in_0_a_ready;
  wire  sram_TLFragmenter_io_in_0_a_valid;
  wire [2:0] sram_TLFragmenter_io_in_0_a_bits_opcode;
  wire [2:0] sram_TLFragmenter_io_in_0_a_bits_param;
  wire [2:0] sram_TLFragmenter_io_in_0_a_bits_size;
  wire  sram_TLFragmenter_io_in_0_a_bits_source;
  wire [29:0] sram_TLFragmenter_io_in_0_a_bits_address;
  wire [3:0] sram_TLFragmenter_io_in_0_a_bits_mask;
  wire [31:0] sram_TLFragmenter_io_in_0_a_bits_data;
  wire  sram_TLFragmenter_io_in_0_b_ready;
  wire  sram_TLFragmenter_io_in_0_b_valid;
  wire [2:0] sram_TLFragmenter_io_in_0_b_bits_opcode;
  wire [1:0] sram_TLFragmenter_io_in_0_b_bits_param;
  wire [2:0] sram_TLFragmenter_io_in_0_b_bits_size;
  wire  sram_TLFragmenter_io_in_0_b_bits_source;
  wire [29:0] sram_TLFragmenter_io_in_0_b_bits_address;
  wire [3:0] sram_TLFragmenter_io_in_0_b_bits_mask;
  wire [31:0] sram_TLFragmenter_io_in_0_b_bits_data;
  wire  sram_TLFragmenter_io_in_0_c_ready;
  wire  sram_TLFragmenter_io_in_0_c_valid;
  wire [2:0] sram_TLFragmenter_io_in_0_c_bits_opcode;
  wire [2:0] sram_TLFragmenter_io_in_0_c_bits_param;
  wire [2:0] sram_TLFragmenter_io_in_0_c_bits_size;
  wire  sram_TLFragmenter_io_in_0_c_bits_source;
  wire [29:0] sram_TLFragmenter_io_in_0_c_bits_address;
  wire [31:0] sram_TLFragmenter_io_in_0_c_bits_data;
  wire  sram_TLFragmenter_io_in_0_c_bits_error;
  wire  sram_TLFragmenter_io_in_0_d_ready;
  wire  sram_TLFragmenter_io_in_0_d_valid;
  wire [2:0] sram_TLFragmenter_io_in_0_d_bits_opcode;
  wire [1:0] sram_TLFragmenter_io_in_0_d_bits_param;
  wire [2:0] sram_TLFragmenter_io_in_0_d_bits_size;
  wire  sram_TLFragmenter_io_in_0_d_bits_source;
  wire  sram_TLFragmenter_io_in_0_d_bits_sink;
  wire [1:0] sram_TLFragmenter_io_in_0_d_bits_addr_lo;
  wire [31:0] sram_TLFragmenter_io_in_0_d_bits_data;
  wire  sram_TLFragmenter_io_in_0_d_bits_error;
  wire  sram_TLFragmenter_io_in_0_e_ready;
  wire  sram_TLFragmenter_io_in_0_e_valid;
  wire  sram_TLFragmenter_io_in_0_e_bits_sink;
  wire  sram_TLFragmenter_io_out_0_a_ready;
  wire  sram_TLFragmenter_io_out_0_a_valid;
  wire [2:0] sram_TLFragmenter_io_out_0_a_bits_opcode;
  wire [2:0] sram_TLFragmenter_io_out_0_a_bits_param;
  wire [1:0] sram_TLFragmenter_io_out_0_a_bits_size;
  wire [3:0] sram_TLFragmenter_io_out_0_a_bits_source;
  wire [29:0] sram_TLFragmenter_io_out_0_a_bits_address;
  wire [3:0] sram_TLFragmenter_io_out_0_a_bits_mask;
  wire [31:0] sram_TLFragmenter_io_out_0_a_bits_data;
  wire  sram_TLFragmenter_io_out_0_b_ready;
  wire  sram_TLFragmenter_io_out_0_b_valid;
  wire [2:0] sram_TLFragmenter_io_out_0_b_bits_opcode;
  wire [1:0] sram_TLFragmenter_io_out_0_b_bits_param;
  wire [1:0] sram_TLFragmenter_io_out_0_b_bits_size;
  wire [3:0] sram_TLFragmenter_io_out_0_b_bits_source;
  wire [29:0] sram_TLFragmenter_io_out_0_b_bits_address;
  wire [3:0] sram_TLFragmenter_io_out_0_b_bits_mask;
  wire [31:0] sram_TLFragmenter_io_out_0_b_bits_data;
  wire  sram_TLFragmenter_io_out_0_c_ready;
  wire  sram_TLFragmenter_io_out_0_c_valid;
  wire [2:0] sram_TLFragmenter_io_out_0_c_bits_opcode;
  wire [2:0] sram_TLFragmenter_io_out_0_c_bits_param;
  wire [1:0] sram_TLFragmenter_io_out_0_c_bits_size;
  wire [3:0] sram_TLFragmenter_io_out_0_c_bits_source;
  wire [29:0] sram_TLFragmenter_io_out_0_c_bits_address;
  wire [31:0] sram_TLFragmenter_io_out_0_c_bits_data;
  wire  sram_TLFragmenter_io_out_0_c_bits_error;
  wire  sram_TLFragmenter_io_out_0_d_ready;
  wire  sram_TLFragmenter_io_out_0_d_valid;
  wire [2:0] sram_TLFragmenter_io_out_0_d_bits_opcode;
  wire [1:0] sram_TLFragmenter_io_out_0_d_bits_param;
  wire [1:0] sram_TLFragmenter_io_out_0_d_bits_size;
  wire [3:0] sram_TLFragmenter_io_out_0_d_bits_source;
  wire  sram_TLFragmenter_io_out_0_d_bits_sink;
  wire [1:0] sram_TLFragmenter_io_out_0_d_bits_addr_lo;
  wire [31:0] sram_TLFragmenter_io_out_0_d_bits_data;
  wire  sram_TLFragmenter_io_out_0_d_bits_error;
  wire  sram_TLFragmenter_io_out_0_e_ready;
  wire  sram_TLFragmenter_io_out_0_e_valid;
  wire  sram_TLFragmenter_io_out_0_e_bits_sink;
  wire  TLMonitor_1_clock;
  wire  TLMonitor_1_reset;
  wire  TLMonitor_1_io_in_0_a_ready;
  wire  TLMonitor_1_io_in_0_a_valid;
  wire [2:0] TLMonitor_1_io_in_0_a_bits_opcode;
  wire [2:0] TLMonitor_1_io_in_0_a_bits_param;
  wire [2:0] TLMonitor_1_io_in_0_a_bits_size;
  wire  TLMonitor_1_io_in_0_a_bits_source;
  wire [29:0] TLMonitor_1_io_in_0_a_bits_address;
  wire [3:0] TLMonitor_1_io_in_0_a_bits_mask;
  wire [31:0] TLMonitor_1_io_in_0_a_bits_data;
  wire  TLMonitor_1_io_in_0_b_ready;
  wire  TLMonitor_1_io_in_0_b_valid;
  wire [2:0] TLMonitor_1_io_in_0_b_bits_opcode;
  wire [1:0] TLMonitor_1_io_in_0_b_bits_param;
  wire [2:0] TLMonitor_1_io_in_0_b_bits_size;
  wire  TLMonitor_1_io_in_0_b_bits_source;
  wire [29:0] TLMonitor_1_io_in_0_b_bits_address;
  wire [3:0] TLMonitor_1_io_in_0_b_bits_mask;
  wire [31:0] TLMonitor_1_io_in_0_b_bits_data;
  wire  TLMonitor_1_io_in_0_c_ready;
  wire  TLMonitor_1_io_in_0_c_valid;
  wire [2:0] TLMonitor_1_io_in_0_c_bits_opcode;
  wire [2:0] TLMonitor_1_io_in_0_c_bits_param;
  wire [2:0] TLMonitor_1_io_in_0_c_bits_size;
  wire  TLMonitor_1_io_in_0_c_bits_source;
  wire [29:0] TLMonitor_1_io_in_0_c_bits_address;
  wire [31:0] TLMonitor_1_io_in_0_c_bits_data;
  wire  TLMonitor_1_io_in_0_c_bits_error;
  wire  TLMonitor_1_io_in_0_d_ready;
  wire  TLMonitor_1_io_in_0_d_valid;
  wire [2:0] TLMonitor_1_io_in_0_d_bits_opcode;
  wire [1:0] TLMonitor_1_io_in_0_d_bits_param;
  wire [2:0] TLMonitor_1_io_in_0_d_bits_size;
  wire  TLMonitor_1_io_in_0_d_bits_source;
  wire  TLMonitor_1_io_in_0_d_bits_sink;
  wire [1:0] TLMonitor_1_io_in_0_d_bits_addr_lo;
  wire [31:0] TLMonitor_1_io_in_0_d_bits_data;
  wire  TLMonitor_1_io_in_0_d_bits_error;
  wire  TLMonitor_1_io_in_0_e_ready;
  wire  TLMonitor_1_io_in_0_e_valid;
  wire  TLMonitor_1_io_in_0_e_bits_sink;
  wire  sram_TLBuffer_clock;
  wire  sram_TLBuffer_reset;
  wire  sram_TLBuffer_io_in_0_a_ready;
  wire  sram_TLBuffer_io_in_0_a_valid;
  wire [2:0] sram_TLBuffer_io_in_0_a_bits_opcode;
  wire [2:0] sram_TLBuffer_io_in_0_a_bits_param;
  wire [1:0] sram_TLBuffer_io_in_0_a_bits_size;
  wire [3:0] sram_TLBuffer_io_in_0_a_bits_source;
  wire [29:0] sram_TLBuffer_io_in_0_a_bits_address;
  wire [3:0] sram_TLBuffer_io_in_0_a_bits_mask;
  wire [31:0] sram_TLBuffer_io_in_0_a_bits_data;
  wire  sram_TLBuffer_io_in_0_b_ready;
  wire  sram_TLBuffer_io_in_0_b_valid;
  wire [2:0] sram_TLBuffer_io_in_0_b_bits_opcode;
  wire [1:0] sram_TLBuffer_io_in_0_b_bits_param;
  wire [1:0] sram_TLBuffer_io_in_0_b_bits_size;
  wire [3:0] sram_TLBuffer_io_in_0_b_bits_source;
  wire [29:0] sram_TLBuffer_io_in_0_b_bits_address;
  wire [3:0] sram_TLBuffer_io_in_0_b_bits_mask;
  wire [31:0] sram_TLBuffer_io_in_0_b_bits_data;
  wire  sram_TLBuffer_io_in_0_c_ready;
  wire  sram_TLBuffer_io_in_0_c_valid;
  wire [2:0] sram_TLBuffer_io_in_0_c_bits_opcode;
  wire [2:0] sram_TLBuffer_io_in_0_c_bits_param;
  wire [1:0] sram_TLBuffer_io_in_0_c_bits_size;
  wire [3:0] sram_TLBuffer_io_in_0_c_bits_source;
  wire [29:0] sram_TLBuffer_io_in_0_c_bits_address;
  wire [31:0] sram_TLBuffer_io_in_0_c_bits_data;
  wire  sram_TLBuffer_io_in_0_c_bits_error;
  wire  sram_TLBuffer_io_in_0_d_ready;
  wire  sram_TLBuffer_io_in_0_d_valid;
  wire [2:0] sram_TLBuffer_io_in_0_d_bits_opcode;
  wire [1:0] sram_TLBuffer_io_in_0_d_bits_param;
  wire [1:0] sram_TLBuffer_io_in_0_d_bits_size;
  wire [3:0] sram_TLBuffer_io_in_0_d_bits_source;
  wire  sram_TLBuffer_io_in_0_d_bits_sink;
  wire [1:0] sram_TLBuffer_io_in_0_d_bits_addr_lo;
  wire [31:0] sram_TLBuffer_io_in_0_d_bits_data;
  wire  sram_TLBuffer_io_in_0_d_bits_error;
  wire  sram_TLBuffer_io_in_0_e_ready;
  wire  sram_TLBuffer_io_in_0_e_valid;
  wire  sram_TLBuffer_io_in_0_e_bits_sink;
  wire  sram_TLBuffer_io_out_0_a_ready;
  wire  sram_TLBuffer_io_out_0_a_valid;
  wire [2:0] sram_TLBuffer_io_out_0_a_bits_opcode;
  wire [2:0] sram_TLBuffer_io_out_0_a_bits_param;
  wire [1:0] sram_TLBuffer_io_out_0_a_bits_size;
  wire [3:0] sram_TLBuffer_io_out_0_a_bits_source;
  wire [29:0] sram_TLBuffer_io_out_0_a_bits_address;
  wire [3:0] sram_TLBuffer_io_out_0_a_bits_mask;
  wire [31:0] sram_TLBuffer_io_out_0_a_bits_data;
  wire  sram_TLBuffer_io_out_0_b_ready;
  wire  sram_TLBuffer_io_out_0_b_valid;
  wire [2:0] sram_TLBuffer_io_out_0_b_bits_opcode;
  wire [1:0] sram_TLBuffer_io_out_0_b_bits_param;
  wire [1:0] sram_TLBuffer_io_out_0_b_bits_size;
  wire [3:0] sram_TLBuffer_io_out_0_b_bits_source;
  wire [29:0] sram_TLBuffer_io_out_0_b_bits_address;
  wire [3:0] sram_TLBuffer_io_out_0_b_bits_mask;
  wire [31:0] sram_TLBuffer_io_out_0_b_bits_data;
  wire  sram_TLBuffer_io_out_0_c_ready;
  wire  sram_TLBuffer_io_out_0_c_valid;
  wire [2:0] sram_TLBuffer_io_out_0_c_bits_opcode;
  wire [2:0] sram_TLBuffer_io_out_0_c_bits_param;
  wire [1:0] sram_TLBuffer_io_out_0_c_bits_size;
  wire [3:0] sram_TLBuffer_io_out_0_c_bits_source;
  wire [29:0] sram_TLBuffer_io_out_0_c_bits_address;
  wire [31:0] sram_TLBuffer_io_out_0_c_bits_data;
  wire  sram_TLBuffer_io_out_0_c_bits_error;
  wire  sram_TLBuffer_io_out_0_d_ready;
  wire  sram_TLBuffer_io_out_0_d_valid;
  wire [2:0] sram_TLBuffer_io_out_0_d_bits_opcode;
  wire [1:0] sram_TLBuffer_io_out_0_d_bits_param;
  wire [1:0] sram_TLBuffer_io_out_0_d_bits_size;
  wire [3:0] sram_TLBuffer_io_out_0_d_bits_source;
  wire  sram_TLBuffer_io_out_0_d_bits_sink;
  wire [1:0] sram_TLBuffer_io_out_0_d_bits_addr_lo;
  wire [31:0] sram_TLBuffer_io_out_0_d_bits_data;
  wire  sram_TLBuffer_io_out_0_d_bits_error;
  wire  sram_TLBuffer_io_out_0_e_ready;
  wire  sram_TLBuffer_io_out_0_e_valid;
  wire  sram_TLBuffer_io_out_0_e_bits_sink;
  wire  TLMonitor_2_clock;
  wire  TLMonitor_2_reset;
  wire  TLMonitor_2_io_in_0_a_ready;
  wire  TLMonitor_2_io_in_0_a_valid;
  wire [2:0] TLMonitor_2_io_in_0_a_bits_opcode;
  wire [2:0] TLMonitor_2_io_in_0_a_bits_param;
  wire [1:0] TLMonitor_2_io_in_0_a_bits_size;
  wire [3:0] TLMonitor_2_io_in_0_a_bits_source;
  wire [29:0] TLMonitor_2_io_in_0_a_bits_address;
  wire [3:0] TLMonitor_2_io_in_0_a_bits_mask;
  wire [31:0] TLMonitor_2_io_in_0_a_bits_data;
  wire  TLMonitor_2_io_in_0_b_ready;
  wire  TLMonitor_2_io_in_0_b_valid;
  wire [2:0] TLMonitor_2_io_in_0_b_bits_opcode;
  wire [1:0] TLMonitor_2_io_in_0_b_bits_param;
  wire [1:0] TLMonitor_2_io_in_0_b_bits_size;
  wire [3:0] TLMonitor_2_io_in_0_b_bits_source;
  wire [29:0] TLMonitor_2_io_in_0_b_bits_address;
  wire [3:0] TLMonitor_2_io_in_0_b_bits_mask;
  wire [31:0] TLMonitor_2_io_in_0_b_bits_data;
  wire  TLMonitor_2_io_in_0_c_ready;
  wire  TLMonitor_2_io_in_0_c_valid;
  wire [2:0] TLMonitor_2_io_in_0_c_bits_opcode;
  wire [2:0] TLMonitor_2_io_in_0_c_bits_param;
  wire [1:0] TLMonitor_2_io_in_0_c_bits_size;
  wire [3:0] TLMonitor_2_io_in_0_c_bits_source;
  wire [29:0] TLMonitor_2_io_in_0_c_bits_address;
  wire [31:0] TLMonitor_2_io_in_0_c_bits_data;
  wire  TLMonitor_2_io_in_0_c_bits_error;
  wire  TLMonitor_2_io_in_0_d_ready;
  wire  TLMonitor_2_io_in_0_d_valid;
  wire [2:0] TLMonitor_2_io_in_0_d_bits_opcode;
  wire [1:0] TLMonitor_2_io_in_0_d_bits_param;
  wire [1:0] TLMonitor_2_io_in_0_d_bits_size;
  wire [3:0] TLMonitor_2_io_in_0_d_bits_source;
  wire  TLMonitor_2_io_in_0_d_bits_sink;
  wire [1:0] TLMonitor_2_io_in_0_d_bits_addr_lo;
  wire [31:0] TLMonitor_2_io_in_0_d_bits_data;
  wire  TLMonitor_2_io_in_0_d_bits_error;
  wire  TLMonitor_2_io_in_0_e_ready;
  wire  TLMonitor_2_io_in_0_e_valid;
  wire  TLMonitor_2_io_in_0_e_bits_sink;
  wire  TLMonitor_3_clock;
  wire  TLMonitor_3_reset;
  wire  TLMonitor_3_io_in_0_a_ready;
  wire  TLMonitor_3_io_in_0_a_valid;
  wire [2:0] TLMonitor_3_io_in_0_a_bits_opcode;
  wire [2:0] TLMonitor_3_io_in_0_a_bits_param;
  wire [1:0] TLMonitor_3_io_in_0_a_bits_size;
  wire [3:0] TLMonitor_3_io_in_0_a_bits_source;
  wire [29:0] TLMonitor_3_io_in_0_a_bits_address;
  wire [3:0] TLMonitor_3_io_in_0_a_bits_mask;
  wire [31:0] TLMonitor_3_io_in_0_a_bits_data;
  wire  TLMonitor_3_io_in_0_b_ready;
  wire  TLMonitor_3_io_in_0_b_valid;
  wire [2:0] TLMonitor_3_io_in_0_b_bits_opcode;
  wire [1:0] TLMonitor_3_io_in_0_b_bits_param;
  wire [1:0] TLMonitor_3_io_in_0_b_bits_size;
  wire [3:0] TLMonitor_3_io_in_0_b_bits_source;
  wire [29:0] TLMonitor_3_io_in_0_b_bits_address;
  wire [3:0] TLMonitor_3_io_in_0_b_bits_mask;
  wire [31:0] TLMonitor_3_io_in_0_b_bits_data;
  wire  TLMonitor_3_io_in_0_c_ready;
  wire  TLMonitor_3_io_in_0_c_valid;
  wire [2:0] TLMonitor_3_io_in_0_c_bits_opcode;
  wire [2:0] TLMonitor_3_io_in_0_c_bits_param;
  wire [1:0] TLMonitor_3_io_in_0_c_bits_size;
  wire [3:0] TLMonitor_3_io_in_0_c_bits_source;
  wire [29:0] TLMonitor_3_io_in_0_c_bits_address;
  wire [31:0] TLMonitor_3_io_in_0_c_bits_data;
  wire  TLMonitor_3_io_in_0_c_bits_error;
  wire  TLMonitor_3_io_in_0_d_ready;
  wire  TLMonitor_3_io_in_0_d_valid;
  wire [2:0] TLMonitor_3_io_in_0_d_bits_opcode;
  wire [1:0] TLMonitor_3_io_in_0_d_bits_param;
  wire [1:0] TLMonitor_3_io_in_0_d_bits_size;
  wire [3:0] TLMonitor_3_io_in_0_d_bits_source;
  wire  TLMonitor_3_io_in_0_d_bits_sink;
  wire [1:0] TLMonitor_3_io_in_0_d_bits_addr_lo;
  wire [31:0] TLMonitor_3_io_in_0_d_bits_data;
  wire  TLMonitor_3_io_in_0_d_bits_error;
  wire  TLMonitor_3_io_in_0_e_ready;
  wire  TLMonitor_3_io_in_0_e_valid;
  wire  TLMonitor_3_io_in_0_e_bits_sink;
  wire  _T_8_a_ready;
  wire  _T_8_a_valid;
  wire [2:0] _T_8_a_bits_opcode;
  wire [2:0] _T_8_a_bits_param;
  wire [2:0] _T_8_a_bits_size;
  wire  _T_8_a_bits_source;
  wire [29:0] _T_8_a_bits_address;
  wire [3:0] _T_8_a_bits_mask;
  wire [31:0] _T_8_a_bits_data;
  wire  _T_8_b_ready;
  wire  _T_8_b_valid;
  wire [2:0] _T_8_b_bits_opcode;
  wire [1:0] _T_8_b_bits_param;
  wire [2:0] _T_8_b_bits_size;
  wire  _T_8_b_bits_source;
  wire [29:0] _T_8_b_bits_address;
  wire [3:0] _T_8_b_bits_mask;
  wire [31:0] _T_8_b_bits_data;
  wire  _T_8_c_ready;
  wire  _T_8_c_valid;
  wire [2:0] _T_8_c_bits_opcode;
  wire [2:0] _T_8_c_bits_param;
  wire [2:0] _T_8_c_bits_size;
  wire  _T_8_c_bits_source;
  wire [29:0] _T_8_c_bits_address;
  wire [31:0] _T_8_c_bits_data;
  wire  _T_8_c_bits_error;
  wire  _T_8_d_ready;
  wire  _T_8_d_valid;
  wire [2:0] _T_8_d_bits_opcode;
  wire [1:0] _T_8_d_bits_param;
  wire [2:0] _T_8_d_bits_size;
  wire  _T_8_d_bits_source;
  wire  _T_8_d_bits_sink;
  wire [1:0] _T_8_d_bits_addr_lo;
  wire [31:0] _T_8_d_bits_data;
  wire  _T_8_d_bits_error;
  wire  _T_8_e_ready;
  wire  _T_8_e_valid;
  wire  _T_8_e_bits_sink;
  wire  _T_15_ready;
  wire  _T_15_valid;
  wire [2:0] _T_15_bits_opcode;
  wire [2:0] _T_15_bits_param;
  wire [2:0] _T_15_bits_size;
  wire  _T_15_bits_source;
  wire [29:0] _T_15_bits_address;
  wire [3:0] _T_15_bits_mask;
  wire [31:0] _T_15_bits_data;
  wire  _T_17_ready;
  wire  _T_17_valid;
  wire [2:0] _T_17_bits_opcode;
  wire [1:0] _T_17_bits_param;
  wire [2:0] _T_17_bits_size;
  wire  _T_17_bits_source;
  wire [29:0] _T_17_bits_address;
  wire [3:0] _T_17_bits_mask;
  wire [31:0] _T_17_bits_data;
  wire  _T_19_ready;
  wire  _T_19_valid;
  wire [2:0] _T_19_bits_opcode;
  wire [2:0] _T_19_bits_param;
  wire [2:0] _T_19_bits_size;
  wire  _T_19_bits_source;
  wire [29:0] _T_19_bits_address;
  wire [31:0] _T_19_bits_data;
  wire  _T_19_bits_error;
  wire  _T_21_ready;
  wire  _T_21_valid;
  wire [2:0] _T_21_bits_opcode;
  wire [1:0] _T_21_bits_param;
  wire [2:0] _T_21_bits_size;
  wire  _T_21_bits_source;
  wire  _T_21_bits_sink;
  wire [1:0] _T_21_bits_addr_lo;
  wire [31:0] _T_21_bits_data;
  wire  _T_21_bits_error;
  wire  _T_23_ready;
  wire  _T_23_valid;
  wire  _T_23_bits_sink;
  wire  _T_30_a_ready;
  wire  _T_30_a_valid;
  wire [2:0] _T_30_a_bits_opcode;
  wire [2:0] _T_30_a_bits_param;
  wire [2:0] _T_30_a_bits_size;
  wire  _T_30_a_bits_source;
  wire [29:0] _T_30_a_bits_address;
  wire [3:0] _T_30_a_bits_mask;
  wire [31:0] _T_30_a_bits_data;
  wire  _T_30_b_ready;
  wire  _T_30_b_valid;
  wire [2:0] _T_30_b_bits_opcode;
  wire [1:0] _T_30_b_bits_param;
  wire [2:0] _T_30_b_bits_size;
  wire  _T_30_b_bits_source;
  wire [29:0] _T_30_b_bits_address;
  wire [3:0] _T_30_b_bits_mask;
  wire [31:0] _T_30_b_bits_data;
  wire  _T_30_c_ready;
  wire  _T_30_c_valid;
  wire [2:0] _T_30_c_bits_opcode;
  wire [2:0] _T_30_c_bits_param;
  wire [2:0] _T_30_c_bits_size;
  wire  _T_30_c_bits_source;
  wire [29:0] _T_30_c_bits_address;
  wire [31:0] _T_30_c_bits_data;
  wire  _T_30_c_bits_error;
  wire  _T_30_d_ready;
  wire  _T_30_d_valid;
  wire [2:0] _T_30_d_bits_opcode;
  wire [1:0] _T_30_d_bits_param;
  wire [2:0] _T_30_d_bits_size;
  wire  _T_30_d_bits_source;
  wire  _T_30_d_bits_sink;
  wire [1:0] _T_30_d_bits_addr_lo;
  wire [31:0] _T_30_d_bits_data;
  wire  _T_30_d_bits_error;
  wire  _T_30_e_ready;
  wire  _T_30_e_valid;
  wire  _T_30_e_bits_sink;
  wire  _T_37_ready;
  wire  _T_37_valid;
  wire [2:0] _T_37_bits_opcode;
  wire [2:0] _T_37_bits_param;
  wire [2:0] _T_37_bits_size;
  wire  _T_37_bits_source;
  wire [29:0] _T_37_bits_address;
  wire [3:0] _T_37_bits_mask;
  wire [31:0] _T_37_bits_data;
  wire  _T_39_ready;
  wire  _T_39_valid;
  wire [2:0] _T_39_bits_opcode;
  wire [1:0] _T_39_bits_param;
  wire [2:0] _T_39_bits_size;
  wire  _T_39_bits_source;
  wire [29:0] _T_39_bits_address;
  wire [3:0] _T_39_bits_mask;
  wire [31:0] _T_39_bits_data;
  wire  _T_41_ready;
  wire  _T_41_valid;
  wire [2:0] _T_41_bits_opcode;
  wire [2:0] _T_41_bits_param;
  wire [2:0] _T_41_bits_size;
  wire  _T_41_bits_source;
  wire [29:0] _T_41_bits_address;
  wire [31:0] _T_41_bits_data;
  wire  _T_41_bits_error;
  wire  _T_43_ready;
  wire  _T_43_valid;
  wire [2:0] _T_43_bits_opcode;
  wire [1:0] _T_43_bits_param;
  wire [2:0] _T_43_bits_size;
  wire  _T_43_bits_source;
  wire  _T_43_bits_sink;
  wire [1:0] _T_43_bits_addr_lo;
  wire [31:0] _T_43_bits_data;
  wire  _T_43_bits_error;
  wire  _T_45_ready;
  wire  _T_45_valid;
  wire  _T_45_bits_sink;
  wire  _T_52_a_ready;
  wire  _T_52_a_valid;
  wire [2:0] _T_52_a_bits_opcode;
  wire [2:0] _T_52_a_bits_param;
  wire [1:0] _T_52_a_bits_size;
  wire [3:0] _T_52_a_bits_source;
  wire [29:0] _T_52_a_bits_address;
  wire [3:0] _T_52_a_bits_mask;
  wire [31:0] _T_52_a_bits_data;
  wire  _T_52_b_ready;
  wire  _T_52_b_valid;
  wire [2:0] _T_52_b_bits_opcode;
  wire [1:0] _T_52_b_bits_param;
  wire [1:0] _T_52_b_bits_size;
  wire [3:0] _T_52_b_bits_source;
  wire [29:0] _T_52_b_bits_address;
  wire [3:0] _T_52_b_bits_mask;
  wire [31:0] _T_52_b_bits_data;
  wire  _T_52_c_ready;
  wire  _T_52_c_valid;
  wire [2:0] _T_52_c_bits_opcode;
  wire [2:0] _T_52_c_bits_param;
  wire [1:0] _T_52_c_bits_size;
  wire [3:0] _T_52_c_bits_source;
  wire [29:0] _T_52_c_bits_address;
  wire [31:0] _T_52_c_bits_data;
  wire  _T_52_c_bits_error;
  wire  _T_52_d_ready;
  wire  _T_52_d_valid;
  wire [2:0] _T_52_d_bits_opcode;
  wire [1:0] _T_52_d_bits_param;
  wire [1:0] _T_52_d_bits_size;
  wire [3:0] _T_52_d_bits_source;
  wire  _T_52_d_bits_sink;
  wire [1:0] _T_52_d_bits_addr_lo;
  wire [31:0] _T_52_d_bits_data;
  wire  _T_52_d_bits_error;
  wire  _T_52_e_ready;
  wire  _T_52_e_valid;
  wire  _T_52_e_bits_sink;
  wire  _T_59_ready;
  wire  _T_59_valid;
  wire [2:0] _T_59_bits_opcode;
  wire [2:0] _T_59_bits_param;
  wire [1:0] _T_59_bits_size;
  wire [3:0] _T_59_bits_source;
  wire [29:0] _T_59_bits_address;
  wire [3:0] _T_59_bits_mask;
  wire [31:0] _T_59_bits_data;
  wire  _T_61_ready;
  wire  _T_61_valid;
  wire [2:0] _T_61_bits_opcode;
  wire [1:0] _T_61_bits_param;
  wire [1:0] _T_61_bits_size;
  wire [3:0] _T_61_bits_source;
  wire [29:0] _T_61_bits_address;
  wire [3:0] _T_61_bits_mask;
  wire [31:0] _T_61_bits_data;
  wire  _T_63_ready;
  wire  _T_63_valid;
  wire [2:0] _T_63_bits_opcode;
  wire [2:0] _T_63_bits_param;
  wire [1:0] _T_63_bits_size;
  wire [3:0] _T_63_bits_source;
  wire [29:0] _T_63_bits_address;
  wire [31:0] _T_63_bits_data;
  wire  _T_63_bits_error;
  wire  _T_65_ready;
  wire  _T_65_valid;
  wire [2:0] _T_65_bits_opcode;
  wire [1:0] _T_65_bits_param;
  wire [1:0] _T_65_bits_size;
  wire [3:0] _T_65_bits_source;
  wire  _T_65_bits_sink;
  wire [1:0] _T_65_bits_addr_lo;
  wire [31:0] _T_65_bits_data;
  wire  _T_65_bits_error;
  wire  _T_67_ready;
  wire  _T_67_valid;
  wire  _T_67_bits_sink;
  wire  _T_74_a_ready;
  wire  _T_74_a_valid;
  wire [2:0] _T_74_a_bits_opcode;
  wire [2:0] _T_74_a_bits_param;
  wire [1:0] _T_74_a_bits_size;
  wire [3:0] _T_74_a_bits_source;
  wire [29:0] _T_74_a_bits_address;
  wire [3:0] _T_74_a_bits_mask;
  wire [31:0] _T_74_a_bits_data;
  wire  _T_74_b_ready;
  wire  _T_74_b_valid;
  wire [2:0] _T_74_b_bits_opcode;
  wire [1:0] _T_74_b_bits_param;
  wire [1:0] _T_74_b_bits_size;
  wire [3:0] _T_74_b_bits_source;
  wire [29:0] _T_74_b_bits_address;
  wire [3:0] _T_74_b_bits_mask;
  wire [31:0] _T_74_b_bits_data;
  wire  _T_74_c_ready;
  wire  _T_74_c_valid;
  wire [2:0] _T_74_c_bits_opcode;
  wire [2:0] _T_74_c_bits_param;
  wire [1:0] _T_74_c_bits_size;
  wire [3:0] _T_74_c_bits_source;
  wire [29:0] _T_74_c_bits_address;
  wire [31:0] _T_74_c_bits_data;
  wire  _T_74_c_bits_error;
  wire  _T_74_d_ready;
  wire  _T_74_d_valid;
  wire [2:0] _T_74_d_bits_opcode;
  wire [1:0] _T_74_d_bits_param;
  wire [1:0] _T_74_d_bits_size;
  wire [3:0] _T_74_d_bits_source;
  wire  _T_74_d_bits_sink;
  wire [1:0] _T_74_d_bits_addr_lo;
  wire [31:0] _T_74_d_bits_data;
  wire  _T_74_d_bits_error;
  wire  _T_74_e_ready;
  wire  _T_74_e_valid;
  wire  _T_74_e_bits_sink;
  wire  _T_81_ready;
  wire  _T_81_valid;
  wire [2:0] _T_81_bits_opcode;
  wire [2:0] _T_81_bits_param;
  wire [1:0] _T_81_bits_size;
  wire [3:0] _T_81_bits_source;
  wire [29:0] _T_81_bits_address;
  wire [3:0] _T_81_bits_mask;
  wire [31:0] _T_81_bits_data;
  wire  _T_83_ready;
  wire  _T_83_valid;
  wire [2:0] _T_83_bits_opcode;
  wire [1:0] _T_83_bits_param;
  wire [1:0] _T_83_bits_size;
  wire [3:0] _T_83_bits_source;
  wire [29:0] _T_83_bits_address;
  wire [3:0] _T_83_bits_mask;
  wire [31:0] _T_83_bits_data;
  wire  _T_85_ready;
  wire  _T_85_valid;
  wire [2:0] _T_85_bits_opcode;
  wire [2:0] _T_85_bits_param;
  wire [1:0] _T_85_bits_size;
  wire [3:0] _T_85_bits_source;
  wire [29:0] _T_85_bits_address;
  wire [31:0] _T_85_bits_data;
  wire  _T_85_bits_error;
  wire  _T_87_ready;
  wire  _T_87_valid;
  wire [2:0] _T_87_bits_opcode;
  wire [1:0] _T_87_bits_param;
  wire [1:0] _T_87_bits_size;
  wire [3:0] _T_87_bits_source;
  wire  _T_87_bits_sink;
  wire [1:0] _T_87_bits_addr_lo;
  wire [31:0] _T_87_bits_data;
  wire  _T_87_bits_error;
  wire  _T_89_ready;
  wire  _T_89_valid;
  wire  _T_89_bits_sink;
  TLXbar_xbar xbar (
    .clock(xbar_clock),
    .reset(xbar_reset),
    .io_in_0_a_ready(xbar_io_in_0_a_ready),
    .io_in_0_a_valid(xbar_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(xbar_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(xbar_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(xbar_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(xbar_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(xbar_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(xbar_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(xbar_io_in_0_a_bits_data),
    .io_in_0_b_ready(xbar_io_in_0_b_ready),
    .io_in_0_b_valid(xbar_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(xbar_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(xbar_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(xbar_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(xbar_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(xbar_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(xbar_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(xbar_io_in_0_b_bits_data),
    .io_in_0_c_ready(xbar_io_in_0_c_ready),
    .io_in_0_c_valid(xbar_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(xbar_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(xbar_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(xbar_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(xbar_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(xbar_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(xbar_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(xbar_io_in_0_c_bits_error),
    .io_in_0_d_ready(xbar_io_in_0_d_ready),
    .io_in_0_d_valid(xbar_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(xbar_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(xbar_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(xbar_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(xbar_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(xbar_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(xbar_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(xbar_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(xbar_io_in_0_d_bits_error),
    .io_in_0_e_ready(xbar_io_in_0_e_ready),
    .io_in_0_e_valid(xbar_io_in_0_e_valid),
    .io_in_0_e_bits_sink(xbar_io_in_0_e_bits_sink),
    .io_out_0_a_ready(xbar_io_out_0_a_ready),
    .io_out_0_a_valid(xbar_io_out_0_a_valid),
    .io_out_0_a_bits_opcode(xbar_io_out_0_a_bits_opcode),
    .io_out_0_a_bits_param(xbar_io_out_0_a_bits_param),
    .io_out_0_a_bits_size(xbar_io_out_0_a_bits_size),
    .io_out_0_a_bits_source(xbar_io_out_0_a_bits_source),
    .io_out_0_a_bits_address(xbar_io_out_0_a_bits_address),
    .io_out_0_a_bits_mask(xbar_io_out_0_a_bits_mask),
    .io_out_0_a_bits_data(xbar_io_out_0_a_bits_data),
    .io_out_0_b_ready(xbar_io_out_0_b_ready),
    .io_out_0_b_valid(xbar_io_out_0_b_valid),
    .io_out_0_b_bits_opcode(xbar_io_out_0_b_bits_opcode),
    .io_out_0_b_bits_param(xbar_io_out_0_b_bits_param),
    .io_out_0_b_bits_size(xbar_io_out_0_b_bits_size),
    .io_out_0_b_bits_source(xbar_io_out_0_b_bits_source),
    .io_out_0_b_bits_address(xbar_io_out_0_b_bits_address),
    .io_out_0_b_bits_mask(xbar_io_out_0_b_bits_mask),
    .io_out_0_b_bits_data(xbar_io_out_0_b_bits_data),
    .io_out_0_c_ready(xbar_io_out_0_c_ready),
    .io_out_0_c_valid(xbar_io_out_0_c_valid),
    .io_out_0_c_bits_opcode(xbar_io_out_0_c_bits_opcode),
    .io_out_0_c_bits_param(xbar_io_out_0_c_bits_param),
    .io_out_0_c_bits_size(xbar_io_out_0_c_bits_size),
    .io_out_0_c_bits_source(xbar_io_out_0_c_bits_source),
    .io_out_0_c_bits_address(xbar_io_out_0_c_bits_address),
    .io_out_0_c_bits_data(xbar_io_out_0_c_bits_data),
    .io_out_0_c_bits_error(xbar_io_out_0_c_bits_error),
    .io_out_0_d_ready(xbar_io_out_0_d_ready),
    .io_out_0_d_valid(xbar_io_out_0_d_valid),
    .io_out_0_d_bits_opcode(xbar_io_out_0_d_bits_opcode),
    .io_out_0_d_bits_param(xbar_io_out_0_d_bits_param),
    .io_out_0_d_bits_size(xbar_io_out_0_d_bits_size),
    .io_out_0_d_bits_source(xbar_io_out_0_d_bits_source),
    .io_out_0_d_bits_sink(xbar_io_out_0_d_bits_sink),
    .io_out_0_d_bits_addr_lo(xbar_io_out_0_d_bits_addr_lo),
    .io_out_0_d_bits_data(xbar_io_out_0_d_bits_data),
    .io_out_0_d_bits_error(xbar_io_out_0_d_bits_error),
    .io_out_0_e_ready(xbar_io_out_0_e_ready),
    .io_out_0_e_valid(xbar_io_out_0_e_valid),
    .io_out_0_e_bits_sink(xbar_io_out_0_e_bits_sink)
  );
  TLMonitor_54 TLMonitor (
    .clock(TLMonitor_clock),
    .reset(TLMonitor_reset),
    .io_in_0_a_ready(TLMonitor_io_in_0_a_ready),
    .io_in_0_a_valid(TLMonitor_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(TLMonitor_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(TLMonitor_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(TLMonitor_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(TLMonitor_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(TLMonitor_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(TLMonitor_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(TLMonitor_io_in_0_a_bits_data),
    .io_in_0_b_ready(TLMonitor_io_in_0_b_ready),
    .io_in_0_b_valid(TLMonitor_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(TLMonitor_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(TLMonitor_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(TLMonitor_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(TLMonitor_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(TLMonitor_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(TLMonitor_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(TLMonitor_io_in_0_b_bits_data),
    .io_in_0_c_ready(TLMonitor_io_in_0_c_ready),
    .io_in_0_c_valid(TLMonitor_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(TLMonitor_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(TLMonitor_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(TLMonitor_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(TLMonitor_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(TLMonitor_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(TLMonitor_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(TLMonitor_io_in_0_c_bits_error),
    .io_in_0_d_ready(TLMonitor_io_in_0_d_ready),
    .io_in_0_d_valid(TLMonitor_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(TLMonitor_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(TLMonitor_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(TLMonitor_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(TLMonitor_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(TLMonitor_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(TLMonitor_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(TLMonitor_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(TLMonitor_io_in_0_d_bits_error),
    .io_in_0_e_ready(TLMonitor_io_in_0_e_ready),
    .io_in_0_e_valid(TLMonitor_io_in_0_e_valid),
    .io_in_0_e_bits_sink(TLMonitor_io_in_0_e_bits_sink)
  );
  TLRAM_sram sram (
    .clock(sram_clock),
    .reset(sram_reset),
    .io_in_0_a_ready(sram_io_in_0_a_ready),
    .io_in_0_a_valid(sram_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(sram_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(sram_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(sram_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(sram_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(sram_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(sram_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(sram_io_in_0_a_bits_data),
    .io_in_0_b_ready(sram_io_in_0_b_ready),
    .io_in_0_b_valid(sram_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(sram_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(sram_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(sram_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(sram_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(sram_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(sram_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(sram_io_in_0_b_bits_data),
    .io_in_0_c_ready(sram_io_in_0_c_ready),
    .io_in_0_c_valid(sram_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(sram_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(sram_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(sram_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(sram_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(sram_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(sram_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(sram_io_in_0_c_bits_error),
    .io_in_0_d_ready(sram_io_in_0_d_ready),
    .io_in_0_d_valid(sram_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(sram_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(sram_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(sram_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(sram_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(sram_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(sram_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(sram_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(sram_io_in_0_d_bits_error),
    .io_in_0_e_ready(sram_io_in_0_e_ready),
    .io_in_0_e_valid(sram_io_in_0_e_valid),
    .io_in_0_e_bits_sink(sram_io_in_0_e_bits_sink)
  );
  TLFragmenter_sram sram_TLFragmenter (
    .clock(sram_TLFragmenter_clock),
    .reset(sram_TLFragmenter_reset),
    .io_in_0_a_ready(sram_TLFragmenter_io_in_0_a_ready),
    .io_in_0_a_valid(sram_TLFragmenter_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(sram_TLFragmenter_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(sram_TLFragmenter_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(sram_TLFragmenter_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(sram_TLFragmenter_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(sram_TLFragmenter_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(sram_TLFragmenter_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(sram_TLFragmenter_io_in_0_a_bits_data),
    .io_in_0_b_ready(sram_TLFragmenter_io_in_0_b_ready),
    .io_in_0_b_valid(sram_TLFragmenter_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(sram_TLFragmenter_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(sram_TLFragmenter_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(sram_TLFragmenter_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(sram_TLFragmenter_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(sram_TLFragmenter_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(sram_TLFragmenter_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(sram_TLFragmenter_io_in_0_b_bits_data),
    .io_in_0_c_ready(sram_TLFragmenter_io_in_0_c_ready),
    .io_in_0_c_valid(sram_TLFragmenter_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(sram_TLFragmenter_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(sram_TLFragmenter_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(sram_TLFragmenter_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(sram_TLFragmenter_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(sram_TLFragmenter_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(sram_TLFragmenter_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(sram_TLFragmenter_io_in_0_c_bits_error),
    .io_in_0_d_ready(sram_TLFragmenter_io_in_0_d_ready),
    .io_in_0_d_valid(sram_TLFragmenter_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(sram_TLFragmenter_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(sram_TLFragmenter_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(sram_TLFragmenter_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(sram_TLFragmenter_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(sram_TLFragmenter_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(sram_TLFragmenter_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(sram_TLFragmenter_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(sram_TLFragmenter_io_in_0_d_bits_error),
    .io_in_0_e_ready(sram_TLFragmenter_io_in_0_e_ready),
    .io_in_0_e_valid(sram_TLFragmenter_io_in_0_e_valid),
    .io_in_0_e_bits_sink(sram_TLFragmenter_io_in_0_e_bits_sink),
    .io_out_0_a_ready(sram_TLFragmenter_io_out_0_a_ready),
    .io_out_0_a_valid(sram_TLFragmenter_io_out_0_a_valid),
    .io_out_0_a_bits_opcode(sram_TLFragmenter_io_out_0_a_bits_opcode),
    .io_out_0_a_bits_param(sram_TLFragmenter_io_out_0_a_bits_param),
    .io_out_0_a_bits_size(sram_TLFragmenter_io_out_0_a_bits_size),
    .io_out_0_a_bits_source(sram_TLFragmenter_io_out_0_a_bits_source),
    .io_out_0_a_bits_address(sram_TLFragmenter_io_out_0_a_bits_address),
    .io_out_0_a_bits_mask(sram_TLFragmenter_io_out_0_a_bits_mask),
    .io_out_0_a_bits_data(sram_TLFragmenter_io_out_0_a_bits_data),
    .io_out_0_b_ready(sram_TLFragmenter_io_out_0_b_ready),
    .io_out_0_b_valid(sram_TLFragmenter_io_out_0_b_valid),
    .io_out_0_b_bits_opcode(sram_TLFragmenter_io_out_0_b_bits_opcode),
    .io_out_0_b_bits_param(sram_TLFragmenter_io_out_0_b_bits_param),
    .io_out_0_b_bits_size(sram_TLFragmenter_io_out_0_b_bits_size),
    .io_out_0_b_bits_source(sram_TLFragmenter_io_out_0_b_bits_source),
    .io_out_0_b_bits_address(sram_TLFragmenter_io_out_0_b_bits_address),
    .io_out_0_b_bits_mask(sram_TLFragmenter_io_out_0_b_bits_mask),
    .io_out_0_b_bits_data(sram_TLFragmenter_io_out_0_b_bits_data),
    .io_out_0_c_ready(sram_TLFragmenter_io_out_0_c_ready),
    .io_out_0_c_valid(sram_TLFragmenter_io_out_0_c_valid),
    .io_out_0_c_bits_opcode(sram_TLFragmenter_io_out_0_c_bits_opcode),
    .io_out_0_c_bits_param(sram_TLFragmenter_io_out_0_c_bits_param),
    .io_out_0_c_bits_size(sram_TLFragmenter_io_out_0_c_bits_size),
    .io_out_0_c_bits_source(sram_TLFragmenter_io_out_0_c_bits_source),
    .io_out_0_c_bits_address(sram_TLFragmenter_io_out_0_c_bits_address),
    .io_out_0_c_bits_data(sram_TLFragmenter_io_out_0_c_bits_data),
    .io_out_0_c_bits_error(sram_TLFragmenter_io_out_0_c_bits_error),
    .io_out_0_d_ready(sram_TLFragmenter_io_out_0_d_ready),
    .io_out_0_d_valid(sram_TLFragmenter_io_out_0_d_valid),
    .io_out_0_d_bits_opcode(sram_TLFragmenter_io_out_0_d_bits_opcode),
    .io_out_0_d_bits_param(sram_TLFragmenter_io_out_0_d_bits_param),
    .io_out_0_d_bits_size(sram_TLFragmenter_io_out_0_d_bits_size),
    .io_out_0_d_bits_source(sram_TLFragmenter_io_out_0_d_bits_source),
    .io_out_0_d_bits_sink(sram_TLFragmenter_io_out_0_d_bits_sink),
    .io_out_0_d_bits_addr_lo(sram_TLFragmenter_io_out_0_d_bits_addr_lo),
    .io_out_0_d_bits_data(sram_TLFragmenter_io_out_0_d_bits_data),
    .io_out_0_d_bits_error(sram_TLFragmenter_io_out_0_d_bits_error),
    .io_out_0_e_ready(sram_TLFragmenter_io_out_0_e_ready),
    .io_out_0_e_valid(sram_TLFragmenter_io_out_0_e_valid),
    .io_out_0_e_bits_sink(sram_TLFragmenter_io_out_0_e_bits_sink)
  );
  TLMonitor_55 TLMonitor_1 (
    .clock(TLMonitor_1_clock),
    .reset(TLMonitor_1_reset),
    .io_in_0_a_ready(TLMonitor_1_io_in_0_a_ready),
    .io_in_0_a_valid(TLMonitor_1_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(TLMonitor_1_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(TLMonitor_1_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(TLMonitor_1_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(TLMonitor_1_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(TLMonitor_1_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(TLMonitor_1_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(TLMonitor_1_io_in_0_a_bits_data),
    .io_in_0_b_ready(TLMonitor_1_io_in_0_b_ready),
    .io_in_0_b_valid(TLMonitor_1_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(TLMonitor_1_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(TLMonitor_1_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(TLMonitor_1_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(TLMonitor_1_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(TLMonitor_1_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(TLMonitor_1_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(TLMonitor_1_io_in_0_b_bits_data),
    .io_in_0_c_ready(TLMonitor_1_io_in_0_c_ready),
    .io_in_0_c_valid(TLMonitor_1_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(TLMonitor_1_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(TLMonitor_1_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(TLMonitor_1_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(TLMonitor_1_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(TLMonitor_1_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(TLMonitor_1_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(TLMonitor_1_io_in_0_c_bits_error),
    .io_in_0_d_ready(TLMonitor_1_io_in_0_d_ready),
    .io_in_0_d_valid(TLMonitor_1_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(TLMonitor_1_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(TLMonitor_1_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(TLMonitor_1_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(TLMonitor_1_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(TLMonitor_1_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(TLMonitor_1_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(TLMonitor_1_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(TLMonitor_1_io_in_0_d_bits_error),
    .io_in_0_e_ready(TLMonitor_1_io_in_0_e_ready),
    .io_in_0_e_valid(TLMonitor_1_io_in_0_e_valid),
    .io_in_0_e_bits_sink(TLMonitor_1_io_in_0_e_bits_sink)
  );
  TLBuffer_sram sram_TLBuffer (
    .clock(sram_TLBuffer_clock),
    .reset(sram_TLBuffer_reset),
    .io_in_0_a_ready(sram_TLBuffer_io_in_0_a_ready),
    .io_in_0_a_valid(sram_TLBuffer_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(sram_TLBuffer_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(sram_TLBuffer_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(sram_TLBuffer_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(sram_TLBuffer_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(sram_TLBuffer_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(sram_TLBuffer_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(sram_TLBuffer_io_in_0_a_bits_data),
    .io_in_0_b_ready(sram_TLBuffer_io_in_0_b_ready),
    .io_in_0_b_valid(sram_TLBuffer_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(sram_TLBuffer_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(sram_TLBuffer_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(sram_TLBuffer_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(sram_TLBuffer_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(sram_TLBuffer_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(sram_TLBuffer_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(sram_TLBuffer_io_in_0_b_bits_data),
    .io_in_0_c_ready(sram_TLBuffer_io_in_0_c_ready),
    .io_in_0_c_valid(sram_TLBuffer_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(sram_TLBuffer_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(sram_TLBuffer_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(sram_TLBuffer_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(sram_TLBuffer_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(sram_TLBuffer_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(sram_TLBuffer_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(sram_TLBuffer_io_in_0_c_bits_error),
    .io_in_0_d_ready(sram_TLBuffer_io_in_0_d_ready),
    .io_in_0_d_valid(sram_TLBuffer_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(sram_TLBuffer_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(sram_TLBuffer_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(sram_TLBuffer_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(sram_TLBuffer_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(sram_TLBuffer_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(sram_TLBuffer_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(sram_TLBuffer_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(sram_TLBuffer_io_in_0_d_bits_error),
    .io_in_0_e_ready(sram_TLBuffer_io_in_0_e_ready),
    .io_in_0_e_valid(sram_TLBuffer_io_in_0_e_valid),
    .io_in_0_e_bits_sink(sram_TLBuffer_io_in_0_e_bits_sink),
    .io_out_0_a_ready(sram_TLBuffer_io_out_0_a_ready),
    .io_out_0_a_valid(sram_TLBuffer_io_out_0_a_valid),
    .io_out_0_a_bits_opcode(sram_TLBuffer_io_out_0_a_bits_opcode),
    .io_out_0_a_bits_param(sram_TLBuffer_io_out_0_a_bits_param),
    .io_out_0_a_bits_size(sram_TLBuffer_io_out_0_a_bits_size),
    .io_out_0_a_bits_source(sram_TLBuffer_io_out_0_a_bits_source),
    .io_out_0_a_bits_address(sram_TLBuffer_io_out_0_a_bits_address),
    .io_out_0_a_bits_mask(sram_TLBuffer_io_out_0_a_bits_mask),
    .io_out_0_a_bits_data(sram_TLBuffer_io_out_0_a_bits_data),
    .io_out_0_b_ready(sram_TLBuffer_io_out_0_b_ready),
    .io_out_0_b_valid(sram_TLBuffer_io_out_0_b_valid),
    .io_out_0_b_bits_opcode(sram_TLBuffer_io_out_0_b_bits_opcode),
    .io_out_0_b_bits_param(sram_TLBuffer_io_out_0_b_bits_param),
    .io_out_0_b_bits_size(sram_TLBuffer_io_out_0_b_bits_size),
    .io_out_0_b_bits_source(sram_TLBuffer_io_out_0_b_bits_source),
    .io_out_0_b_bits_address(sram_TLBuffer_io_out_0_b_bits_address),
    .io_out_0_b_bits_mask(sram_TLBuffer_io_out_0_b_bits_mask),
    .io_out_0_b_bits_data(sram_TLBuffer_io_out_0_b_bits_data),
    .io_out_0_c_ready(sram_TLBuffer_io_out_0_c_ready),
    .io_out_0_c_valid(sram_TLBuffer_io_out_0_c_valid),
    .io_out_0_c_bits_opcode(sram_TLBuffer_io_out_0_c_bits_opcode),
    .io_out_0_c_bits_param(sram_TLBuffer_io_out_0_c_bits_param),
    .io_out_0_c_bits_size(sram_TLBuffer_io_out_0_c_bits_size),
    .io_out_0_c_bits_source(sram_TLBuffer_io_out_0_c_bits_source),
    .io_out_0_c_bits_address(sram_TLBuffer_io_out_0_c_bits_address),
    .io_out_0_c_bits_data(sram_TLBuffer_io_out_0_c_bits_data),
    .io_out_0_c_bits_error(sram_TLBuffer_io_out_0_c_bits_error),
    .io_out_0_d_ready(sram_TLBuffer_io_out_0_d_ready),
    .io_out_0_d_valid(sram_TLBuffer_io_out_0_d_valid),
    .io_out_0_d_bits_opcode(sram_TLBuffer_io_out_0_d_bits_opcode),
    .io_out_0_d_bits_param(sram_TLBuffer_io_out_0_d_bits_param),
    .io_out_0_d_bits_size(sram_TLBuffer_io_out_0_d_bits_size),
    .io_out_0_d_bits_source(sram_TLBuffer_io_out_0_d_bits_source),
    .io_out_0_d_bits_sink(sram_TLBuffer_io_out_0_d_bits_sink),
    .io_out_0_d_bits_addr_lo(sram_TLBuffer_io_out_0_d_bits_addr_lo),
    .io_out_0_d_bits_data(sram_TLBuffer_io_out_0_d_bits_data),
    .io_out_0_d_bits_error(sram_TLBuffer_io_out_0_d_bits_error),
    .io_out_0_e_ready(sram_TLBuffer_io_out_0_e_ready),
    .io_out_0_e_valid(sram_TLBuffer_io_out_0_e_valid),
    .io_out_0_e_bits_sink(sram_TLBuffer_io_out_0_e_bits_sink)
  );
  TLMonitor_56 TLMonitor_2 (
    .clock(TLMonitor_2_clock),
    .reset(TLMonitor_2_reset),
    .io_in_0_a_ready(TLMonitor_2_io_in_0_a_ready),
    .io_in_0_a_valid(TLMonitor_2_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(TLMonitor_2_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(TLMonitor_2_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(TLMonitor_2_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(TLMonitor_2_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(TLMonitor_2_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(TLMonitor_2_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(TLMonitor_2_io_in_0_a_bits_data),
    .io_in_0_b_ready(TLMonitor_2_io_in_0_b_ready),
    .io_in_0_b_valid(TLMonitor_2_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(TLMonitor_2_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(TLMonitor_2_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(TLMonitor_2_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(TLMonitor_2_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(TLMonitor_2_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(TLMonitor_2_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(TLMonitor_2_io_in_0_b_bits_data),
    .io_in_0_c_ready(TLMonitor_2_io_in_0_c_ready),
    .io_in_0_c_valid(TLMonitor_2_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(TLMonitor_2_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(TLMonitor_2_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(TLMonitor_2_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(TLMonitor_2_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(TLMonitor_2_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(TLMonitor_2_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(TLMonitor_2_io_in_0_c_bits_error),
    .io_in_0_d_ready(TLMonitor_2_io_in_0_d_ready),
    .io_in_0_d_valid(TLMonitor_2_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(TLMonitor_2_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(TLMonitor_2_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(TLMonitor_2_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(TLMonitor_2_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(TLMonitor_2_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(TLMonitor_2_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(TLMonitor_2_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(TLMonitor_2_io_in_0_d_bits_error),
    .io_in_0_e_ready(TLMonitor_2_io_in_0_e_ready),
    .io_in_0_e_valid(TLMonitor_2_io_in_0_e_valid),
    .io_in_0_e_bits_sink(TLMonitor_2_io_in_0_e_bits_sink)
  );
  TLMonitor_57 TLMonitor_3 (
    .clock(TLMonitor_3_clock),
    .reset(TLMonitor_3_reset),
    .io_in_0_a_ready(TLMonitor_3_io_in_0_a_ready),
    .io_in_0_a_valid(TLMonitor_3_io_in_0_a_valid),
    .io_in_0_a_bits_opcode(TLMonitor_3_io_in_0_a_bits_opcode),
    .io_in_0_a_bits_param(TLMonitor_3_io_in_0_a_bits_param),
    .io_in_0_a_bits_size(TLMonitor_3_io_in_0_a_bits_size),
    .io_in_0_a_bits_source(TLMonitor_3_io_in_0_a_bits_source),
    .io_in_0_a_bits_address(TLMonitor_3_io_in_0_a_bits_address),
    .io_in_0_a_bits_mask(TLMonitor_3_io_in_0_a_bits_mask),
    .io_in_0_a_bits_data(TLMonitor_3_io_in_0_a_bits_data),
    .io_in_0_b_ready(TLMonitor_3_io_in_0_b_ready),
    .io_in_0_b_valid(TLMonitor_3_io_in_0_b_valid),
    .io_in_0_b_bits_opcode(TLMonitor_3_io_in_0_b_bits_opcode),
    .io_in_0_b_bits_param(TLMonitor_3_io_in_0_b_bits_param),
    .io_in_0_b_bits_size(TLMonitor_3_io_in_0_b_bits_size),
    .io_in_0_b_bits_source(TLMonitor_3_io_in_0_b_bits_source),
    .io_in_0_b_bits_address(TLMonitor_3_io_in_0_b_bits_address),
    .io_in_0_b_bits_mask(TLMonitor_3_io_in_0_b_bits_mask),
    .io_in_0_b_bits_data(TLMonitor_3_io_in_0_b_bits_data),
    .io_in_0_c_ready(TLMonitor_3_io_in_0_c_ready),
    .io_in_0_c_valid(TLMonitor_3_io_in_0_c_valid),
    .io_in_0_c_bits_opcode(TLMonitor_3_io_in_0_c_bits_opcode),
    .io_in_0_c_bits_param(TLMonitor_3_io_in_0_c_bits_param),
    .io_in_0_c_bits_size(TLMonitor_3_io_in_0_c_bits_size),
    .io_in_0_c_bits_source(TLMonitor_3_io_in_0_c_bits_source),
    .io_in_0_c_bits_address(TLMonitor_3_io_in_0_c_bits_address),
    .io_in_0_c_bits_data(TLMonitor_3_io_in_0_c_bits_data),
    .io_in_0_c_bits_error(TLMonitor_3_io_in_0_c_bits_error),
    .io_in_0_d_ready(TLMonitor_3_io_in_0_d_ready),
    .io_in_0_d_valid(TLMonitor_3_io_in_0_d_valid),
    .io_in_0_d_bits_opcode(TLMonitor_3_io_in_0_d_bits_opcode),
    .io_in_0_d_bits_param(TLMonitor_3_io_in_0_d_bits_param),
    .io_in_0_d_bits_size(TLMonitor_3_io_in_0_d_bits_size),
    .io_in_0_d_bits_source(TLMonitor_3_io_in_0_d_bits_source),
    .io_in_0_d_bits_sink(TLMonitor_3_io_in_0_d_bits_sink),
    .io_in_0_d_bits_addr_lo(TLMonitor_3_io_in_0_d_bits_addr_lo),
    .io_in_0_d_bits_data(TLMonitor_3_io_in_0_d_bits_data),
    .io_in_0_d_bits_error(TLMonitor_3_io_in_0_d_bits_error),
    .io_in_0_e_ready(TLMonitor_3_io_in_0_e_ready),
    .io_in_0_e_valid(TLMonitor_3_io_in_0_e_valid),
    .io_in_0_e_bits_sink(TLMonitor_3_io_in_0_e_bits_sink)
  );
  assign io_tl_0_a_ready = xbar_io_in_0_a_ready;
  assign io_tl_0_b_valid = xbar_io_in_0_b_valid;
  assign io_tl_0_b_bits_opcode = xbar_io_in_0_b_bits_opcode;
  assign io_tl_0_b_bits_param = xbar_io_in_0_b_bits_param;
  assign io_tl_0_b_bits_size = xbar_io_in_0_b_bits_size;
  assign io_tl_0_b_bits_source = xbar_io_in_0_b_bits_source;
  assign io_tl_0_b_bits_address = xbar_io_in_0_b_bits_address;
  assign io_tl_0_b_bits_mask = xbar_io_in_0_b_bits_mask;
  assign io_tl_0_b_bits_data = xbar_io_in_0_b_bits_data;
  assign io_tl_0_c_ready = xbar_io_in_0_c_ready;
  assign io_tl_0_d_valid = xbar_io_in_0_d_valid;
  assign io_tl_0_d_bits_opcode = xbar_io_in_0_d_bits_opcode;
  assign io_tl_0_d_bits_param = xbar_io_in_0_d_bits_param;
  assign io_tl_0_d_bits_size = xbar_io_in_0_d_bits_size;
  assign io_tl_0_d_bits_source = xbar_io_in_0_d_bits_source;
  assign io_tl_0_d_bits_sink = xbar_io_in_0_d_bits_sink;
  assign io_tl_0_d_bits_addr_lo = xbar_io_in_0_d_bits_addr_lo;
  assign io_tl_0_d_bits_data = xbar_io_in_0_d_bits_data;
  assign io_tl_0_d_bits_error = xbar_io_in_0_d_bits_error;
  assign io_tl_0_e_ready = xbar_io_in_0_e_ready;
  assign xbar_clock = clock;
  assign xbar_reset = reset;
  assign xbar_io_in_0_a_valid = io_tl_0_a_valid;
  assign xbar_io_in_0_a_bits_opcode = io_tl_0_a_bits_opcode;
  assign xbar_io_in_0_a_bits_param = io_tl_0_a_bits_param;
  assign xbar_io_in_0_a_bits_size = io_tl_0_a_bits_size;
  assign xbar_io_in_0_a_bits_source = io_tl_0_a_bits_source;
  assign xbar_io_in_0_a_bits_address = io_tl_0_a_bits_address;
  assign xbar_io_in_0_a_bits_mask = io_tl_0_a_bits_mask;
  assign xbar_io_in_0_a_bits_data = io_tl_0_a_bits_data;
  assign xbar_io_in_0_b_ready = io_tl_0_b_ready;
  assign xbar_io_in_0_c_valid = io_tl_0_c_valid;
  assign xbar_io_in_0_c_bits_opcode = io_tl_0_c_bits_opcode;
  assign xbar_io_in_0_c_bits_param = io_tl_0_c_bits_param;
  assign xbar_io_in_0_c_bits_size = io_tl_0_c_bits_size;
  assign xbar_io_in_0_c_bits_source = io_tl_0_c_bits_source;
  assign xbar_io_in_0_c_bits_address = io_tl_0_c_bits_address;
  assign xbar_io_in_0_c_bits_data = io_tl_0_c_bits_data;
  assign xbar_io_in_0_c_bits_error = io_tl_0_c_bits_error;
  assign xbar_io_in_0_d_ready = io_tl_0_d_ready;
  assign xbar_io_in_0_e_valid = io_tl_0_e_valid;
  assign xbar_io_in_0_e_bits_sink = io_tl_0_e_bits_sink;
  assign xbar_io_out_0_a_ready = sram_TLFragmenter_io_in_0_a_ready;
  assign xbar_io_out_0_b_valid = sram_TLFragmenter_io_in_0_b_valid;
  assign xbar_io_out_0_b_bits_opcode = sram_TLFragmenter_io_in_0_b_bits_opcode;
  assign xbar_io_out_0_b_bits_param = sram_TLFragmenter_io_in_0_b_bits_param;
  assign xbar_io_out_0_b_bits_size = sram_TLFragmenter_io_in_0_b_bits_size;
  assign xbar_io_out_0_b_bits_source = sram_TLFragmenter_io_in_0_b_bits_source;
  assign xbar_io_out_0_b_bits_address = sram_TLFragmenter_io_in_0_b_bits_address;
  assign xbar_io_out_0_b_bits_mask = sram_TLFragmenter_io_in_0_b_bits_mask;
  assign xbar_io_out_0_b_bits_data = sram_TLFragmenter_io_in_0_b_bits_data;
  assign xbar_io_out_0_c_ready = sram_TLFragmenter_io_in_0_c_ready;
  assign xbar_io_out_0_d_valid = sram_TLFragmenter_io_in_0_d_valid;
  assign xbar_io_out_0_d_bits_opcode = sram_TLFragmenter_io_in_0_d_bits_opcode;
  assign xbar_io_out_0_d_bits_param = sram_TLFragmenter_io_in_0_d_bits_param;
  assign xbar_io_out_0_d_bits_size = sram_TLFragmenter_io_in_0_d_bits_size;
  assign xbar_io_out_0_d_bits_source = sram_TLFragmenter_io_in_0_d_bits_source;
  assign xbar_io_out_0_d_bits_sink = sram_TLFragmenter_io_in_0_d_bits_sink;
  assign xbar_io_out_0_d_bits_addr_lo = sram_TLFragmenter_io_in_0_d_bits_addr_lo;
  assign xbar_io_out_0_d_bits_data = sram_TLFragmenter_io_in_0_d_bits_data;
  assign xbar_io_out_0_d_bits_error = sram_TLFragmenter_io_in_0_d_bits_error;
  assign xbar_io_out_0_e_ready = sram_TLFragmenter_io_in_0_e_ready;
  assign TLMonitor_clock = clock;
  assign TLMonitor_reset = reset;
  assign TLMonitor_io_in_0_a_ready = _T_8_a_ready;
  assign TLMonitor_io_in_0_a_valid = _T_8_a_valid;
  assign TLMonitor_io_in_0_a_bits_opcode = _T_8_a_bits_opcode;
  assign TLMonitor_io_in_0_a_bits_param = _T_8_a_bits_param;
  assign TLMonitor_io_in_0_a_bits_size = _T_8_a_bits_size;
  assign TLMonitor_io_in_0_a_bits_source = _T_8_a_bits_source;
  assign TLMonitor_io_in_0_a_bits_address = _T_8_a_bits_address;
  assign TLMonitor_io_in_0_a_bits_mask = _T_8_a_bits_mask;
  assign TLMonitor_io_in_0_a_bits_data = _T_8_a_bits_data;
  assign TLMonitor_io_in_0_b_ready = _T_8_b_ready;
  assign TLMonitor_io_in_0_b_valid = _T_8_b_valid;
  assign TLMonitor_io_in_0_b_bits_opcode = _T_8_b_bits_opcode;
  assign TLMonitor_io_in_0_b_bits_param = _T_8_b_bits_param;
  assign TLMonitor_io_in_0_b_bits_size = _T_8_b_bits_size;
  assign TLMonitor_io_in_0_b_bits_source = _T_8_b_bits_source;
  assign TLMonitor_io_in_0_b_bits_address = _T_8_b_bits_address;
  assign TLMonitor_io_in_0_b_bits_mask = _T_8_b_bits_mask;
  assign TLMonitor_io_in_0_b_bits_data = _T_8_b_bits_data;
  assign TLMonitor_io_in_0_c_ready = _T_8_c_ready;
  assign TLMonitor_io_in_0_c_valid = _T_8_c_valid;
  assign TLMonitor_io_in_0_c_bits_opcode = _T_8_c_bits_opcode;
  assign TLMonitor_io_in_0_c_bits_param = _T_8_c_bits_param;
  assign TLMonitor_io_in_0_c_bits_size = _T_8_c_bits_size;
  assign TLMonitor_io_in_0_c_bits_source = _T_8_c_bits_source;
  assign TLMonitor_io_in_0_c_bits_address = _T_8_c_bits_address;
  assign TLMonitor_io_in_0_c_bits_data = _T_8_c_bits_data;
  assign TLMonitor_io_in_0_c_bits_error = _T_8_c_bits_error;
  assign TLMonitor_io_in_0_d_ready = _T_8_d_ready;
  assign TLMonitor_io_in_0_d_valid = _T_8_d_valid;
  assign TLMonitor_io_in_0_d_bits_opcode = _T_8_d_bits_opcode;
  assign TLMonitor_io_in_0_d_bits_param = _T_8_d_bits_param;
  assign TLMonitor_io_in_0_d_bits_size = _T_8_d_bits_size;
  assign TLMonitor_io_in_0_d_bits_source = _T_8_d_bits_source;
  assign TLMonitor_io_in_0_d_bits_sink = _T_8_d_bits_sink;
  assign TLMonitor_io_in_0_d_bits_addr_lo = _T_8_d_bits_addr_lo;
  assign TLMonitor_io_in_0_d_bits_data = _T_8_d_bits_data;
  assign TLMonitor_io_in_0_d_bits_error = _T_8_d_bits_error;
  assign TLMonitor_io_in_0_e_ready = _T_8_e_ready;
  assign TLMonitor_io_in_0_e_valid = _T_8_e_valid;
  assign TLMonitor_io_in_0_e_bits_sink = _T_8_e_bits_sink;
  assign sram_clock = clock;
  assign sram_reset = reset;
  assign sram_io_in_0_a_valid = sram_TLBuffer_io_out_0_a_valid;
  assign sram_io_in_0_a_bits_opcode = sram_TLBuffer_io_out_0_a_bits_opcode;
  assign sram_io_in_0_a_bits_param = sram_TLBuffer_io_out_0_a_bits_param;
  assign sram_io_in_0_a_bits_size = sram_TLBuffer_io_out_0_a_bits_size;
  assign sram_io_in_0_a_bits_source = sram_TLBuffer_io_out_0_a_bits_source;
  assign sram_io_in_0_a_bits_address = sram_TLBuffer_io_out_0_a_bits_address;
  assign sram_io_in_0_a_bits_mask = sram_TLBuffer_io_out_0_a_bits_mask;
  assign sram_io_in_0_a_bits_data = sram_TLBuffer_io_out_0_a_bits_data;
  assign sram_io_in_0_b_ready = sram_TLBuffer_io_out_0_b_ready;
  assign sram_io_in_0_c_valid = sram_TLBuffer_io_out_0_c_valid;
  assign sram_io_in_0_c_bits_opcode = sram_TLBuffer_io_out_0_c_bits_opcode;
  assign sram_io_in_0_c_bits_param = sram_TLBuffer_io_out_0_c_bits_param;
  assign sram_io_in_0_c_bits_size = sram_TLBuffer_io_out_0_c_bits_size;
  assign sram_io_in_0_c_bits_source = sram_TLBuffer_io_out_0_c_bits_source;
  assign sram_io_in_0_c_bits_address = sram_TLBuffer_io_out_0_c_bits_address;
  assign sram_io_in_0_c_bits_data = sram_TLBuffer_io_out_0_c_bits_data;
  assign sram_io_in_0_c_bits_error = sram_TLBuffer_io_out_0_c_bits_error;
  assign sram_io_in_0_d_ready = sram_TLBuffer_io_out_0_d_ready;
  assign sram_io_in_0_e_valid = sram_TLBuffer_io_out_0_e_valid;
  assign sram_io_in_0_e_bits_sink = sram_TLBuffer_io_out_0_e_bits_sink;
  assign sram_TLFragmenter_clock = clock;
  assign sram_TLFragmenter_reset = reset;
  assign sram_TLFragmenter_io_in_0_a_valid = xbar_io_out_0_a_valid;
  assign sram_TLFragmenter_io_in_0_a_bits_opcode = xbar_io_out_0_a_bits_opcode;
  assign sram_TLFragmenter_io_in_0_a_bits_param = xbar_io_out_0_a_bits_param;
  assign sram_TLFragmenter_io_in_0_a_bits_size = xbar_io_out_0_a_bits_size;
  assign sram_TLFragmenter_io_in_0_a_bits_source = xbar_io_out_0_a_bits_source;
  assign sram_TLFragmenter_io_in_0_a_bits_address = xbar_io_out_0_a_bits_address;
  assign sram_TLFragmenter_io_in_0_a_bits_mask = xbar_io_out_0_a_bits_mask;
  assign sram_TLFragmenter_io_in_0_a_bits_data = xbar_io_out_0_a_bits_data;
  assign sram_TLFragmenter_io_in_0_b_ready = xbar_io_out_0_b_ready;
  assign sram_TLFragmenter_io_in_0_c_valid = xbar_io_out_0_c_valid;
  assign sram_TLFragmenter_io_in_0_c_bits_opcode = xbar_io_out_0_c_bits_opcode;
  assign sram_TLFragmenter_io_in_0_c_bits_param = xbar_io_out_0_c_bits_param;
  assign sram_TLFragmenter_io_in_0_c_bits_size = xbar_io_out_0_c_bits_size;
  assign sram_TLFragmenter_io_in_0_c_bits_source = xbar_io_out_0_c_bits_source;
  assign sram_TLFragmenter_io_in_0_c_bits_address = xbar_io_out_0_c_bits_address;
  assign sram_TLFragmenter_io_in_0_c_bits_data = xbar_io_out_0_c_bits_data;
  assign sram_TLFragmenter_io_in_0_c_bits_error = xbar_io_out_0_c_bits_error;
  assign sram_TLFragmenter_io_in_0_d_ready = xbar_io_out_0_d_ready;
  assign sram_TLFragmenter_io_in_0_e_valid = xbar_io_out_0_e_valid;
  assign sram_TLFragmenter_io_in_0_e_bits_sink = xbar_io_out_0_e_bits_sink;
  assign sram_TLFragmenter_io_out_0_a_ready = sram_TLBuffer_io_in_0_a_ready;
  assign sram_TLFragmenter_io_out_0_b_valid = sram_TLBuffer_io_in_0_b_valid;
  assign sram_TLFragmenter_io_out_0_b_bits_opcode = sram_TLBuffer_io_in_0_b_bits_opcode;
  assign sram_TLFragmenter_io_out_0_b_bits_param = sram_TLBuffer_io_in_0_b_bits_param;
  assign sram_TLFragmenter_io_out_0_b_bits_size = sram_TLBuffer_io_in_0_b_bits_size;
  assign sram_TLFragmenter_io_out_0_b_bits_source = sram_TLBuffer_io_in_0_b_bits_source;
  assign sram_TLFragmenter_io_out_0_b_bits_address = sram_TLBuffer_io_in_0_b_bits_address;
  assign sram_TLFragmenter_io_out_0_b_bits_mask = sram_TLBuffer_io_in_0_b_bits_mask;
  assign sram_TLFragmenter_io_out_0_b_bits_data = sram_TLBuffer_io_in_0_b_bits_data;
  assign sram_TLFragmenter_io_out_0_c_ready = sram_TLBuffer_io_in_0_c_ready;
  assign sram_TLFragmenter_io_out_0_d_valid = sram_TLBuffer_io_in_0_d_valid;
  assign sram_TLFragmenter_io_out_0_d_bits_opcode = sram_TLBuffer_io_in_0_d_bits_opcode;
  assign sram_TLFragmenter_io_out_0_d_bits_param = sram_TLBuffer_io_in_0_d_bits_param;
  assign sram_TLFragmenter_io_out_0_d_bits_size = sram_TLBuffer_io_in_0_d_bits_size;
  assign sram_TLFragmenter_io_out_0_d_bits_source = sram_TLBuffer_io_in_0_d_bits_source;
  assign sram_TLFragmenter_io_out_0_d_bits_sink = sram_TLBuffer_io_in_0_d_bits_sink;
  assign sram_TLFragmenter_io_out_0_d_bits_addr_lo = sram_TLBuffer_io_in_0_d_bits_addr_lo;
  assign sram_TLFragmenter_io_out_0_d_bits_data = sram_TLBuffer_io_in_0_d_bits_data;
  assign sram_TLFragmenter_io_out_0_d_bits_error = sram_TLBuffer_io_in_0_d_bits_error;
  assign sram_TLFragmenter_io_out_0_e_ready = sram_TLBuffer_io_in_0_e_ready;
  assign TLMonitor_1_clock = clock;
  assign TLMonitor_1_reset = reset;
  assign TLMonitor_1_io_in_0_a_ready = _T_30_a_ready;
  assign TLMonitor_1_io_in_0_a_valid = _T_30_a_valid;
  assign TLMonitor_1_io_in_0_a_bits_opcode = _T_30_a_bits_opcode;
  assign TLMonitor_1_io_in_0_a_bits_param = _T_30_a_bits_param;
  assign TLMonitor_1_io_in_0_a_bits_size = _T_30_a_bits_size;
  assign TLMonitor_1_io_in_0_a_bits_source = _T_30_a_bits_source;
  assign TLMonitor_1_io_in_0_a_bits_address = _T_30_a_bits_address;
  assign TLMonitor_1_io_in_0_a_bits_mask = _T_30_a_bits_mask;
  assign TLMonitor_1_io_in_0_a_bits_data = _T_30_a_bits_data;
  assign TLMonitor_1_io_in_0_b_ready = _T_30_b_ready;
  assign TLMonitor_1_io_in_0_b_valid = _T_30_b_valid;
  assign TLMonitor_1_io_in_0_b_bits_opcode = _T_30_b_bits_opcode;
  assign TLMonitor_1_io_in_0_b_bits_param = _T_30_b_bits_param;
  assign TLMonitor_1_io_in_0_b_bits_size = _T_30_b_bits_size;
  assign TLMonitor_1_io_in_0_b_bits_source = _T_30_b_bits_source;
  assign TLMonitor_1_io_in_0_b_bits_address = _T_30_b_bits_address;
  assign TLMonitor_1_io_in_0_b_bits_mask = _T_30_b_bits_mask;
  assign TLMonitor_1_io_in_0_b_bits_data = _T_30_b_bits_data;
  assign TLMonitor_1_io_in_0_c_ready = _T_30_c_ready;
  assign TLMonitor_1_io_in_0_c_valid = _T_30_c_valid;
  assign TLMonitor_1_io_in_0_c_bits_opcode = _T_30_c_bits_opcode;
  assign TLMonitor_1_io_in_0_c_bits_param = _T_30_c_bits_param;
  assign TLMonitor_1_io_in_0_c_bits_size = _T_30_c_bits_size;
  assign TLMonitor_1_io_in_0_c_bits_source = _T_30_c_bits_source;
  assign TLMonitor_1_io_in_0_c_bits_address = _T_30_c_bits_address;
  assign TLMonitor_1_io_in_0_c_bits_data = _T_30_c_bits_data;
  assign TLMonitor_1_io_in_0_c_bits_error = _T_30_c_bits_error;
  assign TLMonitor_1_io_in_0_d_ready = _T_30_d_ready;
  assign TLMonitor_1_io_in_0_d_valid = _T_30_d_valid;
  assign TLMonitor_1_io_in_0_d_bits_opcode = _T_30_d_bits_opcode;
  assign TLMonitor_1_io_in_0_d_bits_param = _T_30_d_bits_param;
  assign TLMonitor_1_io_in_0_d_bits_size = _T_30_d_bits_size;
  assign TLMonitor_1_io_in_0_d_bits_source = _T_30_d_bits_source;
  assign TLMonitor_1_io_in_0_d_bits_sink = _T_30_d_bits_sink;
  assign TLMonitor_1_io_in_0_d_bits_addr_lo = _T_30_d_bits_addr_lo;
  assign TLMonitor_1_io_in_0_d_bits_data = _T_30_d_bits_data;
  assign TLMonitor_1_io_in_0_d_bits_error = _T_30_d_bits_error;
  assign TLMonitor_1_io_in_0_e_ready = _T_30_e_ready;
  assign TLMonitor_1_io_in_0_e_valid = _T_30_e_valid;
  assign TLMonitor_1_io_in_0_e_bits_sink = _T_30_e_bits_sink;
  assign sram_TLBuffer_clock = clock;
  assign sram_TLBuffer_reset = reset;
  assign sram_TLBuffer_io_in_0_a_valid = sram_TLFragmenter_io_out_0_a_valid;
  assign sram_TLBuffer_io_in_0_a_bits_opcode = sram_TLFragmenter_io_out_0_a_bits_opcode;
  assign sram_TLBuffer_io_in_0_a_bits_param = sram_TLFragmenter_io_out_0_a_bits_param;
  assign sram_TLBuffer_io_in_0_a_bits_size = sram_TLFragmenter_io_out_0_a_bits_size;
  assign sram_TLBuffer_io_in_0_a_bits_source = sram_TLFragmenter_io_out_0_a_bits_source;
  assign sram_TLBuffer_io_in_0_a_bits_address = sram_TLFragmenter_io_out_0_a_bits_address;
  assign sram_TLBuffer_io_in_0_a_bits_mask = sram_TLFragmenter_io_out_0_a_bits_mask;
  assign sram_TLBuffer_io_in_0_a_bits_data = sram_TLFragmenter_io_out_0_a_bits_data;
  assign sram_TLBuffer_io_in_0_b_ready = sram_TLFragmenter_io_out_0_b_ready;
  assign sram_TLBuffer_io_in_0_c_valid = sram_TLFragmenter_io_out_0_c_valid;
  assign sram_TLBuffer_io_in_0_c_bits_opcode = sram_TLFragmenter_io_out_0_c_bits_opcode;
  assign sram_TLBuffer_io_in_0_c_bits_param = sram_TLFragmenter_io_out_0_c_bits_param;
  assign sram_TLBuffer_io_in_0_c_bits_size = sram_TLFragmenter_io_out_0_c_bits_size;
  assign sram_TLBuffer_io_in_0_c_bits_source = sram_TLFragmenter_io_out_0_c_bits_source;
  assign sram_TLBuffer_io_in_0_c_bits_address = sram_TLFragmenter_io_out_0_c_bits_address;
  assign sram_TLBuffer_io_in_0_c_bits_data = sram_TLFragmenter_io_out_0_c_bits_data;
  assign sram_TLBuffer_io_in_0_c_bits_error = sram_TLFragmenter_io_out_0_c_bits_error;
  assign sram_TLBuffer_io_in_0_d_ready = sram_TLFragmenter_io_out_0_d_ready;
  assign sram_TLBuffer_io_in_0_e_valid = sram_TLFragmenter_io_out_0_e_valid;
  assign sram_TLBuffer_io_in_0_e_bits_sink = sram_TLFragmenter_io_out_0_e_bits_sink;
  assign sram_TLBuffer_io_out_0_a_ready = sram_io_in_0_a_ready;
  assign sram_TLBuffer_io_out_0_b_valid = sram_io_in_0_b_valid;
  assign sram_TLBuffer_io_out_0_b_bits_opcode = sram_io_in_0_b_bits_opcode;
  assign sram_TLBuffer_io_out_0_b_bits_param = sram_io_in_0_b_bits_param;
  assign sram_TLBuffer_io_out_0_b_bits_size = sram_io_in_0_b_bits_size;
  assign sram_TLBuffer_io_out_0_b_bits_source = sram_io_in_0_b_bits_source;
  assign sram_TLBuffer_io_out_0_b_bits_address = sram_io_in_0_b_bits_address;
  assign sram_TLBuffer_io_out_0_b_bits_mask = sram_io_in_0_b_bits_mask;
  assign sram_TLBuffer_io_out_0_b_bits_data = sram_io_in_0_b_bits_data;
  assign sram_TLBuffer_io_out_0_c_ready = sram_io_in_0_c_ready;
  assign sram_TLBuffer_io_out_0_d_valid = sram_io_in_0_d_valid;
  assign sram_TLBuffer_io_out_0_d_bits_opcode = sram_io_in_0_d_bits_opcode;
  assign sram_TLBuffer_io_out_0_d_bits_param = sram_io_in_0_d_bits_param;
  assign sram_TLBuffer_io_out_0_d_bits_size = sram_io_in_0_d_bits_size;
  assign sram_TLBuffer_io_out_0_d_bits_source = sram_io_in_0_d_bits_source;
  assign sram_TLBuffer_io_out_0_d_bits_sink = sram_io_in_0_d_bits_sink;
  assign sram_TLBuffer_io_out_0_d_bits_addr_lo = sram_io_in_0_d_bits_addr_lo;
  assign sram_TLBuffer_io_out_0_d_bits_data = sram_io_in_0_d_bits_data;
  assign sram_TLBuffer_io_out_0_d_bits_error = sram_io_in_0_d_bits_error;
  assign sram_TLBuffer_io_out_0_e_ready = sram_io_in_0_e_ready;
  assign TLMonitor_2_clock = clock;
  assign TLMonitor_2_reset = reset;
  assign TLMonitor_2_io_in_0_a_ready = _T_52_a_ready;
  assign TLMonitor_2_io_in_0_a_valid = _T_52_a_valid;
  assign TLMonitor_2_io_in_0_a_bits_opcode = _T_52_a_bits_opcode;
  assign TLMonitor_2_io_in_0_a_bits_param = _T_52_a_bits_param;
  assign TLMonitor_2_io_in_0_a_bits_size = _T_52_a_bits_size;
  assign TLMonitor_2_io_in_0_a_bits_source = _T_52_a_bits_source;
  assign TLMonitor_2_io_in_0_a_bits_address = _T_52_a_bits_address;
  assign TLMonitor_2_io_in_0_a_bits_mask = _T_52_a_bits_mask;
  assign TLMonitor_2_io_in_0_a_bits_data = _T_52_a_bits_data;
  assign TLMonitor_2_io_in_0_b_ready = _T_52_b_ready;
  assign TLMonitor_2_io_in_0_b_valid = _T_52_b_valid;
  assign TLMonitor_2_io_in_0_b_bits_opcode = _T_52_b_bits_opcode;
  assign TLMonitor_2_io_in_0_b_bits_param = _T_52_b_bits_param;
  assign TLMonitor_2_io_in_0_b_bits_size = _T_52_b_bits_size;
  assign TLMonitor_2_io_in_0_b_bits_source = _T_52_b_bits_source;
  assign TLMonitor_2_io_in_0_b_bits_address = _T_52_b_bits_address;
  assign TLMonitor_2_io_in_0_b_bits_mask = _T_52_b_bits_mask;
  assign TLMonitor_2_io_in_0_b_bits_data = _T_52_b_bits_data;
  assign TLMonitor_2_io_in_0_c_ready = _T_52_c_ready;
  assign TLMonitor_2_io_in_0_c_valid = _T_52_c_valid;
  assign TLMonitor_2_io_in_0_c_bits_opcode = _T_52_c_bits_opcode;
  assign TLMonitor_2_io_in_0_c_bits_param = _T_52_c_bits_param;
  assign TLMonitor_2_io_in_0_c_bits_size = _T_52_c_bits_size;
  assign TLMonitor_2_io_in_0_c_bits_source = _T_52_c_bits_source;
  assign TLMonitor_2_io_in_0_c_bits_address = _T_52_c_bits_address;
  assign TLMonitor_2_io_in_0_c_bits_data = _T_52_c_bits_data;
  assign TLMonitor_2_io_in_0_c_bits_error = _T_52_c_bits_error;
  assign TLMonitor_2_io_in_0_d_ready = _T_52_d_ready;
  assign TLMonitor_2_io_in_0_d_valid = _T_52_d_valid;
  assign TLMonitor_2_io_in_0_d_bits_opcode = _T_52_d_bits_opcode;
  assign TLMonitor_2_io_in_0_d_bits_param = _T_52_d_bits_param;
  assign TLMonitor_2_io_in_0_d_bits_size = _T_52_d_bits_size;
  assign TLMonitor_2_io_in_0_d_bits_source = _T_52_d_bits_source;
  assign TLMonitor_2_io_in_0_d_bits_sink = _T_52_d_bits_sink;
  assign TLMonitor_2_io_in_0_d_bits_addr_lo = _T_52_d_bits_addr_lo;
  assign TLMonitor_2_io_in_0_d_bits_data = _T_52_d_bits_data;
  assign TLMonitor_2_io_in_0_d_bits_error = _T_52_d_bits_error;
  assign TLMonitor_2_io_in_0_e_ready = _T_52_e_ready;
  assign TLMonitor_2_io_in_0_e_valid = _T_52_e_valid;
  assign TLMonitor_2_io_in_0_e_bits_sink = _T_52_e_bits_sink;
  assign TLMonitor_3_clock = clock;
  assign TLMonitor_3_reset = reset;
  assign TLMonitor_3_io_in_0_a_ready = _T_74_a_ready;
  assign TLMonitor_3_io_in_0_a_valid = _T_74_a_valid;
  assign TLMonitor_3_io_in_0_a_bits_opcode = _T_74_a_bits_opcode;
  assign TLMonitor_3_io_in_0_a_bits_param = _T_74_a_bits_param;
  assign TLMonitor_3_io_in_0_a_bits_size = _T_74_a_bits_size;
  assign TLMonitor_3_io_in_0_a_bits_source = _T_74_a_bits_source;
  assign TLMonitor_3_io_in_0_a_bits_address = _T_74_a_bits_address;
  assign TLMonitor_3_io_in_0_a_bits_mask = _T_74_a_bits_mask;
  assign TLMonitor_3_io_in_0_a_bits_data = _T_74_a_bits_data;
  assign TLMonitor_3_io_in_0_b_ready = _T_74_b_ready;
  assign TLMonitor_3_io_in_0_b_valid = _T_74_b_valid;
  assign TLMonitor_3_io_in_0_b_bits_opcode = _T_74_b_bits_opcode;
  assign TLMonitor_3_io_in_0_b_bits_param = _T_74_b_bits_param;
  assign TLMonitor_3_io_in_0_b_bits_size = _T_74_b_bits_size;
  assign TLMonitor_3_io_in_0_b_bits_source = _T_74_b_bits_source;
  assign TLMonitor_3_io_in_0_b_bits_address = _T_74_b_bits_address;
  assign TLMonitor_3_io_in_0_b_bits_mask = _T_74_b_bits_mask;
  assign TLMonitor_3_io_in_0_b_bits_data = _T_74_b_bits_data;
  assign TLMonitor_3_io_in_0_c_ready = _T_74_c_ready;
  assign TLMonitor_3_io_in_0_c_valid = _T_74_c_valid;
  assign TLMonitor_3_io_in_0_c_bits_opcode = _T_74_c_bits_opcode;
  assign TLMonitor_3_io_in_0_c_bits_param = _T_74_c_bits_param;
  assign TLMonitor_3_io_in_0_c_bits_size = _T_74_c_bits_size;
  assign TLMonitor_3_io_in_0_c_bits_source = _T_74_c_bits_source;
  assign TLMonitor_3_io_in_0_c_bits_address = _T_74_c_bits_address;
  assign TLMonitor_3_io_in_0_c_bits_data = _T_74_c_bits_data;
  assign TLMonitor_3_io_in_0_c_bits_error = _T_74_c_bits_error;
  assign TLMonitor_3_io_in_0_d_ready = _T_74_d_ready;
  assign TLMonitor_3_io_in_0_d_valid = _T_74_d_valid;
  assign TLMonitor_3_io_in_0_d_bits_opcode = _T_74_d_bits_opcode;
  assign TLMonitor_3_io_in_0_d_bits_param = _T_74_d_bits_param;
  assign TLMonitor_3_io_in_0_d_bits_size = _T_74_d_bits_size;
  assign TLMonitor_3_io_in_0_d_bits_source = _T_74_d_bits_source;
  assign TLMonitor_3_io_in_0_d_bits_sink = _T_74_d_bits_sink;
  assign TLMonitor_3_io_in_0_d_bits_addr_lo = _T_74_d_bits_addr_lo;
  assign TLMonitor_3_io_in_0_d_bits_data = _T_74_d_bits_data;
  assign TLMonitor_3_io_in_0_d_bits_error = _T_74_d_bits_error;
  assign TLMonitor_3_io_in_0_e_ready = _T_74_e_ready;
  assign TLMonitor_3_io_in_0_e_valid = _T_74_e_valid;
  assign TLMonitor_3_io_in_0_e_bits_sink = _T_74_e_bits_sink;
  assign _T_8_a_ready = _T_15_ready;
  assign _T_8_a_valid = _T_15_valid;
  assign _T_8_a_bits_opcode = _T_15_bits_opcode;
  assign _T_8_a_bits_param = _T_15_bits_param;
  assign _T_8_a_bits_size = _T_15_bits_size;
  assign _T_8_a_bits_source = _T_15_bits_source;
  assign _T_8_a_bits_address = _T_15_bits_address;
  assign _T_8_a_bits_mask = _T_15_bits_mask;
  assign _T_8_a_bits_data = _T_15_bits_data;
  assign _T_8_b_ready = _T_17_ready;
  assign _T_8_b_valid = _T_17_valid;
  assign _T_8_b_bits_opcode = _T_17_bits_opcode;
  assign _T_8_b_bits_param = _T_17_bits_param;
  assign _T_8_b_bits_size = _T_17_bits_size;
  assign _T_8_b_bits_source = _T_17_bits_source;
  assign _T_8_b_bits_address = _T_17_bits_address;
  assign _T_8_b_bits_mask = _T_17_bits_mask;
  assign _T_8_b_bits_data = _T_17_bits_data;
  assign _T_8_c_ready = _T_19_ready;
  assign _T_8_c_valid = _T_19_valid;
  assign _T_8_c_bits_opcode = _T_19_bits_opcode;
  assign _T_8_c_bits_param = _T_19_bits_param;
  assign _T_8_c_bits_size = _T_19_bits_size;
  assign _T_8_c_bits_source = _T_19_bits_source;
  assign _T_8_c_bits_address = _T_19_bits_address;
  assign _T_8_c_bits_data = _T_19_bits_data;
  assign _T_8_c_bits_error = _T_19_bits_error;
  assign _T_8_d_ready = _T_21_ready;
  assign _T_8_d_valid = _T_21_valid;
  assign _T_8_d_bits_opcode = _T_21_bits_opcode;
  assign _T_8_d_bits_param = _T_21_bits_param;
  assign _T_8_d_bits_size = _T_21_bits_size;
  assign _T_8_d_bits_source = _T_21_bits_source;
  assign _T_8_d_bits_sink = _T_21_bits_sink;
  assign _T_8_d_bits_addr_lo = _T_21_bits_addr_lo;
  assign _T_8_d_bits_data = _T_21_bits_data;
  assign _T_8_d_bits_error = _T_21_bits_error;
  assign _T_8_e_ready = _T_23_ready;
  assign _T_8_e_valid = _T_23_valid;
  assign _T_8_e_bits_sink = _T_23_bits_sink;
  assign _T_15_ready = xbar_io_in_0_a_ready;
  assign _T_15_valid = io_tl_0_a_valid;
  assign _T_15_bits_opcode = io_tl_0_a_bits_opcode;
  assign _T_15_bits_param = io_tl_0_a_bits_param;
  assign _T_15_bits_size = io_tl_0_a_bits_size;
  assign _T_15_bits_source = io_tl_0_a_bits_source;
  assign _T_15_bits_address = io_tl_0_a_bits_address;
  assign _T_15_bits_mask = io_tl_0_a_bits_mask;
  assign _T_15_bits_data = io_tl_0_a_bits_data;
  assign _T_17_ready = io_tl_0_b_ready;
  assign _T_17_valid = xbar_io_in_0_b_valid;
  assign _T_17_bits_opcode = xbar_io_in_0_b_bits_opcode;
  assign _T_17_bits_param = xbar_io_in_0_b_bits_param;
  assign _T_17_bits_size = xbar_io_in_0_b_bits_size;
  assign _T_17_bits_source = xbar_io_in_0_b_bits_source;
  assign _T_17_bits_address = xbar_io_in_0_b_bits_address;
  assign _T_17_bits_mask = xbar_io_in_0_b_bits_mask;
  assign _T_17_bits_data = xbar_io_in_0_b_bits_data;
  assign _T_19_ready = xbar_io_in_0_c_ready;
  assign _T_19_valid = io_tl_0_c_valid;
  assign _T_19_bits_opcode = io_tl_0_c_bits_opcode;
  assign _T_19_bits_param = io_tl_0_c_bits_param;
  assign _T_19_bits_size = io_tl_0_c_bits_size;
  assign _T_19_bits_source = io_tl_0_c_bits_source;
  assign _T_19_bits_address = io_tl_0_c_bits_address;
  assign _T_19_bits_data = io_tl_0_c_bits_data;
  assign _T_19_bits_error = io_tl_0_c_bits_error;
  assign _T_21_ready = io_tl_0_d_ready;
  assign _T_21_valid = xbar_io_in_0_d_valid;
  assign _T_21_bits_opcode = xbar_io_in_0_d_bits_opcode;
  assign _T_21_bits_param = xbar_io_in_0_d_bits_param;
  assign _T_21_bits_size = xbar_io_in_0_d_bits_size;
  assign _T_21_bits_source = xbar_io_in_0_d_bits_source;
  assign _T_21_bits_sink = xbar_io_in_0_d_bits_sink;
  assign _T_21_bits_addr_lo = xbar_io_in_0_d_bits_addr_lo;
  assign _T_21_bits_data = xbar_io_in_0_d_bits_data;
  assign _T_21_bits_error = xbar_io_in_0_d_bits_error;
  assign _T_23_ready = xbar_io_in_0_e_ready;
  assign _T_23_valid = io_tl_0_e_valid;
  assign _T_23_bits_sink = io_tl_0_e_bits_sink;
  assign _T_30_a_ready = _T_37_ready;
  assign _T_30_a_valid = _T_37_valid;
  assign _T_30_a_bits_opcode = _T_37_bits_opcode;
  assign _T_30_a_bits_param = _T_37_bits_param;
  assign _T_30_a_bits_size = _T_37_bits_size;
  assign _T_30_a_bits_source = _T_37_bits_source;
  assign _T_30_a_bits_address = _T_37_bits_address;
  assign _T_30_a_bits_mask = _T_37_bits_mask;
  assign _T_30_a_bits_data = _T_37_bits_data;
  assign _T_30_b_ready = _T_39_ready;
  assign _T_30_b_valid = _T_39_valid;
  assign _T_30_b_bits_opcode = _T_39_bits_opcode;
  assign _T_30_b_bits_param = _T_39_bits_param;
  assign _T_30_b_bits_size = _T_39_bits_size;
  assign _T_30_b_bits_source = _T_39_bits_source;
  assign _T_30_b_bits_address = _T_39_bits_address;
  assign _T_30_b_bits_mask = _T_39_bits_mask;
  assign _T_30_b_bits_data = _T_39_bits_data;
  assign _T_30_c_ready = _T_41_ready;
  assign _T_30_c_valid = _T_41_valid;
  assign _T_30_c_bits_opcode = _T_41_bits_opcode;
  assign _T_30_c_bits_param = _T_41_bits_param;
  assign _T_30_c_bits_size = _T_41_bits_size;
  assign _T_30_c_bits_source = _T_41_bits_source;
  assign _T_30_c_bits_address = _T_41_bits_address;
  assign _T_30_c_bits_data = _T_41_bits_data;
  assign _T_30_c_bits_error = _T_41_bits_error;
  assign _T_30_d_ready = _T_43_ready;
  assign _T_30_d_valid = _T_43_valid;
  assign _T_30_d_bits_opcode = _T_43_bits_opcode;
  assign _T_30_d_bits_param = _T_43_bits_param;
  assign _T_30_d_bits_size = _T_43_bits_size;
  assign _T_30_d_bits_source = _T_43_bits_source;
  assign _T_30_d_bits_sink = _T_43_bits_sink;
  assign _T_30_d_bits_addr_lo = _T_43_bits_addr_lo;
  assign _T_30_d_bits_data = _T_43_bits_data;
  assign _T_30_d_bits_error = _T_43_bits_error;
  assign _T_30_e_ready = _T_45_ready;
  assign _T_30_e_valid = _T_45_valid;
  assign _T_30_e_bits_sink = _T_45_bits_sink;
  assign _T_37_ready = sram_TLFragmenter_io_in_0_a_ready;
  assign _T_37_valid = xbar_io_out_0_a_valid;
  assign _T_37_bits_opcode = xbar_io_out_0_a_bits_opcode;
  assign _T_37_bits_param = xbar_io_out_0_a_bits_param;
  assign _T_37_bits_size = xbar_io_out_0_a_bits_size;
  assign _T_37_bits_source = xbar_io_out_0_a_bits_source;
  assign _T_37_bits_address = xbar_io_out_0_a_bits_address;
  assign _T_37_bits_mask = xbar_io_out_0_a_bits_mask;
  assign _T_37_bits_data = xbar_io_out_0_a_bits_data;
  assign _T_39_ready = xbar_io_out_0_b_ready;
  assign _T_39_valid = sram_TLFragmenter_io_in_0_b_valid;
  assign _T_39_bits_opcode = sram_TLFragmenter_io_in_0_b_bits_opcode;
  assign _T_39_bits_param = sram_TLFragmenter_io_in_0_b_bits_param;
  assign _T_39_bits_size = sram_TLFragmenter_io_in_0_b_bits_size;
  assign _T_39_bits_source = sram_TLFragmenter_io_in_0_b_bits_source;
  assign _T_39_bits_address = sram_TLFragmenter_io_in_0_b_bits_address;
  assign _T_39_bits_mask = sram_TLFragmenter_io_in_0_b_bits_mask;
  assign _T_39_bits_data = sram_TLFragmenter_io_in_0_b_bits_data;
  assign _T_41_ready = sram_TLFragmenter_io_in_0_c_ready;
  assign _T_41_valid = xbar_io_out_0_c_valid;
  assign _T_41_bits_opcode = xbar_io_out_0_c_bits_opcode;
  assign _T_41_bits_param = xbar_io_out_0_c_bits_param;
  assign _T_41_bits_size = xbar_io_out_0_c_bits_size;
  assign _T_41_bits_source = xbar_io_out_0_c_bits_source;
  assign _T_41_bits_address = xbar_io_out_0_c_bits_address;
  assign _T_41_bits_data = xbar_io_out_0_c_bits_data;
  assign _T_41_bits_error = xbar_io_out_0_c_bits_error;
  assign _T_43_ready = xbar_io_out_0_d_ready;
  assign _T_43_valid = sram_TLFragmenter_io_in_0_d_valid;
  assign _T_43_bits_opcode = sram_TLFragmenter_io_in_0_d_bits_opcode;
  assign _T_43_bits_param = sram_TLFragmenter_io_in_0_d_bits_param;
  assign _T_43_bits_size = sram_TLFragmenter_io_in_0_d_bits_size;
  assign _T_43_bits_source = sram_TLFragmenter_io_in_0_d_bits_source;
  assign _T_43_bits_sink = sram_TLFragmenter_io_in_0_d_bits_sink;
  assign _T_43_bits_addr_lo = sram_TLFragmenter_io_in_0_d_bits_addr_lo;
  assign _T_43_bits_data = sram_TLFragmenter_io_in_0_d_bits_data;
  assign _T_43_bits_error = sram_TLFragmenter_io_in_0_d_bits_error;
  assign _T_45_ready = sram_TLFragmenter_io_in_0_e_ready;
  assign _T_45_valid = xbar_io_out_0_e_valid;
  assign _T_45_bits_sink = xbar_io_out_0_e_bits_sink;
  assign _T_52_a_ready = _T_59_ready;
  assign _T_52_a_valid = _T_59_valid;
  assign _T_52_a_bits_opcode = _T_59_bits_opcode;
  assign _T_52_a_bits_param = _T_59_bits_param;
  assign _T_52_a_bits_size = _T_59_bits_size;
  assign _T_52_a_bits_source = _T_59_bits_source;
  assign _T_52_a_bits_address = _T_59_bits_address;
  assign _T_52_a_bits_mask = _T_59_bits_mask;
  assign _T_52_a_bits_data = _T_59_bits_data;
  assign _T_52_b_ready = _T_61_ready;
  assign _T_52_b_valid = _T_61_valid;
  assign _T_52_b_bits_opcode = _T_61_bits_opcode;
  assign _T_52_b_bits_param = _T_61_bits_param;
  assign _T_52_b_bits_size = _T_61_bits_size;
  assign _T_52_b_bits_source = _T_61_bits_source;
  assign _T_52_b_bits_address = _T_61_bits_address;
  assign _T_52_b_bits_mask = _T_61_bits_mask;
  assign _T_52_b_bits_data = _T_61_bits_data;
  assign _T_52_c_ready = _T_63_ready;
  assign _T_52_c_valid = _T_63_valid;
  assign _T_52_c_bits_opcode = _T_63_bits_opcode;
  assign _T_52_c_bits_param = _T_63_bits_param;
  assign _T_52_c_bits_size = _T_63_bits_size;
  assign _T_52_c_bits_source = _T_63_bits_source;
  assign _T_52_c_bits_address = _T_63_bits_address;
  assign _T_52_c_bits_data = _T_63_bits_data;
  assign _T_52_c_bits_error = _T_63_bits_error;
  assign _T_52_d_ready = _T_65_ready;
  assign _T_52_d_valid = _T_65_valid;
  assign _T_52_d_bits_opcode = _T_65_bits_opcode;
  assign _T_52_d_bits_param = _T_65_bits_param;
  assign _T_52_d_bits_size = _T_65_bits_size;
  assign _T_52_d_bits_source = _T_65_bits_source;
  assign _T_52_d_bits_sink = _T_65_bits_sink;
  assign _T_52_d_bits_addr_lo = _T_65_bits_addr_lo;
  assign _T_52_d_bits_data = _T_65_bits_data;
  assign _T_52_d_bits_error = _T_65_bits_error;
  assign _T_52_e_ready = _T_67_ready;
  assign _T_52_e_valid = _T_67_valid;
  assign _T_52_e_bits_sink = _T_67_bits_sink;
  assign _T_59_ready = sram_TLBuffer_io_in_0_a_ready;
  assign _T_59_valid = sram_TLFragmenter_io_out_0_a_valid;
  assign _T_59_bits_opcode = sram_TLFragmenter_io_out_0_a_bits_opcode;
  assign _T_59_bits_param = sram_TLFragmenter_io_out_0_a_bits_param;
  assign _T_59_bits_size = sram_TLFragmenter_io_out_0_a_bits_size;
  assign _T_59_bits_source = sram_TLFragmenter_io_out_0_a_bits_source;
  assign _T_59_bits_address = sram_TLFragmenter_io_out_0_a_bits_address;
  assign _T_59_bits_mask = sram_TLFragmenter_io_out_0_a_bits_mask;
  assign _T_59_bits_data = sram_TLFragmenter_io_out_0_a_bits_data;
  assign _T_61_ready = sram_TLFragmenter_io_out_0_b_ready;
  assign _T_61_valid = sram_TLBuffer_io_in_0_b_valid;
  assign _T_61_bits_opcode = sram_TLBuffer_io_in_0_b_bits_opcode;
  assign _T_61_bits_param = sram_TLBuffer_io_in_0_b_bits_param;
  assign _T_61_bits_size = sram_TLBuffer_io_in_0_b_bits_size;
  assign _T_61_bits_source = sram_TLBuffer_io_in_0_b_bits_source;
  assign _T_61_bits_address = sram_TLBuffer_io_in_0_b_bits_address;
  assign _T_61_bits_mask = sram_TLBuffer_io_in_0_b_bits_mask;
  assign _T_61_bits_data = sram_TLBuffer_io_in_0_b_bits_data;
  assign _T_63_ready = sram_TLBuffer_io_in_0_c_ready;
  assign _T_63_valid = sram_TLFragmenter_io_out_0_c_valid;
  assign _T_63_bits_opcode = sram_TLFragmenter_io_out_0_c_bits_opcode;
  assign _T_63_bits_param = sram_TLFragmenter_io_out_0_c_bits_param;
  assign _T_63_bits_size = sram_TLFragmenter_io_out_0_c_bits_size;
  assign _T_63_bits_source = sram_TLFragmenter_io_out_0_c_bits_source;
  assign _T_63_bits_address = sram_TLFragmenter_io_out_0_c_bits_address;
  assign _T_63_bits_data = sram_TLFragmenter_io_out_0_c_bits_data;
  assign _T_63_bits_error = sram_TLFragmenter_io_out_0_c_bits_error;
  assign _T_65_ready = sram_TLFragmenter_io_out_0_d_ready;
  assign _T_65_valid = sram_TLBuffer_io_in_0_d_valid;
  assign _T_65_bits_opcode = sram_TLBuffer_io_in_0_d_bits_opcode;
  assign _T_65_bits_param = sram_TLBuffer_io_in_0_d_bits_param;
  assign _T_65_bits_size = sram_TLBuffer_io_in_0_d_bits_size;
  assign _T_65_bits_source = sram_TLBuffer_io_in_0_d_bits_source;
  assign _T_65_bits_sink = sram_TLBuffer_io_in_0_d_bits_sink;
  assign _T_65_bits_addr_lo = sram_TLBuffer_io_in_0_d_bits_addr_lo;
  assign _T_65_bits_data = sram_TLBuffer_io_in_0_d_bits_data;
  assign _T_65_bits_error = sram_TLBuffer_io_in_0_d_bits_error;
  assign _T_67_ready = sram_TLBuffer_io_in_0_e_ready;
  assign _T_67_valid = sram_TLFragmenter_io_out_0_e_valid;
  assign _T_67_bits_sink = sram_TLFragmenter_io_out_0_e_bits_sink;
  assign _T_74_a_ready = _T_81_ready;
  assign _T_74_a_valid = _T_81_valid;
  assign _T_74_a_bits_opcode = _T_81_bits_opcode;
  assign _T_74_a_bits_param = _T_81_bits_param;
  assign _T_74_a_bits_size = _T_81_bits_size;
  assign _T_74_a_bits_source = _T_81_bits_source;
  assign _T_74_a_bits_address = _T_81_bits_address;
  assign _T_74_a_bits_mask = _T_81_bits_mask;
  assign _T_74_a_bits_data = _T_81_bits_data;
  assign _T_74_b_ready = _T_83_ready;
  assign _T_74_b_valid = _T_83_valid;
  assign _T_74_b_bits_opcode = _T_83_bits_opcode;
  assign _T_74_b_bits_param = _T_83_bits_param;
  assign _T_74_b_bits_size = _T_83_bits_size;
  assign _T_74_b_bits_source = _T_83_bits_source;
  assign _T_74_b_bits_address = _T_83_bits_address;
  assign _T_74_b_bits_mask = _T_83_bits_mask;
  assign _T_74_b_bits_data = _T_83_bits_data;
  assign _T_74_c_ready = _T_85_ready;
  assign _T_74_c_valid = _T_85_valid;
  assign _T_74_c_bits_opcode = _T_85_bits_opcode;
  assign _T_74_c_bits_param = _T_85_bits_param;
  assign _T_74_c_bits_size = _T_85_bits_size;
  assign _T_74_c_bits_source = _T_85_bits_source;
  assign _T_74_c_bits_address = _T_85_bits_address;
  assign _T_74_c_bits_data = _T_85_bits_data;
  assign _T_74_c_bits_error = _T_85_bits_error;
  assign _T_74_d_ready = _T_87_ready;
  assign _T_74_d_valid = _T_87_valid;
  assign _T_74_d_bits_opcode = _T_87_bits_opcode;
  assign _T_74_d_bits_param = _T_87_bits_param;
  assign _T_74_d_bits_size = _T_87_bits_size;
  assign _T_74_d_bits_source = _T_87_bits_source;
  assign _T_74_d_bits_sink = _T_87_bits_sink;
  assign _T_74_d_bits_addr_lo = _T_87_bits_addr_lo;
  assign _T_74_d_bits_data = _T_87_bits_data;
  assign _T_74_d_bits_error = _T_87_bits_error;
  assign _T_74_e_ready = _T_89_ready;
  assign _T_74_e_valid = _T_89_valid;
  assign _T_74_e_bits_sink = _T_89_bits_sink;
  assign _T_81_ready = sram_io_in_0_a_ready;
  assign _T_81_valid = sram_TLBuffer_io_out_0_a_valid;
  assign _T_81_bits_opcode = sram_TLBuffer_io_out_0_a_bits_opcode;
  assign _T_81_bits_param = sram_TLBuffer_io_out_0_a_bits_param;
  assign _T_81_bits_size = sram_TLBuffer_io_out_0_a_bits_size;
  assign _T_81_bits_source = sram_TLBuffer_io_out_0_a_bits_source;
  assign _T_81_bits_address = sram_TLBuffer_io_out_0_a_bits_address;
  assign _T_81_bits_mask = sram_TLBuffer_io_out_0_a_bits_mask;
  assign _T_81_bits_data = sram_TLBuffer_io_out_0_a_bits_data;
  assign _T_83_ready = sram_TLBuffer_io_out_0_b_ready;
  assign _T_83_valid = sram_io_in_0_b_valid;
  assign _T_83_bits_opcode = sram_io_in_0_b_bits_opcode;
  assign _T_83_bits_param = sram_io_in_0_b_bits_param;
  assign _T_83_bits_size = sram_io_in_0_b_bits_size;
  assign _T_83_bits_source = sram_io_in_0_b_bits_source;
  assign _T_83_bits_address = sram_io_in_0_b_bits_address;
  assign _T_83_bits_mask = sram_io_in_0_b_bits_mask;
  assign _T_83_bits_data = sram_io_in_0_b_bits_data;
  assign _T_85_ready = sram_io_in_0_c_ready;
  assign _T_85_valid = sram_TLBuffer_io_out_0_c_valid;
  assign _T_85_bits_opcode = sram_TLBuffer_io_out_0_c_bits_opcode;
  assign _T_85_bits_param = sram_TLBuffer_io_out_0_c_bits_param;
  assign _T_85_bits_size = sram_TLBuffer_io_out_0_c_bits_size;
  assign _T_85_bits_source = sram_TLBuffer_io_out_0_c_bits_source;
  assign _T_85_bits_address = sram_TLBuffer_io_out_0_c_bits_address;
  assign _T_85_bits_data = sram_TLBuffer_io_out_0_c_bits_data;
  assign _T_85_bits_error = sram_TLBuffer_io_out_0_c_bits_error;
  assign _T_87_ready = sram_TLBuffer_io_out_0_d_ready;
  assign _T_87_valid = sram_io_in_0_d_valid;
  assign _T_87_bits_opcode = sram_io_in_0_d_bits_opcode;
  assign _T_87_bits_param = sram_io_in_0_d_bits_param;
  assign _T_87_bits_size = sram_io_in_0_d_bits_size;
  assign _T_87_bits_source = sram_io_in_0_d_bits_source;
  assign _T_87_bits_sink = sram_io_in_0_d_bits_sink;
  assign _T_87_bits_addr_lo = sram_io_in_0_d_bits_addr_lo;
  assign _T_87_bits_data = sram_io_in_0_d_bits_data;
  assign _T_87_bits_error = sram_io_in_0_d_bits_error;
  assign _T_89_ready = sram_io_in_0_e_ready;
  assign _T_89_valid = sram_TLBuffer_io_out_0_e_valid;
  assign _T_89_bits_sink = sram_TLBuffer_io_out_0_e_bits_sink;
endmodule
