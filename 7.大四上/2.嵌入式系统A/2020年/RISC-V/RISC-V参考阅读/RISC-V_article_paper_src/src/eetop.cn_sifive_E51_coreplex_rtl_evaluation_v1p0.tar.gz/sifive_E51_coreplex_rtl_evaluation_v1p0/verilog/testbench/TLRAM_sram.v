//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLRAM_sram(
  input         clock,
  input         reset,
  output        io_in_0_a_ready,
  input         io_in_0_a_valid,
  input  [2:0]  io_in_0_a_bits_opcode,
  input  [2:0]  io_in_0_a_bits_param,
  input  [1:0]  io_in_0_a_bits_size,
  input  [3:0]  io_in_0_a_bits_source,
  input  [29:0] io_in_0_a_bits_address,
  input  [3:0]  io_in_0_a_bits_mask,
  input  [31:0] io_in_0_a_bits_data,
  input         io_in_0_b_ready,
  output        io_in_0_b_valid,
  output [2:0]  io_in_0_b_bits_opcode,
  output [1:0]  io_in_0_b_bits_param,
  output [1:0]  io_in_0_b_bits_size,
  output [3:0]  io_in_0_b_bits_source,
  output [29:0] io_in_0_b_bits_address,
  output [3:0]  io_in_0_b_bits_mask,
  output [31:0] io_in_0_b_bits_data,
  output        io_in_0_c_ready,
  input         io_in_0_c_valid,
  input  [2:0]  io_in_0_c_bits_opcode,
  input  [2:0]  io_in_0_c_bits_param,
  input  [1:0]  io_in_0_c_bits_size,
  input  [3:0]  io_in_0_c_bits_source,
  input  [29:0] io_in_0_c_bits_address,
  input  [31:0] io_in_0_c_bits_data,
  input         io_in_0_c_bits_error,
  input         io_in_0_d_ready,
  output        io_in_0_d_valid,
  output [2:0]  io_in_0_d_bits_opcode,
  output [1:0]  io_in_0_d_bits_param,
  output [1:0]  io_in_0_d_bits_size,
  output [3:0]  io_in_0_d_bits_source,
  output        io_in_0_d_bits_sink,
  output [1:0]  io_in_0_d_bits_addr_lo,
  output [31:0] io_in_0_d_bits_data,
  output        io_in_0_d_bits_error,
  output        io_in_0_e_ready,
  input         io_in_0_e_valid,
  input         io_in_0_e_bits_sink
);
  wire [27:0] _T_60;
  wire  addrBits_0;
  wire  addrBits_1;
  wire  addrBits_2;
  wire  addrBits_3;
  wire  addrBits_4;
  wire  addrBits_5;
  wire  addrBits_6;
  wire  addrBits_7;
  wire  addrBits_8;
  wire  addrBits_9;
  wire  addrBits_10;
  wire [1:0] _T_78;
  wire [1:0] _T_79;
  wire [2:0] _T_80;
  wire [4:0] _T_81;
  wire [1:0] _T_82;
  wire [2:0] _T_83;
  wire [1:0] _T_84;
  wire [2:0] _T_85;
  wire [5:0] _T_86;
  wire [10:0] memAddress;
  wire [10:0] mem_RW0_addr;
  wire  mem_RW0_en;
  wire  mem_RW0_clk;
  wire  mem_RW0_wmode;
  wire [7:0] mem_RW0_wdata_0;
  wire [7:0] mem_RW0_wdata_1;
  wire [7:0] mem_RW0_wdata_2;
  wire [7:0] mem_RW0_wdata_3;
  wire [7:0] mem_RW0_rdata_0;
  wire [7:0] mem_RW0_rdata_1;
  wire [7:0] mem_RW0_rdata_2;
  wire [7:0] mem_RW0_rdata_3;
  wire  mem_RW0_wmask_0;
  wire  mem_RW0_wmask_1;
  wire  mem_RW0_wmask_2;
  wire  mem_RW0_wmask_3;
  reg  d_full;
  reg [31:0] _GEN_13;
  reg  d_read;
  reg [31:0] _GEN_14;
  reg [1:0] d_size;
  reg [31:0] _GEN_15;
  reg [3:0] d_source;
  reg [31:0] _GEN_16;
  reg [1:0] d_addr;
  reg [31:0] _GEN_17;
  wire [31:0] d_data;
  wire  _T_104;
  wire  _GEN_0;
  wire  _T_106;
  wire  _GEN_1;
  wire  _T_109;
  wire  _T_110;
  wire [2:0] _T_114_opcode;
  wire [1:0] _T_114_param;
  wire [1:0] _T_114_size;
  wire [3:0] _T_114_source;
  wire  _T_114_sink;
  wire [1:0] _T_114_addr_lo;
  wire [31:0] _T_114_data;
  wire  _T_114_error;
  wire  read;
  wire [7:0] rdata_0;
  wire [7:0] rdata_1;
  wire [7:0] rdata_2;
  wire [7:0] rdata_3;
  wire [7:0] _T_132;
  wire [7:0] _T_133;
  wire [7:0] _T_134;
  wire [7:0] _T_135;
  wire [7:0] wdata_0;
  wire [7:0] wdata_1;
  wire [7:0] wdata_2;
  wire [7:0] wdata_3;
  wire [15:0] _T_144;
  wire [15:0] _T_145;
  wire [31:0] _T_146;
  wire [1:0] _T_148;
  wire  _GEN_2;
  wire [1:0] _GEN_3;
  wire [3:0] _GEN_4;
  wire [1:0] _GEN_5;
  wire  _T_151;
  wire  _T_152;
  wire  _T_153;
  wire  _T_154;
  wire  _T_155;
  wire  _T_156;
  wire  _GEN_18;
  wire  _GEN_20;
  wire  _GEN_22;
  wire  _GEN_24;
  wire  ren;
  wire [10:0] _T_171;
  reg  _T_188;
  reg [31:0] _GEN_19;
  reg [7:0] _T_206_0;
  reg [31:0] _GEN_21;
  reg [7:0] _T_206_1;
  reg [31:0] _GEN_23;
  reg [7:0] _T_206_2;
  reg [31:0] _GEN_25;
  reg [7:0] _T_206_3;
  reg [31:0] _GEN_26;
  wire [7:0] _GEN_29;
  wire [7:0] _GEN_30;
  wire [7:0] _GEN_31;
  wire [7:0] _GEN_32;
  reg [2:0] _GEN_6;
  reg [31:0] _GEN_27;
  reg [1:0] _GEN_7;
  reg [31:0] _GEN_28;
  reg [1:0] _GEN_8;
  reg [31:0] _GEN_33;
  reg [3:0] _GEN_9;
  reg [31:0] _GEN_34;
  reg [29:0] _GEN_10;
  reg [31:0] _GEN_35;
  reg [3:0] _GEN_11;
  reg [31:0] _GEN_36;
  reg [31:0] _GEN_12;
  reg [31:0] _GEN_37;
  mem mem (
    .RW0_addr(mem_RW0_addr),
    .RW0_en(mem_RW0_en),
    .RW0_clk(mem_RW0_clk),
    .RW0_wmode(mem_RW0_wmode),
    .RW0_wdata_0(mem_RW0_wdata_0),
    .RW0_wdata_1(mem_RW0_wdata_1),
    .RW0_wdata_2(mem_RW0_wdata_2),
    .RW0_wdata_3(mem_RW0_wdata_3),
    .RW0_rdata_0(mem_RW0_rdata_0),
    .RW0_rdata_1(mem_RW0_rdata_1),
    .RW0_rdata_2(mem_RW0_rdata_2),
    .RW0_rdata_3(mem_RW0_rdata_3),
    .RW0_wmask_0(mem_RW0_wmask_0),
    .RW0_wmask_1(mem_RW0_wmask_1),
    .RW0_wmask_2(mem_RW0_wmask_2),
    .RW0_wmask_3(mem_RW0_wmask_3)
  );
  assign io_in_0_a_ready = _T_110;
  assign io_in_0_b_valid = 1'h0;
  assign io_in_0_b_bits_opcode = _GEN_6;
  assign io_in_0_b_bits_param = _GEN_7;
  assign io_in_0_b_bits_size = _GEN_8;
  assign io_in_0_b_bits_source = _GEN_9;
  assign io_in_0_b_bits_address = _GEN_10;
  assign io_in_0_b_bits_mask = _GEN_11;
  assign io_in_0_b_bits_data = _GEN_12;
  assign io_in_0_c_ready = 1'h1;
  assign io_in_0_d_valid = d_full;
  assign io_in_0_d_bits_opcode = {{2'd0}, d_read};
  assign io_in_0_d_bits_param = _T_114_param;
  assign io_in_0_d_bits_size = _T_114_size;
  assign io_in_0_d_bits_source = _T_114_source;
  assign io_in_0_d_bits_sink = _T_114_sink;
  assign io_in_0_d_bits_addr_lo = _T_114_addr_lo;
  assign io_in_0_d_bits_data = d_data;
  assign io_in_0_d_bits_error = _T_114_error;
  assign io_in_0_e_ready = 1'h1;
  assign _T_60 = io_in_0_a_bits_address[29:2];
  assign addrBits_0 = _T_60[0];
  assign addrBits_1 = _T_60[1];
  assign addrBits_2 = _T_60[2];
  assign addrBits_3 = _T_60[3];
  assign addrBits_4 = _T_60[4];
  assign addrBits_5 = _T_60[5];
  assign addrBits_6 = _T_60[6];
  assign addrBits_7 = _T_60[7];
  assign addrBits_8 = _T_60[8];
  assign addrBits_9 = _T_60[9];
  assign addrBits_10 = _T_60[10];
  assign _T_78 = {addrBits_1,addrBits_0};
  assign _T_79 = {addrBits_4,addrBits_3};
  assign _T_80 = {_T_79,addrBits_2};
  assign _T_81 = {_T_80,_T_78};
  assign _T_82 = {addrBits_7,addrBits_6};
  assign _T_83 = {_T_82,addrBits_5};
  assign _T_84 = {addrBits_10,addrBits_9};
  assign _T_85 = {_T_84,addrBits_8};
  assign _T_86 = {_T_85,_T_83};
  assign memAddress = {_T_86,_T_81};
  assign mem_RW0_addr = _T_152 ? memAddress : _T_171;
  assign mem_RW0_en = ren | _T_152;
  assign mem_RW0_clk = clock;
  assign mem_RW0_wmode = _T_152;
  assign mem_RW0_wdata_0 = wdata_0;
  assign mem_RW0_wdata_1 = wdata_1;
  assign mem_RW0_wdata_2 = wdata_2;
  assign mem_RW0_wdata_3 = wdata_3;
  assign mem_RW0_wmask_0 = _GEN_18;
  assign mem_RW0_wmask_1 = _GEN_20;
  assign mem_RW0_wmask_2 = _GEN_22;
  assign mem_RW0_wmask_3 = _GEN_24;
  assign d_data = _T_146;
  assign _T_104 = io_in_0_d_ready & io_in_0_d_valid;
  assign _GEN_0 = _T_104 ? 1'h0 : d_full;
  assign _T_106 = io_in_0_a_ready & io_in_0_a_valid;
  assign _GEN_1 = _T_106 ? 1'h1 : _GEN_0;
  assign _T_109 = d_full == 1'h0;
  assign _T_110 = io_in_0_d_ready | _T_109;
  assign _T_114_opcode = 3'h0;
  assign _T_114_param = 2'h0;
  assign _T_114_size = d_size;
  assign _T_114_source = d_source;
  assign _T_114_sink = 1'h0;
  assign _T_114_addr_lo = d_addr;
  assign _T_114_data = 32'h0;
  assign _T_114_error = 1'h0;
  assign read = io_in_0_a_bits_opcode == 3'h4;
  assign rdata_0 = _GEN_29;
  assign rdata_1 = _GEN_30;
  assign rdata_2 = _GEN_31;
  assign rdata_3 = _GEN_32;
  assign _T_132 = io_in_0_a_bits_data[7:0];
  assign _T_133 = io_in_0_a_bits_data[15:8];
  assign _T_134 = io_in_0_a_bits_data[23:16];
  assign _T_135 = io_in_0_a_bits_data[31:24];
  assign wdata_0 = _T_132;
  assign wdata_1 = _T_133;
  assign wdata_2 = _T_134;
  assign wdata_3 = _T_135;
  assign _T_144 = {rdata_1,rdata_0};
  assign _T_145 = {rdata_3,rdata_2};
  assign _T_146 = {_T_145,_T_144};
  assign _T_148 = io_in_0_a_bits_address[1:0];
  assign _GEN_2 = _T_106 ? read : d_read;
  assign _GEN_3 = _T_106 ? io_in_0_a_bits_size : d_size;
  assign _GEN_4 = _T_106 ? io_in_0_a_bits_source : d_source;
  assign _GEN_5 = _T_106 ? _T_148 : d_addr;
  assign _T_151 = read == 1'h0;
  assign _T_152 = _T_106 & _T_151;
  assign _T_153 = io_in_0_a_bits_mask[0];
  assign _T_154 = io_in_0_a_bits_mask[1];
  assign _T_155 = io_in_0_a_bits_mask[2];
  assign _T_156 = io_in_0_a_bits_mask[3];
  assign _GEN_18 = _T_152 ? _T_153 : 1'h0;
  assign _GEN_20 = _T_152 ? _T_154 : 1'h0;
  assign _GEN_22 = _T_152 ? _T_155 : 1'h0;
  assign _GEN_24 = _T_152 ? _T_156 : 1'h0;
  assign ren = _T_106 & read;
  assign _T_171 = memAddress;
  assign _GEN_29 = _T_188 ? mem_RW0_rdata_0 : _T_206_0;
  assign _GEN_30 = _T_188 ? mem_RW0_rdata_1 : _T_206_1;
  assign _GEN_31 = _T_188 ? mem_RW0_rdata_2 : _T_206_2;
  assign _GEN_32 = _T_188 ? mem_RW0_rdata_3 : _T_206_3;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_13 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  d_full = _GEN_13[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_14 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  d_read = _GEN_14[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_15 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  d_size = _GEN_15[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_16 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  d_source = _GEN_16[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_17 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  d_addr = _GEN_17[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_19 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_188 = _GEN_19[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_21 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_206_0 = _GEN_21[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_23 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_206_1 = _GEN_23[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_25 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_206_2 = _GEN_25[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_26 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_206_3 = _GEN_26[7:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_27 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_27[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_28 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_28[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_33 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_33[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_34 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_34[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_35 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_35[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_36 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_11 = _GEN_36[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_37 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_12 = _GEN_37[31:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      d_full <= 1'h0;
    end else begin
      if (_T_106) begin
        d_full <= 1'h1;
      end else begin
        if (_T_104) begin
          d_full <= 1'h0;
        end
      end
    end
    if (_T_106) begin
      d_read <= read;
    end
    if (_T_106) begin
      d_size <= io_in_0_a_bits_size;
    end
    if (_T_106) begin
      d_source <= io_in_0_a_bits_source;
    end
    if (_T_106) begin
      d_addr <= _T_148;
    end
    _T_188 <= ren;
    if (_T_188) begin
      _T_206_0 <= mem_RW0_rdata_0;
    end
    if (_T_188) begin
      _T_206_1 <= mem_RW0_rdata_1;
    end
    if (_T_188) begin
      _T_206_2 <= mem_RW0_rdata_2;
    end
    if (_T_188) begin
      _T_206_3 <= mem_RW0_rdata_3;
    end
  end
endmodule
