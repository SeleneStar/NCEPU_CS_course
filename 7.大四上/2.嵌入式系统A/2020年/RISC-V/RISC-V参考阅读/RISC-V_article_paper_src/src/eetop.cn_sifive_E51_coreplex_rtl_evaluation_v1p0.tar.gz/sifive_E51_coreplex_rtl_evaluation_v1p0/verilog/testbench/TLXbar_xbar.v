//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module TLXbar_xbar(
  input         clock,
  input         reset,
  output        io_in_0_a_ready,
  input         io_in_0_a_valid,
  input  [2:0]  io_in_0_a_bits_opcode,
  input  [2:0]  io_in_0_a_bits_param,
  input  [2:0]  io_in_0_a_bits_size,
  input         io_in_0_a_bits_source,
  input  [29:0] io_in_0_a_bits_address,
  input  [3:0]  io_in_0_a_bits_mask,
  input  [31:0] io_in_0_a_bits_data,
  input         io_in_0_b_ready,
  output        io_in_0_b_valid,
  output [2:0]  io_in_0_b_bits_opcode,
  output [1:0]  io_in_0_b_bits_param,
  output [2:0]  io_in_0_b_bits_size,
  output        io_in_0_b_bits_source,
  output [29:0] io_in_0_b_bits_address,
  output [3:0]  io_in_0_b_bits_mask,
  output [31:0] io_in_0_b_bits_data,
  output        io_in_0_c_ready,
  input         io_in_0_c_valid,
  input  [2:0]  io_in_0_c_bits_opcode,
  input  [2:0]  io_in_0_c_bits_param,
  input  [2:0]  io_in_0_c_bits_size,
  input         io_in_0_c_bits_source,
  input  [29:0] io_in_0_c_bits_address,
  input  [31:0] io_in_0_c_bits_data,
  input         io_in_0_c_bits_error,
  input         io_in_0_d_ready,
  output        io_in_0_d_valid,
  output [2:0]  io_in_0_d_bits_opcode,
  output [1:0]  io_in_0_d_bits_param,
  output [2:0]  io_in_0_d_bits_size,
  output        io_in_0_d_bits_source,
  output        io_in_0_d_bits_sink,
  output [1:0]  io_in_0_d_bits_addr_lo,
  output [31:0] io_in_0_d_bits_data,
  output        io_in_0_d_bits_error,
  output        io_in_0_e_ready,
  input         io_in_0_e_valid,
  input         io_in_0_e_bits_sink,
  input         io_out_0_a_ready,
  output        io_out_0_a_valid,
  output [2:0]  io_out_0_a_bits_opcode,
  output [2:0]  io_out_0_a_bits_param,
  output [2:0]  io_out_0_a_bits_size,
  output        io_out_0_a_bits_source,
  output [29:0] io_out_0_a_bits_address,
  output [3:0]  io_out_0_a_bits_mask,
  output [31:0] io_out_0_a_bits_data,
  output        io_out_0_b_ready,
  input         io_out_0_b_valid,
  input  [2:0]  io_out_0_b_bits_opcode,
  input  [1:0]  io_out_0_b_bits_param,
  input  [2:0]  io_out_0_b_bits_size,
  input         io_out_0_b_bits_source,
  input  [29:0] io_out_0_b_bits_address,
  input  [3:0]  io_out_0_b_bits_mask,
  input  [31:0] io_out_0_b_bits_data,
  input         io_out_0_c_ready,
  output        io_out_0_c_valid,
  output [2:0]  io_out_0_c_bits_opcode,
  output [2:0]  io_out_0_c_bits_param,
  output [2:0]  io_out_0_c_bits_size,
  output        io_out_0_c_bits_source,
  output [29:0] io_out_0_c_bits_address,
  output [31:0] io_out_0_c_bits_data,
  output        io_out_0_c_bits_error,
  output        io_out_0_d_ready,
  input         io_out_0_d_valid,
  input  [2:0]  io_out_0_d_bits_opcode,
  input  [1:0]  io_out_0_d_bits_param,
  input  [2:0]  io_out_0_d_bits_size,
  input         io_out_0_d_bits_source,
  input         io_out_0_d_bits_sink,
  input  [1:0]  io_out_0_d_bits_addr_lo,
  input  [31:0] io_out_0_d_bits_data,
  input         io_out_0_d_bits_error,
  input         io_out_0_e_ready,
  output        io_out_0_e_valid,
  output        io_out_0_e_bits_sink
);
  wire  in_0_a_ready;
  wire  in_0_a_valid;
  wire [2:0] in_0_a_bits_opcode;
  wire [2:0] in_0_a_bits_param;
  wire [2:0] in_0_a_bits_size;
  wire  in_0_a_bits_source;
  wire [29:0] in_0_a_bits_address;
  wire [3:0] in_0_a_bits_mask;
  wire [31:0] in_0_a_bits_data;
  wire  in_0_b_ready;
  wire  in_0_b_valid;
  wire [2:0] in_0_b_bits_opcode;
  wire [1:0] in_0_b_bits_param;
  wire [2:0] in_0_b_bits_size;
  wire  in_0_b_bits_source;
  wire [29:0] in_0_b_bits_address;
  wire [3:0] in_0_b_bits_mask;
  wire [31:0] in_0_b_bits_data;
  wire  in_0_c_ready;
  wire  in_0_c_valid;
  wire [2:0] in_0_c_bits_opcode;
  wire [2:0] in_0_c_bits_param;
  wire [2:0] in_0_c_bits_size;
  wire  in_0_c_bits_source;
  wire [29:0] in_0_c_bits_address;
  wire [31:0] in_0_c_bits_data;
  wire  in_0_c_bits_error;
  wire  in_0_d_ready;
  wire  in_0_d_valid;
  wire [2:0] in_0_d_bits_opcode;
  wire [1:0] in_0_d_bits_param;
  wire [2:0] in_0_d_bits_size;
  wire  in_0_d_bits_source;
  wire  in_0_d_bits_sink;
  wire [1:0] in_0_d_bits_addr_lo;
  wire [31:0] in_0_d_bits_data;
  wire  in_0_d_bits_error;
  wire  in_0_e_ready;
  wire  in_0_e_valid;
  wire  in_0_e_bits_sink;
  wire  out_0_a_ready;
  wire  out_0_a_valid;
  wire [2:0] out_0_a_bits_opcode;
  wire [2:0] out_0_a_bits_param;
  wire [2:0] out_0_a_bits_size;
  wire  out_0_a_bits_source;
  wire [29:0] out_0_a_bits_address;
  wire [3:0] out_0_a_bits_mask;
  wire [31:0] out_0_a_bits_data;
  wire  out_0_b_ready;
  wire  out_0_b_valid;
  wire [2:0] out_0_b_bits_opcode;
  wire [1:0] out_0_b_bits_param;
  wire [2:0] out_0_b_bits_size;
  wire  out_0_b_bits_source;
  wire [29:0] out_0_b_bits_address;
  wire [3:0] out_0_b_bits_mask;
  wire [31:0] out_0_b_bits_data;
  wire  out_0_c_ready;
  wire  out_0_c_valid;
  wire [2:0] out_0_c_bits_opcode;
  wire [2:0] out_0_c_bits_param;
  wire [2:0] out_0_c_bits_size;
  wire  out_0_c_bits_source;
  wire [29:0] out_0_c_bits_address;
  wire [31:0] out_0_c_bits_data;
  wire  out_0_c_bits_error;
  wire  out_0_d_ready;
  wire  out_0_d_valid;
  wire [2:0] out_0_d_bits_opcode;
  wire [1:0] out_0_d_bits_param;
  wire [2:0] out_0_d_bits_size;
  wire  out_0_d_bits_source;
  wire  out_0_d_bits_sink;
  wire [1:0] out_0_d_bits_addr_lo;
  wire [31:0] out_0_d_bits_data;
  wire  out_0_d_bits_error;
  wire  out_0_e_ready;
  wire  out_0_e_valid;
  wire  out_0_e_bits_sink;
  wire  _T_521_0;
  wire  requestAIO_0_0;
  wire  _T_574_0;
  wire  requestCIO_0_0;
  wire  _T_627_0;
  wire  requestBOI_0_0;
  wire  _T_680_0;
  wire  requestDOI_0_0;
  wire  _T_726_0;
  wire  requestEIO_0_0;
  wire [11:0] _T_771;
  wire [4:0] _T_772;
  wire [4:0] _T_773;
  wire [2:0] _T_774;
  wire  _T_775;
  wire  _T_777;
  wire [2:0] _T_779;
  wire [2:0] beatsAI_0;
  wire [2:0] beatsBO_0;
  wire [2:0] beatsCI_0;
  wire [11:0] _T_819;
  wire [4:0] _T_820;
  wire [4:0] _T_821;
  wire [2:0] _T_822;
  wire  _T_823;
  wire [2:0] _T_825;
  wire [2:0] beatsDO_0;
  wire  beatsEI_0;
  wire  _T_845_0_ready;
  wire  _T_845_0_valid;
  wire [2:0] _T_845_0_bits_opcode;
  wire [2:0] _T_845_0_bits_param;
  wire [2:0] _T_845_0_bits_size;
  wire  _T_845_0_bits_source;
  wire [29:0] _T_845_0_bits_address;
  wire [3:0] _T_845_0_bits_mask;
  wire [31:0] _T_845_0_bits_data;
  wire  _T_861;
  wire  _T_870_0_ready;
  wire  _T_870_0_valid;
  wire [2:0] _T_870_0_bits_opcode;
  wire [1:0] _T_870_0_bits_param;
  wire [2:0] _T_870_0_bits_size;
  wire  _T_870_0_bits_source;
  wire [29:0] _T_870_0_bits_address;
  wire [3:0] _T_870_0_bits_mask;
  wire [31:0] _T_870_0_bits_data;
  wire  _T_886;
  wire  _T_895_0_ready;
  wire  _T_895_0_valid;
  wire [2:0] _T_895_0_bits_opcode;
  wire [2:0] _T_895_0_bits_param;
  wire [2:0] _T_895_0_bits_size;
  wire  _T_895_0_bits_source;
  wire [29:0] _T_895_0_bits_address;
  wire [31:0] _T_895_0_bits_data;
  wire  _T_895_0_bits_error;
  wire  _T_911;
  wire  _T_920_0_ready;
  wire  _T_920_0_valid;
  wire [2:0] _T_920_0_bits_opcode;
  wire [1:0] _T_920_0_bits_param;
  wire [2:0] _T_920_0_bits_size;
  wire  _T_920_0_bits_source;
  wire  _T_920_0_bits_sink;
  wire [1:0] _T_920_0_bits_addr_lo;
  wire [31:0] _T_920_0_bits_data;
  wire  _T_920_0_bits_error;
  wire  _T_936;
  wire  _T_945_0_ready;
  wire  _T_945_0_valid;
  wire  _T_945_0_bits_sink;
  wire  _T_961;
  reg [2:0] _T_964;
  reg [31:0] _GEN_52;
  wire  _T_966;
  wire  _T_967;
  wire [1:0] _GEN_0;
  wire [1:0] _T_969;
  wire  _T_970;
  wire  _T_971;
  wire  _T_975_0;
  wire  _T_979;
  wire  _T_982_0;
  wire  _T_997;
  wire  _T_998;
  wire  _T_999;
  wire  _T_1001;
  wire [2:0] _T_1003;
  wire  _T_1004;
  wire [2:0] _GEN_1;
  wire [3:0] _T_1005;
  wire [3:0] _T_1006;
  wire [2:0] _T_1007;
  wire [2:0] _T_1008;
  wire  _T_1012_0;
  reg  _T_1022_0;
  reg [31:0] _GEN_53;
  wire  _T_1030_0;
  reg [2:0] _T_1042;
  reg [31:0] _GEN_54;
  wire  _T_1044;
  wire  _T_1045;
  wire [1:0] _GEN_2;
  wire [1:0] _T_1047;
  wire  _T_1048;
  wire  _T_1049;
  wire  _T_1053_0;
  wire  _T_1057;
  wire  _T_1060_0;
  wire  _T_1075;
  wire  _T_1076;
  wire  _T_1077;
  wire  _T_1079;
  wire [2:0] _T_1081;
  wire  _T_1082;
  wire [2:0] _GEN_3;
  wire [3:0] _T_1083;
  wire [3:0] _T_1084;
  wire [2:0] _T_1085;
  wire [2:0] _T_1086;
  wire  _T_1090_0;
  reg  _T_1100_0;
  reg [31:0] _GEN_55;
  wire  _T_1108_0;
  reg [2:0] _GEN_4;
  reg [31:0] _GEN_56;
  reg [1:0] _GEN_5;
  reg [31:0] _GEN_57;
  reg [2:0] _GEN_6;
  reg [31:0] _GEN_58;
  reg  _GEN_7;
  reg [31:0] _GEN_59;
  reg [29:0] _GEN_8;
  reg [31:0] _GEN_60;
  reg [3:0] _GEN_9;
  reg [31:0] _GEN_61;
  reg [31:0] _GEN_10;
  reg [31:0] _GEN_62;
  reg [2:0] _GEN_11;
  reg [31:0] _GEN_63;
  reg [2:0] _GEN_12;
  reg [31:0] _GEN_64;
  reg [2:0] _GEN_13;
  reg [31:0] _GEN_65;
  reg  _GEN_14;
  reg [31:0] _GEN_66;
  reg [29:0] _GEN_15;
  reg [31:0] _GEN_67;
  reg [31:0] _GEN_16;
  reg [31:0] _GEN_68;
  reg  _GEN_17;
  reg [31:0] _GEN_69;
  reg  _GEN_18;
  reg [31:0] _GEN_70;
  reg [2:0] _GEN_19;
  reg [31:0] _GEN_71;
  reg [1:0] _GEN_20;
  reg [31:0] _GEN_72;
  reg [2:0] _GEN_21;
  reg [31:0] _GEN_73;
  reg  _GEN_22;
  reg [31:0] _GEN_74;
  reg [29:0] _GEN_23;
  reg [31:0] _GEN_75;
  reg [3:0] _GEN_24;
  reg [31:0] _GEN_76;
  reg [31:0] _GEN_25;
  reg [31:0] _GEN_77;
  reg [2:0] _GEN_26;
  reg [31:0] _GEN_78;
  reg [2:0] _GEN_27;
  reg [31:0] _GEN_79;
  reg [2:0] _GEN_28;
  reg [31:0] _GEN_80;
  reg  _GEN_29;
  reg [31:0] _GEN_81;
  reg [29:0] _GEN_30;
  reg [31:0] _GEN_82;
  reg [31:0] _GEN_31;
  reg [31:0] _GEN_83;
  reg  _GEN_32;
  reg [31:0] _GEN_84;
  reg  _GEN_33;
  reg [31:0] _GEN_85;
  reg [2:0] _GEN_34;
  reg [31:0] _GEN_86;
  reg [1:0] _GEN_35;
  reg [31:0] _GEN_87;
  reg [2:0] _GEN_36;
  reg [31:0] _GEN_88;
  reg  _GEN_37;
  reg [31:0] _GEN_89;
  reg [29:0] _GEN_38;
  reg [31:0] _GEN_90;
  reg [3:0] _GEN_39;
  reg [31:0] _GEN_91;
  reg [31:0] _GEN_40;
  reg [31:0] _GEN_92;
  reg [2:0] _GEN_41;
  reg [31:0] _GEN_93;
  reg [2:0] _GEN_42;
  reg [31:0] _GEN_94;
  reg [2:0] _GEN_43;
  reg [31:0] _GEN_95;
  reg  _GEN_44;
  reg [31:0] _GEN_96;
  reg [29:0] _GEN_45;
  reg [31:0] _GEN_97;
  reg [31:0] _GEN_46;
  reg [31:0] _GEN_98;
  reg  _GEN_47;
  reg [31:0] _GEN_99;
  reg  _GEN_48;
  reg [31:0] _GEN_100;
  reg  _GEN_49;
  reg [31:0] _GEN_101;
  reg  _GEN_50;
  reg [31:0] _GEN_102;
  reg  _GEN_51;
  reg [31:0] _GEN_103;
  assign io_in_0_a_ready = in_0_a_ready;
  assign io_in_0_b_valid = 1'h0;
  assign io_in_0_b_bits_opcode = _GEN_4;
  assign io_in_0_b_bits_param = _GEN_5;
  assign io_in_0_b_bits_size = _GEN_6;
  assign io_in_0_b_bits_source = _GEN_7;
  assign io_in_0_b_bits_address = _GEN_8;
  assign io_in_0_b_bits_mask = _GEN_9;
  assign io_in_0_b_bits_data = _GEN_10;
  assign io_in_0_c_ready = 1'h1;
  assign io_in_0_d_valid = in_0_d_valid;
  assign io_in_0_d_bits_opcode = in_0_d_bits_opcode;
  assign io_in_0_d_bits_param = in_0_d_bits_param;
  assign io_in_0_d_bits_size = in_0_d_bits_size;
  assign io_in_0_d_bits_source = in_0_d_bits_source;
  assign io_in_0_d_bits_sink = in_0_d_bits_sink;
  assign io_in_0_d_bits_addr_lo = in_0_d_bits_addr_lo;
  assign io_in_0_d_bits_data = in_0_d_bits_data;
  assign io_in_0_d_bits_error = in_0_d_bits_error;
  assign io_in_0_e_ready = 1'h1;
  assign io_out_0_a_valid = out_0_a_valid;
  assign io_out_0_a_bits_opcode = out_0_a_bits_opcode;
  assign io_out_0_a_bits_param = out_0_a_bits_param;
  assign io_out_0_a_bits_size = out_0_a_bits_size;
  assign io_out_0_a_bits_source = out_0_a_bits_source;
  assign io_out_0_a_bits_address = out_0_a_bits_address;
  assign io_out_0_a_bits_mask = out_0_a_bits_mask;
  assign io_out_0_a_bits_data = out_0_a_bits_data;
  assign io_out_0_b_ready = 1'h1;
  assign io_out_0_c_valid = 1'h0;
  assign io_out_0_c_bits_opcode = _GEN_11;
  assign io_out_0_c_bits_param = _GEN_12;
  assign io_out_0_c_bits_size = _GEN_13;
  assign io_out_0_c_bits_source = _GEN_14;
  assign io_out_0_c_bits_address = _GEN_15;
  assign io_out_0_c_bits_data = _GEN_16;
  assign io_out_0_c_bits_error = _GEN_17;
  assign io_out_0_d_ready = out_0_d_ready;
  assign io_out_0_e_valid = 1'h0;
  assign io_out_0_e_bits_sink = _GEN_18;
  assign in_0_a_ready = _T_845_0_ready;
  assign in_0_a_valid = io_in_0_a_valid;
  assign in_0_a_bits_opcode = io_in_0_a_bits_opcode;
  assign in_0_a_bits_param = io_in_0_a_bits_param;
  assign in_0_a_bits_size = io_in_0_a_bits_size;
  assign in_0_a_bits_source = io_in_0_a_bits_source;
  assign in_0_a_bits_address = io_in_0_a_bits_address;
  assign in_0_a_bits_mask = io_in_0_a_bits_mask;
  assign in_0_a_bits_data = io_in_0_a_bits_data;
  assign in_0_b_ready = 1'h0;
  assign in_0_b_valid = 1'h0;
  assign in_0_b_bits_opcode = _GEN_19;
  assign in_0_b_bits_param = _GEN_20;
  assign in_0_b_bits_size = _GEN_21;
  assign in_0_b_bits_source = _GEN_22;
  assign in_0_b_bits_address = _GEN_23;
  assign in_0_b_bits_mask = _GEN_24;
  assign in_0_b_bits_data = _GEN_25;
  assign in_0_c_ready = _T_895_0_ready;
  assign in_0_c_valid = 1'h0;
  assign in_0_c_bits_opcode = _GEN_26;
  assign in_0_c_bits_param = _GEN_27;
  assign in_0_c_bits_size = _GEN_28;
  assign in_0_c_bits_source = _GEN_29;
  assign in_0_c_bits_address = _GEN_30;
  assign in_0_c_bits_data = _GEN_31;
  assign in_0_c_bits_error = _GEN_32;
  assign in_0_d_ready = io_in_0_d_ready;
  assign in_0_d_valid = _T_920_0_valid;
  assign in_0_d_bits_opcode = _T_920_0_bits_opcode;
  assign in_0_d_bits_param = _T_920_0_bits_param;
  assign in_0_d_bits_size = _T_920_0_bits_size;
  assign in_0_d_bits_source = _T_920_0_bits_source;
  assign in_0_d_bits_sink = _T_920_0_bits_sink;
  assign in_0_d_bits_addr_lo = _T_920_0_bits_addr_lo;
  assign in_0_d_bits_data = _T_920_0_bits_data;
  assign in_0_d_bits_error = _T_920_0_bits_error;
  assign in_0_e_ready = _T_945_0_ready;
  assign in_0_e_valid = 1'h0;
  assign in_0_e_bits_sink = _GEN_33;
  assign out_0_a_ready = io_out_0_a_ready;
  assign out_0_a_valid = _T_845_0_valid;
  assign out_0_a_bits_opcode = _T_845_0_bits_opcode;
  assign out_0_a_bits_param = _T_845_0_bits_param;
  assign out_0_a_bits_size = _T_845_0_bits_size;
  assign out_0_a_bits_source = _T_845_0_bits_source;
  assign out_0_a_bits_address = _T_845_0_bits_address;
  assign out_0_a_bits_mask = _T_845_0_bits_mask;
  assign out_0_a_bits_data = _T_845_0_bits_data;
  assign out_0_b_ready = _T_870_0_ready;
  assign out_0_b_valid = 1'h0;
  assign out_0_b_bits_opcode = _GEN_34;
  assign out_0_b_bits_param = _GEN_35;
  assign out_0_b_bits_size = _GEN_36;
  assign out_0_b_bits_source = _GEN_37;
  assign out_0_b_bits_address = _GEN_38;
  assign out_0_b_bits_mask = _GEN_39;
  assign out_0_b_bits_data = _GEN_40;
  assign out_0_c_ready = 1'h0;
  assign out_0_c_valid = 1'h0;
  assign out_0_c_bits_opcode = _GEN_41;
  assign out_0_c_bits_param = _GEN_42;
  assign out_0_c_bits_size = _GEN_43;
  assign out_0_c_bits_source = _GEN_44;
  assign out_0_c_bits_address = _GEN_45;
  assign out_0_c_bits_data = _GEN_46;
  assign out_0_c_bits_error = _GEN_47;
  assign out_0_d_ready = _T_920_0_ready;
  assign out_0_d_valid = io_out_0_d_valid;
  assign out_0_d_bits_opcode = io_out_0_d_bits_opcode;
  assign out_0_d_bits_param = io_out_0_d_bits_param;
  assign out_0_d_bits_size = io_out_0_d_bits_size;
  assign out_0_d_bits_source = io_out_0_d_bits_source;
  assign out_0_d_bits_sink = io_out_0_d_bits_sink;
  assign out_0_d_bits_addr_lo = io_out_0_d_bits_addr_lo;
  assign out_0_d_bits_data = io_out_0_d_bits_data;
  assign out_0_d_bits_error = io_out_0_d_bits_error;
  assign out_0_e_ready = 1'h0;
  assign out_0_e_valid = 1'h0;
  assign out_0_e_bits_sink = _GEN_48;
  assign _T_521_0 = 1'h1;
  assign requestAIO_0_0 = _T_521_0;
  assign _T_574_0 = 1'h1;
  assign requestCIO_0_0 = _T_574_0;
  assign _T_627_0 = 1'h1;
  assign requestBOI_0_0 = _T_627_0;
  assign _T_680_0 = 1'h1;
  assign requestDOI_0_0 = _T_680_0;
  assign _T_726_0 = 1'h0;
  assign requestEIO_0_0 = _T_726_0;
  assign _T_771 = 12'h1f << in_0_a_bits_size;
  assign _T_772 = _T_771[4:0];
  assign _T_773 = ~ _T_772;
  assign _T_774 = _T_773[4:2];
  assign _T_775 = in_0_a_bits_opcode[2];
  assign _T_777 = _T_775 == 1'h0;
  assign _T_779 = _T_777 ? _T_774 : 3'h0;
  assign beatsAI_0 = _T_779;
  assign beatsBO_0 = 3'h0;
  assign beatsCI_0 = 3'h0;
  assign _T_819 = 12'h1f << out_0_d_bits_size;
  assign _T_820 = _T_819[4:0];
  assign _T_821 = ~ _T_820;
  assign _T_822 = _T_821[4:2];
  assign _T_823 = out_0_d_bits_opcode[0];
  assign _T_825 = _T_823 ? _T_822 : 3'h0;
  assign beatsDO_0 = _T_825;
  assign beatsEI_0 = 1'h0;
  assign _T_845_0_ready = out_0_a_ready;
  assign _T_845_0_valid = _T_861;
  assign _T_845_0_bits_opcode = in_0_a_bits_opcode;
  assign _T_845_0_bits_param = in_0_a_bits_param;
  assign _T_845_0_bits_size = in_0_a_bits_size;
  assign _T_845_0_bits_source = in_0_a_bits_source;
  assign _T_845_0_bits_address = in_0_a_bits_address;
  assign _T_845_0_bits_mask = in_0_a_bits_mask;
  assign _T_845_0_bits_data = in_0_a_bits_data;
  assign _T_861 = in_0_a_valid & requestAIO_0_0;
  assign _T_870_0_ready = _GEN_49;
  assign _T_870_0_valid = _T_886;
  assign _T_870_0_bits_opcode = out_0_b_bits_opcode;
  assign _T_870_0_bits_param = out_0_b_bits_param;
  assign _T_870_0_bits_size = out_0_b_bits_size;
  assign _T_870_0_bits_source = out_0_b_bits_source;
  assign _T_870_0_bits_address = out_0_b_bits_address;
  assign _T_870_0_bits_mask = out_0_b_bits_mask;
  assign _T_870_0_bits_data = out_0_b_bits_data;
  assign _T_886 = out_0_b_valid & requestBOI_0_0;
  assign _T_895_0_ready = _GEN_50;
  assign _T_895_0_valid = _T_911;
  assign _T_895_0_bits_opcode = in_0_c_bits_opcode;
  assign _T_895_0_bits_param = in_0_c_bits_param;
  assign _T_895_0_bits_size = in_0_c_bits_size;
  assign _T_895_0_bits_source = in_0_c_bits_source;
  assign _T_895_0_bits_address = in_0_c_bits_address;
  assign _T_895_0_bits_data = in_0_c_bits_data;
  assign _T_895_0_bits_error = in_0_c_bits_error;
  assign _T_911 = in_0_c_valid & requestCIO_0_0;
  assign _T_920_0_ready = in_0_d_ready;
  assign _T_920_0_valid = _T_936;
  assign _T_920_0_bits_opcode = out_0_d_bits_opcode;
  assign _T_920_0_bits_param = out_0_d_bits_param;
  assign _T_920_0_bits_size = out_0_d_bits_size;
  assign _T_920_0_bits_source = out_0_d_bits_source;
  assign _T_920_0_bits_sink = out_0_d_bits_sink;
  assign _T_920_0_bits_addr_lo = out_0_d_bits_addr_lo;
  assign _T_920_0_bits_data = out_0_d_bits_data;
  assign _T_920_0_bits_error = out_0_d_bits_error;
  assign _T_936 = out_0_d_valid & requestDOI_0_0;
  assign _T_945_0_ready = _GEN_51;
  assign _T_945_0_valid = _T_961;
  assign _T_945_0_bits_sink = in_0_e_bits_sink;
  assign _T_961 = in_0_e_valid & requestEIO_0_0;
  assign _T_966 = _T_964 == 3'h0;
  assign _T_967 = _T_966 & out_0_a_ready;
  assign _GEN_0 = {{1'd0}, _T_845_0_valid};
  assign _T_969 = _GEN_0 << 1;
  assign _T_970 = _T_969[0];
  assign _T_971 = ~ _T_970;
  assign _T_975_0 = _T_971;
  assign _T_979 = _T_975_0 & _T_845_0_valid;
  assign _T_982_0 = _T_979;
  assign _T_997 = _T_845_0_valid == 1'h0;
  assign _T_998 = _T_997 | _T_982_0;
  assign _T_999 = _T_998 | reset;
  assign _T_1001 = _T_999 == 1'h0;
  assign _T_1003 = _T_982_0 ? beatsAI_0 : 3'h0;
  assign _T_1004 = out_0_a_ready & out_0_a_valid;
  assign _GEN_1 = {{2'd0}, _T_1004};
  assign _T_1005 = _T_964 - _GEN_1;
  assign _T_1006 = $unsigned(_T_1005);
  assign _T_1007 = _T_1006[2:0];
  assign _T_1008 = _T_967 ? _T_1003 : _T_1007;
  assign _T_1012_0 = 1'h0;
  assign _T_1030_0 = _T_966 ? _T_982_0 : _T_1022_0;
  assign _T_1044 = _T_1042 == 3'h0;
  assign _T_1045 = _T_1044 & in_0_d_ready;
  assign _GEN_2 = {{1'd0}, _T_920_0_valid};
  assign _T_1047 = _GEN_2 << 1;
  assign _T_1048 = _T_1047[0];
  assign _T_1049 = ~ _T_1048;
  assign _T_1053_0 = _T_1049;
  assign _T_1057 = _T_1053_0 & _T_920_0_valid;
  assign _T_1060_0 = _T_1057;
  assign _T_1075 = _T_920_0_valid == 1'h0;
  assign _T_1076 = _T_1075 | _T_1060_0;
  assign _T_1077 = _T_1076 | reset;
  assign _T_1079 = _T_1077 == 1'h0;
  assign _T_1081 = _T_1060_0 ? beatsDO_0 : 3'h0;
  assign _T_1082 = in_0_d_ready & in_0_d_valid;
  assign _GEN_3 = {{2'd0}, _T_1082};
  assign _T_1083 = _T_1042 - _GEN_3;
  assign _T_1084 = $unsigned(_T_1083);
  assign _T_1085 = _T_1084[2:0];
  assign _T_1086 = _T_1045 ? _T_1081 : _T_1085;
  assign _T_1090_0 = 1'h0;
  assign _T_1108_0 = _T_1044 ? _T_1060_0 : _T_1100_0;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_52 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_964 = _GEN_52[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_53 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_1022_0 = _GEN_53[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_54 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_1042 = _GEN_54[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_55 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _T_1100_0 = _GEN_55[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_56 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_4 = _GEN_56[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_57 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_5 = _GEN_57[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_58 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_6 = _GEN_58[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_59 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_7 = _GEN_59[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_60 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_8 = _GEN_60[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_61 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_9 = _GEN_61[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_62 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_10 = _GEN_62[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_63 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_11 = _GEN_63[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_64 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_12 = _GEN_64[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_65 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_13 = _GEN_65[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_66 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_14 = _GEN_66[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_67 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_15 = _GEN_67[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_68 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_16 = _GEN_68[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_69 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_17 = _GEN_69[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_70 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_18 = _GEN_70[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_71 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_19 = _GEN_71[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_72 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_20 = _GEN_72[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_73 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_21 = _GEN_73[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_74 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_22 = _GEN_74[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_75 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_23 = _GEN_75[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_76 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_24 = _GEN_76[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_77 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_25 = _GEN_77[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_78 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_26 = _GEN_78[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_79 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_27 = _GEN_79[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_80 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_28 = _GEN_80[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_81 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_29 = _GEN_81[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_82 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_30 = _GEN_82[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_83 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_31 = _GEN_83[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_84 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_32 = _GEN_84[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_85 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_33 = _GEN_85[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_86 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_34 = _GEN_86[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_87 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_35 = _GEN_87[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_88 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_36 = _GEN_88[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_89 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_37 = _GEN_89[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_90 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_38 = _GEN_90[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_91 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_39 = _GEN_91[3:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_92 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_40 = _GEN_92[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_93 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_41 = _GEN_93[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_94 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_42 = _GEN_94[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_95 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_43 = _GEN_95[2:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_96 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_44 = _GEN_96[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_97 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_45 = _GEN_97[29:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_98 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_46 = _GEN_98[31:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_99 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_47 = _GEN_99[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_100 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_48 = _GEN_100[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_101 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_49 = _GEN_101[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_102 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_50 = _GEN_102[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_103 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_51 = _GEN_103[0:0];
  `endif
  end
`endif
  always @(posedge clock) begin
    if (reset) begin
      _T_964 <= 3'h0;
    end else begin
      if (_T_967) begin
        if (_T_982_0) begin
          _T_964 <= beatsAI_0;
        end else begin
          _T_964 <= 3'h0;
        end
      end else begin
        _T_964 <= _T_1007;
      end
    end
    if (reset) begin
      _T_1022_0 <= _T_1012_0;
    end else begin
      if (_T_966) begin
        _T_1022_0 <= _T_982_0;
      end
    end
    if (reset) begin
      _T_1042 <= 3'h0;
    end else begin
      if (_T_1045) begin
        if (_T_1060_0) begin
          _T_1042 <= beatsDO_0;
        end else begin
          _T_1042 <= 3'h0;
        end
      end else begin
        _T_1042 <= _T_1085;
      end
    end
    if (reset) begin
      _T_1100_0 <= _T_1090_0;
    end else begin
      if (_T_1044) begin
        _T_1100_0 <= _T_1060_0;
      end
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Arbiter.scala:65 assert((prefixOR zip winner) map { case (p,w) => !p || !w } reduce {_ && _})\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_1001) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Arbiter.scala:67 assert (!valids.reduce(_||_) || winner.reduce(_||_))\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_1001) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Arbiter.scala:65 assert((prefixOR zip winner) map { case (p,w) => !p || !w } reduce {_ && _})\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_T_1079) begin
          $fwrite(32'h80000002,"Assertion failed\n    at Arbiter.scala:67 assert (!valids.reduce(_||_) || winner.reduce(_||_))\n");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_T_1079) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
