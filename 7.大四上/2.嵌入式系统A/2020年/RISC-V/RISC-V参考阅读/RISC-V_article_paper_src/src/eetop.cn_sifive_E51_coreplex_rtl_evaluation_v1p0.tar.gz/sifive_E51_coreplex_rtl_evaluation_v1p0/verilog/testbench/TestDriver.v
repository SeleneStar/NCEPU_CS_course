//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
// See LICENSE.SiFive for license details.

module TestDriver;

  reg clock = 1'b0;
  reg reset = 1'b1;

  always #1 clock = ~clock;
  initial #(777.7) reset = 0;

  reg [1023:0] vcdplusfile = 0;
  reg [1023:0] testfile = 0;

  always @(negedge reset)  begin
    if ($value$plusargs("testfile=%s", testfile))
    begin
      $readmemh(testfile, testHarness.testRAM.sram.mem.mem_ext.ram);
    end
  end

  initial begin
    if ($value$plusargs("vcdplusfile=%s", vcdplusfile))
    begin
      $vcdplusfile(vcdplusfile);
      $vcdpluson(0);
      $vcdplusmemon(0);
    end
  end

  wire success;
  integer stderr = 32'h80000002;
  reg [63:0] trace_count = 0;
  always @(posedge clock)
  begin
    trace_count = trace_count + 1;
    if (!reset)
    begin
      if (success)
      begin
        $fdisplay(stderr, "Completed after %d simulation cycles", trace_count);
        $vcdplusclose; $dumpoff;
        $finish;
      end
    end
  end

  ECoreplexIPAllPortRAMTestHarness testHarness(
    .clock(clock),
    .reset(reset),
    .io_success(success)
  );

endmodule
