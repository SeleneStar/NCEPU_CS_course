//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_103_sim(
  input         _EVAL_0,
  input         _EVAL_12,
  input         _EVAL_11,
  input  [26:0] _EVAL_28,
  input         _EVAL_1
);
  wire  _EVAL_14;
  wire  _EVAL_17;
  wire  _EVAL_19;
  wire  _EVAL_25;
  wire [26:0] _EVAL_26;
  assign _EVAL_14 = _EVAL_12;
  assign _EVAL_17 = _EVAL_25;
  assign _EVAL_19 = _EVAL_25;
  assign _EVAL_25 = _EVAL_1 ? _EVAL_0 : _EVAL_11;
  assign _EVAL_26 = _EVAL_28;
endmodule
