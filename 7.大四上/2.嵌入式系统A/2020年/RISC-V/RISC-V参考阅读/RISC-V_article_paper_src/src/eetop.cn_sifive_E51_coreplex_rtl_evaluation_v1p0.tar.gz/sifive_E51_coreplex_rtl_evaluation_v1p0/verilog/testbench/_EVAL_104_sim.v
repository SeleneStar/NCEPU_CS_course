//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_104_sim(
  input  [63:0] _EVAL_922,
  input  [69:0] _EVAL_544,
  input  [63:0] _EVAL_808
);
  wire  _EVAL_374;
  wire [1:0] _EVAL_396;
  wire  _EVAL_408;
  wire  _EVAL_416;
  wire  _EVAL_442;
  wire  _EVAL_456;
  wire [1:0] _EVAL_460;
  wire  _EVAL_484;
  wire [1:0] _EVAL_487;
  wire  _EVAL_492;
  wire  _EVAL_523;
  wire  _EVAL_530;
  wire [1:0] _EVAL_557;
  wire  _EVAL_595;
  wire  _EVAL_605;
  wire  _EVAL_631;
  wire  _EVAL_645;
  wire [1:0] _EVAL_678;
  wire [53:0] _EVAL_720;
  wire  _EVAL_735;
  wire  _EVAL_780;
  wire  _EVAL_803;
  wire  _EVAL_806;
  wire  _EVAL_813;
  wire [53:0] _EVAL_829;
  wire [31:0] _EVAL_852;
  wire  _EVAL_859;
  wire  _EVAL_871;
  wire [1:0] _EVAL_905;
  wire  _EVAL_913;
  wire  _EVAL_923;
  wire  _EVAL_946;
  wire [31:0] _EVAL_970;
  wire  _EVAL_1032;
  assign _EVAL_374 = _EVAL_922[5];
  assign _EVAL_396 = _EVAL_544[66:65];
  assign _EVAL_408 = _EVAL_922[0];
  assign _EVAL_416 = _EVAL_922[1];
  assign _EVAL_442 = _EVAL_408;
  assign _EVAL_456 = _EVAL_544[64];
  assign _EVAL_460 = _EVAL_922[9:8];
  assign _EVAL_484 = _EVAL_544[62];
  assign _EVAL_487 = _EVAL_905;
  assign _EVAL_492 = _EVAL_922[2];
  assign _EVAL_523 = _EVAL_922[4];
  assign _EVAL_530 = _EVAL_416;
  assign _EVAL_557 = _EVAL_460;
  assign _EVAL_595 = _EVAL_946;
  assign _EVAL_605 = _EVAL_631;
  assign _EVAL_631 = _EVAL_544[69];
  assign _EVAL_645 = _EVAL_484;
  assign _EVAL_678 = _EVAL_396;
  assign _EVAL_720 = _EVAL_829;
  assign _EVAL_735 = _EVAL_806;
  assign _EVAL_780 = _EVAL_523;
  assign _EVAL_803 = _EVAL_922[6];
  assign _EVAL_806 = _EVAL_544[63];
  assign _EVAL_813 = _EVAL_803;
  assign _EVAL_829 = _EVAL_808[63:10];
  assign _EVAL_852 = _EVAL_544[31:0];
  assign _EVAL_859 = _EVAL_492;
  assign _EVAL_871 = _EVAL_922[3];
  assign _EVAL_905 = _EVAL_544[68:67];
  assign _EVAL_913 = _EVAL_871;
  assign _EVAL_923 = _EVAL_374;
  assign _EVAL_946 = _EVAL_922[7];
  assign _EVAL_970 = _EVAL_852;
  assign _EVAL_1032 = _EVAL_456;
endmodule
