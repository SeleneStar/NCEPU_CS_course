//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_106_sim(
  input  [1:0]  _EVAL_9,
  input  [6:0]  _EVAL_11,
  input         _EVAL_33,
  input         _EVAL_39,
  input         _EVAL_16,
  input  [1:0]  _EVAL_40,
  input         _EVAL_262,
  input         _EVAL_119,
  input         _EVAL_10,
  input  [5:0]  _EVAL_43,
  input         _EVAL_14,
  input         _EVAL_32,
  input  [1:0]  _EVAL_24,
  input  [1:0]  _EVAL_18,
  input  [38:0] _EVAL_1
);
  wire  _EVAL_51;
  wire  _EVAL_53;
  wire [1:0] _EVAL_75;
  reg  _EVAL_79;
  reg [31:0] _GEN_0;
  wire [1:0] _EVAL_82;
  wire  _EVAL_87;
  reg [5:0] _EVAL_89;
  reg [31:0] _GEN_1;
  wire [38:0] _EVAL_96;
  wire  _EVAL_130;
  reg [6:0] _EVAL_139;
  reg [31:0] _GEN_2;
  reg [1:0] _EVAL_143;
  reg [31:0] _GEN_3;
  wire  _EVAL_144;
  wire [5:0] _EVAL_147;
  wire [1:0] _EVAL_148;
  reg [1:0] _EVAL_151;
  reg [31:0] _GEN_4;
  reg [1:0] _EVAL_155;
  reg [31:0] _GEN_5;
  reg  _EVAL_169;
  reg [31:0] _GEN_6;
  wire  _EVAL_180;
  wire  _EVAL_187;
  reg [1:0] _EVAL_188;
  reg [31:0] _GEN_7;
  wire  _EVAL_192;
  reg [38:0] _EVAL_198;
  reg [63:0] _GEN_8;
  wire  _EVAL_202;
  reg  _EVAL_225;
  reg [31:0] _GEN_9;
  wire [6:0] _EVAL_229;
  wire  _EVAL_244;
  wire [1:0] _EVAL_267;
  assign _EVAL_51 = _EVAL_180 | _EVAL_53;
  assign _EVAL_53 = _EVAL_16 == 1'h0;
  assign _EVAL_75 = _EVAL_262 ? _EVAL_18 : _EVAL_143;
  assign _EVAL_82 = _EVAL_262 ? _EVAL_9 : _EVAL_155;
  assign _EVAL_87 = _EVAL_10 >= _EVAL_119;
  assign _EVAL_96 = _EVAL_262 ? _EVAL_1 : _EVAL_198;
  assign _EVAL_130 = _EVAL_262 ? _EVAL_10 : _EVAL_225;
  assign _EVAL_144 = _EVAL_262 ? _EVAL_16 : _EVAL_169;
  assign _EVAL_147 = _EVAL_262 ? _EVAL_43 : _EVAL_89;
  assign _EVAL_148 = _EVAL_262 ? _EVAL_24 : _EVAL_188;
  assign _EVAL_180 = _EVAL_39 == 1'h0;
  assign _EVAL_187 = _EVAL_262 ? _EVAL_14 : _EVAL_79;
  assign _EVAL_192 = _EVAL_202 == 1'h0;
  assign _EVAL_202 = _EVAL_244 | _EVAL_32;
  assign _EVAL_229 = _EVAL_262 ? _EVAL_11 : _EVAL_139;
  assign _EVAL_244 = _EVAL_51 | _EVAL_87;
  assign _EVAL_267 = _EVAL_262 ? _EVAL_40 : _EVAL_151;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_79 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_89 = _GEN_1[5:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_139 = _GEN_2[6:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_143 = _GEN_3[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_151 = _GEN_4[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_155 = _GEN_5[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_169 = _GEN_6[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_188 = _GEN_7[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_198 = _GEN_8[38:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_9 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_225 = _GEN_9[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_33) begin
    if (_EVAL_262) begin
      _EVAL_79 <= _EVAL_14;
    end
    if (_EVAL_262) begin
      _EVAL_89 <= _EVAL_43;
    end
    if (_EVAL_262) begin
      _EVAL_139 <= _EVAL_11;
    end
    if (_EVAL_262) begin
      _EVAL_143 <= _EVAL_18;
    end
    if (_EVAL_262) begin
      _EVAL_151 <= _EVAL_40;
    end
    if (_EVAL_262) begin
      _EVAL_155 <= _EVAL_9;
    end
    if (_EVAL_262) begin
      _EVAL_169 <= _EVAL_16;
    end
    if (_EVAL_262) begin
      _EVAL_188 <= _EVAL_24;
    end
    if (_EVAL_262) begin
      _EVAL_198 <= _EVAL_1;
    end
    if (_EVAL_262) begin
      _EVAL_225 <= _EVAL_10;
    end
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_192) begin
          $fwrite(32'h80000002,"40664cf0");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_192) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
