//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_110_sim(
  input  [63:0] _EVAL_3,
  input         _EVAL_12,
  input  [3:0]  _EVAL_2,
  input         _EVAL_18,
  input  [63:0] _EVAL_1
);
  wire [63:0] _EVAL_22;
  reg [63:0] _EVAL_23;
  reg [63:0] _GEN_0;
  reg [63:0] _EVAL_105;
  reg [63:0] _GEN_1;
  wire [3:0] _EVAL_110;
  reg [3:0] _EVAL_304;
  reg [31:0] _GEN_2;
  wire [63:0] _EVAL_470;
  assign _EVAL_22 = _EVAL_18 ? _EVAL_3 : _EVAL_23;
  assign _EVAL_110 = _EVAL_18 ? _EVAL_2 : _EVAL_304;
  assign _EVAL_470 = _EVAL_18 ? _EVAL_1 : _EVAL_105;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_23 = _GEN_0[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_105 = _GEN_1[63:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_304 = _GEN_2[3:0];
  `endif
  end
`endif
  always @(posedge _EVAL_12) begin
    if (_EVAL_18) begin
      _EVAL_23 <= _EVAL_3;
    end
    if (_EVAL_18) begin
      _EVAL_105 <= _EVAL_1;
    end
    if (_EVAL_18) begin
      _EVAL_304 <= _EVAL_2;
    end
  end
endmodule
