//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_114_sim(
  input   _EVAL_8,
  input   _EVAL_12,
  input   _EVAL_40,
  input   _EVAL_32,
  input   _EVAL_46
);
  wire  _EVAL_28;
  wire  _EVAL_34;
  wire  _EVAL_35;
  wire  _EVAL_44;
  assign _EVAL_28 = _EVAL_32 == _EVAL_40;
  assign _EVAL_34 = _EVAL_46 | _EVAL_28;
  assign _EVAL_35 = _EVAL_44 == 1'h0;
  assign _EVAL_44 = _EVAL_34 | _EVAL_12;
  always @(posedge _EVAL_8) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_35) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_35) begin
          $fwrite(32'h80000002,"bc8432df");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
