//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_115_sim(
  input   _EVAL_34,
  input   _EVAL_33,
  input   _EVAL_5,
  input   _EVAL_21,
  input   _EVAL_43
);
  wire  _EVAL_24;
  wire  _EVAL_31;
  wire  _EVAL_49;
  wire  _EVAL_50;
  assign _EVAL_24 = _EVAL_50 == 1'h0;
  assign _EVAL_31 = _EVAL_33 | _EVAL_49;
  assign _EVAL_49 = _EVAL_43 == _EVAL_34;
  assign _EVAL_50 = _EVAL_31 | _EVAL_21;
  always @(posedge _EVAL_5) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_24) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_24) begin
          $fwrite(32'h80000002,"fff0b970");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
