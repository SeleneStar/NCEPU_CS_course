//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_139_sim(
  input         _EVAL_19,
  input  [2:0]  _EVAL_41,
  input  [31:0] _EVAL_50,
  input         _EVAL_37,
  input         _EVAL_95,
  input  [3:0]  _EVAL_5,
  input         _EVAL_74,
  input         _EVAL_14,
  input  [3:0]  _EVAL_134,
  input  [2:0]  _EVAL_117,
  input         _EVAL_124
);
  wire [31:0] _EVAL_162;
  wire [31:0] _EVAL_163;
  wire  _EVAL_165;
  wire [1:0] _EVAL_166;
  wire  _EVAL_167;
  wire [8:0] _EVAL_170;
  wire  _EVAL_175;
  wire [2:0] _EVAL_176;
  wire [31:0] _EVAL_182;
  wire [11:0] _EVAL_183;
  wire [2:0] _EVAL_185;
  wire [2:0] _EVAL_193;
  wire  _EVAL_194;
  wire  _EVAL_198;
  wire  _EVAL_210;
  wire [32:0] _EVAL_211;
  wire [32:0] _EVAL_217;
  wire [2:0] _EVAL_225;
  wire [8:0] _EVAL_228;
  wire [2:0] _EVAL_229;
  wire [32:0] _EVAL_230;
  wire [8:0] _EVAL_232;
  wire  _EVAL_233;
  wire [8:0] _EVAL_234;
  wire [32:0] _EVAL_235;
  wire [9:0] _EVAL_241;
  wire [32:0] _EVAL_242;
  wire  _EVAL_243;
  wire [2:0] _EVAL_245;
  wire [31:0] _EVAL_249;
  wire [32:0] _EVAL_250;
  wire [32:0] _EVAL_251;
  wire [32:0] _EVAL_252;
  wire  _EVAL_253;
  wire [32:0] _EVAL_254;
  wire [32:0] _EVAL_258;
  wire [32:0] _EVAL_259;
  wire [8:0] _EVAL_260;
  wire [32:0] _EVAL_263;
  wire [2:0] _EVAL_265;
  wire [2:0] _EVAL_266;
  wire [8:0] _EVAL_268;
  wire  _EVAL_269;
  wire [2:0] _EVAL_270;
  wire  _EVAL_272;
  wire [9:0] _EVAL_280;
  wire [9:0] _EVAL_281;
  wire [31:0] _EVAL_282;
  wire [2:0] _EVAL_283;
  wire  _EVAL_286;
  wire [32:0] _EVAL_288;
  wire [11:0] _EVAL_289;
  wire [8:0] _EVAL_290;
  wire [32:0] _EVAL_291;
  wire [2:0] _EVAL_292;
  wire [11:0] _EVAL_293;
  wire [2:0] _EVAL_294;
  wire [32:0] _EVAL_295;
  wire  _EVAL_296;
  wire [32:0] _EVAL_297;
  wire  _EVAL_299;
  wire [8:0] _EVAL_300;
  wire [32:0] _EVAL_306;
  wire [8:0] _EVAL_307;
  wire  _EVAL_309;
  wire [9:0] _EVAL_311;
  reg [8:0] _EVAL_314;
  reg [31:0] _GEN_0;
  wire  _EVAL_316;
  wire [26:0] _EVAL_317;
  wire [11:0] _EVAL_319;
  wire  _EVAL_320;
  wire  _EVAL_322;
  wire [26:0] _EVAL_323;
  wire [32:0] _EVAL_325;
  wire  _EVAL_327;
  wire [2:0] _EVAL_332;
  wire [8:0] _EVAL_333;
  wire [1:0] _EVAL_334;
  wire [32:0] _EVAL_335;
  wire  _EVAL_337;
  wire [31:0] _EVAL_344;
  wire [32:0] _EVAL_346;
  reg [8:0] _EVAL_349;
  reg [31:0] _GEN_1;
  wire  _EVAL_354;
  wire [2:0] _EVAL_356;
  wire [32:0] _EVAL_357;
  assign _EVAL_162 = _EVAL_50 ^ 32'h4000;
  assign _EVAL_163 = _EVAL_50 ^ 32'h80000000;
  assign _EVAL_165 = _EVAL_349 == 9'h0;
  assign _EVAL_166 = _EVAL_198 ? 2'h2 : 2'h0;
  assign _EVAL_167 = $signed(_EVAL_250) == $signed(33'sh0);
  assign _EVAL_170 = _EVAL_165 ? _EVAL_307 : _EVAL_290;
  assign _EVAL_175 = $signed(_EVAL_251) == $signed(33'sh0);
  assign _EVAL_176 = {{1'd0}, _EVAL_334};
  assign _EVAL_182 = _EVAL_50 ^ 32'h1000;
  assign _EVAL_183 = ~ _EVAL_293;
  assign _EVAL_185 = _EVAL_253 ? 3'h5 : 3'h0;
  assign _EVAL_193 = _EVAL_266 | _EVAL_270;
  assign _EVAL_194 = _EVAL_316;
  assign _EVAL_198 = _EVAL_175;
  assign _EVAL_210 = _EVAL_309;
  assign _EVAL_211 = $signed(_EVAL_217) & $signed(33'sha6005000);
  assign _EVAL_217 = {1'b0,$signed(_EVAL_50)};
  assign _EVAL_225 = _EVAL_322 ? 3'h6 : 3'h0;
  assign _EVAL_228 = _EVAL_327 ? _EVAL_170 : _EVAL_349;
  assign _EVAL_229 = _EVAL_332 | _EVAL_245;
  assign _EVAL_230 = $signed(_EVAL_252);
  assign _EVAL_232 = _EVAL_183[11:3];
  assign _EVAL_233 = _EVAL_41[0];
  assign _EVAL_234 = _EVAL_320 ? _EVAL_268 : _EVAL_300;
  assign _EVAL_235 = $signed(_EVAL_288) & $signed(33'sha6005000);
  assign _EVAL_241 = _EVAL_349 - 9'h1;
  assign _EVAL_242 = {1'b0,$signed(_EVAL_249)};
  assign _EVAL_243 = _EVAL_117[2];
  assign _EVAL_245 = {{2'd0}, _EVAL_194};
  assign _EVAL_249 = _EVAL_50 ^ 32'h20000000;
  assign _EVAL_250 = $signed(_EVAL_235);
  assign _EVAL_251 = $signed(_EVAL_295);
  assign _EVAL_252 = $signed(_EVAL_258) & $signed(33'sha6004000);
  assign _EVAL_253 = _EVAL_354;
  assign _EVAL_254 = $signed(_EVAL_325);
  assign _EVAL_258 = {1'b0,$signed(_EVAL_163)};
  assign _EVAL_259 = $signed(_EVAL_297) & $signed(33'sha6005000);
  assign _EVAL_260 = _EVAL_337 ? _EVAL_234 : _EVAL_314;
  assign _EVAL_263 = $signed(_EVAL_259);
  assign _EVAL_265 = _EVAL_193 | _EVAL_294;
  assign _EVAL_266 = _EVAL_229 | _EVAL_283;
  assign _EVAL_268 = _EVAL_269 ? _EVAL_333 : 9'h0;
  assign _EVAL_269 = _EVAL_243 == 1'h0;
  assign _EVAL_270 = {{1'd0}, _EVAL_166};
  assign _EVAL_272 = _EVAL_296;
  assign _EVAL_280 = $unsigned(_EVAL_281);
  assign _EVAL_281 = _EVAL_314 - 9'h1;
  assign _EVAL_282 = _EVAL_50 ^ 32'h2000000;
  assign _EVAL_283 = _EVAL_210 ? 3'h7 : 3'h0;
  assign _EVAL_286 = _EVAL_299;
  assign _EVAL_288 = {1'b0,$signed(_EVAL_162)};
  assign _EVAL_289 = ~ _EVAL_319;
  assign _EVAL_290 = _EVAL_311[8:0];
  assign _EVAL_291 = $signed(_EVAL_346);
  assign _EVAL_292 = _EVAL_265;
  assign _EVAL_293 = _EVAL_323[11:0];
  assign _EVAL_294 = _EVAL_272 ? 3'h4 : 3'h0;
  assign _EVAL_295 = $signed(_EVAL_335) & $signed(33'sha6000000);
  assign _EVAL_296 = $signed(_EVAL_291) == $signed(33'sh0);
  assign _EVAL_297 = {1'b0,$signed(_EVAL_182)};
  assign _EVAL_299 = $signed(_EVAL_230) == $signed(33'sh0);
  assign _EVAL_300 = _EVAL_280[8:0];
  assign _EVAL_306 = {1'b0,$signed(_EVAL_344)};
  assign _EVAL_307 = _EVAL_233 ? _EVAL_232 : 9'h0;
  assign _EVAL_309 = $signed(_EVAL_263) == $signed(33'sh0);
  assign _EVAL_311 = $unsigned(_EVAL_241);
  assign _EVAL_316 = $signed(_EVAL_357) == $signed(33'sh0);
  assign _EVAL_317 = 27'hfff << _EVAL_134;
  assign _EVAL_319 = _EVAL_317[11:0];
  assign _EVAL_320 = _EVAL_314 == 9'h0;
  assign _EVAL_322 = _EVAL_167;
  assign _EVAL_323 = 27'hfff << _EVAL_5;
  assign _EVAL_325 = $signed(_EVAL_242) & $signed(33'sha6004000);
  assign _EVAL_327 = _EVAL_19 & _EVAL_124;
  assign _EVAL_332 = _EVAL_356 | _EVAL_225;
  assign _EVAL_333 = _EVAL_289[11:3];
  assign _EVAL_334 = _EVAL_286 ? 2'h3 : 2'h0;
  assign _EVAL_335 = {1'b0,$signed(_EVAL_282)};
  assign _EVAL_337 = _EVAL_95 & _EVAL_74;
  assign _EVAL_344 = _EVAL_50 ^ 32'h4000000;
  assign _EVAL_346 = $signed(_EVAL_306) & $signed(33'sha4000000);
  assign _EVAL_354 = $signed(_EVAL_254) == $signed(33'sh0);
  assign _EVAL_356 = _EVAL_176 | _EVAL_185;
  assign _EVAL_357 = $signed(_EVAL_211);
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_314 = _GEN_0[8:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_349 = _GEN_1[8:0];
  `endif
  end
`endif
  always @(posedge _EVAL_37) begin
    if (_EVAL_14) begin
      _EVAL_314 <= 9'h0;
    end else begin
      if (_EVAL_337) begin
        if (_EVAL_320) begin
          if (_EVAL_269) begin
            _EVAL_314 <= _EVAL_333;
          end else begin
            _EVAL_314 <= 9'h0;
          end
        end else begin
          _EVAL_314 <= _EVAL_300;
        end
      end
    end
    if (_EVAL_14) begin
      _EVAL_349 <= 9'h0;
    end else begin
      if (_EVAL_327) begin
        if (_EVAL_165) begin
          if (_EVAL_233) begin
            _EVAL_349 <= _EVAL_232;
          end else begin
            _EVAL_349 <= 9'h0;
          end
        end else begin
          _EVAL_349 <= _EVAL_290;
        end
      end
    end
  end
endmodule
