//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_146_sim(
  input         _EVAL_56,
  input         _EVAL_136,
  input  [15:0] _EVAL_91,
  input         _EVAL_55,
  input         _EVAL_50,
  input         Queue__EVAL_7,
  input         Queue__EVAL_10,
  input  [31:0] _EVAL_148,
  input         _EVAL_27,
  input         _EVAL_121,
  input  [1:0]  _EVAL_119,
  input         _EVAL_88,
  input         _EVAL_20,
  input         _EVAL_117,
  input         _EVAL_139
);
  wire [15:0] _EVAL_52;
  wire [1:0] _EVAL_60;
  wire  _EVAL_66;
  wire  _EVAL_68;
  wire  _EVAL_72;
  wire  _EVAL_74;
  wire  _EVAL_78;
  wire  _EVAL_79;
  wire  _EVAL_93;
  wire  _EVAL_96;
  wire  finisher_reset;
  wire  finisher_clock;
  wire  finisher_failure;
  wire  finisher_success;
  wire  finisher_done;
  wire  finisher_idx;
  wire [15:0] finisher_code;
  wire [2:0] _EVAL_122;
  wire  _EVAL_126;
  wire  _EVAL_128;
  wire [1:0] _EVAL_131;
  wire [31:0] _EVAL_132;
  wire  _EVAL_134;
  wire  _EVAL_142;
  wire  _EVAL_152;
  TestFinisher #(.CODEBITS(16), .IDXBITS(1)) finisher (
    .reset(finisher_reset),
    .clock(finisher_clock),
    .failure(finisher_failure),
    .success(finisher_success),
    .done(finisher_done),
    .idx(finisher_idx),
    .code(finisher_code)
  );
  assign _EVAL_52 = _EVAL_148[31:16];
  assign _EVAL_60 = _EVAL_119 & _EVAL_131;
  assign _EVAL_66 = _EVAL_60[0];
  assign _EVAL_68 = _EVAL_128 & _EVAL_66;
  assign _EVAL_72 = _EVAL_91 == 16'h3333;
  assign _EVAL_74 = _EVAL_96;
  assign _EVAL_78 = _EVAL_152 & _EVAL_142;
  assign _EVAL_79 = _EVAL_139 & Queue__EVAL_10;
  assign _EVAL_93 = _EVAL_126;
  assign _EVAL_96 = _EVAL_79 & _EVAL_50;
  assign finisher_reset = _EVAL_20;
  assign finisher_clock = _EVAL_27;
  assign finisher_failure = _EVAL_72;
  assign finisher_success = _EVAL_136;
  assign finisher_done = _EVAL_117;
  assign finisher_idx = 1'h0;
  assign finisher_code = _EVAL_52;
  assign _EVAL_122 = 3'h0;
  assign _EVAL_126 = _EVAL_78 & _EVAL_66;
  assign _EVAL_128 = _EVAL_152 & _EVAL_55;
  assign _EVAL_131 = {{1'd0}, _EVAL_88};
  assign _EVAL_132 = 32'h0;
  assign _EVAL_134 = _EVAL_68;
  assign _EVAL_142 = _EVAL_55 == 1'h0;
  assign _EVAL_152 = _EVAL_121 & _EVAL_56;
endmodule
