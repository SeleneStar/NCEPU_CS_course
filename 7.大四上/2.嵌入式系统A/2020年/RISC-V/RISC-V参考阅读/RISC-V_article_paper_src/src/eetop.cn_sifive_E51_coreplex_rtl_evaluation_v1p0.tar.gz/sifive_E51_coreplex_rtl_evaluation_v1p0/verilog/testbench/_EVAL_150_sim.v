//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_150_sim(
  input         Repeater__EVAL_5,
  input         _EVAL_165,
  input  [3:0]  Repeater__EVAL_7,
  input         _EVAL_54,
  input         _EVAL_6,
  input  [31:0] Repeater__EVAL_0
);
  wire  _EVAL_83;
  wire  _EVAL_89;
  wire  _EVAL_94;
  wire  _EVAL_113;
  wire  _EVAL_121;
  wire  _EVAL_133;
  wire  _EVAL_137;
  wire  _EVAL_147;
  wire  _EVAL_167;
  assign _EVAL_83 = Repeater__EVAL_5 == 1'h0;
  assign _EVAL_89 = 1'h1;
  assign _EVAL_94 = _EVAL_133 | _EVAL_6;
  assign _EVAL_113 = _EVAL_94 == 1'h0;
  assign _EVAL_121 = _EVAL_167 | _EVAL_6;
  assign _EVAL_133 = _EVAL_83 | _EVAL_147;
  assign _EVAL_137 = _EVAL_121 == 1'h0;
  assign _EVAL_147 = Repeater__EVAL_7 == 4'hf;
  assign _EVAL_167 = _EVAL_83 | _EVAL_165;
  always @(posedge _EVAL_54) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_113) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_137) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_137) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_113) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
