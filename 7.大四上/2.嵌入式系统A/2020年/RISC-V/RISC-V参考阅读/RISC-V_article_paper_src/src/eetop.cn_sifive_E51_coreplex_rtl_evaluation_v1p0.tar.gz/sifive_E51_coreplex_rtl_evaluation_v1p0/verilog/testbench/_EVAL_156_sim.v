//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_156_sim(
  input  [3:0]  Repeater__EVAL_19,
  input         _EVAL_22,
  input  [31:0] Repeater__EVAL_12,
  input         _EVAL_180,
  input         Repeater__EVAL_3,
  input         _EVAL_7
);
  wire  _EVAL_84;
  wire  _EVAL_102;
  wire  _EVAL_115;
  wire  _EVAL_150;
  wire  _EVAL_160;
  wire  _EVAL_163;
  wire  _EVAL_165;
  wire  _EVAL_168;
  wire  _EVAL_179;
  assign _EVAL_84 = _EVAL_165 | _EVAL_7;
  assign _EVAL_102 = _EVAL_160 == 1'h0;
  assign _EVAL_115 = Repeater__EVAL_3 == 1'h0;
  assign _EVAL_150 = 1'h1;
  assign _EVAL_160 = _EVAL_168 | _EVAL_7;
  assign _EVAL_163 = _EVAL_84 == 1'h0;
  assign _EVAL_165 = _EVAL_115 | _EVAL_180;
  assign _EVAL_168 = _EVAL_115 | _EVAL_179;
  assign _EVAL_179 = Repeater__EVAL_19 == 4'hf;
  always @(posedge _EVAL_22) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_163) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_102) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_163) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_102) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
