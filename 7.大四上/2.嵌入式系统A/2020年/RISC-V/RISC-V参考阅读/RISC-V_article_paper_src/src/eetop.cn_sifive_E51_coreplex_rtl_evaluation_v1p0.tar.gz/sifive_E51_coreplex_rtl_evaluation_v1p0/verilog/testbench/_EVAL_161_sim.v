//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_161_sim(
  input   _EVAL_80,
  input   _EVAL_22,
  input   _EVAL_105,
  input   _EVAL_97
);
  reg  _EVAL_92;
  reg [31:0] _GEN_0;
  wire  _EVAL_101;
  wire  _EVAL_128;
  wire  _EVAL_132;
  assign _EVAL_101 = _EVAL_97 & _EVAL_105;
  assign _EVAL_128 = _EVAL_101 ? 1'h0 : _EVAL_92;
  assign _EVAL_132 = 1'h1;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_92 = _GEN_0[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_80) begin
    if (_EVAL_22) begin
      _EVAL_92 <= 1'h0;
    end else begin
      if (_EVAL_101) begin
        _EVAL_92 <= 1'h0;
      end
    end
  end
endmodule
