//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_170_sim(
  input   _EVAL_5,
  input   _EVAL_17,
  input   _EVAL_6,
  input   _EVAL_7,
  input   _EVAL_13
);
  wire  _EVAL_26;
  wire  _EVAL_64;
  wire  _EVAL_66;
  wire  _EVAL_67;
  wire  _EVAL_69;
  wire  _EVAL_73;
  wire  _EVAL_107;
  wire  _EVAL_143;
  wire  _EVAL_187;
  wire  _EVAL_221;
  assign _EVAL_26 = _EVAL_73 == 1'h0;
  assign _EVAL_64 = _EVAL_221 == 1'h0;
  assign _EVAL_66 = _EVAL_143 & _EVAL_64;
  assign _EVAL_67 = _EVAL_66 & _EVAL_107;
  assign _EVAL_69 = _EVAL_13 & _EVAL_5;
  assign _EVAL_73 = _EVAL_67 | _EVAL_17;
  assign _EVAL_107 = _EVAL_69 == 1'h0;
  assign _EVAL_143 = _EVAL_187 == 1'h0;
  assign _EVAL_187 = _EVAL_7 & _EVAL_13;
  assign _EVAL_221 = _EVAL_7 & _EVAL_5;
  always @(posedge _EVAL_6) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_26) begin
          $fwrite(32'h80000002,"c7c912dc");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_26) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
