//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_171_sim(
  input   _EVAL_3,
  input   _EVAL_12,
  input   _EVAL_11,
  input   _EVAL_15,
  input   _EVAL_14
);
  wire  _EVAL_22;
  wire  _EVAL_28;
  wire  _EVAL_54;
  wire  _EVAL_58;
  wire  _EVAL_83;
  wire  _EVAL_131;
  wire  _EVAL_170;
  wire  _EVAL_211;
  wire  _EVAL_219;
  wire  _EVAL_233;
  assign _EVAL_22 = _EVAL_54 & _EVAL_219;
  assign _EVAL_28 = _EVAL_83 == 1'h0;
  assign _EVAL_54 = _EVAL_58 == 1'h0;
  assign _EVAL_58 = _EVAL_14 & _EVAL_12;
  assign _EVAL_83 = _EVAL_12 & _EVAL_3;
  assign _EVAL_131 = _EVAL_22 & _EVAL_28;
  assign _EVAL_170 = _EVAL_211 == 1'h0;
  assign _EVAL_211 = _EVAL_131 | _EVAL_11;
  assign _EVAL_219 = _EVAL_233 == 1'h0;
  assign _EVAL_233 = _EVAL_14 & _EVAL_3;
  always @(posedge _EVAL_15) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_170) begin
          $fwrite(32'h80000002,"c7c912dc");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_170) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
