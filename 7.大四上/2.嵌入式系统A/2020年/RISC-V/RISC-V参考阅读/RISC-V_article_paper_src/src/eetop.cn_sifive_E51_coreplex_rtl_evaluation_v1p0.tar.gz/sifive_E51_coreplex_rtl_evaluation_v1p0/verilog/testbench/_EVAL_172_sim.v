//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_172_sim(
  input   _EVAL_0,
  input   _EVAL_12,
  input   _EVAL_10,
  input   _EVAL_13,
  input   _EVAL_1
);
  wire  _EVAL_25;
  wire  _EVAL_37;
  wire  _EVAL_45;
  wire  _EVAL_52;
  wire  _EVAL_54;
  wire  _EVAL_76;
  wire  _EVAL_78;
  wire  _EVAL_87;
  wire  _EVAL_130;
  wire  _EVAL_149;
  assign _EVAL_25 = _EVAL_52 == 1'h0;
  assign _EVAL_37 = _EVAL_54 == 1'h0;
  assign _EVAL_45 = _EVAL_149 == 1'h0;
  assign _EVAL_52 = _EVAL_13 & _EVAL_12;
  assign _EVAL_54 = _EVAL_13 & _EVAL_0;
  assign _EVAL_76 = _EVAL_87 == 1'h0;
  assign _EVAL_78 = _EVAL_130 & _EVAL_76;
  assign _EVAL_87 = _EVAL_12 & _EVAL_0;
  assign _EVAL_130 = _EVAL_25 & _EVAL_37;
  assign _EVAL_149 = _EVAL_78 | _EVAL_10;
  always @(posedge _EVAL_1) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_45) begin
          $fwrite(32'h80000002,"fb380fba");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_45) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
