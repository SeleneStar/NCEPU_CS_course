//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_176_sim(
  input   _EVAL_12,
  input   _EVAL_9,
  input   _EVAL_5,
  input   _EVAL_7,
  input   _EVAL_1
);
  wire  _EVAL_20;
  wire  _EVAL_30;
  wire  _EVAL_31;
  wire  _EVAL_34;
  wire  _EVAL_38;
  wire  _EVAL_40;
  wire  _EVAL_50;
  wire  _EVAL_51;
  wire  _EVAL_54;
  wire  _EVAL_60;
  assign _EVAL_20 = _EVAL_51 | _EVAL_7;
  assign _EVAL_30 = _EVAL_40 == 1'h0;
  assign _EVAL_31 = _EVAL_38 & _EVAL_30;
  assign _EVAL_34 = _EVAL_5 & _EVAL_9;
  assign _EVAL_38 = _EVAL_34 == 1'h0;
  assign _EVAL_40 = _EVAL_5 & _EVAL_12;
  assign _EVAL_50 = _EVAL_20 == 1'h0;
  assign _EVAL_51 = _EVAL_31 & _EVAL_60;
  assign _EVAL_54 = _EVAL_9 & _EVAL_12;
  assign _EVAL_60 = _EVAL_54 == 1'h0;
  always @(posedge _EVAL_1) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_50) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_50) begin
          $fwrite(32'h80000002,"c7c912dc");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
