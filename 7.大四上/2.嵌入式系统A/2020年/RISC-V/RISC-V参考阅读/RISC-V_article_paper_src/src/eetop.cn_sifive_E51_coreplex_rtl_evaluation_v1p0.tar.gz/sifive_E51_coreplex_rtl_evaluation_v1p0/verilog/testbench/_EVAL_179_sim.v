//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_179_sim(
  input   _EVAL_3,
  input   _EVAL_2,
  input   _EVAL_5,
  input   _EVAL_4,
  input   _EVAL_7
);
  wire  _EVAL_11;
  wire  _EVAL_14;
  wire  _EVAL_15;
  wire  _EVAL_16;
  wire  _EVAL_17;
  wire  _EVAL_18;
  wire  _EVAL_19;
  wire  _EVAL_20;
  wire  _EVAL_22;
  wire  _EVAL_23;
  assign _EVAL_11 = _EVAL_3 & _EVAL_2;
  assign _EVAL_14 = _EVAL_18 & _EVAL_16;
  assign _EVAL_15 = _EVAL_17 == 1'h0;
  assign _EVAL_16 = _EVAL_22 == 1'h0;
  assign _EVAL_17 = _EVAL_14 | _EVAL_5;
  assign _EVAL_18 = _EVAL_19 & _EVAL_20;
  assign _EVAL_19 = _EVAL_23 == 1'h0;
  assign _EVAL_20 = _EVAL_11 == 1'h0;
  assign _EVAL_22 = _EVAL_4 & _EVAL_2;
  assign _EVAL_23 = _EVAL_3 & _EVAL_4;
  always @(posedge _EVAL_7) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_15) begin
          $fwrite(32'h80000002,"fdf8b9a");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_15) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
