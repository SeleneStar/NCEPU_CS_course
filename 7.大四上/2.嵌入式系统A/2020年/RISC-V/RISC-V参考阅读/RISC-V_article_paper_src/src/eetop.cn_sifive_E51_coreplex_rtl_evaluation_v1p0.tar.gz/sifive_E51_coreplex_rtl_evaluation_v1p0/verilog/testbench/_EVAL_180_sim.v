//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_180_sim(
  input         _EVAL_3,
  input  [2:0]  dtmInfoChain__EVAL_3,
  input         _EVAL_23,
  input  [15:0] _EVAL_73,
  input         idcodeChain__EVAL_4,
  input  [5:0]  dtmInfoChain__EVAL_19,
  input  [3:0]  dtmInfoChain__EVAL_8,
  input  [3:0]  _EVAL_143,
  input  [3:0]  JtagTapController__EVAL_7,
  input         _EVAL_110,
  input  [14:0] dtmInfoChain__EVAL_25,
  input         _EVAL_133,
  input  [4:0]  JtagTapController__EVAL_14,
  input         _EVAL_77,
  input  [1:0]  dtmInfoChain__EVAL_2,
  input         _EVAL_124,
  input  [10:0] _EVAL_200,
  input         dtmInfoChain__EVAL_23,
  input         _EVAL_13,
  input         dtmInfoChain__EVAL_15,
  input         dmiAccessChain__EVAL_16
);
  wire [11:0] _EVAL_19;
  wire [4:0] _EVAL_22;
  wire [31:0] _EVAL_24;
  wire [31:0] _EVAL_26;
  wire  _EVAL_31;
  wire  _EVAL_32;
  wire  _EVAL_36;
  wire [3:0] _EVAL_38;
  wire [1:0] _EVAL_42;
  wire [15:0] _EVAL_46;
  wire [19:0] _EVAL_56;
  wire  _EVAL_58;
  wire  _EVAL_63;
  wire  _EVAL_68;
  wire [12:0] _EVAL_71;
  wire [1:0] _EVAL_82;
  wire [30:0] _EVAL_90;
  wire [10:0] _EVAL_99;
  wire [31:0] _EVAL_102;
  wire [15:0] _EVAL_105;
  wire  _EVAL_106;
  wire [30:0] _EVAL_107;
  wire [3:0] _EVAL_112;
  wire [30:0] _EVAL_113;
  wire  _EVAL_115;
  wire [6:0] _EVAL_116;
  wire  _EVAL_117;
  wire [12:0] _EVAL_126;
  wire  _EVAL_127;
  wire  _EVAL_128;
  wire  _EVAL_137;
  wire  _EVAL_141;
  wire  _EVAL_160;
  wire [11:0] _EVAL_161;
  wire  _EVAL_170;
  wire  _EVAL_179;
  wire  _EVAL_188;
  wire [10:0] _EVAL_192;
  wire  _EVAL_195;
  wire  _EVAL_196;
  wire [3:0] _EVAL_198;
  wire  _EVAL_202;
  wire [31:0] _GEN_0;
  reg [1:0] _GEN_1;
  reg [31:0] _GEN_4;
  reg [6:0] _GEN_2;
  reg [31:0] _GEN_5;
  reg [31:0] _GEN_3;
  reg [31:0] _GEN_6;
  assign _EVAL_19 = _EVAL_126[11:0];
  assign _EVAL_22 = JtagTapController__EVAL_14;
  assign _EVAL_24 = _GEN_3;
  assign _EVAL_26 = {_EVAL_56,_EVAL_161};
  assign _EVAL_31 = _EVAL_113 != 31'h7f;
  assign _EVAL_32 = _EVAL_31 | _EVAL_3;
  assign _EVAL_36 = _EVAL_160;
  assign _EVAL_38 = _EVAL_198;
  assign _EVAL_42 = _GEN_1;
  assign _EVAL_46 = _EVAL_105;
  assign _EVAL_56 = {_EVAL_143,_EVAL_73};
  assign _EVAL_58 = dmiAccessChain__EVAL_16 ? _EVAL_110 : 1'h0;
  assign _EVAL_63 = _EVAL_128 & _EVAL_23;
  assign _EVAL_68 = _EVAL_137 == 1'h0;
  assign _EVAL_71 = 12'h800 - 12'h1;
  assign _EVAL_82 = _GEN_0[1:0];
  assign _EVAL_90 = {{19'd0}, _EVAL_19};
  assign _EVAL_99 = _EVAL_192;
  assign _EVAL_102 = 32'h0;
  assign _EVAL_105 = _EVAL_102[27:12];
  assign _EVAL_106 = _EVAL_32 == 1'h0;
  assign _EVAL_107 = _EVAL_26[31:1];
  assign _EVAL_112 = JtagTapController__EVAL_7;
  assign _EVAL_113 = _EVAL_107 & _EVAL_90;
  assign _EVAL_115 = _EVAL_202 == 1'h0;
  assign _EVAL_116 = _GEN_2;
  assign _EVAL_117 = _EVAL_82 == 2'h1;
  assign _EVAL_126 = $unsigned(_EVAL_71);
  assign _EVAL_127 = _EVAL_195 == 1'h0;
  assign _EVAL_128 = _EVAL_58;
  assign _EVAL_137 = _EVAL_141 | _EVAL_3;
  assign _EVAL_141 = _EVAL_77 == 1'h0;
  assign _EVAL_160 = _EVAL_102[0];
  assign _EVAL_161 = {_EVAL_200,_EVAL_133};
  assign _EVAL_170 = _EVAL_179 == 1'h0;
  assign _EVAL_179 = _EVAL_188 | _EVAL_3;
  assign _EVAL_188 = _EVAL_63 == 1'h0;
  assign _EVAL_192 = _EVAL_102[11:1];
  assign _EVAL_195 = _EVAL_117 | _EVAL_3;
  assign _EVAL_196 = _EVAL_124 == 1'h0;
  assign _EVAL_198 = _EVAL_102[31:28];
  assign _EVAL_202 = _EVAL_196 | _EVAL_3;
  assign _GEN_0 = _EVAL_26 % 32'h2;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_1 = _GEN_4[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_2 = _GEN_5[6:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _GEN_3 = _GEN_6[31:0];
  `endif
  end
`endif
  always @(posedge _EVAL_13) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_127) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_106) begin
          $fwrite(32'h80000002,"7c77a4cd");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_106) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_115) begin
          $fwrite(32'h80000002,"31a3355e");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_127) begin
          $fwrite(32'h80000002,"d8b17115");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_115) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_170) begin
          $fwrite(32'h80000002,"74575192");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_68) begin
          $fwrite(32'h80000002,"71eafe97");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_170) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_68) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
