//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_19_sim(
  input         _EVAL_150,
  input         _EVAL_850,
  input         _EVAL_15,
  input         _EVAL_600,
  input  [31:0] _EVAL_14,
  input         _EVAL_7
);
  wire  _EVAL_95;
  wire  _EVAL_108;
  wire  _EVAL_192;
  wire [32:0] _EVAL_217;
  wire  _EVAL_307;
  wire [32:0] _EVAL_311;
  wire  _EVAL_349;
  wire  _EVAL_565;
  wire  _EVAL_586;
  wire [32:0] _EVAL_679;
  wire  _EVAL_748;
  wire  _EVAL_768;
  wire  _EVAL_776;
  wire  _EVAL_805;
  wire  _EVAL_834;
  assign _EVAL_95 = _EVAL_834 | _EVAL_776;
  assign _EVAL_108 = _EVAL_150 == 1'h0;
  assign _EVAL_192 = $signed(_EVAL_311) == $signed(33'sh0);
  assign _EVAL_217 = {1'b0,$signed(_EVAL_14)};
  assign _EVAL_307 = _EVAL_805 | _EVAL_15;
  assign _EVAL_311 = $signed(_EVAL_679);
  assign _EVAL_349 = _EVAL_95 | _EVAL_15;
  assign _EVAL_565 = _EVAL_192;
  assign _EVAL_586 = _EVAL_307 == 1'h0;
  assign _EVAL_679 = $signed(_EVAL_217) & $signed(33'sh86000000);
  assign _EVAL_748 = _EVAL_349 == 1'h0;
  assign _EVAL_768 = _EVAL_850 == 1'h0;
  assign _EVAL_776 = _EVAL_850 | _EVAL_150;
  assign _EVAL_805 = _EVAL_768 | _EVAL_108;
  assign _EVAL_834 = _EVAL_600 == 1'h0;
  always @(posedge _EVAL_7) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_748) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_586) begin
          $fwrite(32'h80000002,"341d8c2e");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_748) begin
          $fwrite(32'h80000002,"c27013ad");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_586) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
