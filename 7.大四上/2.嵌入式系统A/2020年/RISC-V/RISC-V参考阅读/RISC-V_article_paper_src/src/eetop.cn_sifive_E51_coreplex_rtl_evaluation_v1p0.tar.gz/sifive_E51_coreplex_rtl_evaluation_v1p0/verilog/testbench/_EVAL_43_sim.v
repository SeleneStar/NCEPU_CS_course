//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_43_sim(
  input   _EVAL_8,
  input   _EVAL_38,
  input   _EVAL_16,
  input   _EVAL_36,
  input   _EVAL_17,
  input   _EVAL_6
);
  reg  _EVAL_28;
  reg [31:0] _GEN_0;
  wire  _EVAL_30;
  wire  _EVAL_34;
  wire  _EVAL_54;
  wire  AsyncResetRegVec__EVAL_0;
  wire  AsyncResetRegVec__EVAL_1;
  wire  AsyncResetRegVec__EVAL_2;
  wire  AsyncResetRegVec__EVAL_3;
  wire  AsyncResetRegVec__EVAL_4;
  _EVAL_32 AsyncResetRegVec (
    ._EVAL_0(AsyncResetRegVec__EVAL_0),
    ._EVAL_1(AsyncResetRegVec__EVAL_1),
    ._EVAL_2(AsyncResetRegVec__EVAL_2),
    ._EVAL_3(AsyncResetRegVec__EVAL_3),
    ._EVAL_4(AsyncResetRegVec__EVAL_4)
  );
  assign _EVAL_30 = _EVAL_16 == _EVAL_17;
  assign _EVAL_34 = _EVAL_36 | _EVAL_38;
  assign _EVAL_54 = _EVAL_34 | _EVAL_6;
  assign AsyncResetRegVec__EVAL_0 = 1'h1;
  assign AsyncResetRegVec__EVAL_1 = _EVAL_6;
  assign AsyncResetRegVec__EVAL_3 = _EVAL_8;
  assign AsyncResetRegVec__EVAL_4 = _EVAL_30;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_28 = _GEN_0[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_8) begin
    if (_EVAL_6) begin
      _EVAL_28 <= 1'h1;
    end else begin
      _EVAL_28 <= _EVAL_54;
    end
  end
endmodule
