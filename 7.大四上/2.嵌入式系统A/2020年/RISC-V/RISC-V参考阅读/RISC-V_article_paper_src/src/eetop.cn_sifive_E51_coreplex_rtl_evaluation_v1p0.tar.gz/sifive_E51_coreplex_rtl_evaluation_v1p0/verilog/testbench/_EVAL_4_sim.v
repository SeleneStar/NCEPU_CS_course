//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_4_sim(
  input   _EVAL_455,
  input   _EVAL_45,
  input   _EVAL_110,
  input   _EVAL_129,
  input   _EVAL_78
);
  wire  _EVAL_141;
  wire  _EVAL_235;
  wire  _EVAL_361;
  wire  _EVAL_396;
  wire  _EVAL_409;
  wire  _EVAL_487;
  wire  _EVAL_522;
  wire  _EVAL_636;
  wire  _EVAL_778;
  wire  _EVAL_842;
  assign _EVAL_141 = _EVAL_842 == 1'h0;
  assign _EVAL_235 = _EVAL_110 == 1'h0;
  assign _EVAL_361 = _EVAL_522 | _EVAL_45;
  assign _EVAL_396 = _EVAL_778 | _EVAL_636;
  assign _EVAL_409 = _EVAL_361 == 1'h0;
  assign _EVAL_487 = _EVAL_129 == 1'h0;
  assign _EVAL_522 = _EVAL_235 | _EVAL_487;
  assign _EVAL_636 = _EVAL_110 | _EVAL_129;
  assign _EVAL_778 = _EVAL_455 == 1'h0;
  assign _EVAL_842 = _EVAL_396 | _EVAL_45;
  always @(posedge _EVAL_78) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_409) begin
          $fwrite(32'h80000002,"341d8c2e");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_141) begin
          $fwrite(32'h80000002,"c27013ad");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_409) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_141) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
