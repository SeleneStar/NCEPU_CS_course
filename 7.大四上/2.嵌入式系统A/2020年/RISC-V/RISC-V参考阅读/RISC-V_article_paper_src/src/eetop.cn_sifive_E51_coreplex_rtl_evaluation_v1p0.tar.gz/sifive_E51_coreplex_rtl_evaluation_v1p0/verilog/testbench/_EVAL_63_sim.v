//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_63_sim(
  input   _EVAL_60,
  input   _EVAL_114,
  input   _EVAL_105,
  input   _EVAL_296,
  input   _EVAL_56,
  input   _EVAL_48,
  input   _EVAL_133,
  input   _EVAL_292,
  input   _EVAL_108,
  input   _EVAL_118,
  input   _EVAL_63,
  input   _EVAL_238,
  input   _EVAL_206,
  input   _EVAL_122,
  input   _EVAL_217,
  input   _EVAL_281,
  input   _EVAL_93,
  input   _EVAL_228,
  input   _EVAL_146,
  input   _EVAL_53
);
  wire  _EVAL_58;
  wire  _EVAL_69;
  wire [2:0] _EVAL_73;
  wire  _EVAL_74;
  wire  _EVAL_79;
  wire  _EVAL_80;
  wire  _EVAL_90;
  wire  _EVAL_91;
  wire  _EVAL_94;
  wire  _EVAL_102;
  wire  _EVAL_109;
  wire  _EVAL_124;
  wire  _EVAL_128;
  wire  _EVAL_132;
  wire  _EVAL_135;
  wire  _EVAL_141;
  wire  _EVAL_147;
  wire  _EVAL_155;
  wire  _EVAL_178;
  wire  _EVAL_179;
  wire  _EVAL_181;
  wire  _EVAL_193;
  wire  _EVAL_195;
  wire  _EVAL_204;
  wire  _EVAL_205;
  wire  _EVAL_213;
  wire  _EVAL_222;
  wire  _EVAL_224;
  wire  _EVAL_235;
  wire  _EVAL_240;
  wire  _EVAL_253;
  wire  _EVAL_258;
  wire  _EVAL_260;
  wire  _EVAL_272;
  wire  _EVAL_276;
  wire  _EVAL_279;
  wire  _EVAL_285;
  wire  _EVAL_291;
  wire [63:0] _EVAL_295;
  wire  _EVAL_299;
  wire  _EVAL_310;
  wire  _EVAL_311;
  assign _EVAL_58 = _EVAL_193 & _EVAL_133;
  assign _EVAL_69 = _EVAL_91;
  assign _EVAL_73 = 3'h0;
  assign _EVAL_74 = _EVAL_258;
  assign _EVAL_79 = _EVAL_213 & _EVAL_146;
  assign _EVAL_80 = _EVAL_299 & _EVAL_93;
  assign _EVAL_90 = _EVAL_311;
  assign _EVAL_91 = _EVAL_147 & _EVAL_60;
  assign _EVAL_94 = _EVAL_260;
  assign _EVAL_102 = _EVAL_79 & _EVAL_122;
  assign _EVAL_109 = _EVAL_155;
  assign _EVAL_124 = _EVAL_141;
  assign _EVAL_128 = _EVAL_178;
  assign _EVAL_132 = _EVAL_58 & _EVAL_217;
  assign _EVAL_135 = _EVAL_102;
  assign _EVAL_141 = _EVAL_193 & _EVAL_281;
  assign _EVAL_147 = _EVAL_193 & _EVAL_146;
  assign _EVAL_155 = _EVAL_205 & _EVAL_114;
  assign _EVAL_178 = _EVAL_205 & _EVAL_105;
  assign _EVAL_179 = _EVAL_147 & _EVAL_206;
  assign _EVAL_181 = _EVAL_80;
  assign _EVAL_193 = _EVAL_296 & _EVAL_108;
  assign _EVAL_195 = _EVAL_179;
  assign _EVAL_204 = _EVAL_240;
  assign _EVAL_205 = _EVAL_224 & _EVAL_133;
  assign _EVAL_213 = _EVAL_253 & _EVAL_108;
  assign _EVAL_222 = _EVAL_132;
  assign _EVAL_224 = _EVAL_253 & _EVAL_48;
  assign _EVAL_235 = _EVAL_279;
  assign _EVAL_240 = _EVAL_224 & _EVAL_281;
  assign _EVAL_253 = _EVAL_118 & _EVAL_292;
  assign _EVAL_258 = _EVAL_213 & _EVAL_281;
  assign _EVAL_260 = _EVAL_79 & _EVAL_53;
  assign _EVAL_272 = _EVAL_213 & _EVAL_133;
  assign _EVAL_276 = _EVAL_291;
  assign _EVAL_279 = _EVAL_299 & _EVAL_228;
  assign _EVAL_285 = _EVAL_310;
  assign _EVAL_291 = _EVAL_272 & _EVAL_63;
  assign _EVAL_295 = 64'h0;
  assign _EVAL_299 = _EVAL_224 & _EVAL_146;
  assign _EVAL_310 = _EVAL_272 & _EVAL_238;
  assign _EVAL_311 = _EVAL_58 & _EVAL_56;
endmodule
