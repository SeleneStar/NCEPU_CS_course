//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_65_sim(
  input         _EVAL_8,
  input  [7:0]  Repeater__EVAL_14,
  input         Repeater__EVAL_21,
  input         _EVAL_14,
  input  [63:0] Repeater__EVAL_8,
  input         _EVAL_93
);
  wire  _EVAL_104;
  wire  _EVAL_115;
  wire  _EVAL_126;
  wire  _EVAL_127;
  wire  _EVAL_130;
  wire  _EVAL_145;
  wire  _EVAL_158;
  wire  _EVAL_162;
  wire  _EVAL_164;
  assign _EVAL_104 = _EVAL_130 | _EVAL_164;
  assign _EVAL_115 = 1'h1;
  assign _EVAL_126 = _EVAL_127 == 1'h0;
  assign _EVAL_127 = _EVAL_104 | _EVAL_8;
  assign _EVAL_130 = Repeater__EVAL_21 == 1'h0;
  assign _EVAL_145 = _EVAL_158 == 1'h0;
  assign _EVAL_158 = _EVAL_162 | _EVAL_8;
  assign _EVAL_162 = _EVAL_130 | _EVAL_93;
  assign _EVAL_164 = Repeater__EVAL_14 == 8'hff;
  always @(posedge _EVAL_14) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_145) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_145) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_126) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_126) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
