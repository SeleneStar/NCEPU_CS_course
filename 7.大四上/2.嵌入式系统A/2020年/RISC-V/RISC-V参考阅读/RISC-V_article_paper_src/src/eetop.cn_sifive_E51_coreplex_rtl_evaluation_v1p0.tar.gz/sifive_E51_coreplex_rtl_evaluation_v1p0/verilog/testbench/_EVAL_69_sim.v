//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_69_sim(
  input         _EVAL_52,
  input  [7:0]  Repeater__EVAL_10,
  input  [63:0] Repeater__EVAL_4,
  input         _EVAL_180,
  input         Repeater__EVAL_8,
  input         _EVAL_66
);
  wire  _EVAL_82;
  wire  _EVAL_87;
  wire  _EVAL_102;
  wire  _EVAL_107;
  wire  _EVAL_109;
  wire  _EVAL_140;
  wire  _EVAL_147;
  wire  _EVAL_157;
  wire  _EVAL_178;
  assign _EVAL_82 = _EVAL_109 | _EVAL_180;
  assign _EVAL_87 = _EVAL_140 == 1'h0;
  assign _EVAL_102 = _EVAL_109 | _EVAL_178;
  assign _EVAL_107 = _EVAL_157 == 1'h0;
  assign _EVAL_109 = Repeater__EVAL_8 == 1'h0;
  assign _EVAL_140 = _EVAL_82 | _EVAL_66;
  assign _EVAL_147 = 1'h1;
  assign _EVAL_157 = _EVAL_102 | _EVAL_66;
  assign _EVAL_178 = Repeater__EVAL_10 == 8'hff;
  always @(posedge _EVAL_52) begin
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_87) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_107) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_107) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_87) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
