//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_73_sim(
  input  [7:0]  Repeater__EVAL_1,
  input         _EVAL_158,
  input         _EVAL_48,
  input  [63:0] Repeater__EVAL_4,
  input         _EVAL_43,
  input         Repeater__EVAL_16
);
  wire  _EVAL_89;
  wire  _EVAL_106;
  wire  _EVAL_111;
  wire  _EVAL_124;
  wire  _EVAL_136;
  wire  _EVAL_146;
  wire  _EVAL_147;
  wire  _EVAL_157;
  wire  _EVAL_163;
  assign _EVAL_89 = Repeater__EVAL_16 == 1'h0;
  assign _EVAL_106 = Repeater__EVAL_1 == 8'hff;
  assign _EVAL_111 = _EVAL_146 | _EVAL_43;
  assign _EVAL_124 = _EVAL_89 | _EVAL_106;
  assign _EVAL_136 = _EVAL_157 == 1'h0;
  assign _EVAL_146 = _EVAL_89 | _EVAL_158;
  assign _EVAL_147 = _EVAL_111 == 1'h0;
  assign _EVAL_157 = _EVAL_124 | _EVAL_43;
  assign _EVAL_163 = 1'h1;
  always @(posedge _EVAL_48) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_136) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_147) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_147) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_136) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
