//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_7_sim(
  input        _EVAL_92,
  input  [3:0] _EVAL_56,
  input        _EVAL_50,
  input        Repeater__EVAL_12,
  input  [1:0] _EVAL_13
);
  wire  _EVAL_84;
  wire  _EVAL_86;
  wire  _EVAL_94;
  wire [1:0] _EVAL_97;
  wire  _EVAL_100;
  wire [7:0] _EVAL_104;
  wire [7:0] _EVAL_105;
  wire [7:0] _EVAL_110;
  wire [1:0] _EVAL_111;
  wire  _EVAL_113;
  wire  _EVAL_114;
  wire  _EVAL_115;
  wire  _EVAL_118;
  wire  _EVAL_123;
  wire  _EVAL_124;
  wire [7:0] _EVAL_131;
  wire  _EVAL_132;
  wire  _EVAL_135;
  wire [3:0] _EVAL_136;
  wire  _EVAL_139;
  wire  _EVAL_142;
  wire  _EVAL_145;
  wire [7:0] _EVAL_147;
  wire [7:0] _EVAL_150;
  wire [7:0] _EVAL_152;
  wire [7:0] _EVAL_153;
  wire [7:0] _EVAL_157;
  wire  _EVAL_161;
  wire [1:0] _EVAL_164;
  wire [7:0] _EVAL_170;
  wire [7:0] _EVAL_171;
  wire  _EVAL_177;
  wire [7:0] _EVAL_179;
  reg [3:0] _EVAL_183;
  reg [31:0] _GEN_0;
  wire [3:0] _EVAL_186;
  wire  _EVAL_195;
  wire  _EVAL_198;
  wire [7:0] _EVAL_200;
  wire [7:0] _EVAL_202;
  wire  _EVAL_203;
  wire [1:0] _EVAL_207;
  wire  _EVAL_211;
  wire [3:0] _EVAL_214;
  wire  _EVAL_216;
  wire  _EVAL_222;
  wire [3:0] _EVAL_226;
  wire [7:0] _EVAL_232;
  wire  _EVAL_234;
  assign _EVAL_84 = _EVAL_56[0];
  assign _EVAL_86 = _EVAL_13[1];
  assign _EVAL_94 = _EVAL_86 == 1'h0;
  assign _EVAL_97 = 2'h1 << _EVAL_84;
  assign _EVAL_100 = _EVAL_211 | _EVAL_177;
  assign _EVAL_104 = {_EVAL_186,_EVAL_183};
  assign _EVAL_105 = _EVAL_104;
  assign _EVAL_110 = _EVAL_104;
  assign _EVAL_111 = _EVAL_97 | 2'h1;
  assign _EVAL_113 = _EVAL_216 & _EVAL_145;
  assign _EVAL_114 = _EVAL_86 & _EVAL_234;
  assign _EVAL_115 = _EVAL_161 & _EVAL_94;
  assign _EVAL_118 = _EVAL_86 & _EVAL_222;
  assign _EVAL_123 = _EVAL_211 | _EVAL_124;
  assign _EVAL_124 = _EVAL_216 & _EVAL_114;
  assign _EVAL_131 = _EVAL_104;
  assign _EVAL_132 = _EVAL_94 & _EVAL_234;
  assign _EVAL_135 = _EVAL_198 | _EVAL_115;
  assign _EVAL_136 = _EVAL_92 ? _EVAL_226 : _EVAL_183;
  assign _EVAL_139 = _EVAL_216 & _EVAL_132;
  assign _EVAL_142 = _EVAL_161 & _EVAL_86;
  assign _EVAL_145 = _EVAL_94 & _EVAL_222;
  assign _EVAL_147 = _EVAL_104;
  assign _EVAL_150 = _EVAL_104;
  assign _EVAL_152 = _EVAL_104;
  assign _EVAL_153 = _EVAL_179;
  assign _EVAL_157 = _EVAL_104;
  assign _EVAL_161 = _EVAL_111[1];
  assign _EVAL_164 = {_EVAL_123,_EVAL_100};
  assign _EVAL_170 = _EVAL_104;
  assign _EVAL_171 = _EVAL_104;
  assign _EVAL_177 = _EVAL_216 & _EVAL_118;
  assign _EVAL_179 = {_EVAL_214,_EVAL_214};
  assign _EVAL_186 = {_EVAL_164,_EVAL_207};
  assign _EVAL_195 = _EVAL_135 | _EVAL_139;
  assign _EVAL_198 = _EVAL_56 >= 4'h2;
  assign _EVAL_200 = _EVAL_104;
  assign _EVAL_202 = _EVAL_179;
  assign _EVAL_203 = _EVAL_135 | _EVAL_113;
  assign _EVAL_207 = {_EVAL_195,_EVAL_203};
  assign _EVAL_211 = _EVAL_198 | _EVAL_142;
  assign _EVAL_214 = _EVAL_104[7:4];
  assign _EVAL_216 = _EVAL_111[0];
  assign _EVAL_222 = _EVAL_234 == 1'h0;
  assign _EVAL_226 = _EVAL_104[7:4];
  assign _EVAL_232 = _EVAL_179;
  assign _EVAL_234 = _EVAL_13[0];
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_183 = _GEN_0[3:0];
  `endif
  end
`endif
  always @(posedge _EVAL_50) begin
    if (_EVAL_92) begin
      _EVAL_183 <= _EVAL_226;
    end
  end
endmodule
