//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_89_sim(
  input        _EVAL_196,
  input        _EVAL_193,
  input        _EVAL_52,
  input        _EVAL_178,
  input        _EVAL_226,
  input        _EVAL_215,
  input        _EVAL_33,
  input        _EVAL_186,
  input        _EVAL_167,
  input  [1:0] _EVAL_211
);
  reg  _EVAL_76;
  reg [31:0] _GEN_0;
  wire  _EVAL_77;
  wire  _EVAL_86;
  wire  _EVAL_94;
  wire  _EVAL_99;
  wire  _EVAL_115;
  wire [1:0] _EVAL_125;
  wire  _EVAL_139;
  wire  _EVAL_144;
  wire  _EVAL_152;
  wire  _EVAL_155;
  wire  _EVAL_166;
  wire  _EVAL_190;
  reg  _EVAL_198;
  reg [31:0] _GEN_1;
  wire  _EVAL_208;
  assign _EVAL_77 = _EVAL_144 == 1'h0;
  assign _EVAL_86 = _EVAL_186 == 1'h0;
  assign _EVAL_94 = _EVAL_226 == 1'h0;
  assign _EVAL_99 = _EVAL_178 == 1'h0;
  assign _EVAL_115 = _EVAL_125 <= 2'h1;
  assign _EVAL_125 = _EVAL_208 + _EVAL_139;
  assign _EVAL_139 = _EVAL_193 & _EVAL_99;
  assign _EVAL_144 = _EVAL_155 | _EVAL_52;
  assign _EVAL_152 = _EVAL_166 | _EVAL_52;
  assign _EVAL_155 = _EVAL_211 == 2'h2;
  assign _EVAL_166 = _EVAL_86 | _EVAL_115;
  assign _EVAL_190 = _EVAL_152 == 1'h0;
  assign _EVAL_208 = _EVAL_215 & _EVAL_94;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_76 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_198 = _GEN_1[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_33) begin
    if (_EVAL_52) begin
      _EVAL_76 <= 1'h0;
    end else begin
      _EVAL_76 <= _EVAL_196;
    end
    if (_EVAL_52) begin
      _EVAL_198 <= 1'h0;
    end
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_167 & _EVAL_77) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_190) begin
          $fwrite(32'h80000002,"83d40550");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_190) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"8af7d234");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"931e171d");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_167 & _EVAL_77) begin
          $fwrite(32'h80000002,"9fb1a08b");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
  end
endmodule
