//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_94_sim(
  input         _EVAL_0,
  input         _EVAL_8,
  input  [38:0] _EVAL_12,
  input  [6:0]  _EVAL_26,
  input         _EVAL_39,
  input  [1:0]  _EVAL_27,
  input         _EVAL_16,
  input         _EVAL_40,
  input  [1:0]  _EVAL_29,
  input  [38:0] _EVAL_36,
  input  [1:0]  _EVAL_24
);
  wire  _EVAL_84;
  reg  _EVAL_119;
  reg [31:0] _GEN_0;
  reg [38:0] _EVAL_299;
  reg [63:0] _GEN_1;
  wire  _EVAL_336;
  reg [38:0] _EVAL_344;
  reg [63:0] _GEN_2;
  wire [1:0] _EVAL_427;
  wire  _EVAL_488;
  reg [6:0] _EVAL_533;
  reg [31:0] _GEN_3;
  wire  _EVAL_547;
  reg [1:0] _EVAL_630;
  reg [31:0] _GEN_4;
  wire  _EVAL_678;
  wire [1:0] _EVAL_905;
  reg  _EVAL_941;
  reg [31:0] _GEN_5;
  wire [38:0] _EVAL_1122;
  wire [1:0] _EVAL_1145;
  wire [6:0] _EVAL_1168;
  wire [1:0] _EVAL_1180;
  reg [1:0] _EVAL_1252;
  reg [31:0] _GEN_6;
  wire [6:0] _EVAL_1255;
  wire [38:0] _EVAL_1325;
  wire [38:0] _EVAL_1338;
  wire [38:0] _EVAL_1702;
  reg [1:0] _EVAL_1733;
  reg [31:0] _GEN_7;
  wire  _EVAL_1794;
  wire [1:0] _EVAL_1814;
  wire [1:0] _EVAL_1817;
  reg  _EVAL_1945;
  reg [31:0] _GEN_8;
  assign _EVAL_84 = _EVAL_1945;
  assign _EVAL_336 = _EVAL_16 ? _EVAL_8 : _EVAL_1945;
  assign _EVAL_427 = _EVAL_630;
  assign _EVAL_488 = _EVAL_16 ? _EVAL_0 : _EVAL_941;
  assign _EVAL_547 = _EVAL_119;
  assign _EVAL_678 = _EVAL_16 ? _EVAL_39 : _EVAL_119;
  assign _EVAL_905 = _EVAL_1733;
  assign _EVAL_1122 = _EVAL_344;
  assign _EVAL_1145 = _EVAL_16 ? _EVAL_29 : _EVAL_1252;
  assign _EVAL_1168 = _EVAL_16 ? _EVAL_26 : _EVAL_533;
  assign _EVAL_1180 = _EVAL_16 ? _EVAL_27 : _EVAL_1733;
  assign _EVAL_1255 = _EVAL_533;
  assign _EVAL_1325 = _EVAL_16 ? _EVAL_12 : _EVAL_299;
  assign _EVAL_1338 = _EVAL_16 ? _EVAL_36 : _EVAL_344;
  assign _EVAL_1702 = _EVAL_299;
  assign _EVAL_1794 = _EVAL_941;
  assign _EVAL_1814 = _EVAL_16 ? _EVAL_24 : _EVAL_630;
  assign _EVAL_1817 = _EVAL_1252;
`ifdef RANDOMIZE
  integer initvar;
  initial begin
    `ifndef verilator
      #0.002 begin end
    `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_0 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_119 = _GEN_0[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_1 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_299 = _GEN_1[38:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_2 = {2{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_344 = _GEN_2[38:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_3 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_533 = _GEN_3[6:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_4 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_630 = _GEN_4[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_5 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_941 = _GEN_5[0:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_6 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_1252 = _GEN_6[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_7 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_1733 = _GEN_7[1:0];
  `endif
  `ifdef RANDOMIZE_REG_INIT
  _GEN_8 = {1{ `ifdef VERILATOR $random `else $urandom `endif }};
  _EVAL_1945 = _GEN_8[0:0];
  `endif
  end
`endif
  always @(posedge _EVAL_40) begin
    if (_EVAL_16) begin
      _EVAL_119 <= _EVAL_39;
    end
    if (_EVAL_16) begin
      _EVAL_299 <= _EVAL_12;
    end
    if (_EVAL_16) begin
      _EVAL_344 <= _EVAL_36;
    end
    if (_EVAL_16) begin
      _EVAL_533 <= _EVAL_26;
    end
    if (_EVAL_16) begin
      _EVAL_630 <= _EVAL_24;
    end
    if (_EVAL_16) begin
      _EVAL_941 <= _EVAL_0;
    end
    if (_EVAL_16) begin
      _EVAL_1252 <= _EVAL_29;
    end
    if (_EVAL_16) begin
      _EVAL_1733 <= _EVAL_27;
    end
    if (_EVAL_16) begin
      _EVAL_1945 <= _EVAL_8;
    end
  end
endmodule
