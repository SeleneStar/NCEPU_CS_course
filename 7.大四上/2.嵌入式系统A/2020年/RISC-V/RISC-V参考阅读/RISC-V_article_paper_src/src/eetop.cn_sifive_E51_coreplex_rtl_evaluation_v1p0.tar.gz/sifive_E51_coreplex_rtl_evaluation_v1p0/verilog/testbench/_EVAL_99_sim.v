//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module _EVAL_99_sim(
  input         _EVAL_86,
  input         _EVAL_61,
  input  [7:0]  Repeater__EVAL_10,
  input         _EVAL_59,
  input  [63:0] Repeater__EVAL_4,
  input         _EVAL_35,
  input         Repeater__EVAL_6,
  input         _EVAL_168
);
  wire  _EVAL_83;
  wire  _EVAL_84;
  wire  _EVAL_88;
  wire  _EVAL_90;
  wire  _EVAL_91;
  wire  _EVAL_98;
  wire  _EVAL_118;
  wire  _EVAL_122;
  wire  _EVAL_146;
  wire  _EVAL_147;
  wire  _EVAL_151;
  wire  _EVAL_155;
  wire  _EVAL_171;
  assign _EVAL_83 = _EVAL_84 == 1'h0;
  assign _EVAL_84 = _EVAL_91 | _EVAL_35;
  assign _EVAL_88 = _EVAL_171 | _EVAL_168;
  assign _EVAL_90 = _EVAL_146 == 1'h0;
  assign _EVAL_91 = _EVAL_98 | _EVAL_118;
  assign _EVAL_98 = Repeater__EVAL_6 == 1'h0;
  assign _EVAL_118 = Repeater__EVAL_10 == 8'hff;
  assign _EVAL_122 = _EVAL_88 | _EVAL_35;
  assign _EVAL_146 = _EVAL_155 | _EVAL_35;
  assign _EVAL_147 = 1'h1;
  assign _EVAL_151 = _EVAL_122 == 1'h0;
  assign _EVAL_155 = _EVAL_98 | _EVAL_86;
  assign _EVAL_171 = _EVAL_61 == 1'h0;
  always @(posedge _EVAL_59) begin
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_83) begin
          $fwrite(32'h80000002,"ede4af2");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_151) begin
          $fwrite(32'h80000002,"b112d5de");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (_EVAL_90) begin
          $fwrite(32'h80000002,"e3480fff");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (1'h0) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_90) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef PRINTF_COND
      if (`PRINTF_COND) begin
    `endif
        if (1'h0) begin
          $fwrite(32'h80000002,"3db019b7");
        end
    `ifdef PRINTF_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_83) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
    `ifndef SYNTHESIS
    `ifdef STOP_COND
      if (`STOP_COND) begin
    `endif
        if (_EVAL_151) begin
          $fatal;
        end
    `ifdef STOP_COND
      end
    `endif
    `endif
  end
endmodule
