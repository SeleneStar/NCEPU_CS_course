//
// Copyright (c) 2016-2017 SiFive, Inc. -- Proprietary and Confidential
// All Rights Reserved.
//
// NOTICE: All information contained herein is, and remains the
// property of SiFive, Inc. The intellectual and technical concepts
// contained herein are proprietary to SiFive, Inc. and may be covered
// by U.S. and Foreign Patents, patents in process, and are protected by
// trade secret or copyright law.
//
// This work may not be copied, modified, re-published, uploaded,
// executed, or distributed in any way, in any medium, whether in whole
// or in part, without prior written permission from SiFive, Inc.
//
// The copyright notice above does not evidence any actual or intended
// publication or disclosure of this source code, which includes
// information that is confidential and/or proprietary, and is a trade
// secret, of SiFive, Inc.
//
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif

module mem(
  input  [10:0] RW0_addr,
  input         RW0_en,
  input         RW0_clk,
  input         RW0_wmode,
  input  [7:0]  RW0_wdata_0,
  input  [7:0]  RW0_wdata_1,
  input  [7:0]  RW0_wdata_2,
  input  [7:0]  RW0_wdata_3,
  output [7:0]  RW0_rdata_0,
  output [7:0]  RW0_rdata_1,
  output [7:0]  RW0_rdata_2,
  output [7:0]  RW0_rdata_3,
  input         RW0_wmask_0,
  input         RW0_wmask_1,
  input         RW0_wmask_2,
  input         RW0_wmask_3
);
  wire [10:0] mem_ext_RW0_addr;
  wire  mem_ext_RW0_en;
  wire  mem_ext_RW0_clk;
  wire  mem_ext_RW0_wmode;
  wire [31:0] mem_ext_RW0_wdata;
  wire [31:0] mem_ext_RW0_rdata;
  wire [3:0] mem_ext_RW0_wmask;
  wire [7:0] _GEN_0;
  wire [7:0] _GEN_1;
  wire [7:0] _GEN_2;
  wire [7:0] _GEN_3;
  wire [7:0] _GEN_4;
  wire [7:0] _GEN_5;
  wire [7:0] _GEN_6;
  wire [7:0] _GEN_7;
  wire [15:0] _GEN_8;
  wire [15:0] _GEN_9;
  wire  _GEN_10;
  wire  _GEN_11;
  wire  _GEN_12;
  wire  _GEN_13;
  wire [1:0] _GEN_14;
  wire [1:0] _GEN_15;
  mem_ext mem_ext (
    .RW0_addr(mem_ext_RW0_addr),
    .RW0_en(mem_ext_RW0_en),
    .RW0_clk(mem_ext_RW0_clk),
    .RW0_wmode(mem_ext_RW0_wmode),
    .RW0_wdata(mem_ext_RW0_wdata),
    .RW0_rdata(mem_ext_RW0_rdata),
    .RW0_wmask(mem_ext_RW0_wmask)
  );
  assign RW0_rdata_0 = $unsigned(_GEN_0);
  assign RW0_rdata_1 = $unsigned(_GEN_1);
  assign RW0_rdata_2 = $unsigned(_GEN_2);
  assign RW0_rdata_3 = $unsigned(_GEN_3);
  assign mem_ext_RW0_addr = RW0_addr;
  assign mem_ext_RW0_en = RW0_en;
  assign mem_ext_RW0_clk = RW0_clk;
  assign mem_ext_RW0_wmode = RW0_wmode;
  assign mem_ext_RW0_wdata = {_GEN_8,_GEN_9};
  assign mem_ext_RW0_wmask = {_GEN_14,_GEN_15};
  assign _GEN_0 = mem_ext_RW0_rdata[7:0];
  assign _GEN_1 = mem_ext_RW0_rdata[15:8];
  assign _GEN_2 = mem_ext_RW0_rdata[23:16];
  assign _GEN_3 = mem_ext_RW0_rdata[31:24];
  assign _GEN_4 = $unsigned(RW0_wdata_3);
  assign _GEN_5 = $unsigned(RW0_wdata_2);
  assign _GEN_6 = $unsigned(RW0_wdata_1);
  assign _GEN_7 = $unsigned(RW0_wdata_0);
  assign _GEN_8 = {_GEN_4,_GEN_5};
  assign _GEN_9 = {_GEN_6,_GEN_7};
  assign _GEN_10 = $unsigned(RW0_wmask_3);
  assign _GEN_11 = $unsigned(RW0_wmask_2);
  assign _GEN_12 = $unsigned(RW0_wmask_1);
  assign _GEN_13 = $unsigned(RW0_wmask_0);
  assign _GEN_14 = {_GEN_10,_GEN_11};
  assign _GEN_15 = {_GEN_12,_GEN_13};
endmodule
